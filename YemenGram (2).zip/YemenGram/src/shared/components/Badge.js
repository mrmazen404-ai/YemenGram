import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Colors } from '../utils/colors';

export default function Badge({
  // ===== الأساسيات =====
  count,           // عدد الإشعارات
  dot = false,     // عرض نقطة فقط (بدون رقم)
  max = 99,        // الحد الأقصى للرقم (99+)

  // ===== التخصيص =====
  size = 'medium', // small, medium, large
  color = Colors.red,
  textColor = Colors.white,

  // ===== الحالات =====
  showZero = false, // إظهار 0 أم لا
  animated = false, // تأثير نبض

  // ===== التنسيق =====
  style,
  textStyle,
}) {
  // ===== حساب الرقم المعروض =====
  const displayCount = () => {
    if (dot) return null;
    if (!count || count === 0) {
      return showZero ? '0' : null;
    }
    return count > max ? `${max}+` : count;
  };

  const number = displayCount();

  // ===== إذا لم يكن هناك رقم ولا نقطة =====
  if (!number && !dot) return null;

  // ===== الحجم =====
  const getSize = () => {
    switch (size) {
      case 'small':
        return { padding: 4, fontSize: 10, minWidth: 18, height: 18 };
      case 'medium':
        return { padding: 6, fontSize: 12, minWidth: 22, height: 22 };
      case 'large':
        return { padding: 8, fontSize: 14, minWidth: 28, height: 28 };
      default:
        return { padding: 6, fontSize: 12, minWidth: 22, height: 22 };
    }
  };

  const sizeConfig = getSize();

  // ===== النقطة فقط =====
  if (dot) {
    return <View style={[styles.dot, { backgroundColor: color }, style]} />;
  }

  // ===== العدد =====
  return (
    <View
      style={[
        styles.badge,
        {
          backgroundColor: color,
          paddingHorizontal: sizeConfig.padding,
          minWidth: sizeConfig.minWidth,
          height: sizeConfig.height,
          borderRadius: sizeConfig.height / 2,
        },
        animated && styles.animated,
        style,
      ]}
    >
      <Text
        style={[
          styles.text,
          {
            fontSize: sizeConfig.fontSize,
            color: textColor,
          },
          textStyle,
        ]}
      >
        {number}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  // ===== Badge =====
  badge: {
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'flex-start',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },

  // ===== النص =====
  text: {
    fontFamily: 'Tajawal-Bold',
    textAlign: 'center',
    includeFontPadding: false,
    textShadowColor: 'rgba(0,0,0,0.1)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 2,
  },
  // ===== النقطة =====
  dot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    borderWidth: 1.5,
    borderColor: Colors.white,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
    elevation: 2,
  },
  // ===== تأثير النبض =====
  animated: {
    shadowColor: Colors.red,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
  },
});