// src/shared/utils/spacing.js
// =============================================
// نظام المسافات الموحد (Spacing System)
// مجموعة من الثوابت والدوال لإدارة المسافات في التطبيق
// =============================================

// =============================================
// 1. الثوابت الأساسية
// =============================================

/**
 * مقياس المسافات الأساسي (وحدة القياس)
 * جميع المسافات مبنية على مضاعفات هذه الوحدة
 */
export const SPACING_UNIT = 4;

/**
 * قائمة المسافات المتاحة
 */
export const SPACING = {
  /** 0px */
  0: 0,
  /** 2px */
  0.5: SPACING_UNIT * 0.5,
  /** 4px */
  1: SPACING_UNIT * 1,
  /** 6px */
  1.5: SPACING_UNIT * 1.5,
  /** 8px */
  2: SPACING_UNIT * 2,
  /** 10px */
  2.5: SPACING_UNIT * 2.5,
  /** 12px */
  3: SPACING_UNIT * 3,
  /** 14px */
  3.5: SPACING_UNIT * 3.5,
  /** 16px */
  4: SPACING_UNIT * 4,
  /** 20px */
  5: SPACING_UNIT * 5,
  /** 24px */
  6: SPACING_UNIT * 6,
  /** 28px */
  7: SPACING_UNIT * 7,
  /** 32px */
  8: SPACING_UNIT * 8,
  /** 36px */
  9: SPACING_UNIT * 9,
  /** 40px */
  10: SPACING_UNIT * 10,
  /** 48px */
  12: SPACING_UNIT * 12,
  /** 56px */
  14: SPACING_UNIT * 14,
  /** 64px */
  16: SPACING_UNIT * 16,
  /** 80px */
  20: SPACING_UNIT * 20,
  /** 96px */
  24: SPACING_UNIT * 24,
  /** 112px */
  28: SPACING_UNIT * 28,
  /** 128px */
  32: SPACING_UNIT * 32,
};

// =============================================
// 2. دوال إنشاء المسافات
// =============================================

/**
 * إنشاء كائن مسافات للـ padding
 * @param {number|Object} value - القيمة أو الكائن
 * @param {number} vertical - المسافة العمودية
 * @param {number} horizontal - المسافة الأفقية
 * @returns {Object}
 */
export const padding = (value, vertical, horizontal) => {
  if (typeof value === 'object') {
    return {
      paddingTop: value.top || 0,
      paddingBottom: value.bottom || 0,
      paddingLeft: value.left || 0,
      paddingRight: value.right || 0,
    };
  }

  if (vertical !== undefined && horizontal !== undefined) {
    return {
      paddingVertical: SPACING[vertical] || vertical,
      paddingHorizontal: SPACING[horizontal] || horizontal,
    };
  }

  const val = SPACING[value] !== undefined ? SPACING[value] : value;
  return { padding: val };
};

/**
 * إنشاء كائن مسافات للـ margin
 * @param {number|Object} value - القيمة أو الكائن
 * @param {number} vertical - المسافة العمودية
 * @param {number} horizontal - المسافة الأفقية
 * @returns {Object}
 */
export const margin = (value, vertical, horizontal) => {
  if (typeof value === 'object') {
    return {
      marginTop: value.top || 0,
      marginBottom: value.bottom || 0,
      marginLeft: value.left || 0,
      marginRight: value.right || 0,
    };
  }

  if (vertical !== undefined && horizontal !== undefined) {
    return {
      marginVertical: SPACING[vertical] || vertical,
      marginHorizontal: SPACING[horizontal] || horizontal,
    };
  }

  const val = SPACING[value] !== undefined ? SPACING[value] : value;
  return { margin: val };
};

// =============================================
// 3. دوال مساعدة
// =============================================

/**
 * الحصول على قيمة مسافة محددة
 * @param {number|string} value - المفتاح أو القيمة
 * @returns {number}
 */
export const getSpacing = (value) => {
  return SPACING[value] !== undefined ? SPACING[value] : value;
};

/**
 * إنشاء مسافة بنمط محدد
 * @param {number} top - المسافة العلوية
 * @param {number} right - المسافة اليمنى
 * @param {number} bottom - المسافة السفلية
 * @param {number} left - المسافة اليسرى
 * @returns {Object}
 */
export const createSpacing = (top, right, bottom, left) => {
  const result = {};

  if (top !== undefined) result.top = SPACING[top] || top;
  if (right !== undefined) result.right = SPACING[right] || right;
  if (bottom !== undefined) result.bottom = SPACING[bottom] || bottom;
  if (left !== undefined) result.left = SPACING[left] || left;

  return result;
};

/**
 * إنشاء مسافة أفقية
 * @param {number} left - المسافة اليسرى
 * @param {number} right - المسافة اليمنى
 * @returns {Object}
 */
export const horizontalSpacing = (left, right) => {
  return {
    marginLeft: SPACING[left] || left,
    marginRight: SPACING[right] || right,
  };
};

/**
 * إنشاء مسافة عمودية
 * @param {number} top - المسافة العلوية
 * @param {number} bottom - المسافة السفلية
 * @returns {Object}
 */
export const verticalSpacing = (top, bottom) => {
  return {
    marginTop: SPACING[top] || top,
    marginBottom: SPACING[bottom] || bottom,
  };
};

// =============================================
// 4. دوال التباعد بين العناصر
// =============================================

/**
 * إنشاء مسافة بين العناصر (Gap)
 * @param {number} value - قيمة المسافة
 * @param {string} direction - الاتجاه (row, column)
 * @returns {Object}
 */
export const gap = (value, direction = 'column') => {
  const val = SPACING[value] !== undefined ? SPACING[value] : value;

  if (direction === 'row') {
    return { gap: val };
  }

  return { gap: val };
};

/**
 * إنشاء مسافة بين العناصر في صف (Row)
 * @param {number} value - قيمة المسافة
 * @returns {Object}
 */
export const rowGap = (value) => gap(value, 'row');

/**
 * إنشاء مسافة بين العناصر في عمود (Column)
 * @param {number} value - قيمة المسافة
 * @returns {Object}
 */
export const columnGap = (value) => gap(value, 'column');

// =============================================
// 5. دوال الـ Padding المسبقة
// =============================================

/**
 * Padding داخلي
 */
export const p = (value) => padding(value);

/**
 * Padding أفقي
 */
export const px = (value) => ({
  paddingLeft: SPACING[value] || value,
  paddingRight: SPACING[value] || value,
});

/**
 * Padding عمودي
 */
export const py = (value) => ({
  paddingTop: SPACING[value] || value,
  paddingBottom: SPACING[value] || value,
});

/**
 * Padding علوي
 */
export const pt = (value) => ({ paddingTop: SPACING[value] || value });

/**
 * Padding سفلي
 */
export const pb = (value) => ({ paddingBottom: SPACING[value] || value });

/**
 * Padding يسار
 */
export const pl = (value) => ({ paddingLeft: SPACING[value] || value });

/**
 * Padding يمين
 */
export const pr = (value) => ({ paddingRight: SPACING[value] || value });

// =============================================
// 6. دوال الـ Margin المسبقة
// =============================================

/**
 * Margin خارجي
 */
export const m = (value) => margin(value);

/**
 * Margin أفقي
 */
export const mx = (value) => ({
  marginLeft: SPACING[value] || value,
  marginRight: SPACING[value] || value,
});

/**
 * Margin عمودي
 */
export const my = (value) => ({
  marginTop: SPACING[value] || value,
  marginBottom: SPACING[value] || value,
});

/**
 * Margin علوي
 */
export const mt = (value) => ({ marginTop: SPACING[value] || value });

/**
 * Margin سفلي
 */
export const mb = (value) => ({ marginBottom: SPACING[value] || value });

/**
 * Margin يسار
 */
export const ml = (value) => ({ marginLeft: SPACING[value] || value });

/**
 * Margin يمين
 */
export const mr = (value) => ({ marginRight: SPACING[value] || value });

// =============================================
// 7. كائن المسافات الرئيسي
// =============================================

export const spacing = {
  // الثوابت
  unit: SPACING_UNIT,
  values: SPACING,

  // دوال إنشاء المسافات
  padding,
  margin,
  get: getSpacing,
  create: createSpacing,
  horizontal: horizontalSpacing,
  vertical: verticalSpacing,

  // دوال الـ Gap
  gap,
  rowGap,
  columnGap,

  // دوال الـ Padding
  p,
  px,
  py,
  pt,
  pb,
  pl,
  pr,

  // دوال الـ Margin
  m,
  mx,
  my,
  mt,
  mb,
  ml,
  mr,
};

export default spacing;