// src/models/InvoiceItem.js
// =============================================
// نموذج عنصر الفاتورة (Invoice Item Model)
// المسؤول عن تسجيل كل منتج في الفاتورة
// =============================================

import { Model } from '@nozbe/watermelondb';
import { field } from '@nozbe/watermelondb/decorators';
import { Q } from '@nozbe/watermelondb';

export default class InvoiceItem extends Model {
  // ===== 1. اسم الجدول =====
  static table = 'invoice_items';

  // ===== 2. الحقول الأساسية =====

  // معرف المستخدم (لفصل البيانات)
  @field('user_id') userId;

  // معرف الفاتورة المرتبطة
  @field('invoice_id') invoiceId;

  // معرف المنتج
  @field('product_id') productId;

  // وصف العنصر (يمكن استخدامه إذا لم يكن هناك منتج محدد)
  @field('description') description;

  // الكمية
  @field('quantity') quantity;

  // سعر الوحدة
  @field('unit_price') unitPrice;

  // المجموع الفرعي (الكمية × سعر الوحدة)
  @field('total') total;

  // ===== 3. العلاقات =====

  static associations = {
    // كل عنصر ينتمي إلى فاتورة واحدة
    invoice: { type: 'belongs_to', key: 'invoice_id' },
    // كل عنصر قد ينتمي إلى منتج واحد (أو لا)
    product: { type: 'belongs_to', key: 'product_id' },
  };

  // ===== 4. دوال مساعدة =====

  /**
   * جلب الفاتورة المرتبطة
   * @returns {Promise<Invoice>}
   */
  async getInvoice() {
    return this.collections.get('invoices').find(this.invoiceId);
  }

  /**
   * جلب المنتج المرتبط (إن وجد)
   * @returns {Promise<Product|null>}
   */
  async getProduct() {
    if (!this.productId) return null;
    return this.collections.get('products').find(this.productId);
  }

  /**
   * الحصول على اسم المنتج
   * @returns {Promise<string>}
   */
  async getProductName() {
    if (this.description) return this.description;
    const product = await this.getProduct();
    return product ? product.name : 'منتج غير معروف';
  }

  /**
   * الحصول على رمز المنتج
   * @returns {Promise<string>}
   */
  async getProductCode() {
    const product = await this.getProduct();
    return product ? product.code : '???';
  }

  /**
   * الحصول على اسم المنتج مع الرمز
   * @returns {Promise<string>}
   */
  async getProductDisplayName() {
    const product = await this.getProduct();
    return product ? `${product.code} - ${product.name}` : this.description || 'منتج غير معروف';
  }

  /**
   * التحقق من صحة العنصر (الكمية والسعر موجبين)
   * @returns {boolean}
   */
  isValid() {
    return (this.quantity || 0) > 0 && (this.unitPrice || 0) >= 0;
  }

  /**
   * حساب المجموع (كمية × سعر)
   * @returns {number}
   */
  calculateTotal() {
    return (this.quantity || 0) * (this.unitPrice || 0);
  }

  /**
   * تحديث المجموع تلقائياً (يُستخدم عند تغيير الكمية أو السعر)
   */
  async recalculateTotal() {
    const newTotal = this.calculateTotal();
    await this.write(() => {
      this.total = newTotal;
    });
  }

  /**
   * الحصول على سعر الوحدة المنسق
   * @param {string} currency
   * @returns {string}
   */
  getFormattedUnitPrice(currency = 'ريال') {
    return `${(this.unitPrice || 0).toLocaleString()} ${currency}`;
  }

  /**
   * الحصول على المجموع المنسق
   * @param {string} currency
   * @returns {string}
   */
  getFormattedTotal(currency = 'ريال') {
    return `${(this.total || 0).toLocaleString()} ${currency}`;
  }

  // ===== 5. دوال ثابتة =====

  /**
   * حساب إجمالي مجموعة عناصر
   * @param {InvoiceItem[]} items
   * @returns {number}
   */
  static sumTotal(items) {
    return items.reduce((sum, item) => sum + (item.total || 0), 0);
  }

  /**
   * حساب إجمالي الكميات في مجموعة
   * @param {InvoiceItem[]} items
   * @returns {number}
   */
  static sumQuantity(items) {
    return items.reduce((sum, item) => sum + (item.quantity || 0), 0);
  }

  /**
   * حساب متوسط سعر الوحدة (المجموع / الكمية)
   * @param {InvoiceItem[]} items
   * @returns {number}
   */
  static averageUnitPrice(items) {
    const total = this.sumTotal(items);
    const quantity = this.sumQuantity(items);
    if (quantity === 0) return 0;
    return total / quantity;
  }

  /**
   * تجميع العناصر حسب المنتج
   * @param {InvoiceItem[]} items
   * @returns {Object}
   */
  static groupByProduct(items) {
    const groups = {};
    for (const item of items) {
      const key = item.productId || 'no-product';
      if (!groups[key]) {
        groups[key] = [];
      }
      groups[key].push(item);
    }
    return groups;
  }

  /**
   * إنشاء عناصر الفاتورة دفعة واحدة
   * @param {Database} database
   * @param {string} invoiceId
   * @param {string} userId
   * @param {Array} itemsData
   * @returns {Promise<InvoiceItem[]>}
   */
  static async createBatch(database, invoiceId, userId, itemsData) {
    const createdItems = [];

    await database.write(async () => {
      for (const data of itemsData) {
        const item = await database.get('invoice_items').create(item => {
          item.userId = userId;
          item.invoiceId = invoiceId;
          item.productId = data.productId || null;
          item.description = data.description || '';
          item.quantity = data.quantity || 1;
          item.unitPrice = data.unitPrice || 0;
          item.total = (data.quantity || 1) * (data.unitPrice || 0);
        });
        createdItems.push(item);
      }
    });

    return createdItems;
  }

  /**
   * تحديث كميات المخزون بناءً على عناصر الفاتورة
   * @param {InvoiceItem[]} items
   * @param {string} operation - 'add' or 'deduct'
   * @param {Database} database
   * @returns {Promise<void>}
   */
  static async updateInventory(items, operation, database) {
    await database.write(async () => {
      for (const item of items) {
        if (!item.productId) continue;

        const product = await database.get('products').find(item.productId);
        if (!product) continue;

        const quantity = item.quantity || 0;

        if (operation === 'add') {
          await product.addStock(quantity);
        } else if (operation === 'deduct') {
          await product.deductStock(quantity);
        }
      }
    });
  }
}