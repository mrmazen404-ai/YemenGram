// src/modules/auth/screens/PIN/PinChangeDialog.js
// واجهة تغيير الرمز السري (Sleek Luxurious Edition)

import React, { useState, useRef, useEffect, memo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Modal,
  Animated,
  Dimensions,
  Platform,
  Vibration,
  StatusBar,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import { Colors } from '../../../../shared/utils/colors';
import { SecurityManager } from '../../../../shared/utils/security';
import { useAuth } from '../../../../shared/contexts/AuthContext';
import Loading from '../../../../shared/components/Loading';

const { width, height } = Dimensions.get('window');
const PIN_LENGTH = 6;
const MAX_ATTEMPTS = 3;

const PinChangeDialog = memo(({ visible, onClose, onDone }) => {
  const { changePIN, verifyPIN } = useAuth();

  // ===== State =====
  const [step, setStep] = useState('verify'); // 'verify', 'new', 'confirm'
  const [pin, setPin] = useState('');
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [verifiedOldPin, setVerifiedOldPin] = useState(''); // ✅ حفظ الرمز القديم للعملية النهائية
  const [error, setError] = useState({ active: false, message: '' });
  const [loading, setLoading] = useState(false);
  const [attempts, setAttempts] = useState(0);

  // ===== Animations =====
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(height * 0.05)).current;
  const shakeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (visible) animateIn();
    else resetState();
  }, [visible]);

  const animateIn = () => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 300, useNativeDriver: true }),
      Animated.spring(slideAnim, { toValue: 0, tension: 80, friction: 12, useNativeDriver: true }),
    ]).start();
  };

  const resetState = () => {
    setStep('verify');
    setPin('');
    setNewPin('');
    setConfirmPin('');
    setVerifiedOldPin('');
    setError({ active: false, message: '' });
    setLoading(false);
    setAttempts(0);
  };

  const triggerHaptic = (type = 'selection') => {
    if (Platform.OS !== 'web') {
      if (type === 'error') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      else if (type === 'success') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      else Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  const doShake = () => {
    triggerHaptic('error');
    Animated.sequence([
      Animated.timing(shakeAnim, { toValue: 12, duration: 40, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -12, duration: 40, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 0, duration: 40, useNativeDriver: true }),
    ]).start();
  };

  const handleKeyPress = async (num) => {
    if (loading) return;
    triggerHaptic();

    if (num === 'delete') {
      if (step === 'verify') setPin(p => p.slice(0, -1));
      else if (step === 'new') setNewPin(p => p.slice(0, -1));
      else setConfirmPin(p => p.slice(0, -1));
      setError({ active: false, message: '' });
      return;
    }

    if (step === 'verify') {
      const p = pin + num;
      if (p.length <= PIN_LENGTH) setPin(p);
      if (p.length === PIN_LENGTH) handleVerifyCurrent(p);
    } else if (step === 'new') {
      const p = newPin + num;
      if (p.length <= PIN_LENGTH) setNewPin(p);
      if (p.length === PIN_LENGTH) handleNewPin(p);
    } else {
      const p = confirmPin + num;
      if (p.length <= PIN_LENGTH) setConfirmPin(p);
      if (p.length === PIN_LENGTH) handleConfirmPin(p);
    }
  };

  const handleVerifyCurrent = async (p) => {
    setLoading(true);
    try {
      const isValid = await verifyPIN(p);
      if (isValid) {
        triggerHaptic('success');
        setVerifiedOldPin(p); // ✅ حفظ الرمز القديم بنجاح
        setTimeout(() => {
          setStep('new');
          setPin('');
          setError({ active: false, message: '' });
        }, 200);
      } else {
        const newAttempts = attempts + 1;
        setAttempts(newAttempts);
        setPin('');
        doShake();
        setError({ active: true, message: `الرمز غير صحيح (${MAX_ATTEMPTS - newAttempts} محاولات)` });
      }
    } catch (e) {
      setError({ active: true, message: 'فشل التحقق' });
    } finally {
      setLoading(false);
    }
  };

  const handleNewPin = (p) => {
    if (SecurityManager.validatePinStrength(p)) {
      triggerHaptic('success');
      setTimeout(() => setStep('confirm'), 250);
    } else {
      setNewPin('');
      doShake();
      setError({ active: true, message: 'رمز ضعيف، جرب رمزاً أكثر تعقيداً' });
    }
  };

  const handleConfirmPin = async (p) => {
    if (p === newPin) {
      setLoading(true);
      try {
        // ✅ استخدام الرمز القديم الذي تم حفظه (verifiedOldPin)
        await changePIN(verifiedOldPin, p);
        triggerHaptic('success');
        if (onDone) onDone();
      } catch (e) {
        doShake();
        setError({ active: true, message: e.message || 'فشل الحفظ' });
      } finally {
        setLoading(false);
      }
    } else {
      setConfirmPin('');
      doShake();
      setError({ active: true, message: 'الرمزان غير متطابقين' });
    }
  };

  const renderDot = (index) => {
    const currentLen = step === 'verify' ? pin.length : step === 'new' ? newPin.length : confirmPin.length;
    return (
      <View key={index} style={[styles.dot, currentLen > index && styles.dotFilled, error.active && currentLen > index && styles.dotError]} />
    );
  };

  return (
    <Modal visible={visible} transparent animationType="none" statusBarTranslucent>
      <View style={styles.overlay}>
        <Animated.View style={[styles.modalContainer, { opacity: fadeAnim, transform: [{ translateY: slideAnim }, { translateX: shakeAnim }] }]}>
          {/* Header */}
          <View style={styles.header}>
            <TouchableOpacity onPress={onClose} style={styles.closeBtn} activeOpacity={0.6}>
              <Ionicons name="close" size={18} color={Colors.gray} />
            </TouchableOpacity>
            <Text style={styles.headerTitle}>تغيير الرمز</Text>
            <View style={{ width: 32 }} />
          </View>

          <View style={styles.content}>
            <View style={styles.iconCircle}>
              <Ionicons name={step === 'verify' ? "shield-checkmark" : "key-outline"} size={24} color={Colors.navy} />
            </View>

            <Text style={styles.title}>
              {step === 'verify' ? 'تأكيد الرمز الحالي' : step === 'new' ? 'رمز جديد' : 'تأكيد الرمز'}
            </Text>

            <View style={styles.dotsRow}>
              {Array.from({ length: PIN_LENGTH }).map((_, i) => renderDot(i))}
            </View>

            <View style={styles.errorBox}>
               {error.active && <Text style={styles.errorText}>{error.message}</Text>}
            </View>

            <View style={styles.keypad}>
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, '', 0, 'delete'].map((k, i) => (
                <TouchableOpacity
                  key={i}
                  style={[styles.key, k === 'delete' && styles.keyDelete, k === '' && styles.keyEmpty]}
                  onPress={() => k !== '' && handleKeyPress(k)}
                  disabled={k === '' || (attempts >= MAX_ATTEMPTS && step === 'verify')}
                  activeOpacity={0.4}
                >
                  {k === 'delete' ? (
                    <Ionicons name="backspace-outline" size={20} color={Colors.dark} />
                  ) : (
                    <Text style={styles.keyText}>{k}</Text>
                  )}
                </TouchableOpacity>
              ))}
            </View>
          </View>

          <View style={styles.footer}>
            <Text style={styles.footerText}>🛡️ حماية اليمن جرام المشفرة</Text>
          </View>
        </Animated.View>
      </View>
      {loading && <Loading visible={true} />}
    </Modal>
  );
});

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
  modalContainer: { width: width * 0.85, maxWidth: 340, backgroundColor: '#FFFFFF', borderRadius: 28, padding: 18, shadowColor: '#000', shadowOffset: { width: 0, height: 8 }, shadowOpacity: 0.15, shadowRadius: 12, elevation: 15 },
  header: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  closeBtn: { width: 32, height: 32, borderRadius: 10, backgroundColor: '#F8FAFC', justifyContent: 'center', alignItems: 'center' },
  headerTitle: { fontSize: 13, fontFamily: 'Tajawal-Bold', color: Colors.gray },
  content: { alignItems: 'center' },
  iconCircle: { width: 54, height: 54, borderRadius: 16, backgroundColor: '#F1F5F9', justifyContent: 'center', alignItems: 'center', marginBottom: 8 },
  title: { fontSize: 18, fontFamily: 'Tajawal-Bold', color: Colors.dark, marginBottom: 15 },
  dotsRow: { flexDirection: 'row-reverse', gap: 10, marginBottom: 8 },
  dot: { width: 12, height: 12, borderRadius: 6, borderWidth: 1.5, borderColor: '#E2E8F0' },
  dotFilled: { backgroundColor: Colors.navy, borderColor: Colors.navy },
  dotError: { backgroundColor: Colors.red, borderColor: Colors.red },
  errorBox: { height: 20, justifyContent: 'center', marginBottom: 10 },
  errorText: { color: Colors.red, fontSize: 10, fontFamily: 'Tajawal-Bold' },
  keypad: { width: '100%', flexDirection: 'row-reverse', flexWrap: 'wrap', justifyContent: 'center', gap: 10 },
  key: { width: '28%', height: 54, borderRadius: 14, backgroundColor: '#F8FAFC', justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: '#F1F5F9' },
  keyEmpty: { backgroundColor: 'transparent', borderWidth: 0 },
  keyDelete: { backgroundColor: '#FFF5F5', borderColor: '#FEE2E2' },
  keyText: { fontSize: 22, fontFamily: 'Tajawal-Bold', color: Colors.navy },
  footer: { marginTop: 15, alignItems: 'center', borderTopWidth: 1, borderTopColor: '#F1F5F9', paddingTop: 10 },
  footerText: { fontSize: 9, fontFamily: 'Tajawal-Medium', color: Colors.placeholder },
});

export default PinChangeDialog;
