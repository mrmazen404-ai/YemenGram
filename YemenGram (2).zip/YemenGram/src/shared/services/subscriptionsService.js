// src/shared/services/subscriptionsService.js
// =============================================
// خدمة الاشتراكات (Subscriptions Service)
// المسؤولة عن إدارة اشتراكات المستخدمين والخطط
// =============================================

import { LocalDB } from '../../modules/database/localDB';
import { Logger } from '../utils/logger';
import { SUBSCRIPTION } from '../utils/constants';
import { notificationService } from './notificationService';

// =============================================
// 1. الثوابت
// =============================================

const PLANS = SUBSCRIPTION.PLANS || {
  FREE: 'free',
  TRIAL: 'trial',
  MONTHLY: 'monthly',
  ANNUAL: 'annual',
  LIFETIME: 'lifetime',
};

const PLANS_AR = SUBSCRIPTION.PLANS_AR || {
  free: 'مجاني',
  trial: 'تجريبي',
  monthly: 'شهري',
  annual: 'سنوي',
  lifetime: 'مدى الحياة',
};

const PLANS_PRICES = SUBSCRIPTION.PLANS_PRICES || {
  free: 0,
  trial: 0,
  monthly: 3000,
  annual: 30000,
  lifetime: 100000,
};

const PLANS_DURATIONS = SUBSCRIPTION.PLANS_DURATIONS || {
  free: 0,
  trial: 60,
  monthly: 30,
  annual: 365,
  lifetime: 99999,
};

const PLANS_USERS = SUBSCRIPTION.PLANS_USERS || {
  free: 1,
  trial: 5,
  monthly: 3,
  annual: 10,
  lifetime: Infinity,
};

const PLANS_REPORTS = SUBSCRIPTION.PLANS_REPORTS || {
  free: 10,
  trial: Infinity,
  monthly: Infinity,
  annual: Infinity,
  lifetime: Infinity,
};

const PLANS_COLORS = SUBSCRIPTION.PLANS_COLORS || {
  free: '#6B7280',
  trial: '#2196F3',
  monthly: '#F39C12',
  annual: '#27AE60',
  lifetime: '#D4A853',
};

const DEFAULT_PLAN = SUBSCRIPTION.DEFAULT_PLAN || 'free';

// =============================================
// 2. دوال التحقق من الاشتراكات
// =============================================

/**
 * التحقق من صحة الاشتراك
 * @param {Object} subscription - بيانات الاشتراك
 * @param {number} currentDate - التاريخ الحالي
 * @returns {boolean}
 */
export const isSubscriptionValid = (subscription, currentDate = Date.now()) => {
  if (!subscription) return false;
  if (!['TRIAL_ACTIVE', 'ACTIVE_FULL'].includes(subscription.status)) return false;
  if (subscription.plan === PLANS.LIFETIME) return true;
  if (!subscription.end_date) return false;
  return subscription.end_date > currentDate;
};

/**
 * التحقق من انتهاء الاشتراك
 * @param {Object} subscription - بيانات الاشتراك
 * @param {number} currentDate - التاريخ الحالي
 * @returns {boolean}
 */
export const isSubscriptionExpired = (subscription, currentDate = Date.now()) => {
  if (!subscription) return true;
  if (subscription.plan === PLANS.LIFETIME) return false;
  if (!subscription.end_date) return true;
  return subscription.end_date <= currentDate;
};

/**
 * التحقق من اقتراب انتهاء الاشتراك
 * @param {Object} subscription - بيانات الاشتراك
 * @param {number} daysThreshold - عدد الأيام قبل الانتهاء
 * @param {number} currentDate - التاريخ الحالي
 * @returns {boolean}
 */
export const isSubscriptionExpiringSoon = (subscription, daysThreshold = 7, currentDate = Date.now()) => {
  if (!subscription) return false;
  if (subscription.plan === PLANS.LIFETIME) return false;
  if (!subscription.end_date) return false;
  const daysRemaining = getDaysRemaining(subscription, currentDate);
  return daysRemaining > 0 && daysRemaining <= daysThreshold;
};

/**
 * الحصول على عدد الأيام المتبقية
 * @param {Object} subscription - بيانات الاشتراك
 * @param {number} currentDate - التاريخ الحالي
 * @returns {number}
 */
export const getDaysRemaining = (subscription, currentDate = Date.now()) => {
  if (!subscription) return 0;
  if (subscription.plan === PLANS.LIFETIME) return 99999;
  if (!subscription.end_date) return 0;
  const diff = subscription.end_date - currentDate;
  return Math.max(0, Math.ceil(diff / (1000 * 60 * 60 * 24)));
};

/**
 * الحصول على عدد المستخدمين المسموح بهم
 * @param {string} plan - اسم الخطة
 * @returns {number}
 */
export const getMaxUsers = (plan) => {
  return PLANS_USERS[plan] || PLANS_USERS[DEFAULT_PLAN];
};

/**
 * الحصول على عدد التقارير المسموح بها
 * @param {string} plan - اسم الخطة
 * @returns {number}
 */
export const getMaxReports = (plan) => {
  return PLANS_REPORTS[plan] || PLANS_REPORTS[DEFAULT_PLAN];
};

// =============================================
// 3. دوال إدارة الاشتراكات
// =============================================

/**
 * إنشاء اشتراك جديد
 * @param {string} userId - معرف المستخدم
 * @param {string} plan - اسم الخطة
 * @param {Object} options - خيارات إضافية
 * @returns {Promise<Object>}
 */
export const createSubscription = async (userId, plan = DEFAULT_PLAN, options = {}) => {
  const { duration = null, startDate = Date.now() } = options;

  try {
    // تعطيل الاشتراكات السابقة
    await LocalDB.execute(
      'UPDATE subscriptions SET status = 'CANCELLED', updated_at = ? WHERE user_id = ? AND status IN ('TRIAL_ACTIVE', 'ACTIVE_FULL')',
      [Date.now(), userId]
    );

    const durationDays = duration || PLANS_DURATIONS[plan] || 0;
    const endDate = durationDays > 0 ? startDate + (durationDays * 24 * 60 * 60 * 1000) : null;

    const subscriptionId = `sub_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
    await LocalDB.execute(
      `INSERT INTO subscriptions
       (id, user_id, status, plan, start_date, end_date, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        subscriptionId, userId, plan === 'trial' ? 'TRIAL_ACTIVE' : 'ACTIVE_FULL', plan, startDate, endDate, Date.now(), Date.now(),
      ]
    );

    // تسجيل في Audit Log
    await LocalDB.addAuditLog('subscription_created', 'subscriptions', subscriptionId, {
      user_id: userId,
      plan,
      end_date: endDate,
    });

    // إرسال إشعار
    await notificationService.notifySuccess(
      userId,
      'تم تفعيل الاشتراك',
      `تم تفعيل خطة ${PLANS_AR[plan] || plan} بنجاح`
    );

    Logger.info(`✅ [Subscriptions] تم إنشاء اشتراك ${plan} للمستخدم ${userId}`);

    return {
      success: true,
      id: subscriptionId,
      userId,
      plan,
      startDate,
      endDate,
      isActive: true,
    };
  } catch (error) {
    Logger.error('❌ [Subscriptions] فشل إنشاء الاشتراك:', error);
    throw error;
  }
};

/**
 * تحديث اشتراك
 * @param {number} subscriptionId - معرف الاشتراك
 * @param {Object} data - بيانات التحديث
 * @returns {Promise<boolean>}
 */
export const updateSubscription = async (subscriptionId, data) => {
  try {
    const updates = [];
    const params = [];

    if (data.plan !== undefined) {
      updates.push('plan = ?');
      params.push(data.plan);
    }

    if (data.end_date !== undefined) {
      updates.push('end_date = ?');
      params.push(data.end_date);
    }

    if (data.status !== undefined) {
      updates.push('status = ?');
      params.push(data.status);
    }

    if (updates.length === 0) return true;

    updates.push('updated_at = ?');
    params.push(Date.now());

    params.push(subscriptionId);

    await LocalDB.execute(
      `UPDATE subscriptions SET ${updates.join(', ')} WHERE id = ?`,
      params
    );

    // تسجيل في Audit Log
    await LocalDB.addAuditLog('subscription_updated', 'subscriptions', subscriptionId, data);

    Logger.info(`✅ [Subscriptions] تم تحديث الاشتراك ${subscriptionId}`);
    return true;
  } catch (error) {
    Logger.error('❌ [Subscriptions] فشل تحديث الاشتراك:', error);
    return false;
  }
};

/**
 * جلب اشتراك المستخدم النشط
 * @param {string} userId - معرف المستخدم
 * @returns {Promise<Object|null>}
 */
export const getActiveSubscription = async (userId) => {
  try {
    return await LocalDB.queryOne(
      `SELECT * FROM subscriptions WHERE user_id = ? AND status IN ('TRIAL_ACTIVE', 'ACTIVE_FULL') ORDER BY created_at DESC LIMIT 1`,
      [userId]
    );
  } catch (error) {
    Logger.error('❌ [Subscriptions] فشل جلب الاشتراك النشط:', error);
    return null;
  }
};

/**
 * جلب جميع اشتراكات المستخدم
 * @param {string} userId - معرف المستخدم
 * @param {number} limit - الحد الأقصى
 * @returns {Promise<Array>}
 */
export const getUserSubscriptions = async (userId, limit = 50) => {
  try {
    return await LocalDB.query(
      'SELECT * FROM subscriptions WHERE user_id = ? ORDER BY created_at DESC LIMIT ?',
      [userId, limit]
    );
  } catch (error) {
    Logger.error('❌ [Subscriptions] فشل جلب اشتراكات المستخدم:', error);
    return [];
  }
};

// =============================================
// 4. دوال تمديد وترقية الاشتراكات
// =============================================

/**
 * تمديد اشتراك
 * @param {string} userId - معرف المستخدم
 * @param {number} extraDays - عدد الأيام الإضافية
 * @returns {Promise<boolean>}
 */
export const extendSubscription = async (userId, extraDays) => {
  try {
    const current = await getActiveSubscription(userId);
    if (!current) {
      throw new Error('لا يوجد اشتراك نشط');
    }

    const newEndDate = current.end_date
      ? current.end_date + (extraDays * 24 * 60 * 60 * 1000)
      : Date.now() + (extraDays * 24 * 60 * 60 * 1000);

    await updateSubscription(current.id, {
      end_date: newEndDate,
      status: 'ACTIVE_FULL',
    });

    // تسجيل في Audit Log
    await LocalDB.addAuditLog('subscription_extended', 'subscriptions', current.id, {
      user_id: userId,
      extra_days: extraDays,
      new_end_date: newEndDate,
    });

    // إرسال إشعار
    await notificationService.notifySuccess(
      userId,
      'تم تمديد الاشتراك',
      `تم تمديد اشتراكك ${extraDays} يوماً إضافياً`
    );

    Logger.info(`✅ [Subscriptions] تم تمديد اشتراك المستخدم ${userId} بـ ${extraDays} يوم`);
    return true;
  } catch (error) {
    Logger.error('❌ [Subscriptions] فشل تمديد الاشتراك:', error);
    throw error;
  }
};

/**
 * ترقية اشتراك
 * @param {string} userId - معرف المستخدم
 * @param {string} newPlan - الخطة الجديدة
 * @param {Object} options - خيارات إضافية
 * @returns {Promise<Object>}
 */
export const upgradeSubscription = async (userId, newPlan, options = {}) => {
  try {
    const current = await getActiveSubscription(userId);

    // تعطيل الاشتراك الحالي
    if (current) {
      await updateSubscription(current.id, { status: 'CANCELLED' });
    }

    // إنشاء اشتراك جديد
    const result = await createSubscription(userId, newPlan, {
      duration: options.duration || PLANS_DURATIONS[newPlan],
      startDate: Date.now(),
    });

    // تسجيل في Audit Log
    await LocalDB.addAuditLog('subscription_upgraded', 'subscriptions', result.id, {
      user_id: userId,
      old_plan: current?.plan || 'none',
      new_plan: newPlan,
    });

    // إرسال إشعار
    await notificationService.notifySuccess(
      userId,
      'تم ترقية الاشتراك',
      `تم ترقية اشتراكك إلى خطة ${PLANS_AR[newPlan] || newPlan}`
    );

    Logger.info(`✅ [Subscriptions] تم ترقية اشتراك المستخدم ${userId} إلى ${newPlan}`);
    return result;
  } catch (error) {
    Logger.error('❌ [Subscriptions] فشل ترقية الاشتراك:', error);
    throw error;
  }
};

/**
 * إلغاء اشتراك
 * @param {string} userId - معرف المستخدم
 * @param {boolean} revertToFree - العودة إلى الخطة المجانية
 * @returns {Promise<boolean>}
 */
export const cancelSubscription = async (userId, revertToFree = true) => {
  try {
    const current = await getActiveSubscription(userId);
    if (!current) {
      throw new Error('لا يوجد اشتراك نشط');
    }

    await updateSubscription(current.id, { status: 'CANCELLED' });

    if (revertToFree) {
      await createSubscription(userId, PLANS.FREE);
    }

    // تسجيل في Audit Log
    await LocalDB.addAuditLog('subscription_cancelled', 'subscriptions', current.id, {
      user_id: userId,
      plan: current.plan,
      revert_to_free: revertToFree,
    });

    // إرسال إشعار
    await notificationService.notifyWarning(
      userId,
      'تم إلغاء الاشتراك',
      revertToFree ? 'تم إلغاء اشتراكك والعودة إلى الخطة المجانية' : 'تم إلغاء اشتراكك'
    );

    Logger.info(`✅ [Subscriptions] تم إلغاء اشتراك المستخدم ${userId}`);
    return true;
  } catch (error) {
    Logger.error('❌ [Subscriptions] فشل إلغاء الاشتراك:', error);
    throw error;
  }
};

// =============================================
// 5. دوال معلومات الخطط
// =============================================

/**
 * الحصول على معلومات الخطة
 * @param {string} plan - اسم الخطة
 * @returns {Object}
 */
export const getPlanInfo = (plan) => {
  return {
    name: plan,
    nameAr: PLANS_AR[plan] || plan,
    price: PLANS_PRICES[plan] || 0,
    duration: PLANS_DURATIONS[plan] || 0,
    maxUsers: PLANS_USERS[plan] || 1,
    maxReports: PLANS_REPORTS[plan] || 10,
    color: PLANS_COLORS[plan] || '#6B7280',
    isFree: plan === PLANS.FREE,
    isTrial: plan === PLANS.TRIAL,
    isPaid: plan !== PLANS.FREE && plan !== PLANS.TRIAL,
    isLifetime: plan === PLANS.LIFETIME,
  };
};

/**
 * الحصول على جميع الخطط
 * @returns {Array}
 */
export const getAllPlans = () => {
  return Object.keys(PLANS).map(key => ({
    key: key,
    ...getPlanInfo(key),
  }));
};

/**
 * التحقق من أن الخطة مدفوعة
 * @param {string} plan - اسم الخطة
 * @returns {boolean}
 */
export const isPaidPlan = (plan) => {
  return plan !== PLANS.FREE && plan !== PLANS.TRIAL;
};

/**
 * التحقق من أن الخطة مجانية
 * @param {string} plan - اسم الخطة
 * @returns {boolean}
 */
export const isFreePlan = (plan) => {
  return plan === PLANS.FREE;
};

/**
 * التحقق من أن الخطة تجريبية
 * @param {string} plan - اسم الخطة
 * @returns {boolean}
 */
export const isTrialPlan = (plan) => {
  return plan === PLANS.TRIAL;
};

// =============================================
// 6. دوال المزامنة مع الخادم
// =============================================

/**
 * مزامنة الاشتراكات مع الخادم
 * @param {string} userId - معرف المستخدم
 * @returns {Promise<Object>}
 */
export const syncSubscriptions = async (userId) => {
  try {
    // جلب الاشتراكات من الخادم (محاكاة)
    // في الواقع سيتم جلبها من Supabase
    const remoteSubscriptions = await api.get(`/subscriptions?user_id=eq.${userId}`);

    for (const sub of remoteSubscriptions) {
      const local = await LocalDB.queryOne(
        'SELECT id FROM subscriptions WHERE id = ?',
        [sub.id]
      );

      if (local) {
        await updateSubscription(local.id, sub);
      } else {
        await LocalDB.execute(
          `INSERT INTO subscriptions
           (id, user_id, status, plan, start_date, end_date, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            sub.id,
            sub.user_id,
            sub.status || 'CANCELLED',
            sub.plan,
            sub.start_date,
            sub.end_date,
            sub.created_at,
            sub.updated_at,
          ]
        );
      }
    }

    Logger.info(`✅ [Subscriptions] تم مزامنة ${remoteSubscriptions.length} اشتراك`);
    return { success: true, count: remoteSubscriptions.length };
  } catch (error) {
    Logger.error('❌ [Subscriptions] فشل مزامنة الاشتراكات:', error);
    return { success: false, error: error.message };
  }
};

// =============================================
// 7. دوال مساعدة إضافية
// =============================================

/**
 * الحصول على سعر الخطة بالتنسيق
 * @param {string} plan - اسم الخطة
 * @param {string} currency - العملة
 * @returns {string}
 */
export const getPlanPriceFormatted = (plan, currency = 'YER') => {
  const price = PLANS_PRICES[plan] || 0;
  if (price === 0) return 'مجاني';
  return `${price.toLocaleString()} ${currency}`;
};

/**
 * الحصول على مدة الخطة بالتنسيق
 * @param {string} plan - اسم الخطة
 * @returns {string}
 */
export const getPlanDurationFormatted = (plan) => {
  const duration = PLANS_DURATIONS[plan] || 0;
  if (duration === 0) return 'دائم';
  if (duration === 99999) return 'مدى الحياة';
  if (duration < 30) return `${duration} يوم`;
  if (duration < 365) return `${Math.floor(duration / 30)} شهر`;
  return `${Math.floor(duration / 365)} سنة`;
};

// =============================================
// 8. كائن الخدمة الرئيسي
// =============================================

export const subscriptionsService = {
  // الثوابت
  PLANS,
  PLANS_AR,
  PLANS_PRICES,
  PLANS_DURATIONS,
  PLANS_USERS,
  PLANS_REPORTS,
  PLANS_COLORS,
  DEFAULT_PLAN,

  // التحقق
  isValid: isSubscriptionValid,
  isExpired: isSubscriptionExpired,
  isExpiringSoon: isSubscriptionExpiringSoon,
  getDaysRemaining,
  getMaxUsers,
  getMaxReports,

  // إدارة
  create: createSubscription,
  update: updateSubscription,
  getActive: getActiveSubscription,
  getUser: getUserSubscriptions,

  // تمديد وترقية
  extend: extendSubscription,
  upgrade: upgradeSubscription,
  cancel: cancelSubscription,

  // معلومات الخطط
  getPlanInfo,
  getAllPlans,
  isPaid: isPaidPlan,
  isFree: isFreePlan,
  isTrial: isTrialPlan,

  // مزامنة
  sync: syncSubscriptions,

  // مساعدة
  getPriceFormatted: getPlanPriceFormatted,
  getDurationFormatted: getPlanDurationFormatted,
};

export default subscriptionsService;