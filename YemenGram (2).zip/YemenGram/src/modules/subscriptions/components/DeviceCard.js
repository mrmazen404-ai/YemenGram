/**
 * بطاقة الجهاز السيادي (Sovereign Device Card)
 */

import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';
import { Colors } from '../../../shared/utils/colors';

export default function DeviceCard({ device, isCurrent, onUnbind }) {
  if (!device) return null;

  return (
    <View style={[styles.card, isCurrent && styles.currentCard]}>
      <View style={styles.main}>
        <View style={[styles.iconBox, isCurrent && { backgroundColor: 'rgba(255,255,255,0.1)' }]}>
          <MaterialCommunityIcons
            name={device.os === 'iOS' ? 'apple' : 'android'}
            size={30}
            color={isCurrent ? '#FFF' : Colors.navy}
          />
        </View>

        <View style={styles.info}>
          <View style={styles.nameRow}>
            <Text style={[styles.name, isCurrent && styles.whiteText]}>{device.name || 'جهاز غير معروف'}</Text>
            {isCurrent && (
              <View style={styles.badge}>
                <Text style={styles.badgeText}>هذا الجهاز</Text>
              </View>
            )}
          </View>
          <Text style={[styles.meta, isCurrent && styles.lightText]}>{device.model} • {device.os}</Text>
          <Text style={[styles.date, isCurrent && styles.lightText]}>
            آخر ظهور: {new Date(device.last_seen || Date.now()).toLocaleString('ar-EG')}
          </Text>
        </View>
      </View>

      {!isCurrent && (
        <TouchableOpacity style={styles.deleteBtn} onPress={onUnbind}>
          <Ionicons name="trash-outline" size={20} color="#EF4444" />
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#FFF',
    borderRadius: 20,
    padding: 15,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#F1F5F9',
    elevation: 2,
  },
  currentCard: {
    backgroundColor: Colors.navy,
    borderColor: Colors.gold,
    borderWidth: 1.5,
  },
  main: { flex: 1, flexDirection: 'row-reverse', alignItems: 'center' },
  iconBox: {
    width: 55,
    height: 55,
    borderRadius: 18,
    backgroundColor: '#F8FAFC',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 15,
  },
  info: { flex: 1, alignItems: 'flex-end' },
  nameRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 8, marginBottom: 4 },
  name: { fontSize: 16, fontFamily: 'Tajawal-Bold', color: '#1E293B' },
  badge: { backgroundColor: Colors.gold, paddingHorizontal: 8, paddingVertical: 2, borderRadius: 8 },
  badgeText: { fontSize: 9, fontFamily: 'Tajawal-Bold', color: Colors.navy },
  meta: { fontSize: 12, fontFamily: 'Tajawal-Medium', color: '#64748B' },
  date: { fontSize: 10, fontFamily: 'Tajawal-Medium', color: '#94A3B8', marginTop: 4 },
  whiteText: { color: '#FFF' },
  lightText: { color: 'rgba(255,255,255,0.7)' },
  deleteBtn: {
    padding: 10,
    borderRadius: 12,
    backgroundColor: '#FEF2F2',
  }
});
