// src/models/FixedAsset.js
// =============================================
// نموذج الأصل الثابت (Fixed Asset Model)
// المسؤول عن إدارة الأصول الثابتة والإهلاك
// =============================================

import { Model } from '@nozbe/watermelondb';
import { field, date, readonly } from '@nozbe/watermelondb/decorators';
import { Q } from '@nozbe/watermelondb';

export default class FixedAsset extends Model {
  // ===== 1. اسم الجدول =====
  static table = 'fixed_assets';

  // ===== 2. الحقول الأساسية =====

  // معرف المستخدم (لفصل البيانات)
  @field('user_id') userId;

  // رمز الأصل الفريد (AST-0001)
  @field('code') code;

  // اسم الأصل
  @field('name') name;

  // فئة الأصل (building, equipment, furniture, vehicle, machinery, other)
  @field('category') category;

  // ===== 3. المعلومات المالية =====

  // تاريخ الشراء
  @field('purchase_date') purchaseDate;

  // تكلفة الشراء
  @field('purchase_cost') purchaseCost;

  // القيمة المتبقية (الخردة)
  @field('salvage_value') salvageValue;

  // العمر الإنتاجي (بالسنوات)
  @field('useful_life') usefulLife;

  // طريقة الإهلاك (straight_line, declining, units_of_production)
  @field('depreciation_method') depreciationMethod;

  // القيمة الحالية (بعد الإهلاك)
  @field('current_value') currentValue;

  // الإهلاك المتراكم
  @field('accumulated_depreciation') accumulatedDepreciation;

  // ===== 4. المفاتيح الخارجية =====

  // الحساب المحاسبي (الأصول الثابتة)
  @field('account_id') accountId;

  // ===== 5. معلومات إضافية =====

  @field('notes') notes;

  // ===== 6. الحالة =====

  @field('is_active') isActive;

  // ===== 7. التواريخ التلقائية =====

  @readonly @date('created_at') createdAt;
  @readonly @date('updated_at') updatedAt;

  // ===== 8. العلاقات =====

  static associations = {
    // كل أصل ينتمي إلى مستخدم واحد
    user: { type: 'belongs_to', key: 'user_id' },
    // كل أصل له حساب محاسبي واحد
    account: { type: 'belongs_to', key: 'account_id' },
    // أصل واحد → لديه عدة سجلات إهلاك
    depreciations: { type: 'has_many', foreignKey: 'asset_id' },
  };

  // ===== 9. دوال مساعدة =====

  /**
   * الحصول على فئة الأصل باللغة العربية
   * @returns {string}
   */
  getCategoryArabic() {
    const categories = {
      building: 'مبنى',
      equipment: 'معدات',
      furniture: 'أثاث',
      vehicle: 'سيارة',
      machinery: 'آلة',
      other: 'أخرى',
    };
    return categories[this.category] || this.category;
  }

  /**
   * الحصول على طريقة الإهلاك باللغة العربية
   * @returns {string}
   */
  getDepreciationMethodArabic() {
    const methods = {
      straight_line: 'القسط الثابت',
      declining: 'المتناقص',
      units_of_production: 'وحدات الإنتاج',
    };
    return methods[this.depreciation_method] || this.depreciation_method;
  }

  /**
   * حساب الإهلاك السنوي (طريقة القسط الثابت)
   * @returns {number}
   */
  calculateStraightLineDepreciation() {
    if (!this.usefulLife || this.usefulLife === 0) return 0;
    const depreciableAmount = (this.purchaseCost || 0) - (this.salvageValue || 0);
    return depreciableAmount / this.usefulLife;
  }

  /**
   * حساب الإهلاك الشهري (طريقة القسط الثابت)
   * @returns {number}
   */
  calculateMonthlyDepreciation() {
    return this.calculateStraightLineDepreciation() / 12;
   }

  /**
   * حساب القيمة الدفترية (التكلفة - الإهلاك المتراكم)
   * @returns {number}
   */
  getBookValue() {
    return (this.purchaseCost || 0) - (this.accumulatedDepreciation || 0);
  }

  /**
   * حساب النسبة المئوية للإهلاك
   * @returns {number}
   */
  getDepreciationPercentage() {
    if (!this.purchaseCost || this.purchaseCost === 0) return 0;
    return ((this.accumulatedDepreciation || 0) / this.purchaseCost) * 100;
  }

  /**
   * التحقق من أن الأصل مكتمل الإهلاك
   * @returns {boolean}
   */
  isFullyDepreciated() {
    return this.getBookValue() <= (this.salvageValue || 0);
  }

  /**
   * جلب الحساب المحاسبي
   * @returns {Promise<Account>}
   */
  async getAccount() {
    if (!this.accountId) return null;
    return this.collections.get('accounts').find(this.accountId);
  }

  /**
   * جلب سجلات الإهلاك
   * @returns {Promise<AssetDepreciation[]>}
   */
  async getDepreciations() {
    return this.collections.get('asset_depreciation').query(
      Q.where('asset_id', this.id)
    ).fetch();
  }

  /**
   * حساب إجمالي الإهلاك المسجل
   * @returns {Promise<number>}
   */
  async getTotalRecordedDepreciation() {
    const depreciations = await this.getDepreciations();
    return depreciations.reduce((sum, d) => sum + (d.amount || 0), 0);
  }

  /**
   * تسجيل إهلاك جديد
   * @param {Database} database
   * @param {string} period
   * @param {number} amount
   * @returns {Promise<AssetDepreciation>}
   */
  async recordDepreciation(database, period, amount) {
    const newAccumulated = (this.accumulatedDepreciation || 0) + amount;
    const newBookValue = (this.purchaseCost || 0) - newAccumulated;

    return await database.write(async () => {
      // 1. تسجيل سجل الإهلاك
      const depreciation = await database.get('asset_depreciation').create(d => {
        d.assetId = this.id;
        d.period = period;
        d.amount = amount;
        d.accumulated = newAccumulated;
      });

      // 2. تحديث الأصل
      await this.update(() => {
        this.accumulatedDepreciation = newAccumulated;
        this.currentValue = newBookValue;
      });

      return depreciation;
    });
  }

  // ===== 10. دوال ثابتة =====

  /**
   * الحصول على رمز الأصل التالي
   * @param {Database} database
   * @returns {Promise<string>}
   */
  static async getNextCode(database) {
    const lastAsset = await database.get('fixed_assets').query(
      Q.sortBy('code', Q.desc),
      Q.take(1)
    ).fetch();

    if (lastAsset.length === 0) {
      return 'AST-0001';
    }

    const lastCode = lastAsset[0].code;
    const numericPart = parseInt(lastCode.split('-')[1] || '0000');
    const nextNumber = numericPart + 1;
    return `AST-${String(nextNumber).padStart(4, '0')}`;
  }

  /**
   * حساب إجمالي قيمة الأصول
   * @param {FixedAsset[]} assets
   * @returns {number}
   */
  static sumPurchaseCost(assets) {
    return assets.reduce((sum, a) => sum + (a.purchaseCost || 0), 0);
  }

  /**
   * حساب إجمالي الإهلاك المتراكم
   * @param {FixedAsset[]} assets
   * @returns {number}
   */
  static sumAccumulatedDepreciation(assets) {
    return assets.reduce((sum, a) => sum + (a.accumulatedDepreciation || 0), 0);
  }

  /**
   * حساب إجمالي القيمة الدفترية
   * @param {FixedAsset[]} assets
   * @returns {number}
   */
  static sumBookValue(assets) {
    return assets.reduce((sum, a) => sum + a.getBookValue(), 0);
  }

  /**
   * تجميع الأصول حسب الفئة
   * @param {FixedAsset[]} assets
   * @returns {Object}
   */
  static groupByCategory(assets) {
    const groups = {};
    for (const asset of assets) {
      const category = asset.category || 'other';
      if (!groups[category]) {
        groups[category] = [];
      }
      groups[category].push(asset);
    }
    return groups;
  }

  /**
   * الحصول على الأصول غير المكتملة الإهلاك
   * @param {FixedAsset[]} assets
   * @returns {FixedAsset[]}
   */
  static getActiveAssets(assets) {
    return assets.filter(a => !a.isFullyDepreciated());
  }

  /**
   * الحصول على الأصول المكتملة الإهلاك
   * @param {FixedAsset[]} assets
   * @returns {FixedAsset[]}
   */
  static getFullyDepreciatedAssets(assets) {
    return assets.filter(a => a.isFullyDepreciated());
  }
}