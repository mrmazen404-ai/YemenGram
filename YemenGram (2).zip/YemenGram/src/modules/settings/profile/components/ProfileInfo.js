// src/modules/settings/profile/components/ProfileInfo.js
// وحدة عرض البيانات المؤسسية (Identity Information Unit)

import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { styles } from '../ProfileStyles';
import { Colors } from '../../../../shared/utils/colors';

export const ProfileInfo = ({ user, onEditEmail, onEditPhone }) => {
  return (
    <View style={styles.section}>
      <View style={styles.sectionHeader}>
        <Ionicons name="business-outline" size={20} color={Colors.navy} />
        <Text style={styles.sectionTitle}>الهوية المؤسسية</Text>
      </View>

      <View style={styles.card}>
        {/* اسم الشركة */}
        <View style={styles.infoItem}>
          <Text style={styles.infoLabel}>اسم الشركة</Text>
          <Text style={styles.infoValue}>{user?.company_name || 'غير محدد'}</Text>
        </View>

        {/* البريد الإلكتروني */}
        <TouchableOpacity
          style={styles.infoItem}
          onPress={onEditEmail}
        >
          <Text style={styles.infoLabel}>البريد الإلكتروني</Text>
          <View style={{ flexDirection: 'row-reverse', alignItems: 'center', gap: 5 }}>
            <Text style={styles.infoValue}>{user?.email}</Text>
            <Ionicons name="create-outline" size={16} color={Colors.gold} />
          </View>
        </TouchableOpacity>

        {/* رقم الهاتف */}
        <TouchableOpacity
          style={[styles.infoItem, styles.lastItem]}
          onPress={onEditPhone}
        >
          <Text style={styles.infoLabel}>رقم الهاتف</Text>
          <View style={{ flexDirection: 'row-reverse', alignItems: 'center', gap: 5 }}>
            <Text style={styles.infoValue}>{user?.phone || 'غير مسجل'}</Text>
            <Ionicons name="create-outline" size={16} color={Colors.gold} />
          </View>
        </TouchableOpacity>
      </View>
    </View>
  );
};
