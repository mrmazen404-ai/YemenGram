// src/models/Payroll.js
// =============================================
// نموذج الراتب (Payroll Model)
// المسؤول عن إدارة رواتب الموظفين الشهرية
// =============================================

import { Model } from '@nozbe/watermelondb';
import { field, date, readonly } from '@nozbe/watermelondb/decorators';
import { Q } from '@nozbe/watermelondb';

export default class Payroll extends Model {
  // ===== 1. اسم الجدول =====
  static table = 'payroll';

  // ===== 2. الحقول الأساسية =====

  // معرف المستخدم (لفصل البيانات)
  @field('user_id') userId;

  // معرف الموظف
  @field('employee_id') employeeId;

  // الشهر (01-12)
  @field('month') month;

  // السنة (YYYY)
  @field('year') year;

  // ===== 3. تفاصيل الراتب =====

  // الراتب الأساسي
  @field('basic_salary') basicSalary;

  // البدلات (الإضافات)
  @field('allowances') allowances;

  // الخصومات
  @field('deductions') deductions;

  // صافي الراتب (basic_salary + allowances - deductions)
  @field('net_salary') netSalary;

  // ===== 4. الحالة =====

  // حالة الراتب (pending, paid, void)
  @field('status') status;

  // ===== 5. التواريخ التلقائية =====

  @readonly @date('created_at') createdAt;
  @readonly @date('updated_at') updatedAt;

  // ===== 6. العلاقات =====

  static associations = {
    // كل راتب ينتمي إلى مستخدم واحد
    user: { type: 'belongs_to', key: 'user_id' },
    // كل راتب ينتمي إلى موظف واحد
    employee: { type: 'belongs_to', key: 'employee_id' },
  };

  // ===== 7. دوال مساعدة =====

  /**
   * الحصول على حالة الراتب باللغة العربية
   * @returns {string}
   */
  getStatusArabic() {
    const statuses = {
      pending: 'معلق',
      paid: 'مدفوع',
      void: 'ملغى',
    };
    return statuses[this.status] || this.status;
  }

  /**
   * الحصول على لون الحالة
   * @returns {string}
   */
  getStatusColor() {
    const colors = {
      pending: '#F39C12',
      paid: '#27AE60',
      void: '#E74C3C',
    };
    return colors[this.status] || '#6B7280';
  }

  /**
   * الحصول على اسم الشهر بالعربية
   * @returns {string}
   */
  getMonthArabic() {
    const months = [
      'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
      'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر',
    ];
    const monthIndex = parseInt(this.month) - 1;
    return months[monthIndex] || this.month;
  }

  /**
   * الحصول على اسم الشهر مع السنة
   * @returns {string}
   */
  getPeriod() {
    return `${this.getMonthArabic()} ${this.year}`;
  }

  /**
   * حساب صافي الراتب (basic + allowances - deductions)
   * @returns {number}
   */
  calculateNetSalary() {
    return (this.basicSalary || 0) + (this.allowances || 0) - (this.deductions || 0);
  }

  /**
   * تحديث صافي الراتب تلقائياً
   */
  async recalculateNetSalary() {
    const newNet = this.calculateNetSalary();
    await this.write(() => {
      this.netSalary = newNet;
    });
  }

  /**
   * التحقق من أن الراتب مدفوع
   * @returns {boolean}
   */
  isPaid() {
    return this.status === 'paid';
  }

  /**
   * التحقق من أن الراتب معلق
   * @returns {boolean}
   */
  isPending() {
    return this.status === 'pending';
  }

  /**
   * جلب الموظف المرتبط
   * @returns {Promise<Employee>}
   */
  async getEmployee() {
    return this.collections.get('employees').find(this.employeeId);
  }

  /**
   * الحصول على اسم الموظف
   * @returns {Promise<string>}
   */
  async getEmployeeName() {
    const employee = await this.getEmployee();
    return employee ? employee.name : 'موظف غير معروف';
  }

  /**
   * الحصول على اسم الموظف مع الراتب
   * @returns {Promise<string>}
   */
  async getDisplayName() {
    const name = await this.getEmployeeName();
    return `${name} - ${this.getPeriod()}`;
  }

  // ===== 8. دوال ثابتة =====

  /**
   * حساب إجمالي الرواتب لمجموعة
   * @param {Payroll[]} payrolls
   * @returns {number}
   */
  static sumNetSalary(payrolls) {
    return payrolls.reduce((sum, p) => sum + (p.netSalary || 0), 0);
  }

  /**
   * حساب إجمالي البدلات لمجموعة
   * @param {Payroll[]} payrolls
   * @returns {number}
   */
  static sumAllowances(payrolls) {
    return payrolls.reduce((sum, p) => sum + (p.allowances || 0), 0);
  }

  /**
   * حساب إجمالي الخصومات لمجموعة
   * @param {Payroll[]} payrolls
   * @returns {number}
   */
  static sumDeductions(payrolls) {
    return payrolls.reduce((sum, p) => sum + (p.deductions || 0), 0);
  }

  /**
   * حساب متوسط الرواتب لمجموعة
   * @param {Payroll[]} payrolls
   * @returns {number}
   */
  static averageNetSalary(payrolls) {
    if (payrolls.length === 0) return 0;
    return this.sumNetSalary(payrolls) / payrolls.length;
  }

  /**
   * تجميع الرواتب حسب الشهر
   * @param {Payroll[]} payrolls
   * @returns {Object}
   */
  static groupByMonth(payrolls) {
    const groups = {};
    for (const payroll of payrolls) {
      const key = `${payroll.year}-${payroll.month}`;
      if (!groups[key]) {
        groups[key] = [];
      }
      groups[key].push(payroll);
    }
    return groups;
  }

  /**
   * تجميع الرواتب حسب الحالة
   * @param {Payroll[]} payrolls
   * @returns {Object}
   */
  static groupByStatus(payrolls) {
    const groups = {};
    for (const payroll of payrolls) {
      if (!groups[payroll.status]) {
        groups[payroll.status] = [];
      }
      groups[payroll.status].push(payroll);
    }
    return groups;
  }

  /**
   * الحصول على الرواتب المدفوعة فقط
   * @param {Payroll[]} payrolls
   * @returns {Payroll[]}
   */
  static getPaidPayrolls(payrolls) {
    return payrolls.filter(p => p.isPaid());
  }

  /**
   * الحصول على الرواتب المعلقة فقط
   * @param {Payroll[]} payrolls
   * @returns {Payroll[]}
   */
  static getPendingPayrolls(payrolls) {
    return payrolls.filter(p => p.isPending());
  }

  /**
   * إنشاء راتب للموظفين دفعة واحدة
   * @param {Database} database
   * @param {string} userId
   * @param {Array} payrollData
   * @returns {Promise<Payroll[]>}
   */
  static async createBatch(database, userId, payrollData) {
    const createdPayrolls = [];

    await database.write(async () => {
      for (const data of payrollData) {
        const payroll = await database.get('payroll').create(p => {
          p.userId = userId;
          p.employeeId = data.employeeId;
          p.month = data.month;
          p.year = data.year;
          p.basicSalary = data.basicSalary || 0;
          p.allowances = data.allowances || 0;
          p.deductions = data.deductions || 0;
          p.netSalary = (data.basicSalary || 0) + (data.allowances || 0) - (data.deductions || 0);
          p.status = data.status || 'pending';
        });
        createdPayrolls.push(payroll);
      }
    });

    return createdPayrolls;
  }
}