// src/shared/contexts/AuthContext.js

import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import NetInfo from '@react-native-community/netinfo';
import { AuthService } from '../../modules/auth/services/authService';
import { LocalDB } from '../../modules/database/localDB';
import { TimeService } from '../../services/timeService';
import { Logger } from '../utils/logger';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [purgeSuccess, setPurgeSuccess] = useState(false);
  const [reAuthRequired, setReAuthRequired] = useState(false);
  const [isOnline, setIsOnline] = useState(true);
  const [securityLock, setSecurityLock] = useState({ isLocked: false, message: '' });

  const applySubscriptionReadOnly = useCallback(async (userId) => {
    if (!userId) { LocalDB.setReadOnlyMode(false); return; }
    const subscription = await LocalDB.queryOne(
      'SELECT status, end_date FROM subscriptions WHERE user_id = ? ORDER BY created_at DESC LIMIT 1',
      [userId]
    );
    const active = subscription && ['TRIAL_ACTIVE', 'ACTIVE_FULL'].includes(subscription.status)
      && (!subscription.end_date || Number(subscription.end_date) > Date.now());
    LocalDB.setReadOnlyMode(!active);
  }, []);

  // ===== مراقبة الإنترنت السيادية =====
  useEffect(() => {
    const unsubscribe = NetInfo.addEventListener(state => {
      console.log(`🌐 [NetInfo] حالة الاتصال: ${state.isConnected ? 'متصل' : 'منقطع'}`);
      setIsOnline(state.isConnected ?? true);
    });
    return () => unsubscribe();
  }, []);

  // ===== تحقق من المصادقة =====
  const checkAuth = useCallback(async () => {
    console.log('🔐 [checkAuth] بدء التحقق من المصادقة...');
    try {
      // ✅ التأكد من الاتصال بقاعدة البيانات
      console.log('📦 [checkAuth] جاري التأكد من الاتصال...');
      await LocalDB.ensureConnection();
      console.log('✅ [checkAuth] الاتصال جاهز');

      // 🛡️ فحص نزاهة الوقت والسيادة
      const integrity = await TimeService.checkSovereignIntegrity();
      if (!integrity.isValid) {
        setSecurityLock({ isLocked: true, message: integrity.message });
        setLoading(false);
        return;
      }

      const result = await AuthService.initialize();
      if (result.isLoggedIn && result.user) {
        // ✅ فحص سياسة تجديد السيادة (7 أيام)
        const isExpired = await AuthService.isSessionExpired();

        if (isExpired) {
          console.log('🛡️ [checkAuth] الجلسة منتهية الصلاحية (أكثر من 7 أيام). طلب إعادة مصادقة.');
          setReAuthRequired(true);
          setIsLoggedIn(false);
          setUser(result.user); // نحفظ بيانات المستخدم لعرضها في شاشة التأكيد
        } else {
          console.log('✅ [checkAuth] المستخدم مسجل دخول وصلاحية الجلسة سارية');
          setUser(result.user);
          setIsLoggedIn(true);
          setReAuthRequired(false);
          await applySubscriptionReadOnly(result.user.id);
        }
      } else {
        console.log('ℹ️ [checkAuth] لا يوجد مستخدم مسجل دخول');
        setUser(null);
        setIsLoggedIn(false);
        setReAuthRequired(false);
        LocalDB.setReadOnlyMode(false);
      }
    } catch (error) {
      console.log('❌ [checkAuth] خطأ:', error.message);
      Logger.error('checkAuth failed:', error);
      setUser(null);
      setIsLoggedIn(false);
    } finally {
      setLoading(false);
      console.log('🏁 [checkAuth] انتهاء التحقق');
    }
  }, [applySubscriptionReadOnly]);

  // ===== التهيئة =====
  useEffect(() => {
    console.log('🔐 [AuthProvider] التهيئة...');
    checkAuth();
  }, []);

  // ===== تسجيل الدخول =====
  const login = useCallback(async (email, password) => {
    console.log('🔑 [login] محاولة تسجيل دخول:', email);
    try {
      // ✅ التأكد من الاتصال
      await LocalDB.ensureConnection();
      console.log('✅ [login] قاعدة البيانات جاهزة');

      const result = await AuthService.login(email, password);
      console.log('✅ [login] تم تسجيل الدخول بنجاح للمستخدم:', result.user.name);
      setUser(result.user);
      setIsLoggedIn(true);
      setReAuthRequired(false); // ✅ تصفير الحالة عند الدخول الناجح
      return result;
    } catch (error) {
      console.log('❌ [login] فشل تسجيل الدخول:', error.message);
      throw error;
    }
  }, []);

  // ===== التسجيل =====
  const register = useCallback(async (userData) => {
    console.log('📝 [register] بدء التسجيل:', userData.email);
    try {
      // ✅ التأكد من الاتصال
      await LocalDB.ensureConnection();
      console.log('✅ [register] قاعدة البيانات جاهزة');

      return await AuthService.register(userData);
    } catch (error) {
      console.log('❌ [register] فشل التسجيل:', error.message);
      throw error;
    }
  }, []);

  // ===== التحقق من OTP =====
  const verifyOTP = useCallback(async (email, code) => {
    console.log('📧 [verifyOTP] التحقق من الكود:', email);
    try {
      await LocalDB.ensureConnection();
      const result = await AuthService.verifyOTP(email, code);
      if (result.success) {
        console.log('✅ [verifyOTP] تم التحقق بنجاح');
        // إذا لم يكن مستخدماً مسجلاً (عملية تسجيل جديد)
        if (result.user) {
          setUser(result.user);
          setIsLoggedIn(true);
        }
        setReAuthRequired(false);
      }
      return result;
    } catch (error) {
      console.log('❌ [verifyOTP] فشل التحقق:', error.message);
      throw error;
    }
  }, []);

  // ===== إرسال OTP =====
  const sendOTP = useCallback(async (email) => {
    console.log('📧 [sendOTP] إرسال OTP إلى:', email);
    try {
      await LocalDB.ensureConnection();
      return await AuthService.sendOTP(email);
    } catch (error) {
      console.log('❌ [sendOTP] فشل إرسال OTP:', error.message);
      throw error;
    }
  }, []);

  // ===== استعادة كلمة المرور =====
  const forgotPassword = useCallback(async (email) => {
    console.log('🔓 [forgotPassword] طلب استعادة كلمة المرور:', email);
    try {
      await LocalDB.ensureConnection();
      return await AuthService.startPasswordRecovery(email);
    } catch (error) {
      console.log('❌ [forgotPassword] فشل طلب الاستعادة:', error.message);
      throw error;
    }
  }, []);

  // ===== إعادة تعيين كلمة المرور =====
  const resetPassword = useCallback(async (email, token, newPassword) => {
    console.log('🔓 [resetPassword] إعادة تعيين كلمة المرور:', email);
    try {
      await LocalDB.init();
      return await AuthService.finalizePasswordReset(email, token, newPassword);
    } catch (error) {
      console.log('❌ [resetPassword] فشل إعادة التعيين:', error.message);
      throw error;
    }
  }, []);

  // ===== تغيير كلمة المرور =====
  const changePassword = useCallback(async (oldPassword, newPassword) => {
    console.log('🔑 [changePassword] تغيير كلمة المرور');
    try {
      return await AuthService.changePassword(oldPassword, newPassword);
    } catch (error) {
      console.log('❌ [changePassword] فشل تغيير كلمة المرور:', error.message);
      throw error;
    }
  }, []);

  // ===== تسجيل الخروج =====
  const logout = useCallback(async () => {
    console.log('🚪 [logout] تسجيل الخروج');
    try {
      await AuthService.logout();
      setUser(null);
      setIsLoggedIn(false);
      setReAuthRequired(false);
      console.log('✅ [logout] تم تسجيل الخروج');
    } catch (error) {
      console.log('❌ [logout] فشل تسجيل الخروج:', error.message);
      throw error;
    }
  }, []);

  // ===== حذف الحساب =====
  const deleteAccount = useCallback(async () => {
    console.log('🗑️ [deleteAccount] حذف الحساب');
    try {
      await AuthService.deleteAccount();
      setPurgeSuccess(true);
      setUser(null);
      setIsLoggedIn(false);
      setReAuthRequired(false);
      console.log('✅ [deleteAccount] تم حذف الحساب بنجاح');
    } catch (error) {
      console.log('❌ [deleteAccount] فشل حذف الحساب:', error.message);
      throw error;
    }
  }, []);

  // ===== تحديث الصورة =====
  const updateAvatar = useCallback(async (base64Image) => {
    if (!user) return;
    console.log('🖼️ [updateAvatar] تحديث الصورة للمستخدم:', user.id);
    try {
      await AuthService.updateAvatar(user.id, base64Image);
      setUser(prev => ({ ...prev, avatar: base64Image }));
      console.log('✅ [updateAvatar] تم تحديث الصورة');
    } catch (error) {
      console.log('❌ [updateAvatar] فشل تحديث الصورة:', error.message);
      throw error;
    }
  }, [user]);

  // ===== تحديث بيانات المستخدم يدوياً =====
  const updateUserData = useCallback((newData) => {
    console.log('🔄 [updateUserData] تحديث بيانات المستخدم في السياق');
    setUser(prev => ({ ...prev, ...newData }));
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        setUser,
        updateUserData,
        loading,
        isLoggedIn,
        login,
        register,
        logout,
        checkAuth,
        verifyOTP,
        sendOTP,
        forgotPassword,
        resetPassword,
        changePassword,
        deleteAccount,
        updateAvatar,
        purgeSuccess,
        setPurgeSuccess,
        reAuthRequired,
        securityLock,
        isOnline,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
export default AuthContext;
