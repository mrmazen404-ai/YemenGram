// src/store/subscriptionSlice.js
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { SubscriptionService } from '../modules/subscriptions/services/SubscriptionService';

/**
 * جلب بيانات الاشتراك النشط من قاعدة البيانات المحلية
 */
export const fetchActiveSubscription = createAsyncThunk(
  'subscription/fetchActive',
  async (userId, { rejectWithValue }) => {
    try {
      const sub = await SubscriptionService.getActiveSubscription(userId);
      if (!sub) return null;

      // تحويل كائن WatermelonDB إلى JSON بسيط للريدكس
      return {
        id: sub.id,
        status: sub.status,
        plan: sub.plan,
        startDate: sub.startDate,
        endDate: sub.endDate,
        maxDevices: sub.maxDevices,
        registeredDevices: sub.registeredDevices,
        maxCustomers: sub.maxCustomers,
        maxInvoices: sub.maxInvoices,
        maxStorage: sub.maxStorage,
        isReadOnly: sub.isReadOnly(),
        daysRemaining: sub.getDaysRemaining(),
        planArabic: sub.getPlanArabic(),
      };
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

const subscriptionSlice = createSlice({
  name: 'subscription',
  initialState: {
    data: null,
    loading: false,
    error: null,
    lastUpdated: null,
  },
  reducers: {
    clearSubscription: (state) => {
      state.data = null;
    },
    updateLocalUsage: (state, action) => {
      if (state.data) {
        const { type, count } = action.payload;
        if (type === 'devices') state.data.registeredDevices = count;
        // يمكن إضافة المزيد من الموارد هنا
      }
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchActiveSubscription.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchActiveSubscription.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
        state.lastUpdated = Date.now();
        state.error = null;
      })
      .addCase(fetchActiveSubscription.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export const { clearSubscription, updateLocalUsage } = subscriptionSlice.actions;
export default subscriptionSlice.reducer;
