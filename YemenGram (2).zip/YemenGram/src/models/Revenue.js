// src/models/Revenue.js
// =============================================
// نموذج الإيراد (Revenue Model)
// المسؤول عن تسجيل الإيرادات المنفصلة (غير المرتبطة بفاتورة بيع)
// =============================================

import { Model } from '@nozbe/watermelondb';
import { field, date, readonly } from '@nozbe/watermelondb/decorators';
import { Q } from '@nozbe/watermelondb';

export default class Revenue extends Model {
  // ===== 1. اسم الجدول =====
  static table = 'revenues';

  // ===== 2. الحقول الأساسية =====

  // معرف المستخدم (لفصل البيانات)
  @field('user_id') userId;

  // رقم السند
  @field('number') number;

  // تاريخ الإيراد
  @field('date') date;

  // معرف الحساب المحاسبي (إيرادات)
  @field('account_id') accountId;

  // المبلغ
  @field('amount') amount;

  // مصدر الإيراد (مبيعات نقدية، إيرادات استثمارية، ...)
  @field('source') source;

  // وصف الإيراد
  @field('description') description;

  // ===== 3. طريقة الدفع =====

  // طريقة الدفع (cash, bank, check)
  @field('payment_method') paymentMethod;

  // الحساب النقدي/البنكي المستخدم
  @field('cash_account_id') cashAccountId;

  // معرف الشيك (إذا كانت طريقة الدفع شيك)
  @field('check_id') checkId;

  // ===== 4. من قام بالإنشاء =====

  @field('created_by') createdBy;

  // ===== 5. التواريخ التلقائية =====

  @readonly @date('created_at') createdAt;
  @readonly @date('updated_at') updatedAt;

  // ===== 6. العلاقات =====

  static associations = {
    // كل إيراد ينتمي إلى مستخدم واحد
    user: { type: 'belongs_to', key: 'user_id' },
    // كل إيراد له حساب محاسبي واحد
    account: { type: 'belongs_to', key: 'account_id' },
    // كل إيراد قد ينتمي إلى حساب نقدي/بنكي
    cashAccount: { type: 'belongs_to', key: 'cash_account_id' },
    // كل إيراد قد ينتمي إلى شيك
    check: { type: 'belongs_to', key: 'check_id' },
  };

  // ===== 7. دوال مساعدة =====

  /**
   * الحصول على طريقة الدفع باللغة العربية
   * @returns {string}
   */
  getPaymentMethodArabic() {
    const methods = {
      cash: 'نقدي',
      bank: 'تحويل بنكي',
      check: 'شيك',
    };
    return methods[this.payment_method] || this.payment_method;
  }

  /**
   * جلب الحساب المحاسبي
   * @returns {Promise<Account>}
   */
  async getAccount() {
    return this.collections.get('accounts').find(this.accountId);
  }

  /**
   * جلب اسم الحساب المحاسبي
   * @returns {Promise<string>}
   */
  async getAccountName() {
    const account = await this.getAccount();
    return account ? account.name : 'حساب غير معروف';
  }

  /**
   * جلب الحساب النقدي/البنكي (إن وجد)
   * @returns {Promise<CashAccount|null>}
   */
  async getCashAccount() {
    if (!this.cashAccountId) return null;
    return this.collections.get('cash_accounts').find(this.cashAccountId);
  }

  /**
   * جلب الشيك المرتبط (إن وجد)
   * @returns {Promise<Check|null>}
   */
  async getCheck() {
    if (!this.checkId) return null;
    return this.collections.get('checks').find(this.checkId);
  }

  /**
   * الحصول على اسم الإيراد المعروض
   * @returns {string}
   */
  getDisplayName() {
    return `${this.number} - ${this.source || 'إيراد'}`;
  }

  // ===== 8. دوال ثابتة =====

  /**
   * الحصول على رقم الإيراد التالي
   * @param {Database} database
   * @returns {Promise<string>}
   */
  static async getNextNumber(database) {
    const lastRevenue = await database.get('revenues').query(
      Q.sortBy('number', Q.desc),
      Q.take(1)
    ).fetch();

    if (lastRevenue.length === 0) {
      return 'REV-0001';
    }

    const lastNumber = lastRevenue[0].number;
    const numericPart = parseInt(lastNumber.split('-')[1] || '0000');
    const nextNumber = numericPart + 1;
    return `REV-${String(nextNumber).padStart(4, '0')}`;
  }

  /**
   * حساب إجمالي الإيرادات
   * @param {Revenue[]} revenues
   * @returns {number}
   */
  static sumAmount(revenues) {
    return revenues.reduce((sum, r) => sum + (r.amount || 0), 0);
  }

  /**
   * تجميع الإيرادات حسب المصدر
   * @param {Revenue[]} revenues
   * @returns {Object}
   */
  static groupBySource(revenues) {
    const groups = {};
    for (const revenue of revenues) {
      const source = revenue.source || 'غير مصنف';
      if (!groups[source]) {
        groups[source] = [];
      }
      groups[source].push(revenue);
    }
    return groups;
  }

  /**
   * تجميع الإيرادات حسب طريقة الدفع
   * @param {Revenue[]} revenues
   * @returns {Object}
   */
  static groupByPaymentMethod(revenues) {
    const groups = {};
    for (const revenue of revenues) {
      const method = revenue.payment_method || 'غير محدد';
      if (!groups[method]) {
        groups[method] = [];
      }
      groups[method].push(revenue);
    }
    return groups;
  }

  /**
   * تجميع الإيرادات حسب الشهر
   * @param {Revenue[]} revenues
   * @returns {Object}
   */
  static groupByMonth(revenues) {
    const groups = {};
    for (const revenue of revenues) {
      const date = new Date(revenue.date);
      const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      if (!groups[key]) {
        groups[key] = [];
      }
      groups[key].push(revenue);
    }
    return groups;
  }
}