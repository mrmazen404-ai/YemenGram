const fs = require('fs');
const path = require('path');

const distPath = path.join(__dirname, '..', 'dist');
const indexPath = path.join(distPath, 'index.html');

const htmlContent = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <title>YemenGram</title>
  <style>
    body { margin: 0; font-family: sans-serif; background: #1B365D; }
    #root { display: flex; justify-content: center; align-items: center; height: 100vh; }
    .loader { color: white; font-size: 20px; text-align: center; }
    .loader span { display: inline-block; animation: pulse 1.4s infinite; }
    .loader span:nth-child(2) { animation-delay: 0.2s; }
    .loader span:nth-child(3) { animation-delay: 0.4s; }
    @keyframes pulse { 0%, 80%, 100% { opacity: 0; } 40% { opacity: 1; } }
  </style>
</head>
<body>
  <div id="root">
    <div class="loader">
      <span>ج</span><span>ا</span><span>ر</span><span>ي</span>
      <span> </span>
      <span>ا</span><span>ل</span><span>ت</span><span>ح</span><span>م</span><span>ي</span><span>ل</span><span>...</span>
    </div>
  </div>
  <script src="index.js"></script>
</body>
</html>`;
// تأكد من وجود مجلد dist
if (!fs.existsSync(distPath)) {
  fs.mkdirSync(distPath, { recursive: true });
}
// أنشئ index.html
fs.writeFileSync(indexPath, htmlContent);
console.log('✅ index.html created successfully!');