// src/shared/types/index.js
// =============================================
// تعريفات الأنواع (Type Definitions)
// للاستخدام في جميع أنحاء التطبيق
// =============================================

// =============================================
// 1. أنواع المستخدم
// =============================================

/**
 * @typedef {Object} User
 * @property {string} id - معرف المستخدم
 * @property {string} user_code - الرقم الفريد للمستخدم
 * @property {string} name - اسم المستخدم
 * @property {string} email - البريد الإلكتروني
 * @property {string} phone - رقم الهاتف
 * @property {string} avatar - صورة المستخدم (Base64)
 * @property {string} role - الدور (admin, accountant, sales, customer)
 * @property {string} company_id - معرف الشركة
 * @property {string} company_name - اسم الشركة
 * @property {string} base_currency - العملة الأساسية
 * @property {number} is_blocked - حالة الحظر (0/1)
 * @property {string} blocked_reason - سبب الحظر
 * @property {number} blocked_at - تاريخ الحظر
 * @property {number} created_at - تاريخ الإنشاء
 * @property {number} updated_at - تاريخ التحديث
 */

/**
 * @typedef {Object} Session
 * @property {string} id - معرف الجلسة
 * @property {string} user_id - معرف المستخدم
 * @property {string} token - توكن المصادقة
 * @property {string} refresh_token - توكن التحديث
 * @property {number} expires_at - تاريخ الانتهاء
 * @property {number} created_at - تاريخ الإنشاء
 */

// =============================================
// 2. أنواع العملاء
// =============================================

/**
 * @typedef {Object} Customer
 * @property {string} id - معرف العميل
 * @property {string} user_id - معرف المستخدم
 * @property {string} code - رمز العميل
 * @property {string} name - اسم العميل
 * @property {string} type - نوع العميل (individual, company)
 * @property {string} phone - رقم الهاتف
 * @property {string} email - البريد الإلكتروني
 * @property {string} address - العنوان
 * @property {string} tax_number - الرقم الضريبي
 * @property {number} credit_limit - السقف الائتماني
 * @property {number} balance - الرصيد
 * @property {string} account_id - معرف الحساب المحاسبي
 * @property {string} tier_id - معرف المستوى
 * @property {string} currency - العملة
 * @property {number} default_discount - الخصم الافتراضي
 * @property {number} payment_terms - مدة السداد
 * @property {number} opening_balance - الرصيد الافتتاحي
 * @property {string} category - الفئة (retail, wholesale)
 * @property {string} preferred_payment_method - طريقة الدفع المفضلة
 * @property {string} contact_person - جهة الاتصال
 * @property {string} contact_phone - هاتف جهة الاتصال
 * @property {string} assigned_to - المسؤول عن العميل
 * @property {string} source - مصدر العميل
 * @property {string} tags - العلامات
 * @property {number} last_contact_date - تاريخ آخر اتصال
 * @property {string} notes - ملاحظات
 * @property {number} is_active - حالة النشاط (0/1)
 * @property {number} created_at - تاريخ الإنشاء
 * @property {number} updated_at - تاريخ التحديث
 */

/**
 * @typedef {Object} CustomerTier
 * @property {string} id - معرف المستوى
 * @property {string} name - اسم المستوى
 * @property {number} level - رقم المستوى
 * @property {string} description - الوصف
 * @property {number} is_active - حالة النشاط
 * @property {number} created_at - تاريخ الإنشاء
 * @property {number} updated_at - تاريخ التحديث
 */

/**
 * @typedef {Object} CustomerContact
 * @property {number} id - المعرف
 * @property {string} customer_id - معرف العميل
 * @property {string} name - اسم جهة الاتصال
 * @property {string} phone - رقم الهاتف
 * @property {string} email - البريد الإلكتروني
 * @property {string} position - المنصب
 * @property {number} is_primary - رئيسي (0/1)
 * @property {number} created_at - تاريخ الإنشاء
 * @property {number} updated_at - تاريخ التحديث
 */

/**
 * @typedef {Object} CustomerNote
 * @property {number} id - المعرف
 * @property {string} customer_id - معرف العميل
 * @property {string} note - نص الملاحظة
 * @property {string} created_by - من قام بالإنشاء
 * @property {number} created_at - تاريخ الإنشاء
 */

/**
 * @typedef {Object} CustomerActivity
 * @property {number} id - المعرف
 * @property {string} customer_id - معرف العميل
 * @property {string} type - النوع (call, email, meeting, note, visit)
 * @property {string} description - الوصف
 * @property {number} date - التاريخ
 * @property {string} created_by - من قام بالإنشاء
 * @property {number} created_at - تاريخ الإنشاء
 */

// =============================================
// 3. أنواع الحسابات
// =============================================

/**
 * @typedef {Object} Account
 * @property {string} id - معرف الحساب
 * @property {string} user_id - معرف المستخدم
 * @property {string} code - رقم الحساب
 * @property {string} name - اسم الحساب
 * @property {string} type - نوع الحساب (asset, liability, equity, revenue, expense)
 * @property {string} parent_id - معرف الحساب الأب
 * @property {string} currency - العملة
 * @property {number} balance - الرصيد
 * @property {number} is_active - حالة النشاط (0/1)
 * @property {string} notes - ملاحظات
 * @property {number} created_at - تاريخ الإنشاء
 * @property {number} updated_at - تاريخ التحديث
 */

/**
 * @typedef {Object} AccountMovement
 * @property {number} id - المعرف
 * @property {string} account_id - معرف الحساب
 * @property {number} date - التاريخ
 * @property {string} journal_entry_id - معرف القيد
 * @property {string} invoice_id - معرف الفاتورة
 * @property {string} reference - المرجع
 * @property {string} description - الوصف
 * @property {number} debit - المدين
 * @property {number} credit - الدائن
 * @property {number} balance - الرصيد التراكمي
 * @property {number} created_at - تاريخ الإنشاء
 */

// =============================================
// 4. أنواع الفواتير
// =============================================

/**
 * @typedef {Object} Invoice
 * @property {string} id - معرف الفاتورة
 * @property {string} user_id - معرف المستخدم
 * @property {string} number - رقم الفاتورة
 * @property {string} type - النوع (sale, purchase, return_sale, return_purchase)
 * @property {number} date - التاريخ
 * @property {string} customer_id - معرف العميل
 * @property {string} supplier_id - معرف المورد
 * @property {string} account_id - معرف الحساب
 * @property {number} total - المجموع
 * @property {number} discount - الخصم
 * @property {number} tax - الضريبة
 * @property {number} net_total - صافي المجموع
 * @property {string} currency - العملة
 * @property {string} status - الحالة (draft, posted, void)
 * @property {string} notes - ملاحظات
 * @property {number} created_at - تاريخ الإنشاء
 * @property {number} updated_at - تاريخ التحديث
 */

/**
 * @typedef {Object} InvoiceItem
 * @property {number} id - المعرف
 * @property {string} user_id - معرف المستخدم
 * @property {string} invoice_id - معرف الفاتورة
 * @property {string} product_id - معرف المنتج
 * @property {string} description - الوصف
 * @property {number} quantity - الكمية
 * @property {number} unit_price - سعر الوحدة
 * @property {number} total - المجموع
 */

// =============================================
// 5. أنواع المدفوعات
// =============================================

/**
 * @typedef {Object} Payment
 * @property {string} id - معرف الدفعة
 * @property {string} user_id - معرف المستخدم
 * @property {string} number - رقم السند
 * @property {number} date - التاريخ
 * @property {string} type - النوع (customer, supplier, expense, salary)
 * @property {string} customer_id - معرف العميل
 * @property {string} supplier_id - معرف المورد
 * @property {string} expense_id - معرف المصروف
 * @property {string} employee_id - معرف الموظف
 * @property {number} amount - المبلغ
 * @property {string} method - الطريقة (cash, bank, check)
 * @property {string} cash_account_id - معرف الحساب النقدي
 * @property {string} check_id - معرف الشيك
 * @property {string} description - الوصف
 * @property {string} status - الحالة (pending, completed, void)
 * @property {string} created_by - من قام بالإنشاء
 * @property {number} created_at - تاريخ الإنشاء
 * @property {number} updated_at - تاريخ التحديث
 */

// =============================================
// 6. أنواع المنتجات والمخزون
// =============================================

/**
 * @typedef {Object} Product
 * @property {string} id - معرف المنتج
 * @property {string} user_id - معرف المستخدم
 * @property {string} code - رمز المنتج
 * @property {string} name - اسم المنتج
 * @property {string} category - الفئة
 * @property {string} unit - الوحدة
 * @property {number} purchase_price - سعر الشراء
 * @property {number} sale_price - سعر البيع
 * @property {number} quantity - الكمية
 * @property {number} min_quantity - الحد الأدنى للكمية
 * @property {string} account_id - معرف الحساب
 * @property {string} notes - ملاحظات
 * @property {number} is_active - حالة النشاط
 * @property {number} created_at - تاريخ الإنشاء
 * @property {number} updated_at - تاريخ التحديث
 */

// =============================================
// 7. أنواع النظام
// =============================================

/**
 * @typedef {Object} Setting
 * @property {string} key - مفتاح الإعداد
 * @property {string} value - قيمة الإعداد
 * @property {number} updated_at - تاريخ التحديث
 */

/**
 * @typedef {Object} Notification
 * @property {number} id - المعرف
 * @property {string} user_id - معرف المستخدم
 * @property {string} type - النوع (info, success, warning, error)
 * @property {string} title - العنوان
 * @property {string} message - الرسالة
 * @property {number} read - حالة القراءة (0/1)
 * @property {string} action - الإجراء
 * @property {string} action_data - بيانات الإجراء (JSON)
 * @property {number} created_at - تاريخ الإنشاء
 */

/**
 * @typedef {Object} Subscription
 * @property {string} id - معرف الاشتراك
 * @property {string} user_id - معرف المستخدم
 * @property {string} plan - الخطة (free, trial, monthly, annual, lifetime)
 * @property {number} start_date - تاريخ البداية
 * @property {number} end_date - تاريخ النهاية
 * @property {number} is_active - حالة النشاط
 * @property {number} created_at - تاريخ الإنشاء
 * @property {number} updated_at - تاريخ التحديث
 */

/**
 * @typedef {Object} AuditLog
 * @property {number} id - المعرف
 * @property {string} user_id - معرف المستخدم
 * @property {string} action - الإجراء
 * @property {string} table_name - اسم الجدول
 * @property {string} record_id - معرف السجل
 * @property {string} details - التفاصيل (JSON)
 * @property {number} created_at - تاريخ الإنشاء
 */

// =============================================
// 8. أنواع المزامنة
// =============================================

/**
 * @typedef {Object} SyncQueue
 * @property {number} id - المعرف
 * @property {string} user_id - معرف المستخدم
 * @property {string} action - الإجراء (insert, update, delete)
 * @property {string} table_name - اسم الجدول
 * @property {string} record_id - معرف السجل
 * @property {string} data - البيانات (JSON)
 * @property {string} status - الحالة (pending, synced, failed)
 * @property {number} attempts - عدد المحاولات
 * @property {number} created_at - تاريخ الإنشاء
 * @property {number} synced_at - تاريخ المزامنة
 */

// =============================================
// 9. أنواع الموردين
// =============================================

/**
 * @typedef {Object} Supplier
 * @property {string} id - معرف المورد
 * @property {string} user_id - معرف المستخدم
 * @property {string} code - رمز المورد
 * @property {string} name - اسم المورد
 * @property {string} phone - رقم الهاتف
 * @property {string} email - البريد الإلكتروني
 * @property {string} address - العنوان
 * @property {string} tax_number - الرقم الضريبي
 * @property {string} account_id - معرف الحساب
 * @property {string} notes - ملاحظات
 * @property {number} is_active - حالة النشاط
 * @property {number} created_at - تاريخ الإنشاء
 * @property {number} updated_at - تاريخ التحديث
 */

// =============================================
// 10. أنواع الموظفين
// =============================================

/**
 * @typedef {Object} Employee
 * @property {string} id - معرف الموظف
 * @property {string} user_id - معرف المستخدم
 * @property {string} code - رمز الموظف
 * @property {string} name - اسم الموظف
 * @property {string} phone - رقم الهاتف
 * @property {string} email - البريد الإلكتروني
 * @property {string} position - المنصب
 * @property {string} department - القسم
 * @property {number} salary - الراتب
 * @property {number} hire_date - تاريخ التعيين
 * @property {string} account_id - معرف الحساب
 * @property {number} is_active - حالة النشاط
 * @property {number} created_at - تاريخ الإنشاء
 * @property {number} updated_at - تاريخ التحديث
 */

/**
 * @typedef {Object} Payroll
 * @property {string} id - معرف الراتب
 * @property {string} user_id - معرف المستخدم
 * @property {string} employee_id - معرف الموظف
 * @property {string} month - الشهر
 * @property {string} year - السنة
 * @property {number} basic_salary - الراتب الأساسي
 * @property {number} allowances - البدلات
 * @property {number} deductions - الخصومات
 * @property {number} net_salary - صافي الراتب
 * @property {string} status - الحالة (pending, paid, void)
 * @property {number} created_at - تاريخ الإنشاء
 * @property {number} updated_at - تاريخ التحديث
 */

// =============================================
// 11. أنواع الأصول الثابتة
// =============================================

/**
 * @typedef {Object} FixedAsset
 * @property {string} id - معرف الأصل
 * @property {string} user_id - معرف المستخدم
 * @property {string} code - رمز الأصل
 * @property {string} name - اسم الأصل
 * @property {string} category - الفئة (building, equipment, furniture, vehicle, machinery, other)
 * @property {number} purchase_date - تاريخ الشراء
 * @property {number} purchase_cost - تكلفة الشراء
 * @property {number} salvage_value - القيمة المتبقية
 * @property {number} useful_life - العمر الإنتاجي
 * @property {string} depreciation_method - طريقة الإهلاك
 * @property {number} current_value - القيمة الحالية
 * @property {number} accumulated_depreciation - الإهلاك المتراكم
 * @property {string} account_id - معرف الحساب
 * @property {string} notes - ملاحظات
 * @property {number} is_active - حالة النشاط
 * @property {number} created_at - تاريخ الإنشاء
 * @property {number} updated_at - تاريخ التحديث
 */

// =============================================
// 12. أنواع النقد والبنوك
// =============================================

/**
 * @typedef {Object} CashAccount
 * @property {string} id - معرف الحساب
 * @property {string} user_id - معرف المستخدم
 * @property {string} code - رمز الحساب
 * @property {string} name - اسم الحساب
 * @property {string} type - النوع (cash, bank)
 * @property {string} account_id - معرف الحساب المحاسبي
 * @property {string} bank_name - اسم البنك
 * @property {string} account_number - رقم الحساب
 * @property {number} balance - الرصيد
 * @property {string} currency - العملة
 * @property {number} is_active - حالة النشاط
 * @property {number} created_at - تاريخ الإنشاء
 * @property {number} updated_at - تاريخ التحديث
 */

/**
 * @typedef {Object} Check
 * @property {string} id - معرف الشيك
 * @property {string} user_id - معرف المستخدم
 * @property {string} number - رقم الشيك
 * @property {string} type - النوع (received, issued)
 * @property {number} amount - المبلغ
 * @property {number} date - التاريخ
 * @property {number} due_date - تاريخ الاستحقاق
 * @property {string} bank_name - اسم البنك
 * @property {string} customer_id - معرف العميل
 * @property {string} supplier_id - معرف المورد
 * @property {string} cash_account_id - معرف الحساب النقدي
 * @property {string} status - الحالة (pending, cleared, bounced, void)
 * @property {string} notes - ملاحظات
 * @property {number} created_at - تاريخ الإنشاء
 * @property {number} updated_at - تاريخ التحديث
 */

// =============================================
// 13. أنواع التقارير
// =============================================

/**
 * @typedef {Object} ReportFilter
 * @property {string} from_date - تاريخ البداية
 * @property {string} to_date - تاريخ النهاية
 * @property {string} customer_id - معرف العميل
 * @property {string} account_id - معرف الحساب
 * @property {string} status - الحالة
 * @property {string} type - النوع
 */

/**
 * @typedef {Object} ReportData
 * @property {string} title - عنوان التقرير
 * @property {Array} data - بيانات التقرير
 * @property {Object} summary - الملخص
 * @property {number} total - الإجمالي
 * @property {number} count - العدد
 */

// =============================================
// 14. أنواع المزامنة المتقدمة
// =============================================

/**
 * @typedef {Object} SyncResult
 * @property {number} success - عدد العمليات الناجحة
 * @property {number} failed - عدد العمليات الفاشلة
 * @property {number} total - الإجمالي
 * @property {Array} errors - قائمة الأخطاء
 */

// =============================================
// 15. تصدير الكائن الرئيسي
// =============================================

export const types = {
  User: 'User',
  Session: 'Session',
  Customer: 'Customer',
  CustomerTier: 'CustomerTier',
  CustomerContact: 'CustomerContact',
  CustomerNote: 'CustomerNote',
  CustomerActivity: 'CustomerActivity',
  Account: 'Account',
  AccountMovement: 'AccountMovement',
  Invoice: 'Invoice',
  InvoiceItem: 'InvoiceItem',
  Payment: 'Payment',
  Product: 'Product',
  Supplier: 'Supplier',
  Employee: 'Employee',
  Payroll: 'Payroll',
  FixedAsset: 'FixedAsset',
  CashAccount: 'CashAccount',
  Check: 'Check',
  Setting: 'Setting',
  Notification: 'Notification',
  Subscription: 'Subscription',
  AuditLog: 'AuditLog',
  SyncQueue: 'SyncQueue',
  ReportFilter: 'ReportFilter',
  ReportData: 'ReportData',
  SyncResult: 'SyncResult',
};

export default types;