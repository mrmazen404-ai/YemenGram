// src/modules/settings/profile/ProfileService.js
// محرك إدارة الهوية (Sovereign Profile Engine - v1.0)
// مسؤول عن: النزاهة البيانية، تحديث الهوية، وتشفير الأفاتار

import { LocalDB } from '../../database/localDB';
import { Logger } from '../../../shared/utils/logger';
import * as Crypto from 'expo-crypto';

export const ProfileService = {
  /**
   * تحديث بيانات المستخدم الأساسية
   */
  async updateBasicInfo(userId, data) {
    try {
      console.log('👤 [ProfileService] تحديث البيانات الأساسية لـ:', userId);

      const { name, company_name } = data;

      await LocalDB.execute(
        'UPDATE user SET name = ?, company_name = ? WHERE id = ?',
        [name, company_name, userId]
      );

      await LocalDB.addAuditLog('profile_update', 'user', userId, {
        updated_fields: ['name', 'company_name'],
        timestamp: new Date().toISOString()
      });

      return { success: true };
    } catch (error) {
      Logger.error('ProfileUpdateFailed', error.message);
      throw new Error('فشل تحديث البيانات الأساسية');
    }
  },

  /**
   * معالجة وحفظ الصورة الشخصية (الأفاتار)
   */
  async saveAvatar(userId, base64Image) {
    try {
      console.log('🖼️ [ProfileService] معالجة الأفاتار السيادي...');

      // 1. تحديث الصورة في قاعدة البيانات
      await LocalDB.execute(
        'UPDATE user SET avatar = ? WHERE id = ?',
        [base64Image, userId]
      );

      // 2. توثيق الحدث أمنياً
      await LocalDB.addAuditLog('avatar_change', 'user', userId, {
        timestamp: new Date().toISOString()
      });

      return { success: true };
    } catch (error) {
      Logger.error('AvatarSaveFailed', error.message);
      throw new Error('فشل حفظ الصورة الشخصية');
    }
  },

  /**
   * التحقق من البريد الإلكتروني الجديد قبل التغيير
   */
  async validateNewEmail(email) {
    const existing = await LocalDB.queryOne('SELECT id FROM user WHERE email = ?', [email.toLowerCase()]);
    if (existing) {
      throw new Error('البريد الإلكتروني مسجل مسبقاً لمستخدم آخر');
    }
    return true;
  },

  /**
   * التحقق من أن رقم الهاتف غير مسجل لمستخدم آخر
   */
  async validateNewPhone(phone) {
    const existing = await LocalDB.queryOne('SELECT id FROM user WHERE phone = ?', [phone]);
    if (existing) {
      throw new Error('رقم الهاتف هذا مسجل مسبقاً لحساب آخر');
    }
    return true;
  },

  /**
   * التحديث النهائي للبريد الإلكتروني في قاعدة البيانات
   */
  async finalizeEmailUpdate(userId, newEmail) {
    try {
      console.log('📧 [ProfileService] تحديث البريد النهائي لـ:', userId);

      await LocalDB.execute(
        'UPDATE user SET email = ? WHERE id = ?',
        [newEmail.toLowerCase(), userId]
      );

      await LocalDB.addAuditLog('email_changed', 'user', userId, {
        new_email: newEmail.toLowerCase(),
        timestamp: new Date().toISOString()
      });

      return { success: true };
    } catch (error) {
      Logger.error('EmailUpdateFailed', error.message);
      throw new Error('فشل التحديث النهائي للبريد');
    }
  },

  /**
   * تحديث رقم الهاتف في قاعدة البيانات (سيادي)
   */
  async updatePhone(userId, newPhone) {
    try {
      console.log('📱 [ProfileService] تحديث رقم الهاتف لـ:', userId);

      await LocalDB.execute(
        'UPDATE user SET phone = ? WHERE id = ?',
        [newPhone, userId]
      );

      await LocalDB.addAuditLog('phone_changed', 'user', userId, {
        new_phone: newPhone,
        timestamp: new Date().toISOString()
      });

      return { success: true };
    } catch (error) {
      Logger.error('PhoneUpdateFailed', error.message);
      throw new Error('فشل تحديث رقم الهاتف');
    }
  }
};
