// src/models/Notification.js
// =============================================
// نموذج الإشعار (Notification Model)
// المسؤول عن إدارة الإشعارات داخل التطبيق
// =============================================

import { Model } from '@nozbe/watermelondb';
import { field, date, readonly } from '@nozbe/watermelondb/decorators';
import { Q } from '@nozbe/watermelondb';

export default class Notification extends Model {
  // ===== 1. اسم الجدول =====
  static table = 'notifications';

  // ===== 2. الحقول الأساسية =====

  // معرف المستخدم
  @field('user_id') userId;

  // نوع الإشعار (info, success, warning, error)
  @field('type') type;

  // عنوان الإشعار
  @field('title') title;

  // نص الإشعار
  @field('message') message;

  // حالة القراءة (0 = غير مقروء، 1 = مقروء)
  @field('read') read;

  // الإجراء المرتبط (مثل: 'open_invoice', 'view_customer')
  @field('action') action;

  // بيانات الإجراء (JSON)
  @field('action_data') actionData;

  // ===== 3. التواريخ التلقائية =====

  @readonly @date('created_at') createdAt;

  // ===== 4. العلاقات =====

  static associations = {
    // كل إشعار ينتمي إلى مستخدم واحد
    user: { type: 'belongs_to', key: 'user_id' },
  };

  // ===== 5. دوال مساعدة =====

  /**
   * الحصول على نوع الإشعار باللغة العربية
   * @returns {string}
   */
  getTypeArabic() {
    const types = {
      info: 'معلومات',
      success: 'نجاح',
      warning: 'تحذير',
      error: 'خطأ',
    };
    return types[this.type] || this.type;
  }

  /**
   * الحصول على لون الإشعار حسب النوع
   * @returns {string}
   */
  getTypeColor() {
    const colors = {
      info: '#2196F3',
      success: '#27AE60',
      warning: '#F39C12',
      error: '#E74C3C',
    };
    return colors[this.type] || '#6B7280';
  }

  /**
   * الحصول على أيقونة الإشعار حسب النوع
   * @returns {string}
   */
  getTypeIcon() {
    const icons = {
      info: 'information-circle',
      success: 'checkmark-circle',
      warning: 'warning',
      error: 'close-circle',
    };
    return icons[this.type] || 'notifications';
  }

  /**
   * التحقق من أن الإشعار مقروء
   * @returns {boolean}
   */
  isRead() {
    return this.read === 1 || this.read === true;
  }

  /**
   * تحديد الإشعار كمقروء
   */
  async markAsRead() {
    if (this.isRead()) return;
    await this.write(() => {
      this.read = 1;
    });
  }

  /**
   * تحديد الإشعار كغير مقروء
   */
  async markAsUnread() {
    if (!this.isRead()) return;
    await this.write(() => {
      this.read = 0;
    });
  }

  /**
   * الحصول على بيانات الإجراء
   * @returns {Object|null}
   */
  getActionData() {
    if (!this.actionData) return null;
    try {
      return JSON.parse(this.actionData);
    } catch {
      return null;
    }
  }

  /**
   * الحصول على الوقت المنقضي منذ إنشاء الإشعار
   * @returns {string}
   */
  getTimeAgo() {
    if (!this.createdAt) return '';
    const now = Date.now();
    const diff = now - this.createdAt;

    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const weeks = Math.floor(diff / (1000 * 60 * 60 * 24 * 7));
    const months = Math.floor(diff / (1000 * 60 * 60 * 24 * 30));

    if (minutes < 1) return 'الآن';
    if (minutes < 60) return `منذ ${minutes} دقيقة`;
    if (hours < 24) return `منذ ${hours} ساعة`;
    if (days < 7) return `منذ ${days} يوم`;
    if (weeks < 4) return `منذ ${weeks} أسبوع`;
    if (months < 12) return `منذ ${months} شهر`;
    return `منذ ${Math.floor(months / 12)} سنة`;
  }

  /**
   * الحصول على اسم الإشعار المعروض
   * @returns {string}
   */
  getDisplayName() {
    return `${this.title} - ${this.getTimeAgo()}`;
  }

  // ===== 6. دوال ثابتة =====

  /**
   * إنشاء إشعار جديد
   * @param {Database} database
   * @param {string} userId
   * @param {string} type
   * @param {string} title
   * @param {string} message
   * @param {string} action
   * @param {any} actionData
   * @returns {Promise<Notification>}
   */
  static async createNotification(database, userId, type, title, message, action = null, actionData = null) {
    return await database.write(async () => {
      return await database.get('notifications').create(notification => {
        notification.userId = userId;
        notification.type = type || 'info';
        notification.title = title;
        notification.message = message;
        notification.read = 0;
        notification.action = action || null;
        notification.actionData = actionData ? JSON.stringify(actionData) : null;
      });
    });
  }

  /**
   * الحصول على الإشعارات غير المقروءة
   * @param {Database} database
   * @param {string} userId
   * @returns {Promise<Notification[]>}
   */
  static async getUnread(database, userId) {
    return database.get('notifications').query(
      Q.where('user_id', userId),
      Q.where('read', false),
      Q.sortBy('created_at', Q.desc)
    ).fetch();
  }

  /**
   * الحصول على جميع إشعارات المستخدم
   * @param {Database} database
   * @param {string} userId
   * @param {number} limit
   * @returns {Promise<Notification[]>}
   */
  static async getUserNotifications(database, userId, limit = 50) {
    return database.get('notifications').query(
      Q.where('user_id', userId),
      Q.sortBy('created_at', Q.desc),
      Q.take(limit)
    ).fetch();
  }

  /**
   * تحديد جميع الإشعارات كمقروءة
   * @param {Database} database
   * @param {string} userId
   * @returns {Promise<void>}
   */
  static async markAllAsRead(database, userId) {
    const notifications = await this.getUnread(database, userId);

    await database.write(async () => {
      for (const notification of notifications) {
        await notification.update(() => {
          notification.read = 1;
        });
      }
    });
  }

  /**
   * حذف الإشعارات القديمة
   * @param {Database} database
   * @param {number} olderThanDays
   * @returns {Promise<number>}
   */
  static async deleteOldNotifications(database, olderThanDays = 30) {
    const cutoffDate = Date.now() - (olderThanDays * 24 * 60 * 60 * 1000);

    const oldNotifications = await database.get('notifications').query(
      Q.where('created_at', Q.lt(cutoffDate))
    ).fetch();

    await database.write(async () => {
      for (const notification of oldNotifications) {
        await notification.destroyPermanently();
      }
    });

    return oldNotifications.length;
  }

  /**
   * الحصول على عدد الإشعارات غير المقروءة
   * @param {Database} database
   * @param {string} userId
   * @returns {Promise<number>}
   */
  static async getUnreadCount(database, userId) {
    const notifications = await this.getUnread(database, userId);
    return notifications.length;
  }

  /**
   * حذف جميع إشعارات المستخدم
   * @param {Database} database
   * @param {string} userId
   * @returns {Promise<void>}
   */
  static async deleteAllUserNotifications(database, userId) {
    const notifications = await database.get('notifications').query(
      Q.where('user_id', userId)
    ).fetch();

    await database.write(async () => {
      for (const notification of notifications) {
        await notification.destroyPermanently();
      }
    });
  }
}