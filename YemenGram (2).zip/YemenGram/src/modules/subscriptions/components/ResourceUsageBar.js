/**
 * شريط استهلاك الموارد (Resource Usage Bar)
 */

import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function ResourceUsageBar({ label, used, limit, percentage, color = '#3B82F6' }) {
  const safePercentage = Math.min(percentage || 0, 100);

  const getProgressColor = () => {
    if (safePercentage >= 95) return '#EF4444'; // خطر
    if (safePercentage >= 80) return '#F97316'; // تحذير
    return color;
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.label}>{label}</Text>
        <Text style={styles.stats}>{used} / {limit}</Text>
      </View>

      <View style={styles.track}>
        <View
          style={[
            styles.thumb,
            {
              width: `${safePercentage}%`,
              backgroundColor: getProgressColor()
            }
          ]}
        />
      </View>

      <View style={styles.footer}>
        <Text style={styles.percentage}>{Math.round(safePercentage)}% مستخدم</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { marginBottom: 20, width: '100%' },
  header: { flexDirection: 'row-reverse', justifyContent: 'space-between', marginBottom: 8 },
  label: { fontSize: 13, fontFamily: 'Tajawal-Bold', color: '#334155' },
  stats: { fontSize: 12, fontFamily: 'Tajawal-Medium', color: '#64748B' },
  track: { height: 8, backgroundColor: '#F1F5F9', borderRadius: 10, flexDirection: 'row-reverse', overflow: 'hidden' },
  thumb: { height: '100%', borderRadius: 10 },
  footer: { marginTop: 6, alignItems: 'flex-end' },
  percentage: { fontSize: 10, fontFamily: 'Tajawal-Medium', color: '#94A3B8' }
});
