/**
 * تنبيه السيادة الرقمية (Sovereign Alert Component)
 * يظهر تحذيرات اقتراب انتهاء الاشتراك أو تجاوز الموارد
 */

import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Animated } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import useSubscriptionDunning from '../../subscriptions/hooks/useSubscriptionDunning';
import RenewalCountdown from '../../subscriptions/components/RenewalCountdown';

export default function SovereignAlert({ onAction }) {
  const { dunningInfo, subscription } = useSubscriptionDunning();
  const fadeAnim = React.useRef(new Animated.Value(0)).current;

  React.useEffect(() => {
    if (dunningInfo) {
      Animated.timing(fadeAnim, { toValue: 1, duration: 500, useNativeDriver: true }).start();
    } else {
      fadeAnim.setValue(0);
    }
  }, [dunningInfo]);

  if (!dunningInfo) return null;

  return (
    <Animated.View style={[styles.container, { opacity: fadeAnim, borderRightColor: dunningInfo.color }]}>
      <View style={styles.topRow}>
        <View style={styles.content}>
          <MaterialCommunityIcons name={dunningInfo.icon} size={20} color={dunningInfo.color} />
          <Text style={[styles.message, { color: dunningInfo.color }]}>{dunningInfo.message}</Text>
        </View>

        <TouchableOpacity style={[styles.actionBtn, { backgroundColor: dunningInfo.color }]} onPress={onAction}>
          <Text style={styles.actionText}>تجديد الآن</Text>
        </TouchableOpacity>
      </View>

      {/* دمج العداد التنازلي عند اقتراب القفل */}
      {subscription?.daysRemaining <= 7 && (
        <View style={styles.countdownWrapper}>
           <RenewalCountdown days={subscription.daysRemaining} />
        </View>
      )}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginHorizontal: 15,
    marginTop: 10,
    borderRadius: 15,
    padding: 15,
    backgroundColor: '#FFF',
    elevation: 4,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    borderRightWidth: 5,
  },
  topRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  content: {
    flex: 1,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 10,
  },
  message: {
    fontSize: 12,
    fontFamily: 'Tajawal-Bold',
    flex: 1,
    textAlign: 'right',
  },
  actionBtn: {
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 10,
  },
  actionText: {
    color: '#FFF',
    fontSize: 11,
    fontFamily: 'Tajawal-Bold',
  },
  countdownWrapper: {
    marginTop: 15,
    borderTopWidth: 1,
    borderTopColor: '#F1F5F9',
    paddingTop: 10,
  }
});
