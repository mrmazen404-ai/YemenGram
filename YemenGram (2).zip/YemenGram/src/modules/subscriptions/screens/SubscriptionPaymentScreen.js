import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import ReceiptUploadScreen from './ReceiptUploadScreen';
import PaymentMethodCard from '../components/PaymentMethodCard';
import { Colors } from '../../../shared/utils/colors';

export default function SubscriptionPaymentScreen({ route, navigation }) {
  const nav = useNavigation();
  const activeNav = navigation || nav;
  const subscriptionId = route?.params?.subscriptionId || 'manual-subscription';

  const handleBack = () => {
    if (activeNav.canGoBack()) {
      activeNav.goBack();
    } else {
      activeNav.navigate('SubscriptionOverview');
    }
  };

  const accounts = [
    { type: 'bank', bankName: 'بنك الكريمي الإسلامي', accountName: 'مؤسسة يمن جرام الرقمية', accountNumber: '123456789', color: '#006135' },
    { type: 'wallet', bankName: 'محفظة جوالي (جوالي)', accountName: 'YG ENTERPRISE', accountNumber: '777881496', color: '#004A99' },
    { type: 'cash', bankName: 'التحويل المباشر (صرافة)', accountName: 'أحمد صالح (مدير مالي)', accountNumber: 'YG-OFFICE-01', color: Colors.gold },
  ];

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.title}>بوابة الدفع السيادية</Text>
      <Text style={styles.subtitle}>يرجى التحويل لأحد الحسابات التالية ثم إرفاق صورة الإيصال.</Text>

      <View style={styles.methodList}>
        {accounts.map((acc, i) => (
          <PaymentMethodCard key={i} {...acc} />
        ))}
      </View>

      <View style={styles.uploadSection}>
         <Text style={styles.sectionTitle}>تأكيد العملية (رفع الإيصال)</Text>
         <ReceiptUploadScreen
            route={{ params: { subscriptionId } }}
            navigation={activeNav}
          />
      </View>

      <TouchableOpacity style={styles.backButton} onPress={handleBack}>
        <Text style={styles.backText}>إلغاء والعودة</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC' },
  content: { padding: 20, paddingTop: 60 },
  title: { fontSize: 26, fontFamily: 'Tajawal-Bold', marginBottom: 8, color: Colors.navy, textAlign: 'right' },
  subtitle: { color: '#64748B', fontSize: 13, fontFamily: 'Tajawal-Medium', marginBottom: 25, textAlign: 'right', lineHeight: 20 },
  methodList: { marginBottom: 30 },
  uploadSection: {
    backgroundColor: '#FFF',
    borderRadius: 25,
    padding: 20,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    marginBottom: 20,
  },
  sectionTitle: { fontSize: 15, fontFamily: 'Tajawal-Bold', color: Colors.navy, marginBottom: 15, textAlign: 'right' },
  backButton: { marginBottom: 30, alignItems: 'center', paddingVertical: 15, borderRadius: 15, backgroundColor: '#F1F5F9' },
  backText: { color: '#64748B', fontFamily: 'Tajawal-Bold', fontSize: 14 },
});
