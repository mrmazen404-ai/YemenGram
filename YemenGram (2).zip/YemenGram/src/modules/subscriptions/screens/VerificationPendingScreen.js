/**
 * شاشة بانتظار التحقق السيادية (Sovereign Verification Pending)
 * تعرض حالة الطلب المعلق مع أنيميشن "النبض" للهيبة والانتظار النشط
 */

import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Animated, ActivityIndicator, Alert, SafeAreaView } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';
import LocalDB from '../../database/localDB';
import { Colors } from '../../../shared/utils/colors';

export default function VerificationPendingScreen() {
  const navigation = useNavigation();
  const [subscription, setSubscription] = React.useState(null);
  const [loading, setLoading] = React.useState(true);

  // ===== Animations =====
  const pulseAnim = useRef(new Animated.Value(1)).current;

  const loadData = async () => {
    try {
      setLoading(true);
      const user = await LocalDB.getUser();
      if (!user?.id) return;

      const row = await LocalDB.queryOne(
        'SELECT * FROM subscriptions WHERE user_id = ? AND status = ? ORDER BY created_at DESC LIMIT 1',
        [user.id, 'VERIFICATION_PENDING']
      );
      setSubscription(row);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();

    // تشغيل أنيميشن النبض (Pulse)
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.2, duration: 1000, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 1000, useNativeDriver: true }),
      ])
    ).start();
  }, []);

  const checkStatus = async () => {
    // محاكاة أو طلب فحص من السيرفر (قريباً عبر SyncWorker)
    setLoading(true);
    setTimeout(() => {
      loadData();
      Alert.alert('تحديث الحالة', 'جاري المزامنة مع الإدارة، يرجى الانتظار قليلاً.');
    }, 1500);
  };

  const handleBack = () => {
    if (navigation.canGoBack()) {
      navigation.goBack();
    } else {
      navigation.navigate('DashboardMain');
    }
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={Colors.navy} />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      {/* 🛡️ الهيدر */}
      <View style={styles.headerNav}>
        <TouchableOpacity style={styles.backBtn} onPress={handleBack}>
           <Ionicons name="chevron-forward" size={24} color={Colors.navy} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>بانتظار التحقق</Text>
        <View style={{ width: 40 }} />
      </View>

      <View style={styles.content}>
        {/* 🔵 النبض السيادي */}
        <View style={styles.pulseContainer}>
        <Animated.View style={[styles.pulseCircle, { transform: [{ scale: pulseAnim }] }]} />
        <View style={styles.iconCircle}>
           <MaterialCommunityIcons name="clock-fast" size={50} color="#FFF" />
        </View>
      </View>

      <Text style={styles.title}>طلبك قيد التدقيق السيادي</Text>

      <View style={styles.infoCard}>
        <Text style={styles.infoText}>باقة الطلب: <Text style={styles.bold}>{subscription?.plan?.toUpperCase() || 'Starter'}</Text></Text>
        <Text style={styles.infoText}>تاريخ الطلب: <Text style={styles.bold}>{subscription?.created_at ? new Date(parseInt(subscription.created_at)).toLocaleDateString('ar-EG') : '---'}</Text></Text>
        <Text style={styles.statusNote}>
          يتم الآن مراجعة إيصال الدفع الخاص بك من قبل الإدارة. تستغرق العملية عادة من 2 إلى 6 ساعات عمل.
        </Text>
      </View>

      <View style={styles.actionContainer}>
        <TouchableOpacity style={styles.refreshBtn} onPress={checkStatus}>
           <Ionicons name="refresh" size={20} color="#FFF" />
           <Text style={styles.btnText}>تحديث الحالة</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.navigate('DashboardMain')}>
           <Text style={styles.backText}>العودة للرئيسية</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.footer}>
         <MaterialCommunityIcons name="shield-check" size={14} color="#94A3B8" />
         <Text style={styles.footerText}>نظام التحقق المحمي - YemenGram</Text>
      </View>
    </View>
     </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  headerNav: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingVertical: 15, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#F1F5F9' },
  backBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: '#F8FAFC', justifyContent: 'center', alignItems: 'center' },
  headerTitle: { fontSize: 18, fontFamily: 'Tajawal-Bold', color: Colors.navy },
  content: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 30,
  },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  pulseContainer: {
    width: 120,
    height: 120,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 40,
  },
  pulseCircle: {
    position: 'absolute',
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: 'rgba(59, 130, 246, 0.2)', // أزرق سيادي شفاف
  },
  iconCircle: {
    width: 90,
    height: 100,
    borderRadius: 45,
    backgroundColor: '#3B82F6',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 10,
    shadowColor: '#3B82F6',
    shadowOpacity: 0.3,
    shadowRadius: 15,
  },
  title: {
    fontSize: 22,
    fontFamily: 'Tajawal-Bold',
    color: '#0F172A',
    textAlign: 'center',
    marginBottom: 20,
  },
  infoCard: {
    backgroundColor: '#FFF',
    borderRadius: 20,
    padding: 20,
    width: '100%',
    borderWidth: 1,
    borderColor: '#E2E8F0',
    marginBottom: 30,
  },
  infoText: {
    fontSize: 14,
    fontFamily: 'Tajawal-Medium',
    color: '#64748B',
    textAlign: 'right',
    marginBottom: 10,
  },
  bold: { color: '#0F172A', fontFamily: 'Tajawal-Bold' },
  statusNote: {
    fontSize: 13,
    fontFamily: 'Tajawal-Medium',
    color: '#334155',
    textAlign: 'center',
    marginTop: 15,
    lineHeight: 20,
    borderTopWidth: 1,
    borderTopColor: '#F1F5F9',
    paddingTop: 15,
  },
  actionContainer: {
    width: '100%',
    gap: 15,
  },
  refreshBtn: {
    backgroundColor: Colors.navy,
    borderRadius: 14,
    paddingVertical: 16,
    flexDirection: 'row-reverse',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 10,
  },
  btnText: { color: '#FFF', fontFamily: 'Tajawal-Bold', fontSize: 15 },
  backBtn: {
    paddingVertical: 10,
    alignItems: 'center',
  },
  backText: { color: '#94A3B8', fontFamily: 'Tajawal-Medium', fontSize: 14 },
  footer: {
    position: 'absolute',
    bottom: 40,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 5,
    opacity: 0.5,
  },
  footerText: { fontSize: 10, color: '#0F172A', fontFamily: 'Tajawal-Medium' }
});
