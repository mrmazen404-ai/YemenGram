import { LocalDB } from '../../database/localDB';
import { STATES } from './SubscriptionEngine';

const ACTIVE = new Set([STATES.TRIAL_ACTIVE, STATES.ACTIVE_FULL]);
const READ_ONLY = new Set([STATES.EXPIRED_GRACE, STATES.TRIAL_EXPIRED, STATES.SECURITY_SUSPENDED, STATES.CANCELLED, STATES.UNSUBSCRIBED]);

const mapRow = (row) => {
  if (!row) return null;
  const now = Date.now();
  const state = row.status;
  const expired = row.end_date != null && Number(row.end_date) <= now;
  const effectiveReadOnly = READ_ONLY.has(state) || expired || state === STATES.RESOURCES_EXCEEDED;
  return {
    ...row,
    userId: row.user_id,
    startDate: row.start_date,
    endDate: row.end_date,
    trialEndDate: row.trial_end_date,
    gracePeriodEnd: row.grace_period_end,
    maxDevices: row.max_devices,
    registeredDevices: row.registered_devices,
    maxCustomers: row.max_customers,
    maxInvoices: row.max_invoices,
    maxStorage: row.max_storage,
    isActiveSubscription: () => ACTIVE.has(state) && !expired,
    isValid: () => ACTIVE.has(state) && !expired,
    isReadOnly: () => effectiveReadOnly,
    getDaysRemaining: () => row.end_date ? Math.max(0, Math.ceil((Number(row.end_date) - now) / 86400000)) : (state === STATES.ACTIVE_FULL ? 99999 : 0),
    getPlanArabic: () => ({ trial: 'تجريبي', monthly: 'شهري', annual: 'سنوي', enterprise: 'مؤسسي', free: 'مجاني' }[row.plan] || row.plan),
  };
};

export const SubscriptionService = {
  async getActiveSubscription(userId) {
    if (!userId) return null;
    const row = await LocalDB.queryOne(
      `SELECT * FROM subscriptions
       WHERE user_id = ? AND status NOT IN (?, ?)
       ORDER BY CASE WHEN status IN (?, ?) THEN 0 ELSE 1 END, created_at DESC LIMIT 1`,
      [userId, STATES.UNSUBSCRIBED, STATES.CANCELLED, STATES.ACTIVE_FULL, STATES.TRIAL_ACTIVE]
    );
    return mapRow(row);
  },

  async getSubscriptionById(subscriptionId, userId) {
    if (!subscriptionId) return null;
    const row = await LocalDB.queryOne(
      'SELECT * FROM subscriptions WHERE id = ? AND user_id = ?',
      [subscriptionId, userId]
    );
    return mapRow(row);
  },

  async checkCurrentValidity(userId) {
    const sub = await this.getActiveSubscription(userId);
    return Boolean(sub?.isValid?.());
  },

  async canWrite(userId) {
    const sub = await this.getActiveSubscription(userId);
    return Boolean(sub && !sub.isReadOnly() && sub.isValid());
  },
};

export default SubscriptionService;
