// src/modules/auth/screens/PIN/PinSetupDialog.js
// واجهة إعداد الرمز السري والأمان الحيوي (Sleek Luxurious Edition)

import React, { useState, useRef, useEffect, memo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Modal,
  Animated,
  Dimensions,
  Platform,
  StatusBar,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as LocalAuthentication from 'expo-local-authentication';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import { Colors } from '../../../../shared/utils/colors';
import { useAuth } from '../../../../shared/contexts/AuthContext';
import { SecurityManager } from '../../../../shared/utils/security';
import Loading from '../../../../shared/components/Loading';

const { width, height } = Dimensions.get('window');
const PIN_LENGTH = 6;

const PinSetupDialog = memo(({ visible, onComplete, onSkip }) => {
  const { setupPIN, enableBiometric } = useAuth();

  // ===== State =====
  const [step, setStep] = useState('create'); // 'create', 'confirm', 'biometric'
  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [error, setError] = useState({ active: false, message: '' });
  const [loading, setLoading] = useState(false);
  const [biometricInfo, setBiometricInfo] = useState({ supported: false, type: '', typeName: '' });

  // ===== Animations =====
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(height * 0.05)).current;
  const shakeAnim = useRef(new Animated.Value(0)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    if (visible) {
      checkBiometricSupport();
      animateIn();
    } else {
      resetState();
    }
  }, [visible]);

  const checkBiometricSupport = async () => {
    try {
      const [hasHardware, isEnrolled, types] = await Promise.all([
        LocalAuthentication.hasHardwareAsync(),
        LocalAuthentication.isEnrolledAsync(),
        LocalAuthentication.supportedAuthenticationTypesAsync(),
      ]);

      if (hasHardware && isEnrolled) {
        let type = 'fingerprint';
        let typeName = 'بصمة الإصبع';
        if (types.includes(LocalAuthentication.AuthenticationType.FACIAL_RECOGNITION)) {
          type = 'face';
          typeName = 'بصمة الوجه';
        }
        setBiometricInfo({ supported: true, type, typeName });
      }
    } catch (e) {}
  };

  const animateIn = () => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 300, useNativeDriver: true }),
      Animated.spring(slideAnim, { toValue: 0, tension: 80, friction: 12, useNativeDriver: true }),
    ]).start();
  };

  const resetState = () => {
    setStep('create');
    setPin('');
    setConfirmPin('');
    setError({ active: false, message: '' });
  };

  const triggerHaptic = (type = 'selection') => {
    if (Platform.OS === 'web') return;
    if (type === 'error') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    else if (type === 'success') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    else Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const doShake = () => {
    triggerHaptic('error');
    Animated.sequence([
      Animated.timing(shakeAnim, { toValue: 10, duration: 40, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -10, duration: 40, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 5, duration: 40, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 0, duration: 40, useNativeDriver: true }),
    ]).start();
  };

  const handleKeyPress = (num) => {
    if (loading) return;
    triggerHaptic();

    if (num === 'delete') {
      if (step === 'create') setPin(p => p.slice(0, -1));
      else if (step === 'confirm') setConfirmPin(p => p.slice(0, -1));
      setError({ active: false, message: '' });
      return;
    }

    if (step === 'create') {
      const nextPin = pin + num;
      if (nextPin.length <= PIN_LENGTH) setPin(nextPin);
      if (nextPin.length === PIN_LENGTH) {
        if (SecurityManager.validatePinStrength(nextPin)) {
          triggerHaptic('success');
          setTimeout(() => setStep('confirm'), 300);
        } else {
          setPin('');
          doShake();
          setError({ active: true, message: 'رمز سهل، اختر رمزاً أكثر تعقيداً' });
        }
      }
    } else if (step === 'confirm') {
      const nextConfirm = confirmPin + num;
      if (nextConfirm.length <= PIN_LENGTH) setConfirmPin(nextConfirm);
      if (nextConfirm.length === PIN_LENGTH) {
        if (nextConfirm === pin) {
          savePinAndProceed();
        } else {
          setConfirmPin('');
          doShake();
          setError({ active: true, message: 'الرمزان غير متطابقين' });
        }
      }
    }
  };

  const savePinAndProceed = async () => {
    setLoading(true);
    try {
      await setupPIN(pin);
      triggerHaptic('success');
      if (biometricInfo.supported) {
        setStep('biometric');
        startPulse();
      } else {
        onComplete();
      }
    } catch (e) {
      setError({ active: true, message: 'فشل حفظ الرمز' });
    } finally {
      setLoading(false);
    }
  };

  const handleBiometricEnable = async () => {
    const result = await LocalAuthentication.authenticateAsync({ promptMessage: `تفعيل ${biometricInfo.typeName}` });
    if (result.success) {
      await enableBiometric();
      triggerHaptic('success');
      onComplete();
    }
  };

  const startPulse = () => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.1, duration: 800, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 800, useNativeDriver: true }),
      ])
    ).start();
  };

  const renderDot = (index) => {
    const currentLen = step === 'create' ? pin.length : confirmPin.length;
    return (
      <View key={index} style={[styles.dot, currentLen > index && styles.dotFilled, error.active && currentLen > index && styles.dotError]} />
    );
  };

  if (step === 'biometric') {
    return (
      <Modal visible={visible} transparent animationType="fade" statusBarTranslucent>
        <View style={styles.overlay}>
          <View style={styles.modalContainer}>
            <Animated.View style={[styles.bioIconCircle, { transform: [{ scale: pulseAnim }] }]}>
              <LinearGradient colors={[Colors.navy, '#1B365D']} style={styles.bioGradient}>
                <Ionicons name={biometricInfo.type === 'face' ? 'scan' : 'finger-print'} size={40} color={Colors.gold} />
              </LinearGradient>
            </Animated.View>
            <Text style={styles.title}>تفعيل الحماية الحيوية</Text>
            <Text style={styles.subtitle}>ننصح بتفعيل {biometricInfo.typeName} لوصول أسرع وأكثر أماناً لبياناتك.</Text>
            <TouchableOpacity style={styles.mainBtn} onPress={handleBiometricEnable}>
              <LinearGradient colors={[Colors.gold, '#D4A853']} style={styles.btnGradient} start={{x:0, y:0}} end={{x:1, y:1}}>
                <Text style={styles.mainBtnText}>تفعيل الآن</Text>
              </LinearGradient>
            </TouchableOpacity>
            <TouchableOpacity style={styles.secondaryBtn} onPress={onComplete}>
              <Text style={styles.secondaryBtnText}>تفعيل لاحقاً</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    );
  }

  return (
    <Modal visible={visible} transparent animationType="none" statusBarTranslucent>
      <View style={styles.overlay}>
        <Animated.View style={[styles.modalContainer, { opacity: fadeAnim, transform: [{ translateY: slideAnim }, { translateX: shakeAnim }] }]}>
          <View style={styles.header}>
            <TouchableOpacity onPress={onSkip} style={styles.closeBtn}><Ionicons name="close" size={18} color={Colors.gray} /></TouchableOpacity>
            <Text style={styles.headerTitle}>أمان النظام</Text>
            <View style={{ width: 32 }} />
          </View>
          <View style={styles.content}>
            <View style={styles.iconCircle}><Ionicons name={step === 'create' ? "shield-half" : "lock-open"} size={24} color={Colors.navy} /></View>
            <Text style={styles.title}>{step === 'create' ? 'إنشاء رمز PIN' : 'تأكيد الرمز'}</Text>
            <View style={styles.dotsRow}>{Array.from({ length: PIN_LENGTH }).map((_, i) => renderDot(i))}</View>
            <View style={styles.errorBox}>{error.active && <Text style={styles.errorText}>{error.message}</Text>}</View>
            <View style={styles.keypad}>
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, '', 0, 'delete'].map((k, i) => (
                <TouchableOpacity key={i} style={[styles.key, k === 'delete' && styles.keyDelete, k === '' && styles.keyEmpty]} onPress={() => k !== '' && handleKeyPress(k)} disabled={k === ''}>
                  {k === 'delete' ? <Ionicons name="backspace-outline" size={20} color={Colors.dark} /> : <Text style={styles.keyText}>{k}</Text>}
                </TouchableOpacity>
              ))}
            </View>
          </View>
          <View style={styles.footer}><Text style={styles.footerText}>🛡️ اليمن جرام - حماية مالية مشفرة</Text></View>
        </Animated.View>
      </View>
      {loading && <Loading visible={true} />}
    </Modal>
  );
});

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
  modalContainer: { width: width * 0.85, maxWidth: 340, backgroundColor: '#FFFFFF', borderRadius: 28, padding: 18, elevation: 20 },
  header: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  closeBtn: { width: 32, height: 32, borderRadius: 10, backgroundColor: '#F8FAFC', justifyContent: 'center', alignItems: 'center' },
  headerTitle: { fontSize: 13, fontFamily: 'Tajawal-Bold', color: Colors.gray },
  content: { alignItems: 'center' },
  iconCircle: { width: 54, height: 54, borderRadius: 16, backgroundColor: '#F1F5F9', justifyContent: 'center', alignItems: 'center', marginBottom: 8 },
  title: { fontSize: 18, fontFamily: 'Tajawal-Bold', color: Colors.dark, marginBottom: 15 },
  dotsRow: { flexDirection: 'row-reverse', gap: 10, marginBottom: 8 },
  dot: { width: 12, height: 12, borderRadius: 6, borderWidth: 1.5, borderColor: '#E2E8F0' },
  dotFilled: { backgroundColor: Colors.navy, borderColor: Colors.navy },
  dotError: { backgroundColor: Colors.red, borderColor: Colors.red },
  errorBox: { height: 20, justifyContent: 'center', marginBottom: 10 },
  errorText: { color: Colors.red, fontSize: 10, fontFamily: 'Tajawal-Bold' },
  keypad: { width: '100%', flexDirection: 'row-reverse', flexWrap: 'wrap', justifyContent: 'center', gap: 10 },
  key: { width: '28%', height: 54, borderRadius: 14, backgroundColor: '#F8FAFC', justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: '#F1F5F9' },
  keyEmpty: { backgroundColor: 'transparent', borderWidth: 0 },
  keyDelete: { backgroundColor: '#FFF5F5' },
  keyText: { fontSize: 22, fontFamily: 'Tajawal-Bold', color: Colors.navy },
  footer: { marginTop: 15, alignItems: 'center', borderTopWidth: 1, borderTopColor: '#F1F5F9', paddingTop: 10 },
  footerText: { fontSize: 9, fontFamily: 'Tajawal-Medium', color: Colors.placeholder },
  bioIconCircle: { width: 100, height: 100, borderRadius: 50, padding: 8, backgroundColor: '#F1F5F9', alignSelf: 'center', marginBottom: 20 },
  bioGradient: { flex: 1, borderRadius: 42, justifyContent: 'center', alignItems: 'center' },
  mainBtn: { width: '100%', height: 50, borderRadius: 14, overflow: 'hidden', marginTop: 15 },
  btnGradient: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  mainBtnText: { fontSize: 14, fontFamily: 'Tajawal-Bold', color: Colors.white },
  secondaryBtn: { padding: 12, alignItems: 'center' },
  secondaryBtnText: { fontSize: 13, fontFamily: 'Tajawal-Medium', color: Colors.gray },
});

export default PinSetupDialog;
