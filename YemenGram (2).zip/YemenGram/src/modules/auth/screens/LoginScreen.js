// src/modules/auth/screens/LoginScreen.js
// شاشة تسجيل الدخول - يمن جرام

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Device from 'expo-device';
import { Colors } from '../../../shared/utils/colors';
import Input from '../../../shared/components/Input';
import Button from '../../../shared/components/Button';
import Toast from '../../../shared/components/Toast';
import Modal from '../../../shared/components/Modal';
import SecurityLoading from '../../../shared/components/SecurityLoading';
import { useAuth } from '../../../shared/contexts/AuthContext';
import { ImageBackground } from 'react-native';

const LOGO = require('../../../shared/assets/images/icon.png');
const HEADER_BG = require('../../../shared/assets/images/hint.png');

// =============================================
// 1. دوال المساعدة والتعقيم
// =============================================
const sanitizeEmail = (email) => email.trim().toLowerCase().replace(/\s/g, '').replace(/[<>{}()]/g, '');
const sanitizePhone = (phone) => phone.trim().replace(/[\s\-\(\)\+]/g, '').replace(/[^0-9]/g, '');
const sanitizeInput = (input) => input.trim().replace(/[<>{}()'"]/g, '');

const getLoginType = (value) => {
  const cleanInput = value.trim().replace(/[<>{}()'"]/g, '');

  // البريد الإلكتروني
  if (/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(cleanInput)) return 'email';

  // تطبيع وتحقق رقم الهاتف
  let phoneClean = cleanInput.replace(/[\s\-\(\)\+]/g, '').replace(/[^0-9]/g, '');
  if (phoneClean.startsWith('967')) phoneClean = phoneClean.substring(3);
  if (phoneClean.startsWith('00967')) phoneClean = phoneClean.substring(5);

  if (/^(77|73|71|70|78)\d{7}$/.test(phoneClean) || /^0\d{7,8}$/.test(phoneClean)) return 'phone';

  return null;
};

const validateIdentifier = (value) => {
  if (!value) return 'البريد الإلكتروني أو رقم الهاتف مطلوب';
  const clean = sanitizeInput(value);
  const type = getLoginType(clean);
  if (!type) return 'أدخل بريداً إلكترونياً أو رقم هاتف صحيح';
  return null;
};

// =============================================
// 2. المكون الرئيسي
// =============================================
export default function LoginScreen({ navigation }) {
  const { login, isOnline, reAuthRequired, user: contextUser } = useAuth();

  const [emailOrPhone, setEmailOrPhone] = useState(reAuthRequired ? contextUser?.email || contextUser?.phone || '' : '');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [loadingText, setLoadingStatus] = useState('جاري تسجيل الدخول...');
  const [stayLoggedIn, setStayLoggedIn] = useState(true);
  const [toast, setToast] = useState({ visible: false, message: '', type: 'error' });
  const [secureText, setSecureText] = useState(true);
  const [deviceInfo, setDeviceInfo] = useState({});
  const [securityThreat, setSecurityThreat] = useState(null); // ✅ حالة تهديد النزاهة
  const [lockUntil, setLockUntil] = useState(0); // وقت انتهاء القفل
  const [remainingTime, setRemainingTime] = useState(0); // الثواني المتبقية

  // ✅ مؤقت تنازلي للعد التنازلي للقفل
  useEffect(() => {
    let interval;
    if (lockUntil > Date.now()) {
      interval = setInterval(() => {
        const diff = Math.ceil((lockUntil - Date.now()) / 1000);
        if (diff <= 0) {
          setLockUntil(0);
          setRemainingTime(0);
          clearInterval(interval);
        } else {
          setRemainingTime(diff);
        }
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [lockUntil]);

  const formatLockTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  useEffect(() => {
    const getDeviceInfo = async () => {
      try {
        setDeviceInfo({
          deviceName: Device.deviceName || 'Unknown Device',
          os: `${Device.osName || ''} ${Device.osVersion || ''}`.trim(),
        });
      } catch (e) {}
    };
    getDeviceInfo();
  }, []);

  const handleLogin = async () => {
    const idErr = validateIdentifier(emailOrPhone);
    if (idErr) { setErrors({ identifier: idErr }); return; }

    setLoading(true);
    setLoadingStatus('جاري فحص بصمة الجهاز...');

    try {
      // ✅ تسلسل أمني رسمي
      setTimeout(() => setLoadingStatus('جاري التحقق من البيانات...'), 800);
      setTimeout(() => setLoadingStatus('جاري تأمين الاتصال...'), 1600);

      await new Promise(resolve => setTimeout(resolve, 2500));

      const cleanInput = sanitizeInput(emailOrPhone);
      const loginType = getLoginType(cleanInput);
      const cleanIdentifier = loginType === 'email' ? sanitizeEmail(cleanInput) : sanitizePhone(cleanInput);

      await login(cleanIdentifier, password);
    } catch (error) {
      if (error.lockUntil) {
        setLockUntil(error.lockUntil);
      }

      if (error.code === 'DEVICE_MISMATCH') {
         setSecurityThreat('device_mismatch');
      } else {
         setToast({ visible: true, message: error.message || 'بيانات الدخول غير صحيحة', type: 'error' });
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView style={styles.root} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>

      {/* ✅ تفعيل دايلوج التحقق الأمني الفخم */}
      <SecurityLoading visible={loading} status={loadingText} />

      {/* ✅ مودال تحذير أمني */}
      <Modal
        visible={!!securityThreat}
        type="danger"
        title={securityThreat === 'device_mismatch' ? "خطأ في تسجيل الدخول" : "تنبيه أمني"}
        message={securityThreat === 'security_threat'
          ? "تم رصد بيئة تشغيل غير آمنة. لا يسمح بالعمليات المالية من هذا الجهاز."
          : securityThreat === 'device_mismatch'
          ? "هذا الحساب مرتبط بجهاز آخر. لا يسمح بالدخول من أجهزة متعددة حماية لبياناتك المالية."
          : "تم رصد تلاعب في ملفات النظام. تم إبطال الجلسة لحمايتك."}
        confirmText="موافق"
        onConfirm={() => setSecurityThreat(null)}
        hideCancel
      />

      <Toast visible={toast.visible} message={toast.message} type={toast.type} onHide={() => setToast(p => ({ ...p, visible: false }))} />

      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
        <ImageBackground
          source={HEADER_BG}
          style={styles.headerSection}
          imageStyle={styles.headerImage}
        >
          <View style={styles.logoWrapper}>
            <Image source={LOGO} style={styles.logo} resizeMode="contain" />
          </View>
          <View style={styles.welcome}>
            <Text style={styles.welcomeTitle}>
              {reAuthRequired ? `مرحباً، ${contextUser?.name}` : 'مرحباً بعودتك'}
            </Text>
            <Text style={styles.welcomeSub}>
              {reAuthRequired ? 'يرجى تأكيد ميثاقك للمتابعة' : 'سجل الدخول لمتابعة أعمالك'}
            </Text>
          </View>
        </ImageBackground>

        <View style={styles.formCard}>
          {/* ✅ تنبيه انتهاء الجلسة */}
          {reAuthRequired && (
            <View style={styles.reAuthAlert}>
              <Ionicons name="time-outline" size={18} color={Colors.gold} />
              <Text style={styles.reAuthAlertText}>
                انتهت صلاحية الجلسة. يرجى إدخال كلمة المرور للمتابعة.
              </Text>
            </View>
          )}

          {/* ✅ تنبيه السيادة الشبكية */}
          {!isOnline && (
            <View style={styles.networkAlert}>
              <Ionicons name="cloud-offline-outline" size={18} color={Colors.red} />
              <Text style={styles.networkAlertText}>
                 لا يوجد اتصال بالإنترنت
              </Text>
            </View>
          )}

          {/* ✅ تنبيه القفل الأمني */}
          {remainingTime > 0 && (
            <View style={styles.lockAlert}>
              <Ionicons name="shield-half-outline" size={20} color={Colors.red}  />
              <Text style={styles.lockAlertText}>
                النظام في وضع الحماية. يرجى الانتظار {formatLockTime(remainingTime)}
              </Text>
            </View>
          )}

          <Input
            label="البريد الإلكتروني أو الهاتف"
            icon="person-outline"
            value={emailOrPhone}
            onChangeText={(v) => { setEmailOrPhone(v); setErrors({}); }}
            keyboardType="email-address"
            autoCapitalize="none"
            error={errors.identifier}
            editable={!reAuthRequired && remainingTime <= 0} // قفل الحقل إذا كان إعادة مصادقة
          />

          <Input
            label="كلمة المرور"
            icon="lock-closed-outline"
            value={password}
            onChangeText={(v) => { setPassword(v); setErrors({}); }}
            secureTextEntry
            error={errors.password}
            editable={remainingTime <= 0} // تعطيل الحقل أثناء القفل
          />

          <View style={styles.stayLoggedRow}>
            <TouchableOpacity
              style={styles.checkboxContainer}
              onPress={() => setStayLoggedIn(!stayLoggedIn)}
              disabled={remainingTime > 0}
            >
              <Ionicons name={stayLoggedIn ? "checkbox" : "square-outline"} size={20} color={stayLoggedIn ? Colors.navy : Colors.gray} />
              <Text style={styles.checkboxLabel}>البقاء متصلاً</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.forgotLink}
              onPress={() => navigation.navigate('ForgotPassword')}
              disabled={remainingTime > 0}
            >
              <Text style={styles.forgotText}>نسيت كلمة المرور؟</Text>
            </TouchableOpacity>
          </View>

          <Button
            title={!isOnline ? 'في انتظار الشبكة...' : (remainingTime > 0 ? `محظور (انتظر ${formatLockTime(remainingTime)})` : (loading ? loadingText : 'تسجيل الدخول'))}
            onPress={handleLogin}
            loading={loading}
            disabled={loading || remainingTime > 0 || !isOnline} // تعطيل الزر تماماً
            style={(remainingTime > 0 || !isOnline) ? { backgroundColor: Colors.gray } : {}}
          />
        </View>

        <View style={styles.footer}>
          <Text style={styles.footerText}>ليس لديك حساب؟</Text>
          <TouchableOpacity onPress={() => navigation.navigate('Register')}>
            <Text style={styles.linkText}>إنشاء حساب جديد</Text>
          </TouchableOpacity>
        </View>

        <Text style={styles.bottomText}>YemenGram © 2026</Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: Colors.lightGray },
  container: { flexGrow: 1, justifyContent: 'center', paddingHorizontal: 20, paddingTop: 10, paddingBottom: 30 },
  headerSection: {
    alignItems: 'center',
    marginBottom: 10,
    paddingVertical: 10,
    width: '112%',
    opacity: 1, // تعتيم خفيف للهيبة والوضوح
    alignSelf: 'center',
    overflow: 'hidden',
    borderBottomLeftRadius: 50,
    borderBottomRightRadius:50,
  },
  headerImage: {
    opacity: 0.9, // تعتيم خفيف للهيبة والوضوح
        resizeMode: 'cover',

    resizeMode: 'center',
    borderRadius:1
  },
  logoWrapper: { width: 260, height: 190, backgroundColor: Colors.white, justifyContent: 'center', alignItems: 'center', borderRadius: 16, elevation: 4, marginBottom: 4 },
  logo: { width: 320, height: 190, borderRadius: 12 },
  welcomeTitle: { fontSize: 24, fontFamily: 'Tajawal-Bold', color: Colors.dark, textAlign: 'right' },
  welcomeSub: { fontSize: 13, fontFamily: 'Tajawal-Regular', color: Colors.gray, textAlign: 'right', marginTop: 4 },
  reAuthAlert: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    backgroundColor: '#FFFCF0',
    padding: 10,
    borderRadius: 12,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: '#FEF3C7',
    gap: 8,
  },
  reAuthAlertText: {
    fontSize: 11,
    fontFamily: 'Tajawal-Medium',
    color: Colors.gold,
    flex: 1,
    textAlign: 'right',
  },
  networkAlert: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    backgroundColor: '#FFF5F5',
    padding: 10,
    borderRadius: 12,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: '#FED7D7',
    gap: 8,
  },
  networkAlertText: {
    fontSize: 12,
    fontFamily: 'Tajawal-Bold',
    color: Colors.red,
    flex: 1,
    textAlign: 'center',
  },
  lockAlert: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    backgroundColor: '#FFF5F5',
    padding: 12,
    borderRadius: 12,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#FED7D7',
    gap: 8
  },
  lockAlertText: { fontSize: 12, fontFamily: 'Tajawal-Bold', color: Colors.red, flex: 1, textAlign: 'center' },
  formCard: { width: '100%', backgroundColor: Colors.white, borderRadius: 20, padding: 20, elevation: 3 },
  forgotLink: { alignSelf: 'flex-end', marginTop: 6, marginBottom: 16, paddingVertical: 4 },
  forgotText: { fontSize: 13, fontFamily: 'Tajawal-Medium', color: Colors.navy  },
  stayLoggedRow: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  checkboxContainer: { flexDirection: 'row-reverse', alignItems: 'center', gap: 4 },
  checkboxLabel: { fontSize: 12, fontFamily: 'Tajawal-Medium', color: Colors.gray },
  footer: { flexDirection: 'row-reverse', marginTop: 24, alignItems: 'center', justifyContent: 'center' },
  footerText: { fontSize: 13, fontFamily: 'Tajawal-Regular', color: Colors.gray },
  linkText: { fontSize: 13, fontFamily: 'Tajawal-Bold', color: Colors.navy, marginStart: 6 },
  bottomText: { marginTop: 20, fontSize: 10, fontFamily: 'Tajawal-Regular', color: Colors.placeholder, textAlign: 'center' },
  welcome: {}
});
