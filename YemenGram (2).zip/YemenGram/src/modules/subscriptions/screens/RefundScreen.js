import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, TextInput, ScrollView, ActivityIndicator } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import LocalDB from '../../database/localDB';
import SubscriptionCoreService from '../services/SubscriptionCoreService';
import { Colors } from '../../../shared/utils/colors';

export default function RefundScreen() {
  const navigation = useNavigation(); const [reason, setReason] = React.useState(''); const [loading, setLoading] = React.useState(false);
  const submit = async () => {
    if (reason.trim().length < 10) return Alert.alert('تنبيه', 'يرجى كتابة سبب مفصل (10 أحرف على الأقل).');
    try {
      setLoading(true); const user = await LocalDB.getUser(); if (!user?.id) throw new Error('يجب تسجيل الدخول.');
      const sub = await LocalDB.queryOne(`SELECT * FROM subscriptions WHERE user_id = ? AND status IN ('ACTIVE_FULL', 'TRIAL_ACTIVE') ORDER BY created_at DESC LIMIT 1`, [user.id]);
      if (!sub) throw new Error('لا يوجد اشتراك صالح لطلب استرداده.');
      if (sub.start_date && Date.now() - Number(sub.start_date) > 14 * 86400000) throw new Error('انتهت نافذة طلب الاسترداد (14 يوماً).');
      if (sub.refund_status === 'pending' || sub.status === 'REFUND_PENDING') throw new Error('يوجد طلب استرداد قيد المراجعة بالفعل.');
      const result = await new SubscriptionCoreService().processEvent(sub.id, 'REFUND_REQUESTED', { userId: user.id, idempotencyKey: `${sub.id}:refund:${user.id}`, data: { reason: reason.trim() } });
      if (result?.duplicate) throw new Error('تم تسجيل الطلب مسبقاً.');
      Alert.alert('تم الإرسال', 'تم تسجيل طلب الاسترداد للمراجعة.'); navigation.goBack();
    } catch (e) { Alert.alert('خطأ', e.message || 'تعذر تسجيل طلب الاسترداد.'); } finally { setLoading(false); }
  };
  return <ScrollView style={styles.container} contentContainerStyle={styles.content}><View style={styles.header}><MaterialCommunityIcons name="currency-usd-off" size={60} color={Colors.gold} /><Text style={styles.title}>طلب استرداد مالي</Text><Text style={styles.subtitle}>تتم مراجعة الطلب وفق سياسة الاسترداد.</Text></View><View style={styles.form}><Text style={styles.label}>سبب الطلب:</Text><TextInput style={styles.input} placeholder="اشرح السبب بوضوح..." multiline numberOfLines={6} value={reason} onChangeText={setReason} textAlign="right" /><View style={styles.policyBox}><Text style={styles.policyText}>• يجب تقديم الطلب خلال 14 يوماً من بدء الاشتراك.</Text><Text style={styles.policyText}>• قبول الطلب يغيّر حالة الاشتراك إلى ملغى.</Text></View><TouchableOpacity style={styles.submitBtn} onPress={submit} disabled={loading}>{loading ? <ActivityIndicator color="#FFF" /> : <Text style={styles.submitText}>إرسال الطلب</Text>}</TouchableOpacity></View></ScrollView>;
}
const styles = StyleSheet.create({ container: { flex: 1, backgroundColor: '#F8FAFC' }, content: { padding: 25, paddingTop: 60 }, header: { alignItems: 'center', marginBottom: 30 }, title: { fontSize: 24, fontWeight: '700', color: Colors.navy, marginTop: 15 }, subtitle: { fontSize: 13, color: '#64748B', textAlign: 'center', marginTop: 10 }, form: { width: '100%' }, label: { fontSize: 14, fontWeight: '700', color: '#334155', marginBottom: 10, textAlign: 'right' }, input: { backgroundColor: '#FFF', borderRadius: 15, padding: 15, borderWidth: 1, borderColor: '#E2E8F0', fontSize: 14, minHeight: 150, textAlignVertical: 'top' }, policyBox: { marginTop: 25, backgroundColor: '#F1F5F9', padding: 15, borderRadius: 12 }, policyText: { fontSize: 11, color: '#64748B', textAlign: 'right', marginBottom: 5 }, submitBtn: { marginTop: 30, backgroundColor: Colors.navy, borderRadius: 14, paddingVertical: 16, alignItems: 'center' }, submitText: { color: '#FFF', fontWeight: '700', fontSize: 15 } });
