// src/models/Transfer.js
// =============================================
// نموذج التحويل (Transfer Model)
// المسؤول عن تسجيل التحويلات بين الحسابات النقدية والبنكية
// =============================================

import { Model } from '@nozbe/watermelondb';
import { field, date, readonly } from '@nozbe/watermelondb/decorators';
import { Q } from '@nozbe/watermelondb';

export default class Transfer extends Model {
  // ===== 1. اسم الجدول =====
  static table = 'transfers';

  // ===== 2. الحقول الأساسية =====

  // معرف المستخدم (لفصل البيانات)
  @field('user_id') userId;

  // رقم السند
  @field('number') number;

  // تاريخ التحويل
  @field('date') date;

  // الحساب المصدر
  @field('from_account_id') fromAccountId;

  // الحساب الهدف
  @field('to_account_id') toAccountId;

  // المبلغ
  @field('amount') amount;

  // العملة
  @field('currency') currency;

  // وصف التحويل
  @field('description') description;

  // ===== 3. الحالة =====

  // حالة التحويل (pending, completed, void)
  @field('status') status;

  // ===== 4. من قام بالإنشاء =====

  @field('created_by') createdBy;

  // ===== 5. التواريخ التلقائية =====

  @readonly @date('created_at') createdAt;
  @readonly @date('updated_at') updatedAt;

  // ===== 6. العلاقات =====

  static associations = {
    // كل تحويل ينتمي إلى مستخدم واحد
    user: { type: 'belongs_to', key: 'user_id' },
    // كل تحويل له حساب مصدر واحد
    fromAccount: { type: 'belongs_to', key: 'from_account_id' },
    // كل تحويل له حساب هدف واحد
    toAccount: { type: 'belongs_to', key: 'to_account_id' },
  };

  // ===== 7. دوال مساعدة =====

  /**
   * الحصول على حالة التحويل باللغة العربية
   * @returns {string}
   */
  getStatusArabic() {
    const statuses = {
      pending: 'معلق',
      completed: 'مكتمل',
      void: 'ملغى',
    };
    return statuses[this.status] || this.status;
  }

  /**
   * الحصول على لون الحالة
   * @returns {string}
   */
  getStatusColor() {
    const colors = {
      pending: '#F39C12',
      completed: '#27AE60',
      void: '#E74C3C',
    };
    return colors[this.status] || '#6B7280';
  }

  /**
   * جلب الحساب المصدر
   * @returns {Promise<CashAccount>}
   */
  async getFromAccount() {
    return this.collections.get('cash_accounts').find(this.fromAccountId);
  }

  /**
   * جلب الحساب الهدف
   * @returns {Promise<CashAccount>}
   */
  async getToAccount() {
    return this.collections.get('cash_accounts').find(this.toAccountId);
  }

  /**
   * جلب اسم الحساب المصدر
   * @returns {Promise<string>}
   */
  async getFromAccountName() {
    const account = await this.getFromAccount();
    return account ? account.name : 'حساب غير معروف';
  }

  /**
   * جلب اسم الحساب الهدف
   * @returns {Promise<string>}
   */
  async getToAccountName() {
    const account = await this.getToAccount();
    return account ? account.name : 'حساب غير معروف';
  }

  /**
   * الحصول على اسم التحويل المعروض
   * @returns {string}
   */
  getDisplayName() {
    return `${this.number} - ${this.description || 'تحويل'}`;
  }

  /**
   * الحصول على مسار التحويل (من → إلى)
   * @returns {Promise<string>}
   */
  async getPath() {
    const fromName = await this.getFromAccountName();
    const toName = await this.getToAccountName();
    return `${fromName} → ${toName}`;
  }

  // ===== 8. دوال ثابتة =====

  /**
   * الحصول على رقم التحويل التالي
   * @param {Database} database
   * @returns {Promise<string>}
   */
  static async getNextNumber(database) {
    const lastTransfer = await database.get('transfers').query(
      Q.sortBy('number', Q.desc),
      Q.take(1)
    ).fetch();

    if (lastTransfer.length === 0) {
      return 'TRF-0001';
    }

    const lastNumber = lastTransfer[0].number;
    const numericPart = parseInt(lastNumber.split('-')[1] || '0000');
    const nextNumber = numericPart + 1;
    return `TRF-${String(nextNumber).padStart(4, '0')}`;
  }

  /**
   * حساب إجمالي التحويلات
   * @param {Transfer[]} transfers
   * @returns {number}
   */
  static sumAmount(transfers) {
    return transfers.reduce((sum, t) => sum + (t.amount || 0), 0);
  }

  /**
   * تجميع التحويلات حسب الحالة
   * @param {Transfer[]} transfers
   * @returns {Object}
   */
  static groupByStatus(transfers) {
    const groups = {};
    for (const transfer of transfers) {
      if (!groups[transfer.status]) {
        groups[transfer.status] = [];
      }
      groups[transfer.status].push(transfer);
    }
    return groups;
  }

  /**
   * حساب إجمالي التحويلات الصادرة من حساب معين
   * @param {Transfer[]} transfers
   * @param {string} accountId
   * @returns {number}
   */
  static sumOutgoing(transfers, accountId) {
    return transfers
      .filter(t => t.fromAccountId === accountId)
      .reduce((sum, t) => sum + (t.amount || 0), 0);
  }

  /**
   * حساب إجمالي التحويلات الواردة إلى حساب معين
   * @param {Transfer[]} transfers
   * @param {string} accountId
   * @returns {number}
   */
  static sumIncoming(transfers, accountId) {
    return transfers
      .filter(t => t.toAccountId === accountId)
      .reduce((sum, t) => sum + (t.amount || 0), 0);
  }
}