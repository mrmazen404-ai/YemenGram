// src/shared/contexts/BackgroundContext.js
// محرك البيئة البصرية العالمي (Sovereign Background Context)

import React, { createContext, useContext, useState, useEffect } from 'react';
import { LocalDB } from '../../modules/database/localDB';

const BackgroundContext = createContext();

export function BackgroundProvider({ children }) {
  // الحالة الافتراضية (خلفية اليمن جرام الملكية)
  const [background, setBackground] = useState({
    uri: null,
    opacity: 0.1, // طبقة التعتيم لضمان مقروئية البيانات المالية
    blur: 0,
    theme: 'default'
  });

  useEffect(() => {
    loadSavedEnvironment();
  }, []);

  const loadSavedEnvironment = async () => {
    try {
      const saved = await LocalDB.getSetting('app_background_config');
      if (saved) setBackground(JSON.parse(saved));
    } catch (e) {
      console.log('Using default environment');
    }
  };

  const updateEnvironment = async (config) => {
    const newConfig = { ...background, ...config };
    setBackground(newConfig);
    // حفظ دائم في قاعدة البيانات
    await LocalDB.saveSetting('app_background_config', JSON.stringify(newConfig));
  };

  return (
    <BackgroundContext.Provider value={{ background, updateEnvironment }}>
      {children}
    </BackgroundContext.Provider>
  );
}

export const useEnvironment = () => useContext(BackgroundContext);
