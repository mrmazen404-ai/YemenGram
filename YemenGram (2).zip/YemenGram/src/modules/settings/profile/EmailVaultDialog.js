// src/modules/settings/profile/EmailVaultDialog.js
// قمرة قيادة البريد السيادي (Email Command Vault)
// إدارة الخصوصية والتحقق المزدوج (Google Security Protocol)

import React, { useState } from 'react';
import { View, Text, Modal, TextInput, TouchableOpacity, ActivityIndicator } from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { Colors } from '../../../shared/utils/colors';
import { styles } from './ProfileStyles';
import Loading from '../../../shared/components/Loading';

export default function EmailVaultDialog({ visible, currentEmail, onHide, onTogglePrivacy, isMasked, onChangeEmailRequest }) {
  const [step, setStep] = useState('menu'); // 'menu', 'new_email', 'otp'
  const [newEmail, setNewEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const triggerHaptic = () => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

  const handleStartChange = () => {
    triggerHaptic();
    setStep('new_email');
  };

  const handleSendOTP = async () => {
    if (!newEmail.includes('@')) {
      setError('يرجى إدخال بريد إلكتروني صحيح');
      return;
    }
    setLoading(true);
    setError('');
    try {
      // محاكاة إرسال OTP للبريد الجديد
      await new Promise(resolve => setTimeout(resolve, 2000));
      setStep('otp');
    } catch (e) {
      setError('فشل إرسال كود التحقق');
    } finally {
      setLoading(false);
    }
  };

  const handleFinalVerify = async () => {
    if (otp.length < 6) return;
    setLoading(true);
    try {
      await onChangeEmailRequest(newEmail, otp);
      setStep('menu');
      onHide();
    } catch (e) {
      setError('كود التحقق غير صحيح');
    } finally {
      setLoading(false);
    }
  };

  const renderContent = () => {
    switch (step) {
      case 'menu':
        return (
          <>
            <Text style={styles.sheetTitle}>قمرة قيادة البريد</Text>
            <Text style={styles.sheetDesc}>تحكم في خصوصية بريدك الرسمي أو ابدأ بروتوكول التغيير</Text>
            <View style={styles.actionGrid}>
              <TouchableOpacity style={styles.actionCard} onPress={onTogglePrivacy}>
                <View style={styles.actionIcon}>
                  <Ionicons name={isMasked ? "eye-outline" : "eye-off-outline"} size={22} color={Colors.navy} />
                </View>
                <Text style={styles.actionLabel}>{isMasked ? 'إظهار البريد' : 'إخفاء البريد'}</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.actionCard} onPress={handleStartChange}>
                <View style={styles.actionIcon}>
                  <Ionicons name="refresh-outline" size={22} color={Colors.gold} />
                </View>
                <Text style={styles.actionLabel}>تغيير البريد</Text>
              </TouchableOpacity>
            </View>
          </>
        );
      case 'new_email':
        return (
          <>
            <Text style={styles.sheetTitle}>البريد الإلكتروني الجديد</Text>
            <Text style={styles.sheetDesc}>أدخل العنوان الجديد لربطه بميثاق الأمان الخاص بك</Text>
            <TextInput
              style={styles.professionalInput}
              placeholder="new-email@yemengram.com"
              value={newEmail}
              onChangeText={setNewEmail}
              keyboardType="email-address"
              autoCapitalize="none"
              autoFocus
            />
            <View style={styles.sheetActionRow}>
              <TouchableOpacity style={styles.confirmBtn} onPress={handleSendOTP}>
                <Text style={styles.confirmBtnText}>إرسال كود التحقق</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.cancelBtn} onPress={() => setStep('menu')}>
                <Text style={styles.cancelBtnText}>تراجع</Text>
              </TouchableOpacity>
            </View>
          </>
        );
      case 'otp':
        return (
          <>
            <Text style={styles.sheetTitle}>تحقق الملكية</Text>
            <Text style={styles.sheetDesc}>أدخل الكود المرسل إلى العنوان الجديد: {newEmail}</Text>
            <TextInput
              style={styles.professionalInput}
              placeholder="0 0 0 0 0 0"
              value={otp}
              onChangeText={setOtp}
              keyboardType="number-pad"
              maxLength={6}
              autoFocus
            />
            <View style={styles.sheetActionRow}>
              <TouchableOpacity style={styles.confirmBtn} onPress={handleFinalVerify}>
                <Text style={styles.confirmBtnText}>توثيق وتغيير</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.cancelBtn} onPress={() => setStep('new_email')}>
                <Text style={styles.cancelBtnText}>تراجع</Text>
              </TouchableOpacity>
            </View>
          </>
        );
    }
  };

  return (
    <Modal visible={visible} transparent animationType="slide">
      <View style={styles.modalOverlay}>
        <View style={styles.bottomSheet}>
          <View style={styles.sheetHandle} />
          {renderContent()}
          {error !== '' && <Text style={{ color: Colors.red, textAlign: 'center', marginTop: 10 }}>{error}</Text>}
          <Loading visible={loading} />
        </View>
      </View>
    </Modal>
  );
}
