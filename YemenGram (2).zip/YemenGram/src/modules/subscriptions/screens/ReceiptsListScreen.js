/**
 * شاشة سجل الإيصالات السيادية (Sovereign Receipts List Screen)
 * تسمح للمستخدم بمتابعة كافة عمليات الدفع المرفوعة وحالاتها
 */

import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, FlatList, Image, TouchableOpacity, ActivityIndicator, RefreshControl } from 'react-native';
import { MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { database } from '../../../models/database';
import { Q } from '@nozbe/watermelondb';
import { useAuth } from '../../../shared/contexts/AuthContext';
import { Colors } from '../../../shared/utils/colors';

export default function ReceiptsListScreen() {
  const navigation = useNavigation();
  const { user } = useAuth();
  const [receipts, setReceipts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const loadReceipts = async () => {
    try {
      if (!user?.id) return;

      const collection = database.get('receipts');
      const data = await collection.query(
        Q.where('user_id', user.id),
        Q.sortBy('created_at', Q.desc)
      ).fetch();

      setReceipts(data);
    } catch (error) {
      console.error('Failed to load receipts:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadReceipts();
  }, []);

  const renderItem = ({ item }) => (
    <View style={styles.card}>
      <View style={styles.cardHeader}>
        <View style={styles.statusBadge}>
          <View style={[styles.statusDot, { backgroundColor: item.getStatusColor() }]} />
          <Text style={[styles.statusText, { color: item.getStatusColor() }]}>
            {item.getStatusArabic()}
          </Text>
        </View>
        <Text style={styles.dateText}>
          {new Date(item.createdAt).toLocaleDateString('ar-EG')}
        </Text>
      </View>

      <View style={styles.cardBody}>
        <View style={styles.infoBox}>
          <Text style={styles.bankName}>{item.bankName || 'حوالة عامة'}</Text>
          <Text style={styles.transactionNum}>رقم العملية: {item.transactionNumber || '---'}</Text>
          <Text style={styles.amountText}>{item.amount.toLocaleString()} ر.ي</Text>
        </View>

        {item.imageUrl ? (
          <Image source={{ uri: item.imageUrl }} style={styles.receiptThumb} />
        ) : (
          <View style={styles.placeholderThumb}>
             <Ionicons name="image-outline" size={20} color="#CBD5E1" />
          </View>
        )}
      </View>

      {item.adminNotes && (
        <View style={styles.notesBox}>
           <Text style={styles.notesTitle}>ملاحظة الإدارة:</Text>
           <Text style={styles.notesText}>{item.adminNotes}</Text>
        </View>
      )}
    </View>
  );

  if (loading) {
    return <View style={styles.center}><ActivityIndicator size="large" color={Colors.navy} /></View>;
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
          <Ionicons name="chevron-forward" size={24} color={Colors.navy} />
        </TouchableOpacity>
        <Text style={styles.title}>سجل الإيصالات</Text>
        <View style={{ width: 40 }} />
      </View>

      <FlatList
        data={receipts}
        keyExtractor={item => item.id}
        renderItem={renderItem}
        contentContainerStyle={styles.list}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); loadReceipts(); }} />}
        ListEmptyComponent={
          <View style={styles.emptyBox}>
            <MaterialCommunityIcons name="receipt-text-minus" size={60} color="#E2E8F0" />
            <Text style={styles.emptyText}>لا توجد إيصالات مرفوعة حالياً</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC' },
  header: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', padding: 20, paddingTop: 50, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#F1F5F9' },
  backBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: '#F8FAFC', justifyContent: 'center', alignItems: 'center' },
  title: { fontSize: 18, fontFamily: 'Tajawal-Bold', color: Colors.navy },
  list: { padding: 15 },
  card: { backgroundColor: '#FFF', borderRadius: 20, padding: 15, marginBottom: 15, borderWidth: 1, borderColor: '#F1F5F9', elevation: 2 },
  cardHeader: { flexDirection: 'row-reverse', justifyContent: 'space-between', marginBottom: 12 },
  statusBadge: { flexDirection: 'row-reverse', alignItems: 'center', gap: 6, backgroundColor: '#F8FAFC', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  statusDot: { width: 8, height: 8, borderRadius: 4 },
  statusText: { fontSize: 11, fontFamily: 'Tajawal-Bold' },
  dateText: { fontSize: 11, fontFamily: 'Tajawal-Medium', color: '#94A3B8' },
  cardBody: { flexDirection: 'row-reverse', gap: 15 },
  infoBox: { flex: 1, alignItems: 'flex-end' },
  bankName: { fontSize: 15, fontFamily: 'Tajawal-Bold', color: '#1E293B', marginBottom: 4 },
  transactionNum: { fontSize: 12, fontFamily: 'Tajawal-Medium', color: '#64748B', marginBottom: 8 },
  amountText: { fontSize: 16, fontFamily: 'Tajawal-Bold', color: Colors.gold },
  receiptThumb: { width: 80, height: 80, borderRadius: 12, backgroundColor: '#F1F5F9' },
  placeholderThumb: { width: 80, height: 80, borderRadius: 12, backgroundColor: '#F8FAFC', justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: '#F1F5F9', borderStyle: 'dashed' },
  notesBox: { marginTop: 12, paddingTop: 12, borderTopWidth: 1, borderTopColor: '#F8FAFC' },
  notesTitle: { fontSize: 11, fontFamily: 'Tajawal-Bold', color: '#EF4444', textAlign: 'right', marginBottom: 4 },
  notesText: { fontSize: 12, fontFamily: 'Tajawal-Medium', color: '#64748B', textAlign: 'right' },
  emptyBox: { alignItems: 'center', marginTop: 100 },
  emptyText: { marginTop: 15, fontSize: 14, fontFamily: 'Tajawal-Medium', color: '#94A3B8' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' }
});
