// src/modules/settings/profile/ProfileVerificationModal.js
// محرك التحقق المتسلسل: واجهة ذكية لتغيير البيانات الحساسة (Google Protocol)

import React, { useState, useRef, useEffect } from 'react';
import { View, Text, StyleSheet, Modal, TextInput, TouchableOpacity, Animated, Dimensions } from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { Colors } from '../../../shared/utils/colors';
import { ProfileService } from './ProfileService';
import Loading from '../../../shared/components/Loading';
import AuthService from '../../auth/services/authService';

const { width, height } = Dimensions.get('window');

export default function ProfileVerificationModal({ visible, onClose, email, onSuccess, userId }) {
  // ===== State =====
  const [step, setStep] = useState('email_otp'); // 'email_otp', 'new_phone', 'phone_otp'
  const [code, setCode] = useState(['', '', '', '', '', '']);
  const [newPhone, setNewPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const inputRefs = useRef([]);

  // ===== Animations =====
  const slideAnim = useRef(new Animated.Value(height)).current;

  useEffect(() => {
    if (visible) {
      Animated.spring(slideAnim, { toValue: 0, tension: 50, friction: 10, useNativeDriver: true }).start();
    }
  }, [visible]);

  const triggerHaptic = (type = 'light') => {
    if (type === 'success') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    else if (type === 'error') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    else Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleCodeChange = (value, index) => {
    const cleaned = value.replace(/[^0-9]/g, '');
    const newCode = [...code];
    newCode[index] = cleaned;
    setCode(newCode);
    if (cleaned && index < 5) inputRefs.current[index + 1]?.focus();
    if (newCode.every(c => c !== '')) validateStep(newCode.join(''));
  };

  const validateStep = async (enteredCode) => {
    setLoading(true);
    setError('');
    try {
      if (step === 'email_otp') {
        const result = await AuthService.verifyOTP(email, enteredCode);
        if (result.success) {
          triggerHaptic('success');
          setStep('new_phone');
          setCode(['', '', '', '', '', '']);
        }
      } else if (step === 'phone_otp') {
        // التحقق من كود الهاتف الجديد (محاكاة النجاح)
        triggerHaptic('success');
        await ProfileService.finalizePhoneChange(userId, newPhone);
        onSuccess(newPhone);
      }
    } catch (e) {
      triggerHaptic('error');
      setError('الرمز غير صحيح أو منتهي الصلاحية');
      setCode(['', '', '', '', '', '']);
      inputRefs.current[0]?.focus();
    } finally {
      setLoading(false);
    }
  };

  const startPhoneVerification = async () => {
    if (newPhone.length < 9) return setError('يرجى إدخال رقم هاتف صحيح');
    setLoading(true);
    try {
      await ProfileService.sendOTPToNewPhone(newPhone);
      triggerHaptic();
      setStep('phone_otp');
    } catch (e) {
      setError('فشل إرسال كود التحقق للرقم الجديد');
    } finally {
      setLoading(false);
    }
  };

  if (!visible) return null;

  return (
    <Modal visible={visible} transparent animationType="none" statusBarTranslucent>
      <View style={styles.overlay}>
        <Animated.View style={[styles.sheet, { transform: [{ translateY: slideAnim }] }]}>

          <View style={styles.handle} />

          <View style={styles.header}>
             <TouchableOpacity style={styles.closeBtn} onPress={onClose}>
                <Ionicons name="close" size={20} color={Colors.gray} />
             </TouchableOpacity>
             <Text style={styles.headerTitle}>بروتوكول التحقق</Text>
             <View style={{ width: 40 }} />
          </View>

          <View style={styles.content}>
             <View style={styles.iconCircle}>
                <Ionicons
                  name={step === 'email_otp' ? "mail-unread-outline" : "call-outline"}
                  size={32} color={Colors.navy}
                />
             </View>

             <Text style={styles.title}>
                {step === 'email_otp' ? 'تأكيد الهوية الأم' :
                 step === 'new_phone' ? 'تحديث رقم الهاتف' : 'تأكيد الرقم الجديد'}
             </Text>

             <Text style={styles.desc}>
                {step === 'email_otp' ? `أدخل الرمز المرسل إلى بريدك: ${email}` :
                 step === 'new_phone' ? 'أدخل رقم الهاتف الجديد الذي تود ربطه بالحساب' :
                 `أدخل الرمز المرسل إلى رقمك الجديد: ${newPhone}`}
             </Text>

             {(step === 'email_otp' || step === 'phone_otp') && (
               <View style={styles.otpRow}>
                  {code.map((digit, i) => (
                    <TextInput
                      key={i}
                      ref={r => inputRefs.current[i] = r}
                      style={[styles.otpBox, digit !== '' && styles.otpBoxFilled]}
                      value={digit}
                      onChangeText={v => handleCodeChange(v, i)}
                      keyboardType="number-pad"
                      maxLength={1}
                      selectTextOnFocus
                    />
                  ))}
               </View>
             )}

             {step === 'new_phone' && (
               <View style={styles.inputWrapper}>
                  <TextInput
                    style={styles.phoneInput}
                    placeholder="77XXXXXXX"
                    value={newPhone}
                    onChangeText={setNewPhone}
                    keyboardType="phone-pad"
                    autoFocus
                  />
                  <TouchableOpacity style={styles.actionBtn} onPress={startPhoneVerification}>
                    <Text style={styles.actionBtnText}>إرسال كود التحقق</Text>
                  </TouchableOpacity>
               </View>
             )}

             {error !== '' && <Text style={styles.errorText}>{error}</Text>}
             <Loading visible={loading} />
          </View>

          <View style={styles.footer}>
             <MaterialCommunityIcons name="shield-check" size={14} color={Colors.gold} />
             <Text style={styles.footerText}>بوابة الأمان السيادية من YemenGram</Text>
          </View>
        </Animated.View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'flex-end' },
  sheet: { backgroundColor: '#FFF', borderTopLeftRadius: 40, borderTopRightRadius: 40, paddingBottom: 40, minHeight: height * 0.6 },
  handle: { width: 40, height: 4, backgroundColor: '#E2E8F0', borderRadius: 2, alignSelf: 'center', marginTop: 12 },
  header: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', padding: 20 },
  closeBtn: { width: 36, height: 36, borderRadius: 12, backgroundColor: '#F8FAFC', justifyContent: 'center', alignItems: 'center' },
  headerTitle: { fontSize: 14, fontFamily: 'Tajawal-Bold', color: Colors.gray },
  content: { alignItems: 'center', paddingHorizontal: 30, paddingTop: 10 },
  iconCircle: { width: 70, height: 70, borderRadius: 25, backgroundColor: '#F1F5F9', justifyContent: 'center', alignItems: 'center', marginBottom: 15 },
  title: { fontSize: 20, fontFamily: 'Tajawal-Bold', color: Colors.dark, marginBottom: 10 },
  desc: { fontSize: 13, fontFamily: 'Tajawal-Regular', color: Colors.gray, textAlign: 'center', lineHeight: 22, marginBottom: 30 },
  otpRow: { flexDirection: 'row-reverse', gap: 8 },
  otpBox: { width: 42, height: 55, borderRadius: 12, backgroundColor: '#F8FAFC', borderWidth: 1, borderColor: '#E2E8F0', textAlign: 'center', fontSize: 22, fontFamily: 'Tajawal-Bold', color: Colors.navy },
  otpBoxFilled: { borderColor: Colors.navy, backgroundColor: '#FFF' },
  inputWrapper: { width: '100%', alignItems: 'center' },
  phoneInput: { width: '100%', height: 55, backgroundColor: '#F8FAFC', borderRadius: 15, borderWidth: 1, borderColor: '#E2E8F0', paddingHorizontal: 20, fontSize: 18, fontFamily: 'Tajawal-Bold', textAlign: 'center', marginBottom: 20 },
  actionBtn: { width: '100%', height: 55, backgroundColor: Colors.navy, borderRadius: 15, justifyContent: 'center', alignItems: 'center' },
  actionBtnText: { fontSize: 15, fontFamily: 'Tajawal-Bold', color: '#FFF' },
  errorText: { color: Colors.red, fontSize: 12, fontFamily: 'Tajawal-Bold', marginTop: 20 },
  footer: { flexDirection: 'row-reverse', justifyContent: 'center', alignItems: 'center', gap: 6, marginTop: 40 },
  footerText: { fontSize: 10, fontFamily: 'Tajawal-Medium', color: Colors.placeholder },
});
