import React from 'react';
import { View, Text, Image, Button, ActivityIndicator, StyleSheet } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import SupabaseService from '../../../services/supabaseClient';
import SubscriptionCoreService from '../services/SubscriptionCoreService';
import { LocalDB } from '../../database/localDB';
import { validateReceipt } from '../utils/validators';

export default function ReceiptUploader({ subscriptionId, userId, amount, onDone }) {
  const [asset, setAsset] = React.useState(null);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState(null);

  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') return setError('يجب السماح بالوصول إلى الصور.');
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.7, allowsEditing: true });
    if (!result.canceled && result.assets?.[0]) {
      const selected = result.assets[0];
      const validation = validateReceipt(selected);
      if (!validation.isValid) return setError(validation.error);
      setAsset(selected);
      setError(null);
    }
  };

  const uploadReceipt = async () => {
    if (!subscriptionId || !userId) return setError('لا يمكن رفع إيصال دون مستخدم واشتراك صحيحين.');
    if (!asset?.uri) return setError('يرجى اختيار صورة الإيصال أولاً.');
    if (!Number.isFinite(Number(amount)) || Number(amount) <= 0) return setError('يجب إدخال مبلغ دفع صحيح أكبر من صفر.');
    setLoading(true); setError(null);
    try {
      const fileName = `${subscriptionId}_${Date.now()}.jpg`;
      const path = `receipts/${userId}/${fileName}`;
      const response = await fetch(asset.uri);
      const blob = await response.blob();
      const uploadRes = await SupabaseService.uploadFile('receipts', path, blob, 'image/jpeg');
      if (!uploadRes.success || !uploadRes.url) throw new Error(uploadRes.error || 'upload_failed');

      const receiptId = `receipt_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
      await LocalDB.execute(
        `INSERT INTO receipts (id, user_id, subscription_id, image_url, amount, status, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, 'pending', ?, ?)`,
        [receiptId, userId, subscriptionId, uploadRes.url, Number(amount), Date.now(), Date.now()]
      );

      const core = new SubscriptionCoreService();
      const result = await core.processEvent(subscriptionId, 'RECEIPT_SUBMITTED', {
        userId,
        plan: 'monthly',
        idempotencyKey: `${subscriptionId}:receipt:${receiptId}`,
        data: { receiptUrl: uploadRes.url, receiptId, amount: Number(amount), uploadedAt: Date.now() },
      });
      if (result?.duplicate) throw new Error('تمت معالجة هذا الإيصال مسبقاً.');
      onDone?.({ success: true, receiptUrl: uploadRes.url, receiptId });
    } catch (e) {
      const message = e?.message || 'upload_failed';
      setError(message); onDone?.({ success: false, error: message });
    } finally { setLoading(false); }
  };

  return <View style={styles.container}>
    {asset?.uri ? <Image source={{ uri: asset.uri }} style={styles.preview} resizeMode="cover" /> : <View style={styles.placeholder}><Text style={styles.placeholderText}>لم يتم اختيار إيصال</Text></View>}
    {error ? <Text style={styles.error}>{error}</Text> : null}
    <View style={styles.actions}><Button title="اختيار الإيصال" onPress={pickImage} /><Button title={loading ? 'جارٍ الرفع...' : 'رفع الإيصال'} onPress={uploadReceipt} disabled={loading || !asset?.uri} /></View>
    {loading ? <ActivityIndicator size="small" style={styles.loader} /> : null}
  </View>;
}

const styles = StyleSheet.create({
  container: { gap: 12 }, preview: { width: '100%', height: 260, borderRadius: 12, backgroundColor: '#ddd' },
  placeholder: { width: '100%', height: 260, borderRadius: 12, backgroundColor: '#efefef', alignItems: 'center', justifyContent: 'center' },
  placeholderText: { color: '#666', fontSize: 14 }, actions: { gap: 8 }, error: { color: '#d32f2f', fontSize: 12, marginTop: 4 }, loader: { marginTop: 8 },
});
