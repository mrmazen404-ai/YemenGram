// src/modules/auth/components/AuthGuard.js
// =============================================
// حماية المسارات (Auth Guard)
// يمنع الوصول إلى الشاشات المحمية بدون مصادقة
// =============================================

import React, { useEffect, useState } from 'react';
import { View, ActivityIndicator, Text, TouchableOpacity } from 'react-native';
import { useAuth } from '../../../shared/contexts/AuthContext';
import { Colors } from '../../../shared/utils/colors';
import { LocalDB } from '../../../shared/services/storageService';
import { Logger } from '../../../shared/utils/logger';

// =============================================
// 1. مكون الحماية الرئيسي
// =============================================

export function AuthGuard({ children, requiredRole = null, fallback = null }) {
  const { user, isLoggedIn, loading, checkAuth } = useAuth();
  const [checking, setChecking] = useState(true);
  const [hasAccess, setHasAccess] = useState(false);
  const [error, setError] =  useState(null);

  // ===== التحقق من الصلاحية =====
  useEffect(() => {
    const checkAccess = async () => {
      try {
        setChecking(true);
        setError(null);

        // 1. التحقق من المصادقة
        if (!isLoggedIn || !user) {
          setHasAccess(false);
          setChecking(false);
          return;
        }

        // 2. التحقق من الصلاحية (إذا كانت مطلوبة)
        if (requiredRole) {
          const hasRole = await checkUserRole(user, requiredRole);
          if (!hasRole) {
            setHasAccess(false);
            setChecking(false);
            return;
          }
        }

        // 3. التحقق من الاشتراك (إذا كان مطلوباً)
        if (requiredRole === 'premium') {
          const hasSubscription = await checkSubscription(user.id);
          if (!hasSubscription) {
            setHasAccess(false);
            setChecking(false);
            return;
          }
        }

        setHasAccess(true);
      } catch (error) {
        Logger.error('❌ [AuthGuard] خطأ في التحقق:', error);
        setError(error.message);
        setHasAccess(false);
      } finally {
        setChecking(false);
      }
    };

    checkAccess();
  }, [isLoggedIn, user, requiredRole]);

  // ===== عرض التحميل =====
  if (loading || checking) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={Colors.navy} />
        <Text style={styles.loadingText}>جاري التحقق...</Text>
      </View>
    );
  }

  // ===== عرض الخطأ =====
  if (error) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorIcon}>⚠️</Text>
        <Text style={styles.errorTitle}>حدث خطأ</Text>
        <Text style={styles.errorMessage}>{error}</Text>
        <TouchableOpacity
          style={styles.retryBtn}
          onPress={() => {
            setError(null);
            setChecking(true);
            // إعادة التحقق
            setTimeout(() => {
              checkAccess();
            }, 500);
          }}
        >
          <Text style={styles.retryText}>إعادة المحاولة</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // ===== عرض رفض الوصول =====
  if (!hasAccess) {
    if (fallback) {
      return fallback;
    }

    return (
      <View style={styles.deniedContainer}>
        <Text style={styles.deniedIcon}>🔒</Text>
        <Text style={styles.deniedTitle}>غير مصرح بالوصول</Text>
        <Text style={styles.deniedMessage}>
          {requiredRole === 'premium'
            ? 'هذه الميزة متاحة فقط للمشتركين المميزين'
            : 'ليس لديك الصلاحية للوصول إلى هذه الصفحة'}
        </Text>
        {requiredRole === 'premium' && (
          <TouchableOpacity style={styles.upgradeBtn}>
            <Text style={styles.upgradeText}>ترقية الاشتراك</Text>
          </TouchableOpacity>
        )}
      </View>
    );
  }

  // ===== عرض المحتوى =====
  return children;
}

// =============================================
// 2. دوال مساعدة
// =============================================

/**
 * التحقق من دور المستخدم
 */
const checkUserRole = async (user, requiredRole) => {
  const roles = {
    admin: ['admin'],
    accountant: ['admin', 'accountant'],
    sales: ['admin', 'accountant', 'sales'],
    customer: ['admin', 'accountant', 'sales', 'customer'],
    premium: ['admin', 'accountant', 'sales', 'customer'],
  };

  const allowedRoles = roles[requiredRole] || [];
  return allowedRoles.includes(user.role);
};

/**
 * التحقق من الاشتراك
 */
const checkSubscription = async (userId) => {
  try {
    const subscription = await LocalDB.queryOne(
      'SELECT * FROM subscriptions WHERE user_id = ? AND is_active = 1',
      [userId]
    );

    if (!subscription) return false;
    if (subscription.plan === 'lifetime') return true;
    if (!subscription.end_date) return false;

    return subscription.end_date > Date.now();
  } catch (error) {
    Logger.error('❌ [AuthGuard] فشل التحقق من الاشتراك:', error);
    return false;
  }
};

// =============================================
// 3. Hooks مخصصة للحماية
// =============================================

/**
 * Hook للتحقق من المصادقة
 */
export const useRequireAuth = (redirectTo = 'Login') => {
  const { isLoggedIn } = useAuth();
  const navigation = useNavigation();

  useEffect(() => {
    if (!isLoggedIn) {
      navigation.navigate(redirectTo);
    }
  }, [isLoggedIn, navigation]);

  return isLoggedIn;
};

/**
 * Hook للتحقق من الصلاحية
 */
export const useRequireRole = (requiredRole, redirectTo = 'Login') => {
  const { user, isLoggedIn } = useAuth();
  const navigation = useNavigation();
  const [authorized, setAuthorized] = useState(false);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    const check = async () => {
      if (!isLoggedIn || !user) {
        navigation.navigate(redirectTo);
        setAuthorized(false);
        setChecking(false);
        return;
      }

      const hasRole = await checkUserRole(user, requiredRole);
      if (!hasRole) {
        setAuthorized(false);
        setChecking(false);
        return;
      }

      setAuthorized(true);
      setChecking(false);
    };

    check();
  }, [isLoggedIn, user, requiredRole]);

  return { authorized, checking };
};

// =============================================
// 4. مكونات مساعدة
// =============================================

/**
 * حماية الشاشة (Screen Guard)
 */
export function ScreenGuard({ children, requiredRole = null }) {
  return (
    <AuthGuard requiredRole={requiredRole}>
      {children}
    </AuthGuard>
  );
}

/**
 * حماية الزر (Button Guard)
 */
export function ButtonGuard({ children, requiredRole = null, onPress, ...props }) {
  const { user, isLoggedIn } = useAuth();
  const [hasAccess, setHasAccess] = useState(false);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    const check = async () => {
      if (!isLoggedIn || !user) {
        setHasAccess(false);
        setChecking(false);
        return;
      }

      if (requiredRole) {
        const hasRole = await checkUserRole(user, requiredRole);
        setHasAccess(hasRole);
      } else {
        setHasAccess(true);
      }
      setChecking(false);
    };

    check();
  }, [isLoggedIn, user]);

  const handlePress = (e) => {
    if (!hasAccess) {
      // عرض رسالة
      return;
    }
    if (onPress) onPress(e);
  };

  return React.cloneElement(children, {
    ...props,
    onPress: handlePress,
    disabled: !hasAccess || checking,
    opacity: hasAccess ? 1 : 0.5,
  });
}

// =============================================
// 5. الأنماط (Styles)
// =============================================
const styles = {
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.white,
    padding: 20,
  },
  loadingText: {
    marginTop: 12,
    fontSize: 14,
    fontFamily: 'Tajawal-Regular',
    color: Colors.gray,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.white,
    padding: 20,
  },
  errorIcon: {
    fontSize: 48,
    marginBottom: 16,
  },
  errorTitle: {
    fontSize: 18,
    fontFamily: 'Tajawal-Bold',
    color: Colors.dark,
    marginBottom: 4,
  },
  errorMessage: {
    fontSize: 14,
    fontFamily: 'Tajawal-Regular',
    color: Colors.gray,
    textAlign: 'center',
    marginBottom: 20,
  },
  retryBtn: {
    backgroundColor: Colors.navy,
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
  },
  retryText: {
    color: Colors.white,
    fontSize: 14,
    fontFamily: 'Tajawal-Medium',
  },
  deniedContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.white,
    padding: 20,
  },
  deniedIcon: {
    fontSize: 48,
    marginBottom: 16,
  },
  deniedTitle: {
    fontSize: 18,
    fontFamily: 'Tajawal-Bold',
    color: Colors.dark,
    marginBottom: 4,
  },
  deniedMessage: {
    fontSize: 14,
    fontFamily: 'Tajawal-Regular',
    color: Colors.gray,
    textAlign: 'center',
    marginBottom: 20,
  },
  upgradeBtn: {
    backgroundColor: Colors.gold,
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
  },
  upgradeText: {
    color: Colors.white,
    fontSize: 14,
    fontFamily: 'Tajawal-Medium',
  },
};

export default AuthGuard;