// src/models/Check.js
// =============================================
// نموذج الشيك (Check Model)
// المسؤول عن إدارة الشيكات الواردة والصادرة
// =============================================

import { Model } from '@nozbe/watermelondb';
import { field, date, readonly } from '@nozbe/watermelondb/decorators';
import { Q } from '@nozbe/watermelondb';

export default class Check extends Model {
  // ===== 1. اسم الجدول =====
  static table = 'checks';

  // ===== 2. الحقول الأساسية =====

  // معرف المستخدم (لفصل البيانات)
  @field('user_id') userId;

  // رقم الشيك
  @field('number') number;

  // نوع الشيك (received, issued)
  @field('type') type;

  // المبلغ
  @field('amount') amount;

  // تاريخ الشيك
  @field('date') date;

  // تاريخ الاستحقاق
  @field('due_date') dueDate;

  // اسم البنك
  @field('bank_name') bankName;

  // ===== 3. الأطراف =====

  // معرف العميل (للشيكات الواردة من العملاء)
  @field('customer_id') customerId;

  // معرف المورد (للشيكات الصادرة للموردين)
  @field('supplier_id') supplierId;

  // ===== 4. مراجع الحسابات =====

  // الحساب النقدي/البنكي المرتبط
  @field('cash_account_id') cashAccountId;

  // ===== 5. الحالة =====

  // حالة الشيك (pending, cleared, bounced, void)
  @field('status') status;

  // ===== 6. معلومات إضافية =====

  @field('notes') notes;

  // ===== 7. التواريخ التلقائية =====

  @readonly @date('created_at') createdAt;
  @readonly @date('updated_at') updatedAt;

  // ===== 8. العلاقات =====

  static associations = {
    // كل شيك ينتمي إلى مستخدم واحد
    user: { type: 'belongs_to', key: 'user_id' },
    // كل شيك قد ينتمي إلى عميل (للشيكات الواردة)
    customer: { type: 'belongs_to', key: 'customer_id' },
    // كل شيك قد ينتمي إلى مورد (للشيكات الصادرة)
    supplier: { type: 'belongs_to', key: 'supplier_id' },
    // كل شيك ينتمي إلى حساب نقدي/بنكي
    cashAccount: { type: 'belongs_to', key: 'cash_account_id' },
  };

  // ===== 9. دوال مساعدة =====

  /**
   * الحصول على نوع الشيك باللغة العربية
   * @returns {string}
   */
  getTypeArabic() {
    const types = {
      received: 'شيك وارد (مقبوض)',
      issued: 'شيك صادر (مسدد)',
    };
    return types[this.type] || this.type;
  }

  /**
   * الحصول على حالة الشيك باللغة العربية
   * @returns {string}
   */
  getStatusArabic() {
    const statuses = {
      pending: 'معلق',
      cleared: 'مقاصة',
      bounced: 'مرتجع',
      void: 'ملغى',
    };
    return statuses[this.status] || this.status;
  }

  /**
   * الحصول على لون الحالة
   * @returns {string}
   */
  getStatusColor() {
    const colors = {
      pending: '#F39C12',
      cleared: '#27AE60',
      bounced: '#E74C3C',
      void: '#6B7280',
    };
    return colors[this.status] || '#6B7280';
  }

  /**
   * التحقق من أن الشيك وارد (مقبوض)
   * @returns {boolean}
   */
  isReceived() {
    return this.type === 'received';
  }

  /**
   * التحقق من أن الشيك صادر (مسدد)
   * @returns {boolean}
   */
  isIssued() {
    return this.type === 'issued';
  }

  /**
   * التحقق من أن الشيك معلق
   * @returns {boolean}
   */
  isPending() {
    return this.status === 'pending';
  }

  /**
   * التحقق من أن الشيك مقاصة
   * @returns {boolean}
   */
  isCleared() {
    return this.status === 'cleared';
  }

  /**
   * التحقق من أن الشيك مرتجع
   * @returns {boolean}
   */
  isBounced() {
    return this.status === 'bounced';
  }

  /**
   * التحقق من أن الشيك ملغى
   * @returns {boolean}
   */
  isVoid() {
    return this.status === 'void';
  }

  /**
   * جلب العميل المرتبط (إن وجد)
   * @returns {Promise<Customer|null>}
   */
  async getCustomer() {
    if (!this.customerId) return null;
    return this.collections.get('customers').find(this.customerId);
  }

  /**
   * جلب المورد المرتبط (إن وجد)
   * @returns {Promise<Supplier|null>}
   */
  async getSupplier() {
    if (!this.supplierId) return null;
    return this.collections.get('suppliers').find(this.supplierId);
  }

  /**
   * جلب الحساب النقدي/البنكي المرتبط
   * @returns {Promise<CashAccount>}
   */
  async getCashAccount() {
    return this.collections.get('cash_accounts').find(this.cashAccountId);
  }

  /**
   * الحصول على اسم الطرف (عميل/مورد)
   * @returns {Promise<string>}
   */
  async getPartyName() {
    if (this.customerId) {
      const customer = await this.getCustomer();
      return customer ? customer.name : 'عميل غير معروف';
    }
    if (this.supplierId) {
      const supplier = await this.getSupplier();
      return supplier ? supplier.name : 'مورد غير معروف';
    }
    return 'غير محدد';
  }

  /**
   * الحصول على اسم الشيك المعروض
   * @returns {string}
   */
  getDisplayName() {
    return `${this.number} - ${this.getTypeArabic()}`;
  }

  /**
   * التحقق من أن الشيك منتهي الصلاحية (تاريخ الاستحقاق مضى)
   * @param {number} currentDate
   * @returns {boolean}
   */
  isOverdue(currentDate = Date.now()) {
    if (!this.dueDate) return false;
    return this.dueDate < currentDate;
  }

  /**
   * الحصول على عدد الأيام المتبقية للاستحقاق
   * @param {number} currentDate
   * @returns {number}
   */
  getDaysUntilDue(currentDate = Date.now()) {
    if (!this.dueDate) return 0;
    const diff = this.dueDate - currentDate;
    return Math.ceil(diff / (1000 * 60 * 60 * 24));
  }

  // ===== 10. دوال ثابتة =====

  /**
   * تجميع الشيكات حسب الحالة
   * @param {Check[]} checks
   * @returns {Object}
   */
  static groupByStatus(checks) {
    const groups = {};
    for (const check of checks) {
      if (!groups[check.status]) {
        groups[check.status] = [];
      }
      groups[check.status].push(check);
    }
    return groups;
  }

  /**
   * تجميع الشيكات حسب النوع
   * @param {Check[]} checks
   * @returns {Object}
   */
  static groupByType(checks) {
    const groups = {};
    for (const check of checks) {
      if (!groups[check.type]) {
        groups[check.type] = [];
      }
      groups[check.type].push(check);
    }
    return groups;
  }

  /**
   * حساب إجمالي قيمة الشيكات
   * @param {Check[]} checks
   * @returns {number}
   */
  static sumAmount(checks) {
    return checks.reduce((sum, c) => sum + (c.amount || 0), 0);
  }

  /**
   * حساب إجمالي قيمة الشيكات الواردة (المقبوضة)
   * @param {Check[]} checks
   * @returns {number}
   */
  static sumReceived(checks) {
    return checks
      .filter(c => c.type === 'received')
      .reduce((sum, c) => sum + (c.amount || 0), 0);
  }

  /**
   * حساب إجمالي قيمة الشيكات الصادرة (المسددة)
   * @param {Check[]} checks
   * @returns {number}
   */
  static sumIssued(checks) {
    return checks
      .filter(c => c.type === 'issued')
      .reduce((sum, c) => sum + (c.amount || 0), 0);
  }

  /**
   * الحصول على الشيكات المنتهية الصلاحية
   * @param {Check[]} checks
   * @param {number} currentDate
   * @returns {Check[]}
   */
  static getOverdueChecks(checks, currentDate = Date.now()) {
    return checks.filter(c => c.isOverdue(currentDate));
  }

  /**
   * الحصول على الشيكات المعلقة التي لم تُقاص بعد
   * @param {Check[]} checks
   * @returns {Check[]}
   */
  static getPendingChecks(checks) {
    return checks.filter(c => c.status === 'pending');
  }
}