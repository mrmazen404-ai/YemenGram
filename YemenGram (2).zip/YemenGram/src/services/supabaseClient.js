import { createClient } from '@supabase/supabase-js';

// =============================================
// 1. الثوابت
// =============================================
const SUPABASE_URL =
  process.env.EXPO_PUBLIC_SUPABASE_URL ||
  process.env.NEXT_PUBLIC_SUPABASE_URL ||
  process.env.SUPABASE_URL ||
  ''; // تم إزالة الرابط الصلب للسيادة

const SUPABASE_ANON_KEY =
  process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ||
  process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY ||
  process.env.SUPABASE_ANON_KEY ||
  process.env.SUPABASE_PUBLISHABLE_KEY ||
  ''; // تم إزالة المفتاح الصلب للسيادة

// =============================================
// 2. تهيئة العميل
// =============================================
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

// =============================================
// 3. دوال الخدمة
// =============================================
const testConnection = async () => {
  try {
    console.log('🔗 [Supabase] جاري اختبار الاتصال...');

    const { data, error } = await supabase
      .from('users')
      .select('count', { count: 'exact', head: true });

    if (error) {
      console.log('❌ [Supabase] فشل الاتصال:', error.message);
      return { success: false, error: error.message };
    }

    console.log('✅ [Supabase] الاتصال ناجح!');
    return { success: true };

  } catch (error) {
    console.log('❌ [Supabase] استثناء:', error.message);
    return { success: false, error: error.message };
  }
};

const login = async (email, password) => {
  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email: email.trim(),
      password: password,
    });

    if (error) {
      console.log('❌ [Supabase] فشل تسجيل الدخول:', error.message);
      return { success: false, error: error.message };
    }

    console.log('✅ [Supabase] تم تسجيل الدخول بنجاح');
    return { success: true, user: data.user, session: data.session };

  } catch (error) {
    console.log('❌ [Supabase] استثناء في تسجيل الدخول:', error.message);
    return { success: false, error: error.message };
  }
};

const register = async (email, password, userData) => {
  try {
    const { data, error } = await supabase.auth.signUp({
      email: email.trim(),
      password: password,
      options: {
        data: {
          name: userData.name,
          company_name: userData.company_name,
          phone: userData.phone,
          user_code: userData.user_code,
        },
      },
    });

    if (error) {
      console.log('❌ [Supabase] فشل التسجيل:', error.message);
      return { success: false, error: error.message };
    }

    console.log('✅ [Supabase] تم التسجيل بنجاح');
    return { success: true, user: data.user, session: data.session };

  } catch (error) {
    console.log('❌ [Supabase] استثناء في التسجيل:', error.message);
    return { success: false, error: error.message };
  }
};

const logout = async () => {
  try {
    const { error } = await supabase.auth.signOut();

    if (error) {
      console.log('❌ [Supabase] فشل تسجيل الخروج:', error.message);
      return { success: false, error: error.message };
    }

    console.log('✅ [Supabase] تم تسجيل الخروج بنجاح');
    return { success: true };

  } catch (error) {
    console.log('❌ [Supabase] استثناء في تسجيل الخروج:', error.message);
    return { success: false, error: error.message };
  }
};

const getCurrentUser = async () => {
  try {
    const { data, error } = await supabase.auth.getUser();

    if (error) {
      console.log('❌ [Supabase] فشل جلب المستخدم:', error.message);
      return { success: false, error: error.message };
    }

    return { success: true, user: data.user };

  } catch (error) {
    console.log('❌ [Supabase] استثناء في جلب المستخدم:', error.message);
    return { success: false, error: error.message };
  }
};

const resetPassword = async (email) => {
  try {
    const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), {
      redirectTo: 'yemengram://reset-password',
    });

    if (error) {
      console.log('❌ [Supabase] فشل استعادة كلمة المرور:', error.message);
      return { success: false, error: error.message };
    }

    console.log('✅ [Supabase] تم إرسال رابط الاستعادة');
    return { success: true };

  } catch (error) {
    console.log('❌ [Supabase] استثناء في استعادة كلمة المرور:', error.message);
    return { success: false, error: error.message };
  }
};

const fetchData = async (table, userId, filters = {}) => {
  try {
    let query = supabase
      .from(table)
      .select('*')
      .eq('user_id', userId);

    for (const [key, value] of Object.entries(filters)) {
      query = query.eq(key, value);
    }

    const { data, error } = await query;

    if (error) {
      console.log(`❌ [Supabase] فشل جلب ${table}:`, error.message);
      return { success: false, error: error.message };
    }

    return { success: true, data };

  } catch (error) {
    console.log(`❌ [Supabase] استثناء في جلب ${table}:`, error.message);
    return { success: false, error: error.message };
  }
};

const insertData = async (table, data) => {
  try {
    const { data: result, error } = await supabase
      .from(table)
      .insert(data)
      .select();

    if (error) {
      console.log(`❌ [Supabase] فشل إضافة ${table}:`, error.message);
      return { success: false, error: error.message };
    }

    return { success: true, data: result };

  } catch (error) {
    console.log(`❌ [Supabase] استثناء في إضافة ${table}:`, error.message);
    return { success: false, error: error.message };
  }
};

const updateData = async (table, id, data) => {
  try {
    const { data: result, error } = await supabase
      .from(table)
      .update(data)
      .eq('id', id)
      .select();

    if (error) {
      console.log(`❌ [Supabase] فشل تحديث ${table}:`, error.message);
      return { success: false, error: error.message };
    }

    return { success: true, data: result };

  } catch (error) {
    console.log(`❌ [Supabase] استثناء في تحديث ${table}:`, error.message);
    return { success: false, error: error.message };
  }
};
const deleteData = async (table, id) => {
  try {
    const { error } = await supabase
      .from(table)
      .delete()
      .eq('id', id);

    if (error) {
      console.log(`❌ [Supabase] فشل حذف ${table}:`, error.message);
      return { success: false, error: error.message };
    }

    return { success: true };

  } catch (error) {
    console.log(`❌ [Supabase] استثناء في حذف ${table}:`, error.message);
    return { success: false, error: error.message };
  }
};

const uploadFile = async (bucket, path, fileBody, contentType = 'image/jpeg') => {
  try {
    const { data, error } = await supabase.storage
      .from(bucket)
      .upload(path, fileBody, {
        contentType,
        upsert: true
      });

    if (error) {
      console.log(`❌ [Supabase] فشل رفع الملف إلى ${bucket}:`, error.message);
      return { success: false, error: error.message };
    }

    const { data: urlData } = supabase.storage.from(bucket).getPublicUrl(path);
    return { success: true, url: urlData.publicUrl };

  } catch (error) {
    console.log(`❌ [Supabase] استثناء في رفع الملف:`, error.message);
    return { success: false, error: error.message };
  }
};

// =============================================
// ✅ تصدير مع default (الكائن كامل)
// =============================================
export default {
  supabase,
  testConnection,
  login,
  register,
  logout,
  getCurrentUser,
  resetPassword,
  fetchData,
  insertData,
  updateData,
  deleteData,
  uploadFile,
};