/**
 * بطاقة طرق الدفع السيادية (Sovereign Payment Method Card)
 * عرض بيانات التحويل مع ميزة النسخ الذكي
 */

import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';
import * as Clipboard from 'expo-clipboard';
import { Colors } from '../../../shared/utils/colors';

export default function PaymentMethodCard({ type, accountName, accountNumber, bankName, color = Colors.navy }) {

  const handleCopy = async () => {
    await Clipboard.setStringAsync(accountNumber);
    Alert.alert('تم النسخ', `تم نسخ رقم الحساب [${accountNumber}] بنجاح.`);
  };

  const getIcon = () => {
    switch (type) {
      case 'bank': return 'bank-outline';
      case 'wallet': return 'wallet-outline';
      case 'cash': return 'cash-multiple';
      default: return 'credit-card-outline';
    }
  };

  return (
    <View style={[styles.card, { borderRightColor: color }]}>
      <View style={styles.header}>
        <View style={[styles.iconBox, { backgroundColor: color + '15' }]}>
          <MaterialCommunityIcons name={getIcon()} size={24} color={color} />
        </View>
        <View style={styles.titleBox}>
          <Text style={styles.bankName}>{bankName}</Text>
          <Text style={styles.accountName}>{accountName}</Text>
        </View>
      </View>

      <View style={styles.body}>
        <View style={styles.numberBox}>
           <Text style={styles.accountNumber}>{accountNumber}</Text>
           <TouchableOpacity style={styles.copyBtn} onPress={handleCopy}>
              <Ionicons name="copy-outline" size={18} color={color} />
           </TouchableOpacity>
        </View>
      </View>

      <View style={styles.footer}>
         <Text style={styles.footerText}>يرجى إرفاق إيصال التحويل فور إتمام العملية.</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#FFF',
    borderRadius: 20,
    padding: 18,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#F1F5F9',
    borderRightWidth: 5,
    elevation: 3,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 10,
  },
  header: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 12,
    marginBottom: 15,
  },
  iconBox: {
    width: 48,
    height: 48,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
  },
  titleBox: { flex: 1, alignItems: 'flex-end' },
  bankName: { fontSize: 16, fontFamily: 'Tajawal-Bold', color: '#1E293B' },
  accountName: { fontSize: 12, fontFamily: 'Tajawal-Medium', color: '#64748B', marginTop: 2 },
  body: {
    backgroundColor: '#F8FAFC',
    borderRadius: 12,
    padding: 12,
    marginBottom: 12,
  },
  numberBox: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  accountNumber: {
    fontSize: 18,
    fontFamily: 'monospace',
    fontWeight: '700',
    color: '#0F172A',
    letterSpacing: 1,
  },
  copyBtn: {
    padding: 8,
    backgroundColor: '#FFF',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  footer: { alignItems: 'flex-end' },
  footerText: { fontSize: 10, fontFamily: 'Tajawal-Medium', color: '#94A3B8' }
});
