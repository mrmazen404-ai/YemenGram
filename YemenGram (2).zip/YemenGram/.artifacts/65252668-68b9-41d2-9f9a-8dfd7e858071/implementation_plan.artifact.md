# بروتوكول تغيير رقم الهاتف السيادي (Phone Change Protocol)

تطوير نظام آمن لتغيير رقم الهاتف للمستخدم مع التحقق من الصيغة اليمنية المعتمدة وفرض تحدي أمني (كلمة المرور) قبل التنفيذ.

## التغييرات المقترحة (Proposed Changes)

### [Component] الملف الشخصي (Profile Module)

سيتم إضافة مكون جديد لإدارة عملية التغيير وتحديث المكونات الحالية لربط الإجراء.

#### [NEW] [ChangePhoneModal.js](file:///F:/YemenGram/src/modules/settings/profile/components/ChangePhoneModal.js)
إنشاء نافذة منبثقة (Modal) تدير الخطوات التالية:
1.  **الخطوة 1 (الإدخال)**: حقل إدخال للرقم الجديد مع التحقق من:
    *   الطول: 9 أرقام بالضبط.
    *   المزود: يبدأ بـ (77, 70, 71, 78, 73).
2.  **الخطوة 2 (التأكيد)**: رسالة تأكيد للمستخدم قبل الانتقال للتحقق الأمني.
3.  **الخطوة 3 (الأمان)**: طلب كلمة المرور الحالية للتحقق من هوية صاحب الإجراء.
4.  **التنفيذ**: تحديث قاعدة البيانات محلياً وتحديث حالة التطبيق فوراً.

#### [MODIFY] [ProfileInfo.js](file:///F:/YemenGram/src/modules/settings/profile/components/ProfileInfo.js)
*   تحويل حقل "رقم الهاتف" إلى عنصر قابل للضغط (TouchableOpacity).
*   إضافة أيقونة التعديل (`create-outline`) بجانب الرقم.
*   ربط الضغط بخاصية `onEditPhone`.

#### [MODIFY] [ProfileScreen.js](file:///F:/YemenGram/src/modules/settings/profile/ProfileScreen.js)
*   إضافة حالة التحكم `showChangePhone`.
*   استيراد وعرض `ChangePhoneModal`.
*   تمرير وظيفة الفتح إلى مكون `ProfileInfo`.

#### [MODIFY] [ProfileService.js](file:///F:/YemenGram/src/modules/settings/profile/ProfileService.js)
*   إضافة دالة `updatePhone(userId, newPhone)` لتحديث جدول `user` في `LocalDB`.
*   تسجيل العملية في سجل التدقيق (Audit Log) كإجراء أمني.

## خطة التحقق (Verification Plan)

### الاختبارات اليدوية
- [ ] إدخال رقم أقل/أكثر من 9 أرقام (يجب الرفض).
- [ ] إدخال رقم لا يبدأ بالمزودات المعتمدة (يجب الرفض).
- [ ] إدخال كلمة مرور خاطئة (يجب منع التغيير).
- [ ] إدخال كلمة مرور صحيحة (تأكيد التغيير اللحظي في الشاشة).
- [ ] التحقق من بقاء البيانات بعد إعادة تشغيل التطبيق (LocalDB).

### سجل التدقيق (Security Audit)
- التأكد من ظهور سجل في `audit_log` يوضح تغيير الرقم.
