// placeholder model for subscription audit log
export default class SubscriptionAuditLog {}
