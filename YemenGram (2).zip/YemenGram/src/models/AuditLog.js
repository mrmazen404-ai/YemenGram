// src/models/AuditLog.js
// نموذج سجل التدقيق الجنائي (Audit Log Model) - v1.1 Cleaned

export const AUDIT_ACTIONS = {
  // الحساب والمصادقة
  LOGIN_SUCCESS: 'login_success',
  LOGIN_FAILED: 'login_failed',
  LOGOUT: 'logout',
  REGISTER_SUCCESS: 'register_success',

  // الملف الشخصي والأمان
  PASSWORD_CHANGE: 'password_change',
  EMAIL_CHANGE: 'email_change',
  AVATAR_UPDATE: 'avatar_update',
  ACCOUNT_DELETED: 'account_deleted',

  // العمليات المالية (قريباً)
  TRANSACTION_CREATE: 'transaction_create',
  ACCOUNT_CREATE: 'account_create',
};

export const AUDIT_COLORS = {
  login_success: '#27AE60',
  login_failed: '#E74C3C',
  logout: '#95A5A6',
  password_change: '#F1C40F',
  account_deleted: '#C0392B',
};

export const AUDIT_ICONS = {
  login_success: 'log-in',
  login_failed: 'alert-circle',
  logout: 'log-out',
  password_change: 'key',
  account_deleted: 'trash',
};
