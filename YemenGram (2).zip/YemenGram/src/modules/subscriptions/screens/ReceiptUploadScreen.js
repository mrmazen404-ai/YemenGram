import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import LocalDB from '../../database/localDB';
import ReceiptUploader from '../components/ReceiptUploader';
import { Colors } from '../../../shared/utils/colors';

export default function ReceiptUploadScreen({ route, navigation }) {
  const subscriptionId = route?.params?.subscriptionId || null;
  const [userId, setUserId] = React.useState(null);

  React.useEffect(() => {
    (async () => {
      try {
        const user = await LocalDB.getUser();
        setUserId(user?.id || null);
      } catch (error) {
        setUserId(null);
      }
    })();
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>تأكيد الهوية المالية (رفع الإيصال)</Text>
      <ReceiptUploader
        subscriptionId={subscriptionId}
        userId={userId}
        onDone={(result) => {
          if (result && result.success) {
            navigation?.navigate?.('SubscriptionVerificationPending');
          }
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 18,
    fontFamily: 'Tajawal-Bold',
    color: Colors.navy,
    marginBottom: 16,
    textAlign: 'right',
  },
});
