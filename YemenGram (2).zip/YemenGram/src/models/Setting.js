// src/models/Setting.js
// نموذج الإعدادات المركزية (Settings Model) - v1.1 Cleaned

export const SETTING_KEYS = {
  BASE_CURRENCY: 'base_currency',
  LANGUAGE: 'language',
  LAST_FULL_AUTH: 'last_full_auth_timestamp',
};

export const DEFAULT_SETTINGS = {
  base_currency: 'YER',
  language: 'ar',
};
