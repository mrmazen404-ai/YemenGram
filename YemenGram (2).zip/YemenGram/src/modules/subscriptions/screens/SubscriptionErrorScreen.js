/**
 * شاشة أعطال المحرك السيادية (Sovereign Engine Error Screen)
 * تظهر عند فشل تحميل بيانات الاشتراك أو تعطل الاتصال بالمحرك المركزي
 */

import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, SafeAreaView, Platform } from 'react-native';
import { MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';
import { Colors } from '../../../shared/utils/colors';

export default function SubscriptionErrorScreen({ route, navigation }) {
  const error = route?.params?.error || 'تعذر الاتصال بمحرك السيادة المالية حالياً.';
  const onRetry = route?.params?.onRetry;

  const handleRetry = () => {
    if (onRetry) onRetry();
    else navigation.goBack();
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>

        {/* ⚠️ أيقونة العطل */}
        <View style={styles.errorIconBox}>
          <MaterialCommunityIcons name="engine-off-outline" size={80} color={Colors.red} />
          <View style={styles.warningBadge}>
             <Ionicons name="alert" size={20} color="#FFF" />
          </View>
        </View>

        <Text style={styles.title}>عطل في محرك الاشتراك</Text>
        <Text style={styles.desc}>
          واجه النظام صعوبة في التحقق من حالة سيادتك المالية. قد يكون السبب انقطاعاً في الاتصال أو صيانة في المحرك المركزي.
        </Text>

        <View style={styles.errorCard}>
           <Text style={styles.errorLabel}>تفاصيل الخطأ التقني:</Text>
           <Text style={styles.errorText}>{error}</Text>
        </View>

        <View style={styles.actionBox}>
          <TouchableOpacity style={styles.retryBtn} onPress={handleRetry}>
            <Ionicons name="refresh" size={20} color="#FFF" />
            <Text style={styles.retryText}>محاولة استعادة الاتصال</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.supportBtn} onPress={() => navigation.navigate('Support')}>
            <Text style={styles.supportText}>التواصل مع الدعم الفني</Text>
          </TouchableOpacity>
        </View>

      </View>

      <View style={styles.footer}>
         <MaterialCommunityIcons name="shield-alert" size={14} color="#94A3B8" />
         <Text style={styles.footerText}>نظام حماية النزاهة - YemenGram ERP</Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC', justifyContent: 'center' },
  content: { padding: 30, alignItems: 'center' },
  errorIconBox: { width: 120, height: 120, justifyContent: 'center', alignItems: 'center', marginBottom: 30 },
  warningBadge: { position: 'absolute', bottom: 10, right: 10, backgroundColor: Colors.red, width: 34, height: 34, borderRadius: 17, borderWidth: 3, borderColor: '#F8FAFC', justifyContent: 'center', alignItems: 'center' },
  title: { fontSize: 22, fontFamily: 'Tajawal-Bold', color: '#0F172A', textAlign: 'center' },
  desc: { fontSize: 14, fontFamily: 'Tajawal-Medium', color: '#64748B', textAlign: 'center', marginTop: 15, lineHeight: 22 },
  errorCard: { backgroundColor: '#FFF', borderRadius: 20, padding: 20, width: '100%', marginTop: 30, borderWidth: 1, borderColor: '#FEE2E2' },
  errorLabel: { fontSize: 12, fontFamily: 'Tajawal-Bold', color: Colors.red, marginBottom: 8, textAlign: 'right' },
  errorText: { fontSize: 12, fontFamily: 'monospace', color: '#334155', textAlign: 'right' },
  actionBox: { width: '100%', marginTop: 40, gap: 15 },
  retryBtn: { backgroundColor: Colors.navy, borderRadius: 15, paddingVertical: 18, flexDirection: 'row-reverse', justifyContent: 'center', alignItems: 'center', gap: 12, elevation: 5 },
  retryText: { color: '#FFF', fontFamily: 'Tajawal-Bold', fontSize: 16 },
  supportBtn: { paddingVertical: 12, alignItems: 'center' },
  supportText: { color: '#94A3B8', fontFamily: 'Tajawal-Bold', fontSize: 14 },
  footer: { position: 'absolute', bottom: 40, alignSelf: 'center', flexDirection: 'row-reverse', alignItems: 'center', gap: 6, opacity: 0.5 },
  footerText: { fontSize: 10, fontFamily: 'Tajawal-Medium', color: '#0F172A' }
});
