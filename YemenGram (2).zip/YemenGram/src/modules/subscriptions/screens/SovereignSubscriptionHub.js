/**
 * مركز السيادة المالية (Sovereign Subscription Hub) - نسخة النخبة (Elite Edition)
 * لوحة التحكم المركزية والشاملة لكافة خدمات الاشتراك بتصميم بطاقات راقية
 */

import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  ActivityIndicator,
  RefreshControl,
  Platform,
  Dimensions
} from 'react-native';
import { MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { Colors } from '../../../shared/utils/colors';
import { useSubscriptionState } from '../hooks/useSubscriptionState';
import SubscriptionAnalytics from '../services/SubscriptionAnalytics';
import ResourceUsageBar from '../components/ResourceUsageBar';
import RenewalCountdown from '../components/RenewalCountdown';
import SafeGradient from '../../../shared/components/SafeGradient';
import SyncTester from '../../../shared/utils/syncTester';

const { width } = Dimensions.get('window');
const CARD_WIDTH = (width - 55) / 2; // حساب عرض البطاقة لعمودين مع هوامش

export default function SovereignSubscriptionHub({ navigation }) {
  const { subscription, isActive, isLoading, refresh, daysRemaining, planInfo } = useSubscriptionState();
  const [usage, setUsage] = useState(null);
  const [refreshing, setRefreshing] = useState(false);

  const loadUsageData = async () => {
    try {
      if (!subscription?.userId) return;
      const data = await SubscriptionAnalytics.getResourceUsage(subscription.userId);
      setUsage(data);
    } catch (error) {
      console.error('Usage Load Fail:', error);
    } finally {
      setRefreshing(false);
    }
  };

  useEffect(() => {
    if (!isLoading) loadUsageData();
  }, [subscription, isLoading]);

  const triggerHaptic = () => {
    if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const onRefresh = () => {
    setRefreshing(true);
    triggerHaptic();
    refresh();
    loadUsageData();
  };

  if (isLoading && !refreshing) {
    return <View style={styles.center}><ActivityIndicator size="large" color={Colors.navy} /></View>;
  }

  // ✅ مكون البطاقة الراقية (The Elite Action Card)
  const ActionCard = ({ label, icon, screen, color = Colors.navy, subLabel, isFullWidth = false }) => (
    <TouchableOpacity
      style={[styles.actionCard, isFullWidth && styles.fullWidthCard]}
      onPress={() => { triggerHaptic(); navigation.navigate(screen); }}
      activeOpacity={0.8}
    >
      <View style={[styles.cardIconBox, { backgroundColor: color + '12' }]}>
        <MaterialCommunityIcons name={icon} size={28} color={color} />
      </View>
      <View style={styles.cardTextContent}>
        <Text style={styles.cardLabel}>{label}</Text>
        {subLabel && <Text style={styles.cardSubLabel} numberOfLines={1}>{subLabel}</Text>}
      </View>
      <View style={styles.cardArrow}>
         <Ionicons name="chevron-back" size={14} color="#CBD5E1" />
      </View>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.root}>
      {/* 🛡️ الهيدر السيادي المطور */}
      <SafeGradient colors={[Colors.navy, '#1E293B']} style={styles.topNav}>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
          <Ionicons name="chevron-forward" size={24} color="#FFF" />
        </TouchableOpacity>
        <Text style={styles.navTitle}>مركز السيادة المالية</Text>
        <View style={styles.idCapsule}>
          <Text style={styles.idText}>ID: {subscription?.userId?.slice(-6).toUpperCase() || 'YG-ID'}</Text>
        </View>
      </SafeGradient>

      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.scrollContent}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={Colors.gold} />}
        showsVerticalScrollIndicator={false}
      >

        {/* 1. قسم التاج الملكي (The Crown) */}
        <View style={styles.crownSection}>
          <View style={styles.crownHeader}>
             <MaterialCommunityIcons name="crown" size={24} color={Colors.gold} />
             <Text style={styles.planName}>{planInfo?.label || 'الباقة المجانية'}</Text>
          </View>
          <RenewalCountdown days={daysRemaining} />
          <View style={styles.statusBadge}>
             <View style={[styles.statusDot, { backgroundColor: isActive ? Colors.green : Colors.red }]} />
             <Text style={styles.statusText}>{isActive ? 'السيادة نشطة' : 'السيادة مقيدة'}</Text>
          </View>
        </View>

        {/* 2. لوحة المراقبة الحية (Live Monitor) */}
        <View style={styles.monitorCard}>
          <Text style={styles.sectionTitleSmall}>مراقبة استهلاك الموارد</Text>
          <ResourceUsageBar
            label="العملاء النشطين"
            used={usage?.customers?.used || 0}
            limit={usage?.customers?.limit || 5}
            percentage={usage?.customers?.percentage || 0}
            color={Colors.navy}
          />
          <ResourceUsageBar
            label="الفواتير المحاسبية"
            used={usage?.invoices?.used || 0}
            limit={usage?.invoices?.limit || 5}
            percentage={usage?.invoices?.percentage || 0}
            color={Colors.gold}
          />
        </View>

        {/* 3. شبكة العمليات النخبوية (The Action Grid) */}

        <Text style={styles.gridTitle}>بوابة التوسع والنمو</Text>
        <View style={styles.gridContainer}>
          <ActionCard label="نظرة عامة" subLabel="تفاصيل الحالة" icon="eye-outline" screen="SubscriptionOverview" color={Colors.navy} />
          <ActionCard label="كتالوج الباقات" subLabel="استعرض المزايا" icon="apps" screen="PlansCatalog" color="#3B82F6" />
          <ActionCard label="ترقية الباقة" subLabel="رفع سقف الموارد" icon="trending-up" screen="SubscriptionUpgrade" color={Colors.gold} />
          <ActionCard label="مركز التنبيهات" subLabel="الرقابة المالية" icon="bell-ring-outline" screen="SubscriptionNotifications" color="#FFB74D" />
          <ActionCard label="الفترة المجانية" subLabel="30 يوماً تجربة" icon="gift-outline" screen="SubscriptionFreeTrialIntro" color="#10B981" isFullWidth />
        </View>

        <Text style={styles.gridTitle}>التوثيق والتحقق المالي</Text>
        <View style={styles.gridContainer}>
          <ActionCard label="أرشيف الفواتير" subLabel="PDF رسمي" icon="file-pdf-box" screen="SubscriptionInvoice" color="#EF4444" />
          <ActionCard label="سجل الإيصالات" subLabel="تتبع الدفعات" icon="receipt" screen="SubscriptionReceipts" color="#F59E0B" />
          <ActionCard label="إدارة الأجهزة" subLabel="الارتباط العتادي" icon="cellphone-link" screen="SubscriptionDeviceManagement" color="#6366F1" />
          <ActionCard label="سجل التدقيق" subLabel="النزاهة المالية" icon="shield-search" screen="SubscriptionTransactions" color={Colors.navy} />
        </View>

        <Text style={styles.gridTitle}>الدعم والسياسات</Text>
        <View style={styles.gridContainer}>
          <ActionCard label="طلب تمديد" subLabel="مهلة 7 أيام" icon="calendar-clock" screen="SubscriptionExtension" color="#8B5CF6" />
          <ActionCard label="دعم النخبة" subLabel="اتصال مباشر" icon="headset" screen="Support" color="#06B6D4" />
          <ActionCard label="استرداد مالي" subLabel="ميثاق الضمان" icon="cash-refund" screen="SubscriptionRefund" color="#94A3B8" />
          <ActionCard label="إلغاء السيادة" subLabel="إيقاف النظام" icon="cancel" screen="SubscriptionCancellation" color="#EF4444" />
        </View>

        {/* 🛠️ أدوات وضع المطور (Developer Mode Sync Testing) */}
        {__DEV__ && (
          <>
            <Text style={styles.gridTitle}>🛠️ أدوات المطور (اختبار المزامنة)</Text>
            <View style={styles.gridContainer}>
              <TouchableOpacity
                style={[styles.actionCard, { borderColor: Colors.gold, backgroundColor: '#FFFBEB' }]}
                onPress={async () => {
                  triggerHaptic();
                  const res = await SyncTester.simulateOfflineAction(subscription?.userId);
                  alert(res.success ? '✅ تم إضافة عميل وهمي لطابور المزامنة' : '❌ فشل: ' + res.error);
                }}
              >
                <View style={[styles.cardIconBox, { backgroundColor: Colors.gold + '12' }]}>
                  <MaterialCommunityIcons name="database-plus" size={28} color={Colors.gold} />
                </View>
                <View style={styles.cardTextContent}>
                  <Text style={styles.cardLabel}>إضافة عميل أوفلاين</Text>
                  <Text style={styles.cardSubLabel}>محاكاة الحفظ المحلي</Text>
                </View>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.actionCard, { borderColor: Colors.green, backgroundColor: '#ECFDF5' }]}
                onPress={async () => {
                  triggerHaptic();
                  const res = await SyncTester.runManualSync();
                  alert(res.success ? '✅ تمت المزامنة مع Supabase بنجاح' : '❌ فشل المزامنة: ' + res.error);
                }}
              >
                <View style={[styles.cardIconBox, { backgroundColor: Colors.green + '12' }]}>
                  <MaterialCommunityIcons name="cloud-sync" size={28} color={Colors.green} />
                </View>
                <View style={styles.cardTextContent}>
                  <Text style={styles.cardLabel}>مزامنة يدوية فورية</Text>
                  <Text style={styles.cardSubLabel}>دفع وسحب السحاب</Text>
                </View>
              </TouchableOpacity>
            </View>
          </>
        )}

        <View style={styles.footer}>
           <Text style={styles.footerText}>YEMEN GRAM ERP • SOVEREIGN EDITION</Text>
           <Text style={styles.versionText}>v1.0.0 SAFE BUILD</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#F8FAFC' },
  topNav: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 20,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
    elevation: 10,
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 10,
  },
  backBtn: { width: 40, height: 40, borderRadius: 15, backgroundColor: 'rgba(255,255,255,0.15)', justifyContent: 'center', alignItems: 'center' },
  navTitle: { fontSize: 18, fontFamily: 'Tajawal-Bold', color: '#FFF' },
  idCapsule: { backgroundColor: 'rgba(0,0,0,0.3)', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 12, borderWidth: 1, borderColor: 'rgba(212, 168, 83, 0.3)' },
  idText: { color: Colors.gold, fontSize: 10, fontFamily: 'Tajawal-Bold' },
  container: { flex: 1 },
  scrollContent: { padding: 15, paddingBottom: 60 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },

  // Crown Section
  crownSection: {
    backgroundColor: '#FFF',
    borderRadius: 30,
    padding: 25,
    alignItems: 'center',
    marginBottom: 20,
    marginTop: 10,
    elevation: 5,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 15,
    borderWidth: 1,
    borderColor: '#F1F5F9',
  },
  crownHeader: { flexDirection: 'row-reverse', alignItems: 'center', gap: 10, marginBottom: 20 },
  planName: { fontSize: 24, fontFamily: 'Tajawal-Bold', color: Colors.navy },
  statusBadge: { flexDirection: 'row-reverse', alignItems: 'center', gap: 6, backgroundColor: '#F8FAFC', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20, marginTop: 15 },
  statusDot: { width: 8, height: 8, borderRadius: 4 },
  statusText: { fontSize: 11, fontFamily: 'Tajawal-Bold', color: '#64748B' },

  // Monitor Card
  monitorCard: {
    backgroundColor: '#FFF',
    borderRadius: 25,
    padding: 20,
    marginBottom: 30,
    borderWidth: 1,
    borderColor: '#F1F5F9',
    elevation: 2,
  },
  sectionTitleSmall: { fontSize: 13, fontFamily: 'Tajawal-Bold', color: Colors.navy, marginBottom: 20, textAlign: 'right', opacity: 0.7 },

  // Grid Styles
  gridTitle: { fontSize: 16, fontFamily: 'Tajawal-Bold', color: '#1E293B', marginBottom: 15, marginRight: 10, textAlign: 'right' },
  gridContainer: {
    flexDirection: 'row-reverse',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 30
  },

  // Action Card Styles
  actionCard: {
    width: CARD_WIDTH,
    backgroundColor: '#FFF',
    borderRadius: 24,
    padding: 18,
    marginBottom: 15,
    borderWidth: 1.5,
    borderColor: '#F1F5F9',
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 3,
    shadowColor: '#000',
    shadowOpacity: 0.04,
    shadowRadius: 10,
  },
  fullWidthCard: {
    width: '100%',
    flexDirection: 'row-reverse',
    justifyContent: 'flex-start',
    gap: 15,
  },
  cardIconBox: {
    width: 54,
    height: 54,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  cardTextContent: { alignItems: 'center', flex: 1 },
  cardLabel: { fontSize: 14, fontFamily: 'Tajawal-Bold', color: '#334155', textAlign: 'center' },
  cardSubLabel: { fontSize: 10, fontFamily: 'Tajawal-Medium', color: '#94A3B8', marginTop: 4, textAlign: 'center' },
  cardArrow: { position: 'absolute', left: 15, top: 18 },

  footer: { alignItems: 'center', marginTop: 30 },
  footerText: { fontSize: 10, fontFamily: 'Tajawal-Bold', color: '#CBD5E1', letterSpacing: 1 },
  versionText: { fontSize: 8, color: '#E2E8F0', marginTop: 5 }
});
