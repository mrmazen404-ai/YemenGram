/**
 * شاشة الخطة الشهرية السيادية (Sovereign Monthly Plan Screen)
 * تعرض تفاصيل العقد الشهري والمزايا قبل الانتقال للدفع
 */

import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, SafeAreaView } from 'react-native';
import { MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';
import { Colors } from '../../../shared/utils/colors';

export default function MonthlyPlanScreen({ navigation }) {
  const features = [
    { title: 'دعم حتى 3 أجهزة متزامنة', icon: 'devices' },
    { title: 'إدارة 100 عميل بنشاط كامل', icon: 'account-group' },
    { title: 'إصدار 500 فاتورة شهرياً', icon: 'file-document-edit' },
    { title: 'مزامنة سحابية لحظية محمية', icon: 'cloud-sync' },
    { title: 'تقارير محاسبية أساسية', icon: 'chart-bar' },
    { title: 'دعم فني عبر البريد والواتساب', icon: 'headset' },
  ];

  return (
    <SafeAreaView style={styles.root}>
      <ScrollView style={styles.container} contentContainerStyle={styles.content}>

        {/* 🛡️ الهيدر الفخم */}
        <View style={styles.header}>
          <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
            <Ionicons name="chevron-forward" size={24} color={Colors.navy} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>تفاصيل العقد الشهري</Text>
          <View style={{ width: 40 }} />
        </View>

        {/* 💰 بطاقة السعر */}
        <View style={styles.priceCard}>
           <Text style={styles.planName}>الخطة الشهرية</Text>
           <View style={styles.amountRow}>
              <Text style={styles.currency}>ر.ي</Text>
              <Text style={styles.amount}>3,000</Text>
              <Text style={styles.period}>/ شهرياً</Text>
           </View>
           <View style={styles.badge}>
              <Text style={styles.badgeText}>الأكثر طلباً للناشئين</Text>
           </View>
        </View>

        <Text style={styles.sectionTitle}>مزايا السيادة المالية:</Text>

        {/* 📋 قائمة المميزات */}
        <View style={styles.featureGrid}>
          {features.map((f, i) => (
            <View key={i} style={styles.featureItem}>
              <View style={styles.iconCircle}>
                <MaterialCommunityIcons name={f.icon} size={20} color={Colors.navy} />
              </View>
              <Text style={styles.featureText}>{f.title}</Text>
            </View>
          ))}
        </View>

        {/* 📜 ميثاق الخدمة */}
        <View style={styles.termsBox}>
           <Text style={styles.termsTitle}>ميثاق الاشتراك:</Text>
           <Text style={styles.termsText}>• يتم تفعيل الميزات فور التأكد من إيصال التحويل.</Text>
           <Text style={styles.termsText}>• يحق لك إلغاء الاشتراك في أي وقت مع بقاء الميزات لنهاية المدة.</Text>
           <Text style={styles.termsText}>• البيانات تظل محفوظة لمدة 90 يوماً بعد انتهاء الاشتراك.</Text>
        </View>

        <TouchableOpacity
          style={styles.subscribeBtn}
          onPress={() => navigation.navigate('SubscriptionPayment', { plan: 'monthly', amount: 3000 })}
        >
          <Text style={styles.subscribeBtnText}>الموافقة والذهاب للدفع</Text>
          <Ionicons name="arrow-back" size={20} color="#FFF" />
        </TouchableOpacity>

        <Text style={styles.footerNote}>بالضغط على الزر أعلاه، أنت توافق على شروط ميثاق اليمن جرام.</Text>

      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#F8FAFC' },
  container: { flex: 1 },
  content: { padding: 20, paddingBottom: 40 },
  header: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', marginBottom: 30 },
  backBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: '#FFF', justifyContent: 'center', alignItems: 'center', elevation: 2 },
  headerTitle: { fontSize: 18, fontFamily: 'Tajawal-Bold', color: Colors.navy },
  priceCard: {
    backgroundColor: Colors.navy,
    borderRadius: 30,
    padding: 30,
    alignItems: 'center',
    marginBottom: 30,
    elevation: 10,
    shadowColor: Colors.navy,
    shadowOpacity: 0.3,
    shadowRadius: 20,
  },
  planName: { fontSize: 16, fontFamily: 'Tajawal-Medium', color: 'rgba(255,255,255,0.7)', marginBottom: 10 },
  amountRow: { flexDirection: 'row-reverse', alignItems: 'baseline', gap: 5 },
  amount: { fontSize: 42, fontFamily: 'Tajawal-Bold', color: '#FFF' },
  currency: { fontSize: 18, fontFamily: 'Tajawal-Bold', color: Colors.gold },
  period: { fontSize: 14, fontFamily: 'Tajawal-Medium', color: 'rgba(255,255,255,0.5)' },
  badge: { backgroundColor: Colors.gold, paddingHorizontal: 15, paddingVertical: 5, borderRadius: 10, marginTop: 20 },
  badgeText: { fontSize: 12, fontFamily: 'Tajawal-Bold', color: Colors.navy },
  sectionTitle: { fontSize: 16, fontFamily: 'Tajawal-Bold', color: '#334155', marginBottom: 20, textAlign: 'right' },
  featureGrid: { gap: 15, marginBottom: 35 },
  featureItem: { flexDirection: 'row-reverse', alignItems: 'center', gap: 15 },
  iconCircle: { width: 40, height: 40, borderRadius: 12, backgroundColor: '#FFF', justifyContent: 'center', alignItems: 'center', elevation: 2 },
  featureText: { fontSize: 14, fontFamily: 'Tajawal-Medium', color: '#475569', flex: 1, textAlign: 'right' },
  termsBox: { backgroundColor: '#F1F5F9', borderRadius: 20, padding: 20, marginBottom: 35 },
  termsTitle: { fontSize: 13, fontFamily: 'Tajawal-Bold', color: Colors.navy, marginBottom: 10, textAlign: 'right' },
  termsText: { fontSize: 11, fontFamily: 'Tajawal-Medium', color: '#64748B', textAlign: 'right', marginBottom: 5 },
  subscribeBtn: {
    backgroundColor: Colors.navy,
    borderRadius: 20,
    paddingVertical: 20,
    flexDirection: 'row-reverse',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 15,
    elevation: 5,
  },
  subscribeBtnText: { color: '#FFF', fontFamily: 'Tajawal-Bold', fontSize: 16 },
  footerNote: { fontSize: 10, fontFamily: 'Tajawal-Medium', color: '#94A3B8', textAlign: 'center', marginTop: 15 },
});