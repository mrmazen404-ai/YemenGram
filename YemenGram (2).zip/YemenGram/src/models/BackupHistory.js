// src/models/BackupHistory.js
// =============================================
// نموذج سجل النسخ الاحتياطي (Backup History Model)
// المسؤول عن تتبع عمليات النسخ الاحتياطي والاستعادة
// =============================================

import { Model } from '@nozbe/watermelondb';
import { field, date, readonly } from '@nozbe/watermelondb/decorators';
import { Q } from '@nozbe/watermelondb';

export default class BackupHistory extends Model {
  // ===== 1. اسم الجدول =====
  static table = 'backup_history';

  // ===== 2. الحقول الأساسية =====

  // اسم ملف النسخ الاحتياطي
  @field('filename') filename;

  // حجم الملف (بالبايت)
  @field('size') size;

  // نوع النسخ الاحتياطي (local, google_drive, cloud)
  @field('type') type;

  // حالة النسخ الاحتياطي (pending, success, failed)
  @field('status') status;

  // ملاحظات إضافية
  @field('notes') notes;

  // ===== 3. التواريخ التلقائية =====

  @readonly @date('created_at') createdAt;

  // ===== 4. دوال مساعدة =====

  /**
   * الحصول على نوع النسخ الاحتياطي باللغة العربية
   * @returns {string}
   */
  getTypeArabic() {
    const types = {
      local: 'محلي',
      google_drive: 'Google Drive',
      cloud: 'سحابي',
    };
    return types[this.type] || this.type;
  }

  /**
   * الحصول على حالة النسخ الاحتياطي باللغة العربية
   * @returns {string}
   */
  getStatusArabic() {
    const statuses = {
      pending: 'قيد التنفيذ',
      success: 'نجاح',
      failed: 'فشل',
    };
    return statuses[this.status] || this.status;
  }

  /**
   * الحصول على لون الحالة
   * @returns {string}
   */
  getStatusColor() {
    const colors = {
      pending: '#F39C12',
      success: '#27AE60',
      failed: '#E74C3C',
    };
    return colors[this.status] || '#6B7280';
  }

  /**
   * الحصول على أيقونة الحالة
   * @returns {string}
   */
  getStatusIcon() {
    const icons = {
      pending: 'time',
      success: 'checkmark-circle',
      failed: 'close-circle',
    };
    return icons[this.status] || 'document';
  }

  /**
   * الحصول على حجم الملف بتنسيق مقروء
   * @returns {string}
   */
  getFormattedSize() {
    if (!this.size || this.size === 0) return '0 B';

    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(this.size) / Math.log(1024));
    const value = (this.size / Math.pow(1024, i)).toFixed(2);
    return `${value} ${sizes[i]}`;
  }

  /**
   * الحصول على تاريخ النسخ الاحتياطي المنسق
   * @returns {string}
   */
  getFormattedDate() {
    if (!this.createdAt) return '';
    const date = new Date(this.createdAt);
    return date.toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  }

  /**
   * الحصول على وقت النسخ الاحتياطي (بالصيغة النسبية)
   * @returns {string}
   */
  getTimeAgo() {
    if (!this.createdAt) return '';
    const now = Date.now();
    const diff = now - this.createdAt;

    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const weeks = Math.floor(diff / (1000 * 60 * 60 * 24 * 7));
    const months = Math.floor(diff / (1000 * 60 * 60 * 24 * 30));

    if (minutes < 1) return 'الآن';
    if (minutes < 60) return `منذ ${minutes} دقيقة`;
    if (hours < 24) return `منذ ${hours} ساعة`;
    if (days < 7) return `منذ ${days} يوم`;
    if (weeks < 4) return `منذ ${weeks} أسبوع`;
    if (months < 12) return `منذ ${months} شهر`;
    return `منذ ${Math.floor(months / 12)} سنة`;
  }

  /**
   * الحصول على اسم النسخ الاحتياطي المعروض
   * @returns {string}
   */
  getDisplayName() {
    return `${this.filename || 'نسخ احتياطي'} - ${this.getFormattedDate()}`;
  }

  /**
   * الحصول على ملخص النسخ الاحتياطي
   * @returns {string}
   */
  getSummary() {
    const size = this.getFormattedSize();
    const type = this.getTypeArabic();
    const status = this.getStatusArabic();
    const date = this.getFormattedDate();
    return `[${type}] ${size} - ${status} (${date})`;
  }

  /**
   * التحقق من أن النسخ الاحتياطي ناجح
   * @returns {boolean}
   */
  isSuccess() {
    return this.status === 'success';
  }

  /**
   * التحقق من أن النسخ الاحتياطي فاشل
   * @returns {boolean}
   */
  isFailed() {
    return this.status === 'failed';
  }

  /**
   * التحقق من أن النسخ الاحتياطي قيد التنفيذ
   * @returns {boolean}
   */
  isPending() {
    return this.status === 'pending';
  }

  // ===== 5. دوال ثابتة =====

  /**
   * إنشاء سجل نسخ احتياطي جديد
   * @param {Database} database
   * @param {string} filename
   * @param {string} type
   * @param {string} status
   * @param {number} size
   * @param {string} notes
   * @returns {Promise<BackupHistory>}
   */
  static async createBackupLog(database, filename, type, status = 'pending', size = 0, notes = null) {
    return await database.write(async () => {
      return await database.get('backup_history').create(log => {
        log.filename = filename || `backup_${Date.now()}.db`;
        log.type = type || 'local';
        log.status = status || 'pending';
        log.size = size || 0;
        log.notes = notes || null;
      });
    });
  }

  /**
   * تحديث حالة نسخ احتياطي
   * @param {Database} database
   * @param {string} backupId
   * @param {string} status
   * @param {number} size
   * @param {string} notes
   * @returns {Promise<void>}
   */
  static async updateBackupStatus(database, backupId, status, size = null, notes = null) {
    await database.write(async () => {
      const backup = await database.get('backup_history').find(backupId);
      await backup.update(() => {
        backup.status = status;
        if (size !== null) backup.size = size;
        if (notes !== null) backup.notes = notes;
      });
    });
  }

  /**
   * الحصول على آخر نسخ احتياطي ناجح
   * @param {Database} database
   * @returns {Promise<BackupHistory|null>}
   */
  static async getLastSuccessfulBackup(database) {
    const backups = await database.get('backup_history').query(
      Q.where('status', 'success'),
      Q.sortBy('created_at', Q.desc),
      Q.take(1)
    ).fetch();

    return backups.length > 0 ? backups[0] : null;
  }

  /**
   * الحصول على عدد الأيام منذ آخر نسخ احتياطي ناجح
   * @param {Database} database
   * @param {number} currentDate
   * @returns {Promise<number>}
   */
  static async getDaysSinceLastBackup(database, currentDate = Date.now()) {
    const lastBackup = await this.getLastSuccessfulBackup(database);
    if (!lastBackup) return -1;

    const diff = currentDate - lastBackup.createdAt;
    return Math.floor(diff / (1000 * 60 * 60 * 24));
  }

  /**
   * الحصول على جميع النسخ الاحتياطية حسب النوع
   * @param {Database} database
   * @param {string} type
   * @param {number} limit
   * @returns {Promise<BackupHistory[]>}
   */
  static async getBackupsByType(database, type, limit = 50) {
    return database.get('backup_history').query(
      Q.where('type', type),
      Q.sortBy('created_at', Q.desc),
      Q.take(limit)
    ).fetch();
  }

  /**
   * الحصول على النسخ الاحتياطية الفاشلة
   * @param {Database} database
   * @param {number} limit
   * @returns {Promise<BackupHistory[]>}
   */
  static async getFailedBackups(database, limit = 20) {
    return database.get('backup_history').query(
      Q.where('status', 'failed'),
      Q.sortBy('created_at', Q.desc),
      Q.take(limit)
    ).fetch();
  }

  /**
   * حذف النسخ الاحتياطية القديمة
   * @param {Database} database
   * @param {number} olderThanDays
   * @returns {Promise<number>}
   */
  static async deleteOldBackups(database, olderThanDays = 30) {
    const cutoffDate = Date.now() - (olderThanDays * 24 * 60 * 60 * 1000);

    const oldBackups = await database.get('backup_history').query(
      Q.where('created_at', Q.lt(cutoffDate))
    ).fetch();

    await database.write(async () => {
      for (const backup of oldBackups) {
        await backup.destroyPermanently();
      }
    });

    return oldBackups.length;
  }

  /**
   * الحصول على إحصائيات النسخ الاحتياطي
   * @param {Database} database
   * @returns {Promise<Object>}
   */
  static async getStats(database) {
    const backups = await database.get('backup_history').query().fetch();

    const stats = {
      total: backups.length,
      success: 0,
      failed: 0,
      pending: 0,
      byType: {},
      totalSize: 0,
      lastSuccess: null,
      lastFailed: null,
    };

    for (const backup of backups) {
      // حسب الحالة
      if (backup.status === 'success') stats.success++;
      else if (backup.status === 'failed') stats.failed++;
      else stats.pending++;

      // حسب النوع
      if (!stats.byType[backup.type]) {
        stats.byType[backup.type] = 0;
      }
      stats.byType[backup.type]++;

      // إجمالي الحجم
      stats.totalSize += backup.size || 0;

      // آخر نجاح وفشل
      if (backup.status === 'success') {
        if (!stats.lastSuccess || backup.createdAt > stats.lastSuccess.createdAt) {
          stats.lastSuccess = backup;
        }
      } else if (backup.status === 'failed') {
        if (!stats.lastFailed || backup.createdAt > stats.lastFailed.createdAt) {
          stats.lastFailed = backup;
        }
      }
    }

    return stats;
  }
}