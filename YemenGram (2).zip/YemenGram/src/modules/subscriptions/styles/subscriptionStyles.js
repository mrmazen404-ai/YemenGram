// placeholder styles for subscriptions
export default {};
