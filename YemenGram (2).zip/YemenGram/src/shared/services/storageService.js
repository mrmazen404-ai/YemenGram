// src/shared/services/storageService.js
// خدمة التخزين المركزي (Storage Orchestrator) - v1.2 Cleaned

import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';
import { LocalDB } from '../../modules/database/localDB';

export const STORAGE_KEYS = {
  USER_DATA: 'userData',
  AUTH_TOKEN: 'userToken',
  DEVICE_FINGERPRINT: 'deviceFingerprint',
  THEME_MODE: 'themeMode',
};

export const StorageService = {
  // التخزين العادي (AsyncStorage)
  async setItem(key, value) {
    try {
      await AsyncStorage.setItem(key, JSON.stringify(value));
    } catch (e) {}
  },

  async getItem(key) {
    try {
      const val = await AsyncStorage.getItem(key);
      return val ? JSON.parse(val) : null;
    } catch (e) { return null; }
  },

  // التخزين الآمن عتادياً (SecureStore)
  async setSecureItem(key, value) {
    try {
      await SecureStore.setItemAsync(key, value);
    } catch (e) {}
  },

  async getSecureItem(key) {
    try {
      return await SecureStore.getItemAsync(key);
    } catch (e) { return null; }
  }
};

export { LocalDB };
