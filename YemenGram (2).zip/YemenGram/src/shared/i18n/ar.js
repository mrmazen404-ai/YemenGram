// src/shared/i18n/ar.js
// ملف الترجمة العربية (Arabic Localization) - v1.2 Cleaned

export default {
  common: {
    save: 'حفظ',
    cancel: 'إلغاء',
    confirm: 'تأكيد',
    delete: 'حذف',
    edit: 'تعديل',
    next: 'التالي',
    back: 'رجوع',
    loading: 'جاري التحميل...',
    success: 'تم بنجاح',
    error: 'حدث خطأ ما',
  },
  auth: {
    login: 'تسجيل الدخول',
    register: 'إنشاء حساب',
    logout: 'تسجيل الخروج',
    email: 'البريد الإلكتروني',
    password: 'كلمة المرور',
    forgot_password: 'نسيت كلمة المرور؟',
  },
  profile: {
    title: 'الملف الشخصي',
    security: 'الأمان',
    appearance: 'المظهر',
  },
  settings: {
    title: 'الإعدادات',
    notifications: 'الإشعارات',
  }
};
