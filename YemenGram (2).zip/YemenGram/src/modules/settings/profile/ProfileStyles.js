// src/modules/settings/profile/ProfileStyles.js
// الدليل البصري للهوية (Sovereign Profile Visual Guide)

import { StyleSheet, Dimensions } from 'react-native';
import { Colors } from '../../../shared/utils/colors';

const { width } = Dimensions.get('window');

export const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: Colors.white,
  },

  // قسم الأفاتار (Hero Section)
  heroSection: {
    alignItems: 'center',
    paddingVertical: 30,
    backgroundColor: '#F8FAFC',
    borderBottomLeftRadius: 40,
    borderBottomRightRadius: 40,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 3,
  },

  avatarContainer: {
    width: 130,
    height: 130,
    borderRadius: 65,
    borderWidth: 3,
    borderColor: Colors.gold,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.white,
    position: 'relative',
    shadowColor: Colors.gold,
    shadowOpacity: 0.2,
    shadowRadius: 15,
    elevation: 10,
  },

  avatarImage: {
    width: 120,
    height: 120,
    borderRadius: 60,
  },

  avatarInitial: {
    width: 120,
    height: 120,
    borderRadius: 60,
    justifyContent: 'center',
    alignItems: 'center',
  },

  initialText: {
    fontSize: 48,
    fontFamily: 'Tajawal-Bold',
    color: Colors.white,
  },

  editBadge: {
    position: 'absolute',
    bottom: 5,
    right: 5,
    backgroundColor: Colors.navy,
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    borderColor: Colors.white,
  },

  userName: {
    fontSize: 22,
    fontFamily: 'Tajawal-Bold',
    color: Colors.dark,
    marginTop: 15,
  },

  userCode: {
    display: 'none', // سنخفيه من هنا لنظهره في الصندوق الجديد
  },

  // صندوق الهوية النخبوي (Sovereign ID Box)
  idCard: {
    backgroundColor: Colors.white,
    marginHorizontal: 10,
    borderRadius: 24,
    padding: 10,
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 25,
    borderWidth: 1.5,
    borderColor: Colors.white,
    shadowColor: Colors.gold,
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.1,
    shadowRadius: 20,
    elevation: 8,
     backgroundColor: Colors.white,
        borderRadius: 20,
        padding: 16,
        borderWidth: 1,
        borderColor: '#F1F5F9',
        shadowColor: '#000',
        shadowOpacity: 0.02,
        shadowRadius: 5,
        elevation: 2,
  },

  idInfo: {
    alignItems: 'flex-end',
  },

  idLabel: {
    fontSize: 10,
    fontFamily: 'Tajawal-Medium',
      color: Colors.navyDark,
    letterSpacing: 1,
    marginBottom: 1,
  },

  idValue: {
    fontSize: 14,
    fontFamily: 'Tajawal-Bold',
    color: Colors.navy,
    letterSpacing: 1,
  },

  copyBtn: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    width: 44,
    height: 44,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },

  // كتل البيانات (Information Cards)
  section: {
    paddingHorizontal: 20,
    marginBottom: 25,
  },

  sectionHeader: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    marginBottom: 15,
    gap: 8,
  },

  sectionTitle: {
    fontSize: 16,
    fontFamily: 'Tajawal-Bold',
    color: Colors.navy,
  },

  card: {
    backgroundColor: Colors.white,
    borderRadius: 20,
    padding: 16,
    borderWidth: 1,
    borderColor: '#F1F5F9',
    shadowColor: '#000',
    shadowOpacity: 0.02,
    shadowRadius: 5,
    elevation: 2,
  },

  infoItem: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F8FAFC',
  },

  lastItem: {
    borderBottomWidth: 0,
  },

  infoLabel: {
    fontSize: 13,
    fontFamily: 'Tajawal-Medium',
    color: Colors.gray,
  },

  infoValue: {
    fontSize: 14,
    fontFamily: 'Tajawal-Bold',
    color: Colors.dark,
  },

  // منطقة الخطر (Danger Zone)
  deleteBtn: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 10,
    paddingVertical: 15,
  },

  deleteText: {
    fontSize: 14,
    fontFamily: 'Tajawal-Bold',
    color: Colors.red,
  },

  // خيارات الصورة (Action Sheet)
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  actionSheet: {
    backgroundColor: Colors.white,
    borderTopLeftRadius: 25,
    borderTopRightRadius: 25,
    padding: 20,
    alignItems: 'center',
  },
  sheetTitle: {
    fontSize: 16,
    fontFamily: 'Tajawal-Bold',
    color: Colors.gray,
    marginBottom: 20,
  },
  sheetItem: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    width: '100%',
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
    gap: 12,
  },
  itemText: {
    fontSize: 15,
    fontFamily: 'Tajawal-Medium',
    color: Colors.dark,
  },
  deleteItem: {
    borderBottomWidth: 0,
  },
  cancelItem: {
    marginTop: 10,
    width: '100%',
    alignItems: 'center',
    paddingVertical: 15,
    backgroundColor: '#F8FAFC',
    borderRadius: 15,
  },
  cancelText: {
    fontSize: 15,
    fontFamily: 'Tajawal-Bold',
    color: Colors.navy,
  }
});
