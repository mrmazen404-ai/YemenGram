/**
 * شاشة الوصول للأرشيف البارد (Sovereign Archived Access Screen)
 * تظهر للمستخدم بعد 120 يوماً من انتهاء الاشتراك (حالة البيانات المتجمدة)
 */

import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, SafeAreaView, ScrollView } from 'react-native';
import { MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';
import { Colors } from '../../../shared/utils/colors';

export default function ArchivedAccessScreen({ navigation }) {
  return (
    <SafeAreaView style={styles.root}>
      <ScrollView style={styles.container} contentContainerStyle={styles.content}>

        {/* ❄️ أيقونة التجمد */}
        <View style={styles.frozenHeader}>
          <View style={styles.iconCircle}>
             <MaterialCommunityIcons name="snowflake" size={60} color="#3B82F6" />
          </View>
          <Text style={styles.title}>بياناتك في الأرشفة الباردة</Text>
          <Text style={styles.subtitle}>لقد مر أكثر من 120 يوماً على انتهاء السيادة المالية. تم تجميد حسابك لحماية تاريخك المحاسبي.</Text>
        </View>

        <View style={styles.statusCard}>
           <Text style={styles.statusTitle}>حالة البيئة الحالية:</Text>
           <View style={styles.statusRow}>
              <Ionicons name="lock-closed" size={18} color="#EF4444" />
              <Text style={styles.statusText}>الدخول العملياتي: محظور</Text>
           </View>
           <View style={styles.statusRow}>
              <Ionicons name="eye-outline" size={18} color={Colors.navy} />
              <Text style={styles.statusText}>عرض التقارير القديمة: متاح (محدود)</Text>
           </View>
           <View style={styles.statusRow}>
              <Ionicons name="cloud-upload-outline" size={18} color="#94A3B8" />
              <Text style={styles.statusText}>المزامنة السحابية: متوقفة</Text>
           </View>
        </View>

        <View style={styles.infoBox}>
           <Text style={styles.infoTitle}>كيفية فك التجميد؟</Text>
           <Text style={styles.infoText}>
             لاستعادة السيادة الكاملة والبدء في إضافة بيانات جديدة، يجب عليك طلب "فك أرشفة" واختيار باقة اشتراك جديدة.
           </Text>
        </View>

        <TouchableOpacity
          style={styles.unfreezeBtn}
          onPress={() => navigation.navigate('PlansCatalog')}
        >
          <Text style={styles.unfreezeBtnText}>طلب فك التجميد والترقية</Text>
          <MaterialCommunityIcons name="fire" size={20} color="#FFF" />
        </TouchableOpacity>

        <TouchableOpacity style={styles.backBtn} onPress={handleBack}>
          <Text style={styles.backText}>العودة للوحة التحكم (قراءة فقط)</Text>
        </TouchableOpacity>

      </ScrollView>

      <View style={styles.footer}>
         <Text style={styles.footerText}>YEMEN GRAM - COLD STORAGE SYSTEM</Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#EFF6FF' }, // خلفية زرقاء باردة
  container: { flex: 1 },
  content: { padding: 30, paddingTop: 60, alignItems: 'center' },
  frozenHeader: { alignItems: 'center', marginBottom: 40 },
  iconCircle: { width: 120, height: 120, borderRadius: 60, backgroundColor: '#DBEAFE', justifyContent: 'center', alignItems: 'center', marginBottom: 25, elevation: 5 },
  title: { fontSize: 24, fontFamily: 'Tajawal-Bold', color: '#1E40AF', textAlign: 'center' },
  subtitle: { fontSize: 13, fontFamily: 'Tajawal-Medium', color: '#60A5FA', textAlign: 'center', marginTop: 12, lineHeight: 20 },
  statusCard: { backgroundColor: '#FFF', borderRadius: 24, padding: 25, width: '100%', marginBottom: 30, borderWidth: 1, borderColor: '#BFDBFE' },
  statusTitle: { fontSize: 15, fontFamily: 'Tajawal-Bold', color: Colors.navy, marginBottom: 20, textAlign: 'right' },
  statusRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 12, marginBottom: 15 },
  statusText: { fontSize: 13, fontFamily: 'Tajawal-Medium', color: '#334155' },
  infoBox: { backgroundColor: 'rgba(59, 130, 246, 0.1)', borderRadius: 15, padding: 20, marginBottom: 40 },
  infoTitle: { fontSize: 14, fontFamily: 'Tajawal-Bold', color: '#1E40AF', textAlign: 'right', marginBottom: 8 },
  infoText: { fontSize: 12, fontFamily: 'Tajawal-Medium', color: '#1E40AF', textAlign: 'right', lineHeight: 18 },
  unfreezeBtn: { backgroundColor: Colors.navy, width: '100%', borderRadius: 16, paddingVertical: 18, flexDirection: 'row-reverse', justifyContent: 'center', alignItems: 'center', gap: 15, elevation: 5 },
  unfreezeBtnText: { color: '#FFF', fontFamily: 'Tajawal-Bold', fontSize: 16 },
  backBtn: { marginTop: 25, paddingVertical: 10 },
  backText: { color: '#94A3B8', fontFamily: 'Tajawal-Bold', fontSize: 13 },
  footer: { position: 'absolute', bottom: 30, alignSelf: 'center' },
  footerText: { fontSize: 10, color: '#BFDBFE', fontFamily: 'Tajawal-Bold', letterSpacing: 1 }
});