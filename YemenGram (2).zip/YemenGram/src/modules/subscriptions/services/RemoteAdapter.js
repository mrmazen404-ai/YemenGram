/**
 * محول الاتصال البعيد (Sovereign Remote Adapter)
 */

import SupabaseService from '../../../services/supabaseClient';

class RemoteAdapter {
  constructor(cfg) {
    this.cfg = cfg || {};
  }

  /**
   * إرسال سجل مزامنة إلى Supabase
   */
  async send(queueEntry) {
    const payload = queueEntry.payload || queueEntry.data || queueEntry;

    try {
      // تدفق تحديثات الاشتراك
      if (payload.type === 'subscription_update' || (payload.tableName === 'subscriptions')) {
        const subscriptionId = payload.subscriptionId || payload.recordId || (payload.data && payload.data.id);
        const data = payload.data || { prevState: payload.prevState, nextState: payload.nextState, event: payload.event, ctx: payload.ctx };

        if (payload.idempotencyKey) data.idempotency_key = payload.idempotencyKey;

        if (subscriptionId) {
          const res = await SupabaseService.updateData('subscriptions', subscriptionId, data);
          if (res.success) return { success: true, action: 'update', data: res.data };

          const ins = await SupabaseService.insertData('subscriptions', [{ id: subscriptionId, ...data }]);
          return { success: ins.success, action: 'insert', data: ins.data };
        }

        const ins2 = await SupabaseService.insertData('subscriptions', [data]);
        return { success: ins2.success, action: 'insert', data: ins2.data };
      }

      // معالج عام للجداول المالية
      if (payload.tableName) {
        const table = payload.tableName;
        if (payload.action === 'insert') {
          const ins = await SupabaseService.insertData(table, [payload.data]);
          return { success: ins.success, action: 'insert', data: ins.data };
        }
        if (payload.action === 'update' && payload.recordId) {
          const upd = await SupabaseService.updateData(table, payload.recordId, payload.data);
          return { success: upd.success, action: 'update', data: upd.data };
        }
      }

      return { success: false, error: 'unsupported_payload' };
    } catch (error) {
      return { success: false, error: error.message || String(error) };
    }
  }
}

export default RemoteAdapter;
