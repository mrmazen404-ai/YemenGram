/**
 * شاشة إدارة الأجهزة السيادية (Sovereign Device Management)
 */

import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Alert,
  ActivityIndicator,
  RefreshControl,
  SafeAreaView,
  TouchableOpacity
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';
import LocalDB from '../../database/localDB';
import HardwareGuard from '../utils/HardwareGuard';
import DeviceCard from '../components/DeviceCard';
import { useSubscriptionState } from '../hooks/useSubscriptionState';
import { Colors } from '../../../shared/utils/colors';

export default function DeviceManagementScreen() {
  const navigation = useNavigation();
  const { subscription, isLoading: isStateLoading } = useSubscriptionState();
  const [devices, setDevices] = React.useState([]);
  const [currentHwid, setCurrentHwid] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const [refreshing, setRefreshing] = React.useState(false);

  const loadDevices = async () => {
    try {
      const hwid = await HardwareGuard.getSovereignId();
      setCurrentHwid(hwid);

      if (!subscription?.userId) return;

      const rows = await LocalDB.query(
        'SELECT * FROM devices WHERE user_id = ? ORDER BY last_seen DESC',
        [subscription.userId]
      );
      setDevices(rows);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  React.useEffect(() => {
    if (!isStateLoading) loadDevices();
  }, [subscription, isStateLoading]);

  const handleUnbind = (device) => {
    Alert.alert(
      'تأكيد فك الارتباط',
      `هل أنت متأكد من حذف الجهاز [${device.name}]؟ لن يتمكن هذا الجهاز من الدخول للنظام إلا بعد إعادة تسجيله.`,
      [
        { text: 'تراجع', style: 'cancel' },
        {
          text: 'تأكيد الحذف',
          style: 'destructive',
          onPress: async () => {
            await LocalDB.execute('DELETE FROM devices WHERE id = ?', [device.id]);
            loadDevices();
          }
        }
      ]
    );
  };

  if (loading || isStateLoading) {
    return <View style={styles.center}><ActivityIndicator size="large" color={Colors.navy} /></View>;
  }

  return (
    <SafeAreaView style={styles.container}>
      {/* 🛡️ الهيدر */}
      <View style={styles.headerNav}>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
           <Ionicons name="chevron-forward" size={24} color={Colors.navy} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>إدارة الأجهزة</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); loadDevices(); }} />}
      >
        <View style={styles.header}>
          <Text style={styles.title}>الأجهزة المرتبطة</Text>
          <View style={styles.badge}>
             <Text style={styles.badgeText}>{devices.length} / {subscription?.maxDevices || 1} أجهزة</Text>
          </View>
        </View>

        <Text style={styles.subtitle}>يمكنك فك ارتباط الأجهزة القديمة لتحرير مقاعد لأجهزة جديدة.</Text>

        {devices.map((device) => (
          <DeviceCard
            key={device.id}
            device={device}
            isCurrent={device.device_id === currentHwid}
            onUnbind={() => handleUnbind(device)}
          />
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC' },
  headerNav: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingVertical: 15, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#F1F5F9' },
  backBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: '#F8FAFC', justifyContent: 'center', alignItems: 'center' },
  headerTitle: { fontSize: 18, fontFamily: 'Tajawal-Bold', color: Colors.navy },
  content: { padding: 20, paddingBottom: 40 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  title: { fontSize: 24, fontFamily: 'Tajawal-Bold', color: '#0F172A' },
  badge: { backgroundColor: Colors.navy, paddingHorizontal: 12, paddingVertical: 4, borderRadius: 10 },
  badgeText: { color: '#FFF', fontSize: 12, fontFamily: 'Tajawal-Bold' },
  subtitle: { fontSize: 13, fontFamily: 'Tajawal-Medium', color: '#64748B', textAlign: 'right', marginBottom: 25 },
});
