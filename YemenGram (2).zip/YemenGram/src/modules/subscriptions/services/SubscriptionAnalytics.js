
import { LocalDB } from '../../database/localDB';
import { store } from '../../../store';
export const SubscriptionAnalytics = {

  async getResourceUsage(userId) {
    try {
      if (!userId) return this._getDefaultUsage();

      // 1. جلب حدود الاشتراك الحالي من Redux (أو قاعدة البيانات)
      const state = store.getState();
      const sub = state.subscription?.data;

      if (!sub) return this._getDefaultUsage();

      // 2. حساب الاستهلاك الفعلي عبر استعلامات SQL سريعة
      const [customerCount, invoiceCount] = await Promise.all([
        this._getTableCount('customers', userId),
        this._getTableCount('invoices', userId),
      ]);

      // حدود مخصصة لوضع التجربة إذا كانت نشطة
      let customerLimit = sub.maxCustomers;
      let invoiceLimit = sub.maxInvoices;

      if (sub.status === 'TRIAL_ACTIVE') {
        customerLimit = 50;
        invoiceLimit = 50;
      }

      // 3. بناء كائن النتائج
      return {
        customers: {
          used: customerCount,
          limit: customerLimit,
          percentage: (customerCount / customerLimit) * 100,
        },
        invoices: {
          used: invoiceCount,
          limit: invoiceLimit,
          percentage: (invoiceCount / invoiceLimit) * 100,
        },
        devices: {
          used: sub.registeredDevices || 1,
          limit: sub.maxDevices,
          percentage: ((sub.registeredDevices || 1) / sub.maxDevices) * 100,
        },
        status: sub.status,
        plan: sub.plan,
        isOverLimit: (customerCount >= customerLimit) || (invoiceCount >= invoiceLimit)
      };
    } catch (error) {
      console.error('Analytics Failure:', error.message);
      return this._getDefaultUsage();
    }
  },

  /**
   * دالة مساعدة لجلب عدد السجلات في جدول معين
   */
  async _getTableCount(tableName, userId) {
    try {
      const result = await LocalDB.queryOne(
        `SELECT COUNT(*) as total FROM ${tableName} WHERE user_id = ?`,
        [userId]
      );
      return result?.total || 0;
    } catch (e) {
      return 0;
    }
  },
  _getDefaultUsage() {
    return {
      customers: { used: 0, limit: 5, percentage: 0 },
      invoices: { used: 0, limit: 5, percentage: 0 },
      devices: { used: 1, limit: 1, percentage: 100 },
      isOverLimit: false
    };
  }
};
export default SubscriptionAnalytics;
