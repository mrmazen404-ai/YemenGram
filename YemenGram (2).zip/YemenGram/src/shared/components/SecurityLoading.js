// src/shared/components/SecurityLoading.js
// مكوّن التحقق الأمني السيادي الفائق (The Sovereign Ultra-Premium Loader)
// نسخة قوقل: تصميم زجاجي مدمج، شعار متحرك فائق النقاء، وهيبة برمجية 10/10

import React, { useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  Animated,
  Dimensions,
  Image,
} from 'react-native';
import { Colors } from '../utils/colors';
import { MaterialCommunityIcons } from '@expo/vector-icons';

const { width, height } = Dimensions.get('screen');

// استيراد الشعار المتحرك بشكل صريح لضمان التحميل في كافة البيئات
import LOGO_ANIMATION from '../assets/images/logo-animation.gif';

export default function SecurityLoading({ visible = false, status = 'جاري التأمين...' }) {

  // ===== Animations =====
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0.9)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    if (visible) {
      // انيميشن الظهور الفخم
      Animated.parallel([
        Animated.timing(fadeAnim, { toValue: 1, duration: 400, useNativeDriver: true }),
        Animated.spring(scaleAnim, { toValue: 1, friction: 7, tension: 40, useNativeDriver: true }),
      ]).start();

      // انيميشن نبض الشعار (Breathing Effect) للهيبة
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, { toValue: 1.05, duration: 1500, useNativeDriver: true }),
          Animated.timing(pulseAnim, { toValue: 1, duration: 1500, useNativeDriver: true }),
        ])
      ).start();
    } else {
      Animated.timing(fadeAnim, { toValue: 0, duration: 300, useNativeDriver: true }).start();
    }
  }, [visible]);

  if (!visible) return null;

  return (
    <Modal visible={visible} transparent animationType="none" statusBarTranslucent>
      <View style={styles.overlay}>
        <Animated.View style={[styles.premiumCard, { opacity: fadeAnim, transform: [{ scale: scaleAnim }] }]}>

          {/* طبقة حماية بصرية علوية */}
          <View style={styles.securityHeader}>
             <MaterialCommunityIcons name="shield-check" size={14} color={Colors.gold} />
             <Text style={styles.headerText}>PROTECTED SESSION</Text>
          </View>

          {/* الشعار المتحرك - القلب النابض للنظام */}
          <Animated.View style={[styles.logoContainer, { transform: [{ scale: pulseAnim }] }]}>
             <Image
               source={LOGO_ANIMATION}
               style={styles.logo}
               resizeMode="contain"
               fadeDuration={0} // إظهار فوري
             />
          </Animated.View>

          {/* منطق المعلومات */}
          <View style={styles.infoBox}>
            <Text style={styles.statusText}>{status}</Text>

            {/* شريط التقدم السيادي (النبض الخفي) */}
            <View style={styles.progressTrack}>
               <Animated.View style={[styles.progressThumb, {
                 width: '30%',
                 transform: [{
                   translateX: pulseAnim.interpolate({
                     inputRange: [1, 1.05],
                     outputRange: [-20, 150]
                   })
                 }]
               }]} />
            </View>

            <View style={styles.footerRow}>
               <MaterialCommunityIcons name="fingerprint" size={12} color="#94A3B8" />
               <Text style={styles.footerText}>التحقق من بصمة النظام</Text>
            </View>
          </View>

        </Animated.View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    width: width,
    height: height,
    backgroundColor: 'rgba(7, 15, 26, 0.8)', // تعتيم كحلي عميق للهيبة
    justifyContent: 'center',
    alignItems: 'center',
  },
  premiumCard: {
    width: width * 0.7, // حجم مدمج واحترافي جداً
    backgroundColor: '#FFFFFF',
    borderRadius: 30,
    padding: 20,
    alignItems: 'center',
    elevation: 25,
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(212, 168, 83, 0.2)', // لمسة ذهبية خفيفة على الحواف
  },
  securityHeader: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 4,
    marginBottom: 10,
    opacity: 0.6,
  },
  headerText: {
    fontSize: 8,
    fontFamily: 'Tajawal-Bold',
    color: Colors.navy,
    letterSpacing: 1,
  },
  logoContainer: {
    width: 130,
    height: 130,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
  },
  logo: {
    width: '100%',
    height: '100%',
  },
  infoBox: {
    alignItems: 'center',
    width: '100%',
  },
  statusText: {
    fontSize: 15,
    fontFamily: 'Tajawal-Bold',
    color: Colors.navy,
    marginBottom: 15,
    textAlign: 'center',
  },
  progressTrack: {
    width: '85%',
    height: 3,
    backgroundColor: '#F1F5F9',
    borderRadius: 10,
    overflow: 'hidden',
    marginBottom: 15,
  },
  progressThumb: {
    height: '100%',
    backgroundColor: Colors.gold,
    borderRadius: 10,
  },
  footerRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 5,
    opacity: 0.4,
  },
  footerText: {
    fontSize: 10,
    fontFamily: 'Tajawal-Medium',
    color: Colors.navy,
  },
});
