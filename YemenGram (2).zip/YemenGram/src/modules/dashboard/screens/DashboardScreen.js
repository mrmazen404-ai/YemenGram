// src/modules/dashboard/screens/DashboardScreen.js
// مركز القيادة السيادي - التصميم والتنسيق فقط (v6.0 Design-Only)

import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Image,
  StatusBar,
  Animated,
  Pressable,
  Dimensions,
  Alert,
} from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { styles } from '../styles/DashboardStyles';
import { Colors } from '../../../shared/utils/colors';
import VaultCard from '../components/VaultCard';
import SovereignCarousel from '../components/SovereignCarousel';
import SafeGradient from '../../../shared/components/SafeGradient';
import SubscriptionStatusCard from '../../subscriptions/components/SubscriptionStatusCard';
import SovereignAlert from '../components/SovereignAlert';

import { useAuth } from '../../../shared/contexts/AuthContext';
import LocalDB from '../../database/localDB';


const getStatusColor = (status) => {
  switch (status) {
    case 'ACTIVE': return '#0f766e';
    case 'PENDING_PAYMENT':
    case 'PENDING_VERIFICATION':
    case 'REVIEWING_RECEIPT':
    case 'PENDING_RENEWAL':
    case 'PENDING_EXTENSION':
      return '#b45309';
    case 'CANCELLED':
    case 'EXPIRED':
      return '#dc2626';
    case 'SUSPENDED':
      return '#7c3aed';
    default:
      return '#6b7280';
  }
};

// ===== الشاشة الرئيسية =====
export default function DashboardScreen({ navigation }) {
  const { user } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);
  const [subscriptionMeta, setSubscriptionMeta] = useState({ status: 'غير مفعّل', plan: 'Starter', color: '#6b7280' });
  const animation = useRef(new Animated.Value(0)).current;
  const drawerBtnScale = useRef(new Animated.Value(1)).current; // محرك حركة زر القائمة

  const loadSubscriptionMeta = async () => {
    try {
      const currentUser = await LocalDB.getUser();
      if (!currentUser?.id) {
        setSubscriptionMeta({ status: 'غير مفعّل', plan: 'Starter', color: '#6b7280' });
        return;
      }

      const row = await LocalDB.queryOne(
        'SELECT * FROM subscriptions WHERE user_id = ? ORDER BY created_at DESC LIMIT 1',
        [currentUser.id]
      );

      if (!row) {
        setSubscriptionMeta({ status: 'غير مفعّل', plan: 'Starter', color: '#6b7280' });
        return;
      }

      const statusValue = row.status || 'ACTIVE';
      const planValue = row.plan || 'starter';
      setSubscriptionMeta({
        status: STATUS_LABELS[statusValue] || statusValue,
        plan: PLAN_LABELS[planValue] || planValue,
        color: getStatusColor(statusValue),
      });
    } catch (error) {
      setSubscriptionMeta({ status: 'غير مفعّل', plan: 'Starter', color: '#6b7280' });
    }
  };

  useEffect(() => {
    loadSubscriptionMeta();
  }, [user?.id]);


  const services = [
    { label: 'الفواتير', icon: 'file-document-outline', color: '#B76E79', screen: 'Invoices', lib: 'Material' },
    { label: 'المصروفات', icon: 'wallet-outline', color: '#E74C3C', screen: 'Expenses', lib: 'Material' },
    { label: 'القيود', icon: 'book-open-variant', color: '#4B7B5E', screen: 'Journal', lib: 'Material' },
    { label: 'المخزون', icon: 'package-variant-closed', color: '#B8943E', screen: 'Inventory', lib: 'Material' },
    { label: 'الموظفين', icon: 'account-group-outline', color: '#5B7B9A', screen: 'Employees', lib: 'Material' },
    { label: 'الخزينة', icon: 'safe', color: Colors.navy, screen: 'CashAccounts', lib: 'Material' },
  ];
  const bloomActions = [
    { label: 'قيد محاسبي', icon: 'document-text', color: Colors.navy, angle: 180 },
    { label: 'فاتورة بيع', icon: 'receipt', color: Colors.navy, angle: 145 },
    { label: 'سند مالي', icon: 'wallet', color: Colors.gold, angle: 90 },
    { label: 'طرف جديد', icon: 'person-add', color: Colors.navy, angle: 35 },
    { label: 'مسح ذكي', icon: 'qr-code', color: Colors.navy, angle: 0 },
  ];
  const toggleMenu = () => {
    const toValue = menuOpen ? 0 : 1;
    Animated.spring(animation, {
      toValue,
      friction: 8,
      tension: 30,
      useNativeDriver: true,
    }).start();
    setMenuOpen(!menuOpen);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  };

  const triggerHaptic = (style = Haptics.ImpactFeedbackStyle.Light) => {
    Haptics.impactAsync(style);
  };

  // ✅ محرك ضغط سيادي "خاطف" (Ultra-Fast Response)
  const handleDrawerPressIn = () => {
    Animated.timing(drawerBtnScale, {
      toValue: 0.9,
      duration: 60, // تقليل الزمن لاستجابة أسرع
      useNativeDriver: true,
    }).start();
  };

  const handleDrawerPress = () => {
    triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
    navigation.openDrawer(); // الفتح الفوري
    Animated.spring(drawerBtnScale, {
      toValue: 1,
      friction: 4,
      tension: 100, // زيادة القوة لعودة خاطفة
      useNativeDriver: true,
    }).start();
  };

  const renderBloomNode = (item, index) => {
    const radius = 130; // ✅ تصغير نصف قطر الانتشار للهيبة والتركيز
    const radian = (item.angle * Math.PI) / 180;
    const screenWidth = Dimensions.get('window').width;

    const translateX = animation.interpolate({
      inputRange: [0, 1],
      outputRange: [0, radius * Math.cos(radian)],
    });
    const translateY = animation.interpolate({
      inputRange: [0, 1],
      outputRange: [0, -radius * Math.sin(radian)],
    });
    const scale = animation.interpolate({
      inputRange: [0, 1],
      outputRange: [0.2, 1],
    });

    return (
      <Animated.View
        key={index}
        style={[
          styles.bloomNode,
          {
            transform: [{ translateX }, { translateY }, { scale }],
            opacity: animation,
            left: screenWidth / 2 - 32,
            bottom: 75,
          },
        ]}
      >
        <TouchableOpacity
          style={styles.bloomNodeTouch}
          onPress={() => { toggleMenu(); triggerHaptic(); }}
          activeOpacity={0.7}
        >
          <Ionicons name={item.icon} size={24} color={item.color} />
          <Text style={styles.bloomNodeLabel}>{item.label}</Text>
        </TouchableOpacity>
      </Animated.View>
    );
  };

  return (
    <View style={styles.root}>
      {/* ✅ تثبيت شريط الهاتف بلون الهوية الصريح */}
      <StatusBar barStyle="light-content" backgroundColor={Colors.navy} translucent={false} />

      {/* الجزء العلوي الموحد لضمان عدم الاختفاء */}
      <View style={{ backgroundColor: Colors.navy }}>
        {/* ===== 1. شريط الحالة الداخلي ===== */}
        <View style={styles.statusBar}>
          <View style={styles.statusLeft}>
            <View style={[styles.statusDot, { backgroundColor: '#4ADE80' }]} />
            <Text style={styles.statusText}>متصل</Text>
          </View>
          <Text style={styles.statusTime}>آخر تحديث: 12:30</Text>
          <TouchableOpacity onPress={() => triggerHaptic()}>
            <Ionicons name="refresh" size={16} color={Colors.gold} />
          </TouchableOpacity>
        </View>

        {/* ===== 2. الهيدر السيادي المطور ===== */}
        <View style={styles.header}>
          <View style={styles.headerRight}>
            <TouchableOpacity
              style={styles.avatarMini}
              onPress={() => { triggerHaptic(); navigation.navigate('Profile'); }}
            >
              {user?.avatar && user.avatar !== 'default_pc' ? (
                <Image source={{ uri: user.avatar }} style={styles.avatarImage} />
              ) : (
                <Text style={styles.avatarInitial}>{user?.name?.charAt(0).toUpperCase() || 'Y'}</Text>
              )}
            </TouchableOpacity>
            <View style={styles.welcomeText}>
              <Text style={styles.greeting}>مرحباً بك،</Text>
              <Text style={styles.userName}>{user?.name || 'المستخدم'}</Text>
            </View>
          </View>

          <View style={styles.headerLeft}>
            <TouchableOpacity style={styles.iconBtn} onPress={() => triggerHaptic()}>
              <MaterialCommunityIcons name="bell-badge-outline" size={22} color={Colors.gold} />
            </TouchableOpacity>

            {/* زر القائمة الجانبية المطور حركياً (سرعة سيادية) */}
            <Pressable
              onPressIn={handleDrawerPressIn}
              onPress={handleDrawerPress}
            >
              <Animated.View style={[
                styles.iconBtn,
                { transform: [{ scale: drawerBtnScale }] }
              ]}>
                <MaterialCommunityIcons name="menu-open" size={26} color={Colors.white} />
              </Animated.View>
            </Pressable>
          </View>
        </View>
      </View>

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* 🚨 تنبيهات السيادة الاستباقية */}
        <SovereignAlert onAction={() => navigation.navigate('SubscriptionRenew')} />

        <SovereignCarousel />

        {/* ===== أزرار التنقل السريع السيادية ===== */}
        <View style={styles.quickNavSection}>
          <View style={styles.quickNavRow}>
            <TouchableOpacity
              style={styles.quickNavBtn}
              activeOpacity={0.8}
              onPress={() => { triggerHaptic(); navigation.navigate('Customers'); }}
            >
              <SafeGradient colors={[Colors.navy, '#1E293B']} style={styles.quickNavGradient}>
                <View style={styles.quickNavIconBox}>
                  <Ionicons name="people-outline" size={22} color={Colors.gold} />
                </View>
                <View style={styles.quickNavInfo}>
                  <Text style={styles.quickNavLabel}>العملاء</Text>
                  <Text style={styles.quickNavSub}>إدارة الأطراف</Text>
                </View>
              </SafeGradient>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.quickNavBtn}
              activeOpacity={0.8}
              onPress={() => { triggerHaptic(); /* navigation.navigate('CustomerPortal'); */ }}
            >
              <SafeGradient colors={[Colors.navy, '#1E293B']} style={styles.quickNavGradient}>
                <View style={styles.quickNavIconBox}>
                  <Ionicons name="globe-outline" size={22} color={Colors.gold} />
                </View>
                <View style={styles.quickNavInfo}>
                  <Text style={styles.quickNavLabel}>بوابة العملاء</Text>
                  <Text style={styles.quickNavSub}>الوصول الذكي</Text>
                </View>
              </SafeGradient>
            </TouchableOpacity>
          </View>

          <View style={styles.quickNavRow}>
            <TouchableOpacity
              style={styles.quickNavBtn}
              activeOpacity={0.8}
              onPress={() => { triggerHaptic(); navigation.navigate('Reports'); }}
            >
              <SafeGradient colors={['#1E293B', Colors.navy]} style={styles.quickNavGradient}>
                <View style={styles.quickNavIconBox}>
                  <Ionicons name="bar-chart-outline" size={22} color={Colors.gold} />
                </View>
                <View style={styles.quickNavInfo}>
                  <Text style={styles.quickNavLabel}>التقارير</Text>
                  <Text style={styles.quickNavSub}>مركز الرقابة</Text>
                </View>
              </SafeGradient>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.quickNavBtn}
              activeOpacity={0.8}
              onPress={() => { triggerHaptic(); navigation.navigate('Accounts'); }}
            >
              <SafeGradient colors={['#1E293B', Colors.navy]} style={styles.quickNavGradient}>
                <View style={styles.quickNavIconBox}>
                  <Ionicons name="list-outline" size={22} color={Colors.gold} />
                </View>
                <View style={styles.quickNavInfo}>
                  <Text style={styles.quickNavLabel}>دليل الحسابات</Text>
                  <Text style={styles.quickNavSub}>شجرة النظام</Text>
                </View>
              </SafeGradient>
            </TouchableOpacity>
          </View>
        </View>

        {/* ===== مركز العمليات السيادي (تم نقله هنا للهيبة والوصول السريع) ===== */}
        <View style={styles.gridSection}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>مركز العمليات</Text>
            <TouchableOpacity onPress={() => triggerHaptic()}>
              <Text style={styles.seeAll}>عرض الكل</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.actionGrid}>
            {services.map((item, index) => (
              <TouchableOpacity
                key={index}
                style={styles.actionCard}
                onPress={() => { triggerHaptic(); navigation.navigate(item.screen); }}
              >
                <View style={styles.iconWrapper}>
                  {item.lib === 'Material' ? (
                    <MaterialCommunityIcons name={item.icon} size={24} color={item.color} />
                  ) : (
                    <Ionicons name={item.icon} size={22} color={item.color} />
                  )}
                </View>
                <Text style={styles.actionLabel}>{item.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <View style={styles.footerSpacer} />
      </ScrollView>

      {/* ===== 9. قائمة Bloom ===== */}
      {menuOpen && <Pressable style={styles.menuOverlay} onPress={toggleMenu} />}
      {bloomActions.map((item, index) => renderBloomNode(item, index))}

      {/* ===== 10. شريط التنقل السفلي الاحترافي ===== */}
      <View style={styles.bottomBar}>
        {/* الرئيسية */}
        <TouchableOpacity
          style={[styles.navItem, styles.navItemActive]}
          onPress={() => { triggerHaptic(); }}
        >
          <MaterialCommunityIcons name="home-variant" size={26} color={Colors.gold} />
        </TouchableOpacity>

        {/* العمليات / الفواتير */}
        <TouchableOpacity
          style={styles.navItem}
          onPress={() => { triggerHaptic(); navigation.navigate('InvoicesTab'); }}
        >
          <MaterialCommunityIcons name="clipboard-text-outline" size={24} color="rgba(255,255,255,0.4)" />
        </TouchableOpacity>

        {/* زر الإضافة (Bloom) */}
        <Animated.View style={{
          transform: [
            { rotate: animation.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '135deg'] }) },
            { scale: animation.interpolate({ inputRange: [0, 1], outputRange: [1, 1.1] }) }
          ]
        }}>
          <TouchableOpacity style={styles.bloomCenterBtn} onPress={toggleMenu} activeOpacity={0.9}>
            <Ionicons name="add" size={38} color={Colors.white} />
          </TouchableOpacity>
        </Animated.View>

        {/* الرقابة / سجل التدقيق */}
        <TouchableOpacity
          style={styles.navItem}
          onPress={() => { triggerHaptic(); navigation.navigate('AuditLog'); }}
        >
          <MaterialCommunityIcons name="shield-key-outline" size={24} color="rgba(255,255,255,0.4)" />
        </TouchableOpacity>

        {/* الإعدادات */}
        <TouchableOpacity
          style={styles.navItem}
          onPress={() => { triggerHaptic(); navigation.navigate('Settings'); }}
        >
          <MaterialCommunityIcons name="cog-outline" size={24} color="rgba(255,255,255,0.4)" />
        </TouchableOpacity>
      </View>
    </View>
  );
}