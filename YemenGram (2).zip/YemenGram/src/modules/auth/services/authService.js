// src/modules/auth/services/authService.js
// =============================================
// خدمة المصادقة (Authentication Service)
// =============================================

import { LocalDB } from '../../database/localDB';
import { CryptoService } from '../../../shared/services/cryptoService';
import { DeviceService } from '../../../shared/services/deviceService'; // ✅ استيراد محرك البصمة
import { sendOTPEmail } from './emailService';
import { generateUniqueUserCode } from '../../../shared/utils/helpers';
import { Platform } from 'react-native';
import * as Device from 'expo-device';
import * as SecureStore from 'expo-secure-store';
import * as FileSystem from 'expo-file-system';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { secureStorage, generateOTP } from '../../../shared/utils/security';
import { SECURITY_POLICY } from '../../../shared/utils/securityPolicy';
import TimeService from '../../../services/timeService';
import { syncService } from '../../../services/syncService';
import SupabaseService from '../../../services/supabaseClient';

// =============================================
// 1. الثوابت الأمنية
// =============================================

const SESSION_DURATION = 7 * 24 * 60 * 60 * 1000;
const MAX_LOGIN_ATTEMPTS = 5;
const LOCK_DURATION = 15 * 60 * 1000;
const OTP_EXPIRY = 10 * 60 * 1000;
const MAX_OTP_ATTEMPTS = 3;

// =============================================
// 2. محركات الحماية (Rate Limiting)
// =============================================

const checkLoginRateLimit = async (identifier, mode = 'login') => {
  const key = identifier.toLowerCase();
  const attemptsKey = `login_attempts_${key}`;
  const lockKey = `login_lock_${key}`;

  const lockUntil = await LocalDB.getSetting(lockKey);
  if (lockUntil && TimeService.getSovereignTime() < parseInt(lockUntil)) {
    const error = new Error(`أمن النظام: الحساب مقفل حمايةً لك.`);
    error.lockUntil = parseInt(lockUntil);
    throw error;
  }

  let attempts = parseInt(await LocalDB.getSetting(attemptsKey) || '0');
  attempts++;
  await LocalDB.saveSetting(attemptsKey, attempts.toString());

  if (mode === 'login' && attempts >= MAX_LOGIN_ATTEMPTS) {
    const lockTime = TimeService.getSovereignTime() + LOCK_DURATION;
    await LocalDB.saveSetting(lockKey, lockTime.toString());

    // تسجيل جنائي لمحاولة اختراق أو تخمين
    await LocalDB.addAuditLog('SECURITY_LOCKOUT', 'user', identifier, {
      reason: 'MAX_ATTEMPTS_EXCEEDED',
      attempts,
      lock_until: new Date(lockTime).toISOString()
    });

    throw new Error('تم قفل محاولات الدخول لرصد نشاط مشبوه');
  }
  return true;
};

const resetLoginRateLimit = async (identifier) => {
  const key = identifier.toLowerCase();
  await LocalDB.saveSetting(`login_attempts_${key}`, '0');
  await LocalDB.saveSetting(`login_lock_${key}`, '0');
};

const checkOTPRateLimit = async (email) => {
  const key = email.toLowerCase();
  const attemptsKey = `otp_attempts_${key}`;
  const lockKey = `otp_lock_${key}`;

  const lockUntil = await LocalDB.getSetting(lockKey);
  if (lockUntil && TimeService.getSovereignTime() < parseInt(lockUntil)) {
    throw new Error(`تم تجاوز محاولات الرمز، حاول لاحقاً`);
  }

  let attempts = parseInt(await LocalDB.getSetting(attemptsKey) || '0');
  attempts++;
  await LocalDB.saveSetting(attemptsKey, attempts.toString());

  if (attempts >= MAX_OTP_ATTEMPTS) {
    const lockTime = TimeService.getSovereignTime() + LOCK_DURATION;
    await LocalDB.saveSetting(lockKey, lockTime.toString());
    throw new Error('تم تجاوز محاولات التحقق، حاول بعد 15 دقيقة');
  }
  return true;
};

// =============================================
// 3. دوال النزاهة والتعقيم
// =============================================

const getDeviceInfo = async () => ({
  deviceName: Device.deviceName || 'Unknown',
  os: `${Device.osName} ${Device.osVersion}`,
  platform: Platform.OS,
});

const sanitizeEmail = (email) => {
  if (!email) return '';
  const clean = email.trim().toLowerCase();
  return /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/.test(clean) ? clean : '';
};

const signSession = async (token, fingerprint) => {
  const secret = await SecureStore.getItemAsync('sovereign_secret') || await CryptoService.generateKey();
  if (!await SecureStore.getItemAsync('sovereign_secret')) {
    await SecureStore.setItemAsync('sovereign_secret', secret);
  }
  return await CryptoService.hashIdentifier(`${token}:${fingerprint}${secret}`);
};

// =============================================
// 4. الخدمة السيادية (The Purified Engine)
// =============================================

export const AuthService = {

  async initialize() {
    try {
      if (__DEV__) console.log('🔐 [AuthService] بدء تهيئة النظام...');
      await LocalDB.ensureConnection();

      const token = await SecureStore.getItemAsync('userToken');
      const deviceFingerprint = await SecureStore.getItemAsync('deviceFingerprint');
      const currentHardwareId = await DeviceService.getSovereignFingerprint(); // جلب بصمة العتاد الحالية

      if (!token || !deviceFingerprint) return { isLoggedIn: false };

      const storedSession = await LocalDB.queryOne('SELECT * FROM session WHERE token = ?', [token]);
      const expectedSignature = await signSession(token, deviceFingerprint);

      // ✅ فحص تزوير الجلسة أو نقل البيانات لجهاز آخر
      if (!storedSession ||
          storedSession.signature !== expectedSignature ||
          storedSession.hardware_signature !== currentHardwareId) {

        await LocalDB.addAuditLog('SECURITY_THREAT', 'session', '0', {
          reason: 'SESSION_TAMPERED_OR_CLONED',
          action: 'FORCE_LOGOUT'
        });

        await this.logout();
        return { isLoggedIn: false, reason: 'tampered' };
      }

      const user = await LocalDB.getUser();
      if (!user || user.is_blocked === 1) {
        if (user?.is_blocked === 1) await SecureStore.deleteItemAsync('userToken');
        return { isLoggedIn: false };
      }

      return { isLoggedIn: true, user };
    } catch (error) {
      return { isLoggedIn: false };
    }
  },

  async checkUniqueness(email, phone, name, company) {
    await LocalDB.ensureConnection();

    // 1. الفحص العتادي العميق (حتى لو مسحت قاعدة البيانات)
    const hardwareId = await DeviceService.getSovereignFingerprint();
    const hasExistingOwnership = await SecureStore.getItemAsync('sovereign_account_linked');

    if (hasExistingOwnership === 'true') {
       return { success: false, field: 'device', message: 'تنبيه أمني: هذا الجهاز مرتبط بحساب آخر مسجل مسبقاً. يرجى تسجيل الدخول بحسابك الأصلي.' };
    }

    const checks = [
      { field: 'email', query: 'SELECT id FROM user WHERE email = ?', value: email.toLowerCase().trim(), msg: 'البريد الإلكتروني مسجل مسبقاً' },
      { field: 'phone', query: 'SELECT id FROM user WHERE phone = ?', value: phone.trim(), msg: 'رقم الهاتف مرتبط بحساب آخر' },
      { field: 'name', query: 'SELECT id FROM user WHERE name = ?', value: name.trim(), msg: 'هذا الاسم مسجل مسبقاً، يرجى استخدام اسمك الرباعي بدقة' },
      { field: 'company', query: 'SELECT id FROM user WHERE company_name = ?', value: company.trim(), msg: 'اسم الشركة هذا محجوز لكيان تجاري آخر' },
    ];

    for (const check of checks) {
      const exists = await LocalDB.queryOne(check.query, [check.value]);
      if (exists) {
        await LocalDB.addAuditLog('REGISTRATION_CONFLICT', 'user', '0', {
          field: check.field,
          attempted_value: check.value
        });
        return { success: false, field: check.field, message: check.msg };
      }
    }

    // 2. فحص تضارب البصمة في قاعدة البيانات (لضمان عدم التلاعب)
    const deviceExists = await LocalDB.queryOne('SELECT id FROM user WHERE trusted_device_id = ?', [hardwareId]);
    if (deviceExists) {
      await LocalDB.addAuditLog('DEVICE_ALREADY_LINKED', 'user', '0', {
        hardware_id: hardwareId
      });
      // إعادة تثبيت الختم في SecureStore لحماية العتاد
      await SecureStore.setItemAsync('sovereign_account_linked', 'true');
      return { success: false, field: 'device', message: 'هذا الجهاز مرتبط بحساب نشط بالفعل. لا يسمح بتعدد الحسابات.' };
    }

    return { success: true };
  },

  async login(identifier, password) {
    if (!identifier || !password) throw new Error('البيانات مطلوبة');
    const cleanId = identifier.trim();
    await checkLoginRateLimit(cleanId, 'login');

    const user = await LocalDB.queryOne('SELECT * FROM user WHERE email = ? OR phone = ?', [cleanId, cleanId]);
    if (!user || user.is_blocked === 1) throw new Error('بيانات الدخول غير صحيحة');

    // ✅ فحص الارتباط السيادي بالجهاز
    const currentHardwareId = await DeviceService.getSovereignFingerprint();
    if (user.trusted_device_id && user.trusted_device_id !== currentHardwareId) {
      // تسجيل محاولة دخول من جهاز غير موثوق
      await LocalDB.addAuditLog('SECURITY_ALERT', 'user', user.id, {
        reason: 'DEVICE_MISMATCH',
        attempted_device: await DeviceService.getDeviceMetadata(),
        trusted_device: user.device_metadata
      });

      const error = new Error('هذا الحساب مرتبط بجهاز آخر. لا يسمح بالدخول من هذا العتاد.');
      error.code = 'DEVICE_MISMATCH';
      throw error;
    }

    const storedHash = await SecureStore.getItemAsync('local_password_verifier');
    const isValid = await CryptoService.verifyPassword(password, storedHash);

    if (!isValid) throw new Error('بيانات الدخول غير صحيحة');

    // 🔗 تسجيل الدخول في Supabase Auth لضمان توفر جلسة سحابية حقيقية للمزامنة
    try {
      await SupabaseService.login(cleanId, password);
    } catch (sbErr) {
      console.warn('⚠️ [AuthService] تحذير سحابي في تسجيل الدخول (يعمل أوفلاين):', sbErr.message);
    }

    await resetLoginRateLimit(cleanId);
    const token = await CryptoService.generateKey();
    const deviceFingerprint = await CryptoService.hashIdentifier(JSON.stringify(await getDeviceInfo()));
    const signature = await signSession(token, deviceFingerprint);

    await SecureStore.setItemAsync('userToken', token);
    await SecureStore.setItemAsync('deviceFingerprint', deviceFingerprint);
    await SecureStore.setItemAsync('last_full_auth_timestamp', TimeService.getSovereignTime().toString());

    await LocalDB.saveSession(token, deviceFingerprint, signature, (TimeService.getSovereignTime() + SESSION_DURATION).toString());

    // تحديث توقيع العتاد في الجلسة
    await LocalDB.execute('UPDATE session SET hardware_signature = ? WHERE token = ?', [currentHardwareId, token]);

    // 🔄 محاولة مزامنة فورية بعد تسجيل الدخول مع تسجيل النتيجة في سجل التدقيق
    try {
      const syncRes = await syncService.sync();
      if (!syncRes.success) {
        await LocalDB.addAuditLog('SYNC_WARNING', 'user', user.id, {
          action: 'LOGIN_SYNC_FAILED',
          error: syncRes.error
        });
        console.warn('⚠️ [AuthService] فشلت المزامنة أثناء تسجيل الدخول:', syncRes.error);
      } else {
        await LocalDB.addAuditLog('SYNC_SUCCESS', 'user', user.id, {
          action: 'LOGIN_SYNC_SUCCESS'
        });
        console.log('✅ [AuthService] تمت المزامنة بنجاح أثناء تسجيل الدخول');
      }
    } catch (syncErr) {
      await LocalDB.addAuditLog('SYNC_ERROR', 'user', user.id, {
        action: 'LOGIN_SYNC_EXCEPTION',
        error: syncErr.message
      });
      console.error('❌ [AuthService] استثناء في مزامنة تسجيل الدخول:', syncErr.message);
    }

    return { success: true, user, token };
  },

  async register(userData) {
    const { name, company, email, phone, password, currency } = userData;
    if (__DEV__) console.log('📝 [AuthService] بدء عملية التسجيل:', email);

    if (!name || !company || !email || !phone || !password) throw new Error('جميع الحقول مطلوبة');

    // 1. التحقق النهائي من التكرار (حائط الصد الأخير)
    const uniqueness = await this.checkUniqueness(email, phone, name, company);
    if (!uniqueness.success) {
      throw new Error(uniqueness.message);
    }

    // 2. تشفير فوري لحماية الخصوصية
    const passwordVerifier = await CryptoService.derivePasswordVerifier(password);

    await LocalDB.savePendingRegistration({
      name: name.trim(),
      company: company.trim(),
      email: email.toLowerCase().trim(),
      phone: phone.trim(),
      passwordVerifier,
      currency: currency || 'YER',
    });

    await secureStorage.setItem('pending_registration_password', password);

    // 3. إطلاق ميثاق الـ OTP
    await this.sendOTP(email.toLowerCase().trim());
    return { success: true, message: 'تم إرسال كود التحقق' };
  },

  async sendOTP(email) {
    const cleanEmail = sanitizeEmail(email);
    if (!cleanEmail) throw new Error('بريد غير صحيح');

    const existingUser = await LocalDB.queryOne('SELECT id FROM user WHERE email = ?', [cleanEmail]);
    const pendingReg = await LocalDB.getPendingRegistration();
    const isAuthenticated = !!(await SecureStore.getItemAsync('userToken'));

    if (!existingUser && (!pendingReg || pendingReg.email !== cleanEmail) && !isAuthenticated) {
      return { success: true, message: 'سيصلك الرمز إذا كان الحساب موجوداً' };
    }

    const code = await generateOTP();
    await LocalDB.saveSetting(`otp_${cleanEmail}`, code);
    await LocalDB.saveSetting(`otp_expiry_${cleanEmail}`, (TimeService.getSovereignTime() + OTP_EXPIRY).toString());

    try { await sendOTPEmail(cleanEmail, code); } catch {}
    return { success: true };
  },

  async verifyOTP(email, code) {
    const cleanEmail = sanitizeEmail(email);
    await checkOTPRateLimit(cleanEmail);

    const storedCode = await LocalDB.getSetting(`otp_${cleanEmail}`);
    const expiry = await LocalDB.getSetting(`otp_expiry_${cleanEmail}`);

    if (!storedCode || TimeService.getSovereignTime() > parseInt(expiry) || storedCode !== code) {
      throw new Error('الرمز غير صحيح أو منتهي');
    }

    await LocalDB.saveSetting(`otp_${cleanEmail}`, '');
    const user = await LocalDB.queryOne('SELECT * FROM user WHERE email = ?', [cleanEmail]);

    if (user) return { success: true, user };

    const isAuthenticated = !!(await SecureStore.getItemAsync('userToken'));
    if (isAuthenticated) return { success: true, isEmailChange: true };

    const pending = await LocalDB.getPendingRegistration();
    if (!pending) throw new Error('انتهت صلاحية الجلسة');

    const userId = `user_${TimeService.getSovereignTime()}`;
    const hardwareId = await DeviceService.getSovereignFingerprint();
    const metadata = await DeviceService.getDeviceMetadata();
    const userCode = await generateUniqueUserCode();

    const pendingPassword = await secureStorage.getItem('pending_registration_password');
    if (!pendingPassword) throw new Error('انتهت جلسة التسجيل؛ يرجى بدء التسجيل من جديد');

    // 🔗 تسجيل الحساب في Supabase Auth لضمان توفر جلسة سحابية حقيقية للمزامنة
    try {
      await SupabaseService.register(pending.email, pendingPassword, {
        name: pending.name,
        company_name: pending.company,
        phone: pending.phone,
        user_code: userCode,
      });
    } catch (sbRegErr) {
      console.warn('⚠️ [AuthService] تحذير سحابي عند التسجيل (يعمل محلياً):', sbRegErr.message);
    }

    await SecureStore.setItemAsync('local_password_verifier', pending.passwordVerifier, {
      keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY,
    });
    await secureStorage.deleteItem('pending_registration_password');
    await LocalDB.saveUser({
      id: userId, user_code: userCode,
      name: pending.name, email: pending.email, phone: pending.phone,
      role: 'admin', company_name: pending.company, avatar: 'default_pc',
      trusted_device_id: hardwareId, // ربط الجهاز الموثوق
      device_metadata: metadata       // توثيق معلومات الجهاز
    });

    const token = await CryptoService.generateKey();
    await SecureStore.setItemAsync('userToken', token);
    await SecureStore.setItemAsync('last_full_auth_timestamp', TimeService.getSovereignTime().toString());

    // 🔄 محاولة مزامنة فورية بعد إنشاء الحساب الجديد مع تسجيل النتيجة في سجل التدقيق
    try {
      const syncRes = await syncService.sync();
      if (!syncRes.success) {
        await LocalDB.addAuditLog('SYNC_WARNING', 'user', userId, {
          action: 'REGISTER_SYNC_FAILED',
          error: syncRes.error
        });
        console.warn('⚠️ [AuthService] فشلت المزامنة أثناء إنشاء الحساب:', syncRes.error);
      } else {
        await LocalDB.addAuditLog('SYNC_SUCCESS', 'user', userId, {
          action: 'REGISTER_SYNC_SUCCESS'
        });
        console.log('✅ [AuthService] تمت المزامنة بنجاح أثناء إنشاء الحساب');
      }
    } catch (syncErr) {
      await LocalDB.addAuditLog('SYNC_ERROR', 'user', userId, {
        action: 'REGISTER_SYNC_EXCEPTION',
        error: syncErr.message
      });
      console.error('❌ [AuthService] استثناء في مزامنة إنشاء الحساب:', syncErr.message);
    }

    return { success: true, userId, user: await LocalDB.getUser() };
  },

  async changePassword(oldPassword, newPassword) {
    const user = await LocalDB.getUser();
    await checkLoginRateLimit(user.email, 'login');

    const storedHash = await SecureStore.getItemAsync('local_password_verifier');
    if (!await CryptoService.verifyPassword(oldPassword, storedHash)) throw new Error('كلمة المرor الحالية خطأ');

    const newVerifier = await CryptoService.derivePasswordVerifier(newPassword);
    await SecureStore.setItemAsync('local_password_verifier', newVerifier, {
      keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY,
    });
    await LocalDB.execute('DELETE FROM session');
    await SecureStore.setItemAsync('last_full_auth_timestamp', TimeService.getSovereignTime().toString());

    return { success: true };
  },

  async logout() {
    await SecureStore.deleteItemAsync('userToken');
    await SecureStore.deleteItemAsync('deviceFingerprint');
    await SecureStore.deleteItemAsync('last_full_auth_timestamp');
    await LocalDB.clearSession();
    return { success: true };
  },

  async deleteAccount() {
    try {
      await SecureStore.deleteItemAsync('userToken');
      await SecureStore.deleteItemAsync('deviceFingerprint');
      await SecureStore.deleteItemAsync('last_full_auth_timestamp');
      await SecureStore.deleteItemAsync('sovereign_secret');
      await AsyncStorage.clear();
      const avatarDir = `${FileSystem.documentDirectory}avatars/`;
      if ((await FileSystem.getInfoAsync(avatarDir)).exists) await FileSystem.deleteAsync(avatarDir);
      await LocalDB.clearAll();
      return { success: true };
    } catch (e) { throw e; }
  },

  async isSessionExpired() {
    const lastAuth = await SecureStore.getItemAsync('last_full_auth_timestamp');
    if (!lastAuth) {
      await SecureStore.setItemAsync('last_full_auth_timestamp', TimeService.getSovereignTime().toString());
      return false;
    }
    const diffDays = (TimeService.getSovereignTime() - parseInt(lastAuth)) / (1000 * 60 * 60 * 24);
    return diffDays > SECURITY_POLICY.MAX_SESSION_DAYS;
  },

  /**
   * بدء عملية استعادة كلمة المرور (رسمي)
   */
  async startPasswordRecovery(email) {
    await LocalDB.ensureConnection();
    const cleanEmail = email.toLowerCase().trim();

    // فحص وجود الحساب (بدون تسريب المعلومة)
    const user = await LocalDB.queryOne('SELECT id FROM user WHERE email = ?', [cleanEmail]);

    // توليد كود OTP
    const code = await generateOTP();
    await LocalDB.saveSetting(`recovery_otp_${cleanEmail}`, code);
    await LocalDB.saveSetting(`recovery_otp_expiry_${cleanEmail}`, (Date.now() + OTP_EXPIRY).toString());

    // إرسال الكود فقط إذا كان المستخدم موجوداً (حماية خصوصية الحسابات)
    if (user) {
      try { await sendOTPEmail(cleanEmail, code); } catch (e) {}
    }

    return { success: true, message: 'سيصلك رمز التحقق إذا كان البريد مسجلاً لدينا' };
  },

  /**
   * التحقق من رمز الاستعادة وتوليد توكن مؤقت
   */
  async verifyRecoveryOTP(email, code) {
    const cleanEmail = email.toLowerCase().trim();
    const storedCode = await LocalDB.getSetting(`recovery_otp_${cleanEmail}`);
    const expiry = await LocalDB.getSetting(`recovery_otp_expiry_${cleanEmail}`);

    if (!storedCode || Date.now() > parseInt(expiry) || storedCode !== code) {
      throw new Error('الرمز غير صحيح أو منتهي الصلاحية');
    }

    // توليد توكن استعادة مؤقت (صالح لـ 5 دقائق)
    const recoveryToken = await CryptoService.generateKey();
    await LocalDB.saveSetting(`recovery_token_${cleanEmail}`, recoveryToken);
    await LocalDB.saveSetting(`recovery_token_expiry_${cleanEmail}`, (Date.now() + 300000).toString());

    return { success: true, recoveryToken };
  },

  /**
   * التنفيذ النهائي لتغيير كلمة المرور وتطهير الجلسات
   */
  async finalizePasswordReset(email, token, newPassword) {
    const cleanEmail = email.toLowerCase().trim();
    const storedToken = await LocalDB.getSetting(`recovery_token_${cleanEmail}`);
    const expiry = await LocalDB.getSetting(`recovery_token_expiry_${cleanEmail}`);

    if (!storedToken || storedToken !== token || Date.now() > parseInt(expiry)) {
      throw new Error('انتهت صلاحية جلسة الاستعادة. يرجى البدء من جديد.');
    }

    // 1. تشفير كلمة المرور الجديدة
    const newVerifier = await CryptoService.derivePasswordVerifier(newPassword);
    await SecureStore.setItemAsync('local_password_verifier', newVerifier, {
      keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY,
    });

    // 2. إبادة جماعية لكافة الجلسات (لحماية الحساب من المخترقين)
    await LocalDB.execute('DELETE FROM session');

    // 3. تطهير توكنات الاستعادة
    await LocalDB.saveSetting(`recovery_token_${cleanEmail}`, '');
    await LocalDB.saveSetting(`recovery_otp_${cleanEmail}`, '');

    // 4. تسجيل حدث أمني جنائي
    await LocalDB.addAuditLog('PASSWORD_RECOVERY_SUCCESS', 'user', '0', { email: cleanEmail });

    return { success: true };
  },

  async updateAvatar(userId, img) { await LocalDB.execute('UPDATE user SET avatar = ? WHERE id = ?', [img, userId]); return true; }
};

export default AuthService;
