// src/models/Employee.js
// =============================================
// نموذج الموظف (Employee Model)
// المسؤول عن إدارة بيانات الموظفين في النظام
// =============================================

import { Model } from '@nozbe/watermelondb';
import { field, date, readonly } from '@nozbe/watermelondb/decorators';
import { Q } from '@nozbe/watermelondb';

export default class Employee extends Model {
  // ===== 1. اسم الجدول =====
  static table = 'employees';

  // ===== 2. الحقول الأساسية =====

  // معرف المستخدم (لفصل البيانات)
  @field('user_id') userId;

  // رمز الموظف الفريد (EMP-0001)
  @field('code') code;

  // اسم الموظف
  @field('name') name;

  // ===== 3. معلومات الاتصال =====

  @field('phone') phone;
  @field('email') email;

  // ===== 4. المعلومات الوظيفية =====

  // المنصب/المسمى الوظيفي
  @field('position') position;

  // القسم
  @field('department') department;

  // الراتب الأساسي
  @field('salary') salary;

  // تاريخ التعيين
  @field('hire_date') hireDate;

  // ===== 5. المفاتيح الخارجية =====

  // الحساب المحاسبي (رواتب الموظفين)
  @field('account_id') accountId;

  // ===== 6. الحالة =====

  @field('is_active') isActive;

  // ===== 7. التواريخ التلقائية =====

  @readonly @date('created_at') createdAt;
  @readonly @date('updated_at') updatedAt;

  // ===== 8. العلاقات =====

  static associations = {
    // كل موظف ينتمي إلى مستخدم واحد
    user: { type: 'belongs_to', key: 'user_id' },
    // كل موظف له حساب محاسبي واحد
    account: { type: 'belongs_to', key: 'account_id' },
    // موظف واحد → لديه عدة رواتب
    payrolls: { type: 'has_many', foreignKey: 'employee_id' },
    // موظف واحد → لديه عدة مدفوعات (رواتب)
    payments: { type: 'has_many', foreignKey: 'employee_id' },
  };

  // ===== 9. دوال مساعدة =====

  /**
   * التحقق من نشاط الموظف
   * @returns {boolean}
   */
  isActiveEmployee() {
    return this.isActive === 1 || this.isActive === true;
  }

  /**
   * الحصول على اسم الموظف مع الرمز
   * @returns {string}
   */
  getDisplayName() {
    return `${this.code} - ${this.name}`;
  }

  /**
   * الحصول على الاسم الكامل مع المنصب
   * @returns {string}
   */
  getFullName() {
    return this.position ? `${this.name} (${this.position})` : this.name;
  }

  /**
   * جلب الحساب المحاسبي
   * @returns {Promise<Account>}
   */
  async getAccount() {
    if (!this.accountId) return null;
    return this.collections.get('accounts').find(this.accountId);
  }

  /**
   * جلب رواتب الموظف
   * @returns {Promise<Payroll[]>}
   */
  async getPayrolls() {
    return this.collections.get('payroll').query(
      Q.where('employee_id', this.id)
    ).fetch();
  }

  /**
   * جلب مدفوعات الموظف
   * @returns {Promise<Payment[]>}
   */
  async getPayments() {
    return this.collections.get('payments').query(
      Q.where('employee_id', this.id)
    ).fetch();
  }

  /**
   * حساب إجمالي الرواتب للموظف
   * @returns {Promise<number>}
   */
  async getTotalSalaries() {
    const payrolls = await this.getPayrolls();
    return payrolls.reduce((sum, p) => sum + (p.netSalary || 0), 0);
  }

  /**
   * حساب عدد أشهر الخدمة
   * @param {number} currentDate
   * @returns {number}
   */
  getMonthsOfService(currentDate = Date.now()) {
    if (!this.hireDate) return 0;
    const hire = new Date(this.hireDate);
    const now = new Date(currentDate);
    const months = (now.getFullYear() - hire.getFullYear()) * 12 +
                   (now.getMonth() - hire.getMonth());
    return Math.max(0, months);
  }

  /**
   * حساب سنوات الخدمة
   * @param {number} currentDate
   * @returns {number}
   */
  getYearsOfService(currentDate = Date.now()) {
    const months = this.getMonthsOfService(currentDate);
    return months / 12;
  }

  /**
   * الحصول على تاريخ التوظيف المنسق
   * @returns {string}
   */
  getFormattedHireDate() {
    if (!this.hireDate) return '';
    const date = new Date(this.hireDate);
    return date.toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  }

  // ===== 10. دوال ثابتة =====

  /**
   * الحصول على رمز الموظف التالي
   * @param {Database} database
   * @returns {Promise<string>}
   */
  static async getNextCode(database) {
    const lastEmployee = await database.get('employees').query(
      Q.sortBy('code', Q.desc),
      Q.take(1)
    ).fetch();

    if (lastEmployee.length === 0) {
      return 'EMP-0001';
    }

    const lastCode = lastEmployee[0].code;
    const numericPart = parseInt(lastCode.split('-')[1] || '0000');
    const nextNumber = numericPart + 1;
    return `EMP-${String(nextNumber).padStart(4, '0')}`;
  }

  /**
   * حساب إجمالي رواتب مجموعة موظفين
   * @param {Employee[]} employees
   * @returns {number}
   */
  static sumSalaries(employees) {
    return employees.reduce((sum, e) => sum + (e.salary || 0), 0);
  }

  /**
   * تجميع الموظفين حسب القسم
   * @param {Employee[]} employees
   * @returns {Object}
   */
  static groupByDepartment(employees) {
    const groups = {};
    for (const employee of employees) {
      const department = employee.department || 'غير محدد';
      if (!groups[department]) {
        groups[department] = [];
      }
      groups[department].push(employee);
    }
    return groups;
  }

  /**
   * تجميع الموظفين حسب المنصب
   * @param {Employee[]} employees
   * @returns {Object}
   */
  static groupByPosition(employees) {
    const groups = {};
    for (const employee of employees) {
      const position = employee.position || 'غير محدد';
      if (!groups[position]) {
        groups[position] = [];
      }
      groups[position].push(employee);
    }
    return groups;
  }

  /**
   * الحصول على الموظفين النشطين فقط
   * @param {Employee[]} employees
   * @returns {Employee[]}
   */
  static getActiveEmployees(employees) {
    return employees.filter(e => e.isActiveEmployee());
  }
}