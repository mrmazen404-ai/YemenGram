import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Switch } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '../../../shared/utils/colors';
import { useAuth } from '../../../shared/contexts/AuthContext';

const settingsSections = [
  {
    title: 'الحساب',
    items: [
      { icon: 'person-circle', label: 'الملف الشخصي', screen: 'Profile' },
      { icon: 'globe', label: 'اللغة والمظهر', screen: 'Appearance' },
    ],
  },
  {
    title: 'النظام',
    items: [
      { icon: 'notifications', label: 'الإشعارات', screen: 'Notifications' },
      { icon: 'receipt', label: 'الفواتير', screen: 'InvoiceSettings' },
      { icon: 'print', label: 'الطباعة', screen: 'Print' },
      { icon: 'share', label: 'التصدير', screen: 'Export' },
    ],
  },
  {
    title: 'العمليات',
    items: [
      { icon: 'cube', label: 'المخزون', screen: 'InventorySettings' },
      { icon: 'wallet', label: 'النقد والبنوك', screen: 'CashSettings' },
      { icon: 'journal', label: 'القيود', screen: 'JournalSettings' },
      { icon: 'people', label: 'العملاء', screen: 'CustomerSettings' },
      { icon: 'stats-chart', label: 'التقارير', screen: 'ReportSettings' },
    ],
  },
  {
    title: 'متقدم',
    items: [
      { icon: 'cloud-upload', label: 'النسخ الاحتياطي', screen: 'Backup' },
      { icon: 'log-in', label: 'بوابة العميل', screen: 'ClientPortal' },
      { icon: 'people-circle', label: 'المستخدمين', screen: 'Users' },
      { icon: 'grid', label: 'لوحة التحكم', screen: 'DashboardSettings' },
      { icon: 'send', label: 'المشاركة', screen: 'Sharing' },
    ],
  },
  {
    title: 'أخرى',
    items: [
      { icon: 'document-text', label: 'سجل التدقيق', screen: 'AuditLog' },
      { icon: 'color-palette', label: 'تخصيص الواجهة', screen: 'Theme' },
      { icon: 'headset', label: 'الدعم الفني', screen: 'Support' },
      { icon: 'document-lock', label: 'قانوني', screen: 'Legal' },
      // ✅ أضف هذا العنصر
      { icon: 'information-circle', label: 'عن التطبيق', screen: 'About' },
    ],
  },
];

export default function SettingsScreen({ navigation }) {
  const { user, logout } = useAuth();
  const [darkMode, setDarkMode] = React.useState(false);
  const [notifications, setNotifications] = React.useState(true);

  return (
    <View style={styles.root}>
      {/* هيدر */}
      <View style={styles.header}>
        <View style={styles.headerRow}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
            <Ionicons name="arrow-back" size={22} color={Colors.dark} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>الإعدادات</Text>
          <View style={styles.backBtn} />
        </View>
        <View style={styles.userCard}>
          <View style={styles.userAvatar}>
            <Text style={styles.userInitial}>{user?.name?.charAt(0) || 'ي'}</Text>
          </View>
          <View style={styles.userInfo}>
            <Text style={styles.userName}>{user?.name || 'المستخدم'}</Text>
            <Text style={styles.userEmail}>{user?.email || ''}</Text>
          </View>
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* إعدادات سريعة */}
        <View style={styles.quickRow}>
          <TouchableOpacity style={styles.quickCard} activeOpacity={0.7}>
            <View style={[styles.quickIcon, { backgroundColor: '#E3F2FD' }]}>
              <Ionicons name="moon" size={22} color={Colors.navy} />
            </View>
            <Text style={styles.quickLabel}>الوضع الداكن</Text>
            <Switch value={darkMode} onValueChange={setDarkMode} trackColor={{ false: Colors.border, true: Colors.navy }} thumbColor={Colors.white} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.quickCard} activeOpacity={0.7}>
            <View style={[styles.quickIcon, { backgroundColor: '#E8F5E9' }]}>
              <Ionicons name="notifications" size={22} color={Colors.green} />
            </View>
            <Text style={styles.quickLabel}>الإشعارات</Text>
            <Switch value={notifications} onValueChange={setNotifications} trackColor={{ false: Colors.border, true: Colors.green }} thumbColor={Colors.white} />
          </TouchableOpacity>
        </View>

        {/* أقسام الإعدادات */}
        {settingsSections.map((section, secIndex) => (
          <View key={secIndex} style={styles.section}>
            <Text style={styles.sectionTitle}>{section.title}</Text>
            <View style={styles.sectionCard}>
              {section.items.map((item, itemIndex) => (
                <TouchableOpacity
                  key={itemIndex}
                  style={[styles.menuItem, itemIndex < section.items.length - 1 && styles.menuItemBorder]}
                  activeOpacity={0.5}
                  onPress={() => navigation.navigate(item.screen)}
                >
                  <View style={[styles.menuIcon, { backgroundColor: Colors.lightGray }]}>
                    <Ionicons name={item.icon} size={20} color={Colors.navy} />
                  </View>
                  <Text style={styles.menuLabel}>{item.label}</Text>
                  <Ionicons name="chevron-forward" size={18} color={Colors.placeholder} />
                </TouchableOpacity>
              ))}
            </View>
          </View>
        ))}

        {/* خطورة */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: Colors.red }]}>منطقة الخطر</Text>
          <View style={styles.sectionCard}>
            <TouchableOpacity style={styles.menuItem} activeOpacity={0.5} onPress={logout}>
              <View style={[styles.menuIcon, { backgroundColor: '#FFF0F0' }]}>
                <Ionicons name="log-out" size={20} color={Colors.red} />
              </View>
              <Text style={[styles.menuLabel, { color: Colors.red }]}>تسجيل الخروج</Text>
              <Ionicons name="chevron-forward" size={18} color={Colors.red} />
            </TouchableOpacity>
          </View>
        </View>

        <Text style={styles.footer}>YemenGram © 2026</Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#F5F6FA' },

  header: { backgroundColor: Colors.white, paddingBottom: 16, borderBottomLeftRadius: 28, borderBottomRightRadius: 28, shadowColor: '#000', shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.06, shadowRadius: 10, elevation: 4 },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 18, paddingTop: 50, paddingBottom: 6 },
  backBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: '#F5F6FA', justifyContent: 'center', alignItems: 'center' },
  headerTitle: { fontSize: 20, fontFamily: 'Tajawal-Bold', color: Colors.dark },

  userCard: { flexDirection: 'row', alignItems: 'center', gap: 12, marginHorizontal: 18, marginTop: 10 },
  userAvatar: { width: 52, height: 52, borderRadius: 18, backgroundColor: Colors.navy, justifyContent: 'center', alignItems: 'center' },
  userInitial: { fontSize: 24, fontFamily: 'Tajawal-Bold', color: Colors.white },
  userInfo: { flex: 1 },
  userName: { fontSize: 16, fontFamily: 'Tajawal-Bold', color: Colors.dark, textAlign: 'right' },
  userEmail: { fontSize: 12, fontFamily: 'Tajawal-Regular', color: Colors.gray, textAlign: 'right' },

  scroll: { padding: 16, paddingBottom: 40 },

  quickRow: { flexDirection: 'row', gap: 10, marginBottom: 20 },
  quickCard: { flex: 1, backgroundColor: Colors.white, borderRadius: 16, padding: 14, alignItems: 'center', gap: 8, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.04, shadowRadius: 6, elevation: 2 },
  quickIcon: { width: 44, height: 44, borderRadius: 14, justifyContent: 'center', alignItems: 'center' },
  quickLabel: { fontSize: 12, fontFamily: 'Tajawal-Medium', color: Colors.dark },

  section: { marginBottom: 18 },
  sectionTitle: { fontSize: 13, fontFamily: 'Tajawal-Bold', color: Colors.placeholder, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 8, paddingHorizontal: 4, textAlign: 'right' },
  sectionCard: { backgroundColor: Colors.white, borderRadius: 16, overflow: 'hidden', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.04, shadowRadius: 6, elevation: 2 },
  menuItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: 14, paddingHorizontal: 16, gap: 12 },
  menuItemBorder: { borderBottomWidth: 1, borderBottomColor: '#F5F6FA' },
  menuIcon: { width: 40, height: 40, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  menuLabel: { flex: 1, fontSize: 14, fontFamily: 'Tajawal-Medium', color: Colors.dark, textAlign: 'right' },
  footer: { textAlign: 'center', marginTop: 24, fontSize: 11, fontFamily: 'Tajawal-Regular', color: Colors.placeholder },
});