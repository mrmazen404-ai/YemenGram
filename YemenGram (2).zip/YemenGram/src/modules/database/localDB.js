// src/modules/database/localDB.js
import * as SQLite from 'expo-sqlite';
import { runMigrations } from './migrations';

let db = null;
let isInitialized = false;
let initPromise = null;
let isSystemReadOnly = false;

// الجداول الحساسة التي سيتم قفلها في وضع القراءة فقط
const PROTECTED_TABLES = [
  'accounts', 'account_movements', 'journal_entries', 'journal_details',
  'customers', 'suppliers', 'products', 'invoices', 'invoice_items',
  'payments', 'expenses', 'revenues', 'transfers', 'employees',
  'payroll', 'fixed_assets', 'subscriptions', 'subscription_event_keys', 'receipts', 'sync_queue', 'audit_log'
];

// =============================================
// 0. حارس السيادة (Internal Guard)
// =============================================

const verifySovereignGuard = (sql) => {
  if (!isSystemReadOnly) return true;

  const normalizedSql = sql.toLowerCase().trim();
  if (normalizedSql.startsWith('select')) return true;

  // استخدام Regex لضمان أننا نفحص اسم الجدول الصريح بعد الكلمات المفتاحية
  // يمنع هذا التداخل مع أسماء الحقول المشابهة لأسماء الجداول
  const tableRegex = /(?:into|update|from|delete\s+from)\s+([a-zA-Z0-9_]+)/;
  const match = normalizedSql.match(tableRegex);
  const targetTable = match ? match[1] : null;

  if (targetTable && PROTECTED_TABLES.includes(targetTable)) {
    console.warn(`🛡️ [LocalDB] رفض العملية: الجدول [${targetTable}] مغلق في وضع القراءة فقط.`);
    return false;
  }

  return true;
};

// =============================================
// 1. تهيئة قاعدة البيانات (Strict Singleton)
// =============================================

export const initDB = async () => {
  // 1. إذا كان الاتصال نشطاً وجاهزاً، لا تفعل شيئاً
  if (isInitialized && db) {
    return true;
  }

  // 2. منع السباق (Race Condition)
  if (initPromise) {
    console.log('⏳ [LocalDB] هناك عملية تهيئة جارية، الانتظار...');
    return initPromise;
  }

  initPromise = (async () => {
    try {
      console.log('📦 [LocalDB] بدء تهيئة قاعدة البيانات الحصرية...');

      // ✅ فتح اتصال واحد فقط
      const database = await SQLite.openDatabaseAsync('yemengram.db');

      if (!database) throw new Error('فشل فتح الملف');

      // ✅ إعدادات الأمان والانتظار (Busy Timeout)
      await database.execAsync(`
        PRAGMA busy_timeout = 20000;
        PRAGMA journal_mode = WAL;
        PRAGMA synchronous = NORMAL;
      `);

      // ✅ اختبار الاتصال الأساسي
      await database.execAsync('SELECT 1;');

      db = database;
      console.log('✅ [LocalDB] تم إنشاء الاتصال الرئيسي');

      // ✅ تشغيل الترحيلات
      const migrationResult = await runMigrations(db);
      if (!migrationResult || !migrationResult.success) {
        throw new Error(migrationResult?.error || 'فشل الترحيل');
      }

      isInitialized = true;
      console.log('🎉 [LocalDB] قاعدة البيانات جاهزة 100%');
      return true;
    } catch (error) {
      console.log('❌ [LocalDB] خطأ حرج في التهيئة:', error.message);
      // لا تصفر db هنا لتجنب تكرار الفتح إذا كان الخطأ عارضاً
      isInitialized = false;
      throw error;
    } finally {
      initPromise = null;
    }
  })();

  return initPromise;
};

// =============================================
// 2. التأكد من الاتصال (بدون فتح ملفات جديدة)
// =============================================

export const ensureConnection = async () => {
  if (db && isInitialized) {
    try {
      await db.execAsync('SELECT 1;');
      return true;
    } catch {
      isInitialized = false;
      db = null;
    }
  }
  return await initDB();
};

// =============================================
// 3. دوال الاستعلام (تستخدم الاتصال الموحد)
// =============================================

export const execute = async (sql, params = [], options = {}) => {
  if (!options.system && !verifySovereignGuard(sql)) {
    throw new Error('النظام في وضع القراءة فقط. يرجى تجديد الاشتراك لمواصلة العمليات.');
  }
  await ensureConnection();
  return await db.runAsync(sql, params);
};

export const query = async (sql, params = []) => {
  await ensureConnection();
  return await db.getAllAsync(sql, params);
};

export const queryOne = async (sql, params = []) => {
  await ensureConnection();
  return await db.getFirstAsync(sql, params);
};

export const queryOneWithRetry = async (sql, params = [], retries = 3) => {
  for (let i = 0; i < retries; i++) {
    try {
      return await queryOne(sql, params);
    } catch (error) {
      if (error.message.includes('disk I/O') || error.message.includes('locked')) {
        console.log(`⚠️ [LocalDB] محاولة استعادة القفل ${i + 1}/${retries}...`);
        await new Promise(r => setTimeout(r, 1000));
        continue;
      }
      throw error;
    }
  }
  return await queryOne(sql, params);
};

export const saveUser = async (user) => {
  await execute(
    `INSERT OR REPLACE INTO user
     (id, user_code, name, email, phone, avatar, role, company_id, company_name, base_currency, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))`,
    [user.id, user.user_code, user.name, user.email, user.phone, user.avatar, user.role, user.company_id, user.company_name, user.base_currency]
  );
};

export const getUser = async () => {
  return await queryOne('SELECT * FROM user LIMIT 1');
};

export const saveSession = async (token, fingerprint, signature, expiresAt) => {
  await execute('DELETE FROM session');
  await execute(
    'INSERT INTO session (token, device_fingerprint, signature, expires_at, created_at) VALUES (?, ?, ?, ?, datetime("now"))',
    [token, fingerprint, signature, expiresAt]
  );
};

export const getSession = async () => {
  return await queryOne('SELECT * FROM session ORDER BY id DESC LIMIT 1');
};

export const clearSession = async () => {
  await execute('DELETE FROM session');
};

export const saveSetting = async (key, value) => {
  await execute('INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (?, ?, datetime("now"))', [key, String(value)]);
};

export const getSetting = async (key) => {
  const row = await queryOne('SELECT value FROM settings WHERE key = ?', [key]);
  return row?.value || null;
};

export const addAuditLog = async (action, tableName, recordId, details, userId = null, options = {}) => {
  try {
    await execute(
      'INSERT INTO audit_log (user_id, action, table_name, record_id, details, created_at) VALUES (?, ?, ?, ?, ?, datetime("now"))',
      [userId, action, tableName, recordId, details ? JSON.stringify(details) : null],
      options
    );
  } catch (e) {
    console.log('⚠️ فشل تسجيل Log:', e.message);
  }
};

export const savePendingRegistration = async (data) => {
  await saveSetting('pending_registration', JSON.stringify(data));
};

export const getPendingRegistration = async () => {
  const data = await getSetting('pending_registration');
  return data ? JSON.parse(data) : null;
};

export const removePendingRegistration = async () => {
  await execute('DELETE FROM settings WHERE key = ?', ['pending_registration']);
};

export const clearAll = async () => {
  await execute('DELETE FROM user');
  await execute('DELETE FROM session');
  await execute('DELETE FROM settings');
};

export const setReadOnlyMode = (status) => {
  isSystemReadOnly = status;
  console.log(`🛡️ [LocalDB] تم ضبط وضع القراءة فقط: ${status}`);
};

export const LocalDB = {
  init: initDB,
  ensureConnection,
  query,
  queryOne,
  queryOneWithRetry,
  execute,
  transaction,
  setReadOnlyMode,
  saveUser,
  getUser,
  saveSession,
  getSession,
  clearSession,
  saveSetting,
  getSetting,
  addAuditLog,
  savePendingRegistration,
  getPendingRegistration,
  removePendingRegistration,
  clearAll
};

export default LocalDB;
