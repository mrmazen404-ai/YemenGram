// src/shared/hooks/useForm.js
// =============================================
// Hook إدارة النماذج (Form Management)
// يدير حالة النماذج، التحقق، الإرسال، والأخطاء
// =============================================

import { useState, useCallback, useRef, useEffect } from 'react';

// =============================================
// Hook الرئيسي
// =============================================

export function useForm({
  // ===== البيانات الأولية =====
  initialValues = {},
  initialErrors = {},
  initialTouched = {},

  // ===== التحقق =====
  validate = null,           // دالة التحقق (تستقبل القيم وتعيد الأخطاء)
  validateOnChange = true,   // التحقق عند التغيير
  validateOnBlur = true,     // التحقق عند مغادرة الحقل
  validateOnSubmit = true,   // التحقق عند الإرسال

  // ===== الإرسال =====
  onSubmit = null,           // دالة الإرسال (تستقبل القيم)
  onSubmitSuccess = null,    // دالة النجاح
  onSubmitError = null,      // دالة الفشل

  // ===== الحالة =====
  enableReinitialize = false, // إعادة التهيئة عند تغيير initialValues
  resetAfterSubmit = false,   // إعادة تعيين النموذج بعد الإرسال الناجح

  // ===== التخصيص =====
  debug = false,             // وضع التصحيح
}) {
  // ===== الحالة الأساسية =====
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState(initialErrors);
  const [touched, setTouched] = useState(initialTouched);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isValidating, setIsValidating] = useState(false);
  const [submitCount, setSubmitCount] = useState(0);
  const [isDirty, setIsDirty] = useState(false);

  // ===== المراجع =====
  const initialValuesRef = useRef(initialValues);
  const isMounted = useRef(true);

  // =============================================
  // 1. إعادة التهيئة
  // =============================================

  useEffect(() => {
    if (enableReinitialize && initialValues !== initialValuesRef.current) {
      setValues(initialValues);
      initialValuesRef.current = initialValues;
      setIsDirty(false);
    }
  }, [initialValues, enableReinitialize]);

  useEffect(() => {
    return () => {
      isMounted.current = false;
    };
  }, []);

  // =============================================
  // 2. دوال المساعدة
  // =============================================

  /**
   * التحقق من النموذج
   */
  const validateForm = useCallback(async (formValues) => {
    if (!validate) return {};

    setIsValidating(true);
    try {
      const validationErrors = await validate(formValues);
      if (debug) {
        console.log('🔍 [useForm] نتائج التحقق:', validationErrors);
      }
      return validationErrors || {};
    } catch (error) {
      console.log('❌ [useForm] خطأ في التحقق:', error.message);
      return {};
    } finally {
      setIsValidating(false);
    }
  }, [validate, debug]);

  /**
   * التحقق من حقل واحد
   */
  const validateField = useCallback(async (name, value) => {
    const formValues = { ...values, [name]: value };
    const validationErrors = await validateForm(formValues);
    return validationErrors[name] || null;
  }, [values, validateForm]);

  // =============================================
  // 3. دوال معالجة الحقول
  // =============================================

  /**
   * تغيير قيمة حقل
   */
  const handleChange = useCallback(async (name, value) => {
    const newValues = { ...values, [name]: value };
    setValues(newValues);
    setIsDirty(true);

    if (debug) {
      console.log(`✏️ [useForm] تغيير ${name}:`, value);
    }

    // التحقق عند التغيير
    if (validateOnChange && touched[name]) {
      const fieldError = await validateField(name, value);
      setErrors(prev => ({ ...prev, [name]: fieldError }));
    }
  }, [values, touched, validateOnChange, validateField, debug]);

  /**
   * تغيير قيمة حقل مع معالجة الأحداث
   */
  const handleInputChange = useCallback((name) => (value) => {
    handleChange(name, value);
  }, [handleChange]);

  /**
   * تغيير قيمة حقل (لكائنات متداخلة)
   */
  const handleNestedChange = useCallback((path) => (value) => {
    const keys = path.split('.');
    const newValues = { ...values };
    let current = newValues;
    for (let i = 0; i < keys.length - 1; i++) {
      current = current[keys[i]];
    }
    current[keys[keys.length - 1]] = value;
    setValues(newValues);
    setIsDirty(true);

    if (debug) {
      console.log(`✏️ [useForm] تغيير ${path}:`, value);
    }
  }, [values, debug]);

  /**
   * تغيير قيمة حقل (مع التحقق الفوري)
   */
  const handleChangeWithValidation = useCallback(async (name, value) => {
    const newValues = { ...values, [name]: value };
    setValues(newValues);
    setIsDirty(true);

    const fieldError = await validateField(name, value);
    setErrors(prev => ({ ...prev, [name]: fieldError }));
    return fieldError;
  }, [values, validateField]);

  /**
   * معالجة فقدان التركيز (Blur)
   */
  const handleBlur = useCallback(async (name) => {
    setTouched(prev => ({ ...prev, [name]: true }));

    if (validateOnBlur && values[name] !== undefined) {
      const fieldError = await validateField(name, values[name]);
      setErrors(prev => ({ ...prev, [name]: fieldError }));
    }

    if (debug) {
      console.log(`👆 [useForm] خروج من ${name}`);
    }
  }, [values, validateOnBlur, validateField, debug]);

  /**
   * معالجة فقدان التركيز (للاستخدام المباشر)
   */
  const handleInputBlur = useCallback((name) => () => {
    handleBlur(name);
  }, [handleBlur]);

  /**
   * إعادة تعيين النموذج
   */
  const resetForm = useCallback((newValues = null) => {
    setValues(newValues || initialValues);
    setErrors(initialErrors);
    setTouched(initialTouched);
    setIsDirty(false);
    setSubmitCount(0);

    if (debug) {
      console.log('🔄 [useForm] إعادة تعيين النموذج');
    }
  }, [initialValues, initialErrors, initialTouched, debug]);

  /**
   * تعيين أخطاء يدوياً
   */
  const setFieldError = useCallback((name, error) => {
    setErrors(prev => ({ ...prev, [name]: error }));
  }, []);

  /**
   * تعيين قيمة حقل يدوياً
   */
  const setFieldValue = useCallback((name, value) => {
    setValues(prev => ({ ...prev, [name]: value }));
    setIsDirty(true);
  }, []);

  /**
   * تعيين جميع القيم يدوياً
   */
  const setValuesManually = useCallback((newValues) => {
    setValues(newValues);
    setIsDirty(true);
  }, []);

  // =============================================
  // 4. الإرسال
  // =============================================

  const handleSubmit = useCallback(async (e) => {
    if (e && e.preventDefault) {
      e.preventDefault();
    }

    setSubmitCount(prev => prev + 1);

    if (debug) {
      console.log('📤 [useForm] بدء الإرسال');
    }

    // تعيين جميع الحقول كـ touched
    const allTouched = {};
    Object.keys(values).forEach(key => {
      allTouched[key] = true;
    });
    setTouched(allTouched);

    // التحقق
    let validationErrors = {};
    if (validateOnSubmit) {
      validationErrors = await validateForm(values);
      setErrors(validationErrors);

      if (Object.keys(validationErrors).length > 0) {
        if (debug) {
          console.log('❌ [useForm] فشل التحقق:', validationErrors);
        }
        return { success: false, errors: validationErrors };
      }
    }

    if (!onSubmit) {
      if (debug) {
        console.log('⚠️ [useForm] لا توجد دالة إرسال');
      }
      return { success: false, error: 'لا توجد دالة إرسال' };
    }

    setIsSubmitting(true);
    try {
      const result = await onSubmit(values);

      if (debug) {
        console.log('✅ [useForm] تم الإرسال بنجاح:', result);
      }

      if (onSubmitSuccess) {
        onSubmitSuccess(result);
      }

      if (resetAfterSubmit) {
        resetForm();
      }

      return { success: true, result };
    } catch (error) {
      if (debug) {
        console.log('❌ [useForm] فشل الإرسال:', error.message);
      }

      if (onSubmitError) {
        onSubmitError(error);
      }

      return { success: false, error };
    } finally {
      if (isMounted.current) {
        setIsSubmitting(false);
      }
    }
  }, [values, validateForm, validateOnSubmit, onSubmit, onSubmitSuccess, onSubmitError, resetAfterSubmit, resetForm, debug]);

  // =============================================
  // 5. دوال مساعدة إضافية
  // =============================================

  /**
   * التحقق من وجود أخطاء
   */
  const hasErrors = useCallback(() => {
    return Object.keys(errors).some(key => errors[key] !== null && errors[key] !== undefined);
  }, [errors]);

  /**
   * التحقق من صحة النموذج
   */
  const isValid = useCallback(() => {
    return !hasErrors() && !isSubmitting;
  }, [hasErrors, isSubmitting]);

  /**
   * التحقق من وجود تغييرات
   */
  const isDirtyForm = useCallback(() => {
    return isDirty;
  }, [isDirty]);

  /**
   * الحصول على أول خطأ
   */
  const getFirstError = useCallback(() => {
    for (const key of Object.keys(errors)) {
      if (errors[key]) return errors[key];
    }
    return null;
  }, [errors]);

  /**
   * الحصول على جميع الأخطاء كـ مصفوفة
   */
  const getErrorsArray = useCallback(() => {
    return Object.keys(errors)
      .filter(key => errors[key])
      .map(key => ({ field: key, message: errors[key] }));
  }, [errors]);

  /**
   * تنظيف الأخطاء
   */
  const clearErrors = useCallback(() => {
    setErrors({});
  }, []);

  /**
   * تنظيف الحقول التي تم لمسها
   */
  const clearTouched = useCallback(() => {
    setTouched({});
  }, []);

  // =============================================
  // 6. القيمة المرجعة
  // =============================================

  return {
    // الحالة
    values,
    errors,
    touched,
    isSubmitting,
    isValidating,
    submitCount,
    isDirty,
    isValid: isValid(),
    hasErrors: hasErrors(),
    getFirstError: getFirstError(),
    getErrorsArray: getErrorsArray(),

    // دوال معالجة الحقول
    handleChange,
    handleInputChange,
    handleNestedChange,
    handleChangeWithValidation,
    handleBlur,
    handleInputBlur,
    setFieldValue,
    setFieldError,
    setValuesManually,

    // دوال التحقق والإرسال
    validateForm,
    validateField,
    handleSubmit,

    // دوال إعادة التعيين
    resetForm,
    clearErrors,
    clearTouched,
  };
}

// =============================================
// Hook مساعد: التحقق من صحة البريد الإلكتروني
// =============================================

export const validators = {
  required: (message = 'هذا الحقل مطلوب') => (value) => {
    if (!value || value.trim() === '') return message;
    return null;
  },

  email: (message = 'بريد إلكتروني غير صحيح') => (value) => {
    if (!value) return null;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
    if (!emailRegex.test(value.trim())) return message;
    return null;
  },

  phone: (message = 'رقم هاتف غير صحيح') => (value) => {
    if (!value) return null;
    const clean = value.replace(/[\s\-\(\)\+]/g, '');
    if (!/^\d{9,}$/.test(clean)) return message;
    return null;
  },

  minLength: (min, message = `الحد الأدنى ${min} أحرف`) => (value) => {
    if (!value) return null;
    if (value.length < min) return message;
    return null;
  },

  maxLength: (max, message = `الحد الأقصى ${max} أحرف`) => (value) => {
    if (!value) return null;
    if (value.length > max) return message;
    return null;
  },

  min: (min, message = `الحد الأدنى ${min}`) => (value) => {
    if (value === undefined || value === null || value === '') return null;
    if (Number(value) < min) return message;
    return null;
  },

  max: (max, message = `الحد الأقصى ${max}`) => (value) => {
    if (value === undefined || value === null || value === '') return null;
    if (Number(value) > max) return message;
    return null;
  },

  pattern: (pattern, message = 'قيمة غير صحيحة') => (value) => {
    if (!value) return null;
    if (!pattern.test(value)) return message;
    return null;
  },

  confirm: (field, message = 'القيم غير متطابقة') => (value, allValues) => {
    if (value !== allValues[field]) return message;
    return null;
  },
};

export default useForm;