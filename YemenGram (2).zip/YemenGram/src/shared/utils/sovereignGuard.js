// src/shared/utils/sovereignGuard.js
// =============================================
// حارس السيادة (The Sovereign Guard)
// المسؤول عن إنفاذ "قفل النواة" ومنع الكتابة في وضع القراءة فقط
// =============================================

import { store } from '../../store';
import { Logger } from './logger';
import SubscriptionAnalytics from '../../modules/subscriptions/services/SubscriptionAnalytics';

// الجداول الحساسة التي سيتم قفلها في وضع القراءة فقط
const PROTECTED_TABLES = [
  'accounts',
  'account_movements',
  'journal_entries',
  'journal_details',
  'customers',
  'suppliers',
  'products',
  'invoices',
  'invoice_items',
  'payments',
  'expenses',
  'revenues',
  'transfers',
  'employees',
  'payroll',
  'fixed_assets'
];

export const SovereignGuard = {
  /**
   * فحص هل العملية مسموح بها بناءً على حالة الاشتراك وحدود الموارد
   * @param {string} sql - نص الاستعلام لفحص الجدول المستهدف
   * @returns {boolean} - true إذا كانت العملية مسموحاً بها
   */
  async verifyOperation(sql) {
    const normalizedSql = sql.toLowerCase().trim();

    // 1. السماح بعمليات القراءة دائماً
    if (normalizedSql.startsWith('select')) return true;

    // 2. تحديد الجدول المستهدف
    const targetTable = PROTECTED_TABLES.find(table =>
      normalizedSql.includes(`into ${table}`) ||
      normalizedSql.includes(`update ${table}`) ||
      normalizedSql.includes(`from ${table}`) ||
      normalizedSql.includes(`delete from ${table}`)
    );

    if (!targetTable) return true;

    // 3. جلب بيانات الاشتراك من المتجر
    const state = store.getState();
    const subscription = state.subscription?.data;
    const userId = state.auth?.user?.id;

    if (!subscription) return true;

    // 4. إنفاذ القفل إذا كان النظام في وضع القراءة فقط (تاريخي أو أمني)
    if (subscription.isReadOnly) {
      Logger.warn('SovereignGuard', `محاولة كتابة مرفوضة على جدول ${targetTable}. النظام في وضع القراءة فقط.`);
      return false;
    }

    // 5. إنفاذ قفل الموارد (Resource Enforcement)
    // منع الإضافة (INSERT) فقط عند تجاوز الحدود
    if (normalizedSql.includes(`into ${targetTable}`)) {
      if (targetTable === 'customers' || targetTable === 'invoices') {
        const usage = await SubscriptionAnalytics.getResourceUsage(userId);

        if (usage.isOverLimit) {
          Logger.security('Resource Limit Exceeded', { table: targetTable, userId });
          return false;
        }
      }
    }

    return true;
  },

  /**
   * رسالة الخطأ السيادية
   */
  getLockdownMessage(sql = '') {
    if (sql.toLowerCase().includes('into')) {
      return 'عذراً، لقد تجاوزت حدود الموارد المسموح بها في باقتك الحالية. يرجى الترقية لمواصلة العمليات.';
    }
    return 'عذراً، النظام في وضع القراءة فقط حالياً. يرجى تفعيل أو تجديد الاشتراك لمواصلة العمليات المالية.';
  }
};
