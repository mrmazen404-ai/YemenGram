# YemenGram — Security Implementation

## Implemented in this build

- Replaced custom XOR encryption with AES-256-GCM using `@noble/ciphers`.
- Added versioned authenticated payloads with nonce and associated data.
- Removed fixed encryption and backup keys.
- Generated and stored the local encryption key in `expo-secure-store` with device-only accessibility.
- Replaced direct SHA-256 password storage with PBKDF2-SHA256 verifier records using an independent salt and 210,000 iterations.
- Removed the registration password from SQLite. The pending password is encrypted through the secure-storage facade and deleted after registration.
- Removed plaintext `password_hash` storage from LocalDB.
- Replaced `Math.random()` OTP generation with CSPRNG-backed OTP generation.
- Replaced the random device identifier fallback with CSPRNG bytes.
- Made device validation fail-closed and removed the generic device-ID fallback.
- Secured backup restore with an explicit table allowlist, identifier validation, and a transaction with rollback.
- Added Supabase error checks to the WatermelonDB sync push path.
- Corrected pull classification so deleted records are not treated as updated records.
- Removed server secret from the working `.env` and added `.env.example`.
- Fixed unresolved local imports and added a Web-specific WatermelonDB fallback so `better-sqlite3` does not enter the browser bundle.
- Added `npm run security:smoke` to test AES-GCM round-trip and tamper rejection.
- Updated direct Supabase and React Navigation dependencies to patched compatible versions.

## Verification completed

- `npm run security:smoke` — passed.
- `npx expo export --platform web` — passed.
- Local-import scan — no unresolved local imports.
- Secret scan — no embedded service-role secret or fixed encryption key in the sanitized source.
- Legacy XOR/password-hash scan — no active legacy implementation remains.

## Required external actions before production

1. **Rotate the exposed Supabase service-role/secret key in the Supabase dashboard.** This cannot be completed by source-code changes alone.
2. Confirm RLS policies for every user-owned table and test cross-user access with the public client key.
3. Move all service-role credentials to a server-side Edge Function/backend secret manager.
4. Add Play Integrity/App Attest or a reviewed native integrity provider if device attestation is a hard requirement.
5. Review existing backups: old XOR backups are intentionally not accepted by the new authenticated format. Migrate them in a controlled, isolated process before rollout if they contain required data.
6. Plan an Expo SDK upgrade. `npm audit` still reports transitive vulnerabilities from the current Expo SDK 52 and WatermelonDB dependency tree; forcing a major upgrade was intentionally not performed because it requires a separate compatibility migration and native rebuild.
7. Build and test a real Release APK/IPA on physical devices; the Web export only validates JavaScript bundling and import integrity.

## Important design note

Local backups are now encrypted with a device-bound key in Keychain/Keystore. Restoring on a different device requires a separate user-approved key export/recovery design; a fixed shared key is deliberately not used.
