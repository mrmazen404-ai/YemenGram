// src/modules/dashboard/components/SovereignCarousel.js
// محرك السلايدر السيادي اللانهائي (The Sovereign Infinite Loop Engine)
// تمرير انسيابي مستمر، توصيط مطلق، وأداء احترافي فائق

import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  Animated,
  Dimensions,
  StyleSheet,
  Platform,
  Image,
} from 'react-native';
import * as Haptics from 'expo-haptics';
import VaultCard from './VaultCard';
import { Colors } from '../../../shared/utils/colors';
import SafeGradient from '../../../shared/components/SafeGradient';

const { width } = Dimensions.get('window');
const scale = (size) => (width / 375) * size;

// هندسة التوصيط الذهبية
const CARD_WIDTH = width * 0.90;
const CARD_MARGIN = scale(7);
const FULL_SIZE = CARD_WIDTH + (CARD_MARGIN * 2);
const SPACER = (width - CARD_WIDTH) / 2 - CARD_MARGIN;

const SLIDE_DATA = [
  { id: '1', type: 'vault' },
  { id: '2', type: 'image', source: require('../../../shared/assets/images/Data Security.png'), title: 'السيادة الأمنية الرقمية', sub: 'تشفير عسكري MASVS L2 لحماية أصولك.' },
  { id: '3', type: 'image', source: require('../../../shared/assets/images/cloud Service.png'), title: 'المزامنة السحابية الذكية', sub: 'بياناتك متصلة ومحمية في سحابة YG.' },
  { id: '4', type: 'image', source: require('../../../shared/assets/images/team support.jpg'), title: 'دعم النخبة الاستشاري', sub: 'خبراء بجانبك في كل خطوة مالية.' },
  { id: '5', type: 'image', source: require('../../../shared/assets/images/customers getwey.png'), title: 'بوابة الوصول الشامل', sub: 'تجربة مستخدم تفوق المعايير العالمية.' },
];

export default function SovereignCarousel() {
  const [activeIndex, setActiveIndex] = useState(0);
  const scrollX = useRef(new Animated.Value(0)).current;
  const flatListRef = useRef(null);
  const timerRef = useRef(null);

  // محرك التنقل التلقائي السلس
  useEffect(() => {
    startAutoPlay();
    return () => stopAutoPlay();
  }, [activeIndex]);

  const startAutoPlay = () => {
    stopAutoPlay();
    timerRef.current = setInterval(() => {
        let nextIndex = (activeIndex + 1) % SLIDE_DATA.length;
      flatListRef.current?.scrollToOffset({
        offset: nextIndex * FULL_SIZE,
        animated: true,
      });
    }, 4500);
  };

  const stopAutoPlay = () => {
    if (timerRef.current) clearInterval(timerRef.current);
  };

  const renderItem = ({ item, index }) => {
    const inputRange = [
      (index - 1) * FULL_SIZE,
      index * FULL_SIZE,
      (index + 1) * FULL_SIZE,
    ];

    const cardScale = scrollX.interpolate({
      inputRange,
        outputRange: [0.93, 1, 0.93],
      extrapolate: 'clamp',
    });

    const cardOpacity = scrollX.interpolate({
      inputRange,
      outputRange: [0.52, 1, 0.5],
      extrapolate: 'clamp',
    });

    return (
      <Animated.View style={[
        styles.cardWrapper,
        { transform: [{ scale: cardScale }], opacity: cardOpacity }
      ]}>
        {item.type === 'vault' ? (
          <VaultCard />
        ) : (
          <View style={styles.imageCard}>
            <Image source={item.source} style={styles.slideImage} resizeMode="cover" />
            <SafeGradient
              colors={['transparent', 'rgba(10, 25, 47, 0.9)']}
              style={styles.textOverlay}
            >
              <Text style={styles.slideTitle}>{item.title}</Text>
              <Text style={styles.slideSub} numberOfLines={1}>{item.sub}</Text>
            </SafeGradient>
            <View style={styles.premiumBadge}>
               <Text style={styles.badgeText}>YEMENGRAM ELITE</Text>
            </View>
          </View>
        )}
      </Animated.View>
    );
  };

  return (
    <View style={styles.container}>
      <Animated.FlatList
        ref={flatListRef}
        data={SLIDE_DATA}
        renderItem={renderItem}
        horizontal
        showsHorizontalScrollIndicator={false}
        snapToInterval={FULL_SIZE}
        decelerationRate="fast"
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { x: scrollX } } }],
          { useNativeDriver: true }
        )}
        onMomentumScrollEnd={(e) => {
          const index = Math.round(e.nativeEvent.contentOffset.x / FULL_SIZE);
          if (index !== activeIndex) {
            setActiveIndex(index);
          }
        }}
        onScrollBeginDrag={() => {
          stopAutoPlay();
          scrollX.stopAnimation(); // إيقاف أي حركة معلقة لمنع الاهتزاز
        }}
        onScrollEndDrag={startAutoPlay}
        scrollEventThrottle={16} // زيادة دقة الأحداث (60fps)
        snapToAlignment="center" // ضمان التمركز الدقيق
        disableIntervalMomentum={true} // منع القفز فوق العناصر
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ paddingHorizontal: SPACER }}
        removeClippedSubviews={false} // لضمان سلاسة الأنيميشن
      />

      {/* مؤشر النقاط السيادي */}
      <View style={styles.pagination}>
        {SLIDE_DATA.map((_, i) => {
          const scaleX = scrollX.interpolate({
            inputRange: [(i - 1) * FULL_SIZE, i * FULL_SIZE, (i + 1) * FULL_SIZE],
            outputRange: [1, 3, 1],
            extrapolate: 'clamp',
          });
          const opacity = scrollX.interpolate({
            inputRange: [(i - 1) * FULL_SIZE, i * FULL_SIZE, (i + 1) * FULL_SIZE],
            outputRange: [0.3, 1, 0.3],
            extrapolate: 'clamp',
          });

          return (
            <Animated.View
              key={i}
              style={[styles.dot, { opacity, transform: [{ scaleX }], backgroundColor: Colors.gold }]}
            />
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginTop: scale(12),
    height: scale(200),
    alignItems: 'center',
  },
  cardWrapper: {
    width: CARD_WIDTH,
    marginHorizontal: CARD_MARGIN,
    height: scale(165),
    borderRadius: scale(24),
    backgroundColor: Colors.navy,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 8,
  },
  imageCard: {
    flex: 1,
    borderRadius: scale(24),
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(212, 168, 83, 0.1)',
  },
  slideImage: {
    width: '100%',
    height: '100%',
  },
  textOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '60%',
    justifyContent: 'flex-end',
    padding: scale(15),
  },
  slideTitle: {
    fontSize: scale(14),
    fontFamily: 'Tajawal-Bold',
    color: Colors.white,
    textAlign: 'left',
  },
  slideSub: {
    fontSize: scale(9),
    fontFamily: 'Tajawal-Medium',
    color: Colors.gold,
    marginTop: scale(2),
    textAlign: 'left',
  },
  premiumBadge: {
    position: 'absolute',
    top: scale(10),
    right: scale(12),
    backgroundColor: 'rgba(0,0,0,0.4)',
    paddingHorizontal: scale(8),
    paddingVertical: scale(3),
    borderRadius: scale(6),
    borderWidth: 0.5,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  badgeText: {
    fontSize: scale(7),
    fontFamily: 'Tajawal-Bold',
    color: 'rgba(255,255,255,0.7)',
    letterSpacing: 0.5,
  },
  pagination: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: scale(12),
  },
  dot: {
    height: 4,
    width: 6,
    borderRadius: 2,
    marginHorizontal: 4,
  },
});
