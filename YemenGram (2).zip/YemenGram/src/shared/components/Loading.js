// src/shared/components/Loading.js
// مكوّن التحميل السحري النقي (The Sovereign Pure Aesthetic Loading)
// تصميم: كمن امركه - شفافية مطلقة، تركيز على الشعار المتحرك، واحترافية عالية

import React, { useEffect, useRef } from 'react';
import {
  View,
  StyleSheet,
  Modal,
  Animated,
  Dimensions,
  Image,
  Text,
} from 'react-native';
import { Colors } from '../utils/colors';

const { width } = Dimensions.get('window');

/**
 * مكوّن التحميل السيادي
 * تم تصميمه ليكون أجمل لحظة في التطبيق - يظهر الشعار فقط بنقاء تام مع إمكانية إضافة نص
 */
export default function Loading({ visible = false, text = '' }) {
  // استخدام الشعار الذي قمنا بضغطه (69KB) لضمان السرعة
  const logo = require('../assets/images/logo-animation.gif');

  // ===== Animations =====
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0.8)).current;

  useEffect(() => {
    if (visible) {
      // أنيميشن الظهور السحري (Google Protocol)
      Animated.parallel([
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 500,
          useNativeDriver: true,
        }),
        Animated.spring(scaleAnim, {
          toValue: 1,
          friction: 8,
          tension: 40,
          useNativeDriver: true,
        }),
      ]).start();
    } else {
      // الاختفاء الهادئ
      Animated.timing(fadeAnim, {
        toValue: 0,
        duration: 300,
        useNativeDriver: true,
      }).start();
    }
  }, [visible]);

  if (!visible) return null;

  return (
    <View style={styles.fullScreenOverlay}>
      <Animated.View
        style={[
          styles.container,
          {
            opacity: fadeAnim,
            transform: [{ scale: scaleAnim }],
          },
        ]}
      >
        {/* الشعار المتحرك يظهر بنقاء مطلق بدون أي حواف أو أشرطة */}
        <View style={styles.logoWrapper}>
          <Image
            source={logo}
            style={styles.logo}
            resizeMode="contain"
          />
        </View>

        {text !== '' && (
          <Text style={styles.text}>{text}</Text>
        )}
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  fullScreenOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(255, 255, 255, 0.98)',
    zIndex: 99999,
    elevation: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  container: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoWrapper: {
    width: 200, // مساحة ضوء وافرة
    height: 200,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logo: {
    width: '100%',
    height: '100%',
  },
  text: {
    marginTop: 20,
    fontSize: 16,
    fontFamily: 'Tajawal-Bold',
    color: Colors.navy,
    textAlign: 'center',
  },
});
