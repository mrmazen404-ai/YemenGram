// src/modules/audit/AuditScreen.js
// مركز التدقيق والنزاهة الرقمية (Forensic Command Center)
// نسخة قوقل النهائية - تفعيل "المصفوفة السيادية الثلاثية" (حقيقي 100%)

import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StatusBar, RefreshControl, Alert } from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { styles } from './AuditStyles';
import { AuditService } from './AuditService';
import { TriplePulseChart } from './AuditCharts';
import { Colors } from '../../shared/utils/colors';
import SecurityLoading from '../../shared/components/SecurityLoading';

export default function AuditScreen({ navigation }) {
  const [logs, setLogs] = useState([]);
  const [score, setScore] = useState(100);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // بيانات مصفوفة الألوان الثلاثية
  const [matrixData, setMatrixData] = useState({
    green: [0, 0], yellow: [0, 0], red: [0, 0], labels: ['-']
  });

  const loadData = async (f = 'all') => {
    try {
      const [fetchedLogs, integrityScore, triplePulse] = await Promise.all([
        AuditService.getLogs(f, 'all'),
        AuditService.calculateIntegrity(),
        AuditService.getTriplePulseData()
      ]);
      setLogs(fetchedLogs);
      setScore(integrityScore);
      setMatrixData(triplePulse);
    } catch (e) {
      console.log('Forensic Audit Error');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => { loadData(); }, []);

  const getActionTheme = (action) => {
    const act = action.toLowerCase();
    if (act.includes('fail') || act.includes('error')) return { icon: 'alert-circle', color: '#E74C3C', bg: 'rgba(231, 76, 60, 0.08)' };
    if (act.includes('login')) return { icon: 'shield-account', color: '#3498DB', bg: 'rgba(52, 152, 219, 0.1)' };
    return { icon: 'check-circle', color: '#2ECC71', bg: 'rgba(46, 204, 113, 0.08)' };
  };

  return (
    <View style={styles.root}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      <SecurityLoading visible={loading} status="جاري تدقيق النزاهة..." />

      <View style={styles.header}>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
          <Ionicons name="chevron-forward" size={24} color={Colors.navy} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>مركز العمليات والنزاهة</Text>
        <TouchableOpacity style={styles.refreshBtn} onPress={() => { setLoading(true); loadData(); }}>
          <Ionicons name="refresh" size={20} color={Colors.navy} />
        </TouchableOpacity>
      </View>

      <ScrollView
        contentContainerStyle={styles.scrollBody}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={loadData} tintColor={Colors.navy} />}
      >
        <View style={styles.intelligenceCard}>
           <View style={styles.integrityRow}>
              <View>
                 <Text style={styles.integrityLabel}>مؤشر النزاهة الرقمية</Text>
                 <Text style={[styles.integrityValue, { color: score > 90 ? '#2ECC71' : '#F1C40F' }]}>%{score}</Text>
              </View>
              <MaterialCommunityIcons name="finance" size={40} color={Colors.navy} style={{ opacity: 0.1 }} />
           </View>

           {/* استدعاء الرسم الثلاثي المطور (حقيقي وحي) */}
           <TriplePulseChart
             greenData={matrixData.green}
             yellowData={matrixData.yellow}
             redData={matrixData.red}
             labels={matrixData.labels}
           />
        </View>

        <Text style={styles.sectionLabel}>الأرشيف الجنائي اللحظي</Text>
        <View style={styles.logCard}>
           {logs.map((log, idx) => {
              const theme = getActionTheme(log.action);
              return (
                <View key={idx} style={[styles.logItem, idx === logs.length - 1 && { borderBottomWidth: 0 }]}>
                   <View style={[styles.logIconBox, { backgroundColor: theme.bg }]}>
                      <MaterialCommunityIcons name={theme.icon} size={22} color={theme.color} />
                   </View>
                   <View style={styles.logInfo}>
                      <Text style={styles.logAction}>{log.action.replace(/_/g, ' ').toUpperCase()}</Text>
                      <Text style={styles.logTime}>{new Date(log.created_at).toLocaleString('ar-EG')}</Text>
                   </View>
                   <Ionicons name="chevron-back" size={14} color="#E2E8F0" />
                </View>
              );
           })}
        </View>

        <Text style={styles.footerNote}>SOVEREIGN INVESTIGATIVE MATRIX • GOOGLE SECURE ARCHITECTURE</Text>
      </ScrollView>
    </View>
  );
}
