import React, { useEffect, useRef } from 'react';
import { Animated, Text, StyleSheet, TouchableOpacity, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '../utils/colors';

export default function Toast({ message, description, type = 'error', visible, onHide, duration = 4000 }) {
  const translateY = useRef(new Animated.Value(-120)).current;
  const opacity = useRef(new Animated.Value(0)).current;
  const progress = useRef(new Animated.Value(1)).current;
  useEffect(() => {
    if (visible) {
      // دخول
      translateY.setValue(-120);
      opacity.setValue(0);
      progress.setValue(1);

      Animated.parallel([
        Animated.spring(translateY, {
          toValue: 0,
          friction: 8,
          tension: 60,
          useNativeDriver: true,
        }),
        Animated.timing(opacity, {
          toValue: 1,
          duration: 400,
          useNativeDriver: true,
        }),
      ]).start();

      // شريط التقدم
      Animated.timing(progress, {
        toValue: 0,
        duration: duration,
        useNativeDriver: false,
      }).start();

      // خروج تلقائي
      const timer = setTimeout(() => {
        hideToast();
      }, duration);

      return () => clearTimeout(timer);
    }
  }, [visible]);

  const hideToast = () => {
    Animated.parallel([
      Animated.timing(translateY, {
        toValue: -120,
        duration: 350,
        useNativeDriver: true,
      }),
      Animated.timing(opacity, {
        toValue: 0,
        duration: 350,
        useNativeDriver: true,
      }),
    ]).start(() => {
      if (onHide) onHide();
    });
  };

  if (!visible) return null;

  const config = {
    success: {
      bg: '#F0FFF4',
      border: '#C6F6D5',
      icon: 'checkmark-circle',
      color: Colors.green,
      title: 'نجاح',
    },
    error: {
      bg: '#FFF5F5',
      border: '#FED7D7',
      icon: 'close-circle',
      color: Colors.red,
      title: 'خطأ',
    },
    warning: {
      bg: '#FFFAF0',
      border: '#FEEBC8',
      icon: 'alert-circle',
      color: Colors.orange,
      title: 'تحذير',
    },
    info: {
      bg: '#EBF8FF',
      border: '#BEE3F8',
      icon: 'information-circle',
      color: '#3498DB',
      title: 'تنبيه',
    },
  };

  const style = config[type] || config.info;

  return (
    <Animated.View
      style={[
        styles.container,
        {
          transform: [{ translateY }],
          opacity,
          borderColor: style.border,
          backgroundColor: style.bg,
        },
      ]}
    >
      {/* أيقونة */}
      <View style={[styles.iconWrapper, { backgroundColor: style.color + '18' }]}>
        <Ionicons name={style.icon} size={28} color={style.color} />
      </View>

      {/* المحتوى */}
      <View style={styles.content}>
        <Text style={[styles.title, { color: style.color }]}>
          {style.title}
        </Text>
        <Text style={styles.message}>{message}</Text>
        {description && (
          <Text style={styles.description}>{description}</Text>
        )}
      </View>

      {/* زر الإغلاق */}
      <TouchableOpacity style={styles.closeBtn} onPress={hideToast} activeOpacity={0.6}>
        <Ionicons name="close" size={18} color={Colors.gray} />
      </TouchableOpacity>

      {/* شريط التقدم */}
      <Animated.View
        style={[
          styles.progressBar,
          {
            width: progress.interpolate({
              inputRange: [0, 1],
              outputRange: ['0%', '100%'],
            }),
            backgroundColor: style.color,
          },
        ]}
      />
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 50,
    left: 20,
    right: 20,
    padding: 16,
    borderRadius: 16,
    borderWidth: 1.5,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 8,
    zIndex: 9999,
    overflow: 'hidden',
  },

  iconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    flexShrink: 0,
  },

  content: {
    flex: 1,
    gap: 2,
  },

  title: {
    fontSize: 14,
    fontFamily: 'Tajawal-Bold',
    textAlign: 'right',
  },

  message: {
    fontSize: 13,
    fontFamily: 'Tajawal-Regular',
    color: Colors.dark,
    textAlign: 'right',
  },

  description: {
    fontSize: 11,
    fontFamily: 'Tajawal-Regular',
    color: Colors.gray,
    textAlign: 'right',
    marginTop: 2,
  },

  closeBtn: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: 'rgba(0,0,0,0.04)',
    justifyContent: 'center',
    alignItems: 'center',
    flexShrink: 0,
  },

  progressBar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    height: 3,
    borderBottomLeftRadius: 16,
    borderBottomRightRadius: 16,
  },
});