// src/shared/utils/currencyConverter.js
// =============================================
// محول العملات (Currency Converter)
// دوال لتحويل العملات وإدارة أسعار الصرف
// =============================================

import { CURRENCIES, DEFAULT_CURRENCY } from './constants';
import { Logger } from './logger';

// =============================================
// 1. الثوابت
// =============================================

const EXCHANGE_RATE_CACHE_KEY = 'exchange_rates_cache';
const EXCHANGE_RATE_CACHE_TIME_KEY = 'exchange_rates_cache_time';
const CACHE_TTL = 5 * 60 * 1000; // 5 دقائق

// =============================================
// 2. تخزين مؤقت للأسعار
// =============================================

let cachedRates = null;
let cachedTime = null;

/**
 * حفظ أسعار الصرف في الكاش
 * @param {Object} rates - أسعار الصرف
 */
export const cacheExchangeRates = async (rates) => {
  try {
    cachedRates = rates;
    cachedTime = Date.now();
    // يمكن تخزينها في AsyncStorage إذا لزم الأمر
  } catch (error) {
    Logger.error('Failed to cache exchange rates:', error);
  }
};

/**
 * الحصول على أسعار الصرف من الكاش
 * @returns {Object|null}
 */
export const getCachedExchangeRates = () => {
  if (!cachedRates || !cachedTime) return null;
  if (Date.now() - cachedTime > CACHE_TTL) return null;
  return cachedRates;
};

/**
 * مسح الكاش
 */
export const clearExchangeRateCache = () => {
  cachedRates = null;
  cachedTime = null;
};

// =============================================
// 3. دوال التحويل الأساسية
// =============================================

/**
 * تحويل مبلغ من عملة إلى أخرى
 * @param {number} amount - المبلغ
 * @param {string} fromCurrency - العملة المصدر
 * @param {string} toCurrency - العملة الهدف
 * @param {Object} rates - أسعار الصرف (اختياري)
 * @returns {number}
 */
export const convertCurrency = (amount, fromCurrency, toCurrency, rates = null) => {
  if (!amount || amount === 0) return 0;
  if (fromCurrency === toCurrency) return amount;

  const exchangeRates = rates || cachedRates || getDefaultRates();

  const fromRate = exchangeRates[fromCurrency] || 1;
  const toRate = exchangeRates[toCurrency] || 1;

  if (fromRate === 0 || toRate === 0) return amount;

  // التحويل: المبلغ × (سعر الهدف / سعر المصدر)
  const result = amount * (toRate / fromRate);
  return Math.round(result * 100) / 100;
};

/**
 * تحويل مبلغ من عملة إلى العملة الأساسية
 * @param {number} amount - المبلغ
 * @param {string} fromCurrency - العملة المصدر
 * @param {string} baseCurrency - العملة الأساسية
 * @param {Object} rates - أسعار الصرف
 * @returns {number}
 */
export const convertToBase = (amount, fromCurrency, baseCurrency = DEFAULT_CURRENCY, rates = null) => {
  return convertCurrency(amount, fromCurrency, baseCurrency, rates);
};

/**
 * تحويل مبلغ من العملة الأساسية إلى عملة أخرى
 * @param {number} amount - المبلغ
 * @param {string} toCurrency - العملة الهدف
 * @param {string} baseCurrency - العملة الأساسية
 * @param {Object} rates - أسعار الصرف
 * @returns {number}
 */
export const convertFromBase = (amount, toCurrency, baseCurrency = DEFAULT_CURRENCY, rates = null) => {
  return convertCurrency(amount, baseCurrency, toCurrency, rates);
};

// =============================================
// 4. دوال تنسيق التحويل
// =============================================

/**
 * تحويل وتنسيق المبلغ
 * @param {number} amount - المبلغ
 * @param {string} fromCurrency - العملة المصدر
 * @param {string} toCurrency - العملة الهدف
 * @param {Object} options - خيارات التنسيق
 * @param {Object} rates - أسعار الصرف
 * @returns {string}
 */
export const convertAndFormat = (amount, fromCurrency, toCurrency, options = {}, rates = null) => {
  const converted = convertCurrency(amount, fromCurrency, toCurrency, rates);
  return formatConvertedAmount(converted, toCurrency, options);
};

/**
 * تنسيق المبلغ المحول
 * @param {number} amount - المبلغ
 * @param {string} currency - العملة
 * @param {Object} options - خيارات التنسيق
 * @returns {string}
 */
export const formatConvertedAmount = (amount, currency, options = {}) => {
  const {
    decimals = 2,
    showSymbol = true,
    useGrouping = true,
  } = options;

  const currencyInfo = CURRENCIES[currency];
  if (!currencyInfo) {
    return `${amount.toFixed(decimals)} ${currency}`;
  }

  const symbol = showSymbol ? currencyInfo.symbol : '';
  const formatted = Number(amount).toFixed(decimals);
  const grouped = useGrouping ? Number(formatted).toLocaleString() : formatted;

  return `${grouped} ${symbol}`.trim();
};

// =============================================
// 5. دوال أسعار الصرف
// =============================================

/**
 * الحصول على أسعار الصرف الافتراضية
 * @returns {Object}
 */
export const getDefaultRates = () => {
  const rates = {};
  for (const [code, info] of Object.entries(CURRENCIES)) {
    rates[code] = 1;
  }
  return rates;
};

/**
 * الحصول على أسعار الصرف مع العملة الأساسية
 * @param {string} baseCurrency - العملة الأساسية
 * @param {Object} rates - أسعار الصرف
 * @returns {Object}
 */
export const getRatesWithBase = (baseCurrency = DEFAULT_CURRENCY, rates = null) => {
  const exchangeRates = rates || cachedRates || getDefaultRates();
  const baseRate = exchangeRates[baseCurrency] || 1;

  const result = {};
  for (const [code, rate] of Object.entries(exchangeRates)) {
    result[code] = rate / baseRate;
  }
  return result;
};

/**
 * تحديث سعر صرف عملة
 * @param {Object} rates - أسعار الصرف الحالية
 * @param {string} currency - العملة
 * @param {number} newRate - السعر الجديد
 * @returns {Object}
 */
export const updateRate = (rates, currency, newRate) => {
  return {
    ...rates,
    [currency]: newRate,
  };
};

/**
 * تحديث عدة أسعار صرف
 * @param {Object} rates - أسعار الصرف الحالية
 * @param {Object} newRates - الأسعار الجديدة
 * @returns {Object}
 */
export const updateRates = (rates, newRates) => {
  return {
    ...rates,
    ...newRates,
  };
};

// =============================================
// 6. دوال المساعدة
// =============================================

/**
 * الحصول على رمز العملة
 * @param {string} currency - كود العملة
 * @returns {string}
 */
export const getCurrencySymbol = (currency) => {
  const info = CURRENCIES[currency];
  return info?.symbol || currency;
};

/**
 * الحصول على اسم العملة
 * @param {string} currency - كود العملة
 * @returns {string}
 */
export const getCurrencyName = (currency) => {
  const info = CURRENCIES[currency];
  return info?.name || currency;
};

/**
 * التحقق من دعم العملة
 * @param {string} currency - كود العملة
 * @returns {boolean}
 */
export const isCurrencySupported = (currency) => {
  return !!CURRENCIES[currency];
};

/**
 * الحصول على قائمة العملات المدعومة
 * @returns {Array}
 */
export const getSupportedCurrencies = () => {
  return Object.keys(CURRENCIES);
};

/**
 * الحصول على معلومات العملة
 * @param {string} currency - كود العملة
 * @returns {Object|null}
 */
export const getCurrencyInfo = (currency) => {
  return CURRENCIES[currency] || null;
};

// =============================================
// 7. كائن المحول الرئيسي
// =============================================

export const currencyConverter = {
  // التحويل
  convert: convertCurrency,
  convertToBase,
  convertFromBase,
  convertAndFormat,

  // التنسيق
  format: formatConvertedAmount,

  // أسعار الصرف
  getDefaultRates,
  getRatesWithBase,
  updateRate,
  updateRates,

  // الكاش
  cache: cacheExchangeRates,
  getCached: getCachedExchangeRates,
  clearCache: clearExchangeRateCache,

  // المساعدة
  getSymbol: getCurrencySymbol,
  getName: getCurrencyName,
  isSupported: isCurrencySupported,
  getSupported: getSupportedCurrencies,
  getInfo: getCurrencyInfo,
};

export default currencyConverter;