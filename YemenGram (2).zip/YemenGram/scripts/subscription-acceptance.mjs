import assert from 'node:assert/strict';
import { STATES, EVENTS, transition } from '../src/modules/subscriptions/services/SubscriptionEngine.js';

const check = (state, event, ctx, expected) => {
  const result = transition(state, event, ctx);
  assert.equal(result.nextState, expected, `${state} + ${event}`);
  assert.equal(result.valid, true, `${state} + ${event} must be valid`);
  return result;
};

check(STATES.UNSUBSCRIBED, EVENTS.START_FREE_TRIAL, { userId: 'u1' }, STATES.TRIAL_ACTIVE);
check(STATES.TRIAL_ACTIVE, EVENTS.EXPIRE, {}, STATES.TRIAL_EXPIRED);
check(STATES.ACTIVE_FULL, EVENTS.EXPIRE, {}, STATES.EXPIRED_GRACE);
check(STATES.ACTIVE_FULL, EVENTS.REFUND_REQUESTED, { userId: 'u1' }, STATES.REFUND_PENDING);
check(STATES.REFUND_PENDING, EVENTS.REFUND_APPROVED, { actorId: 'a1', actorRole: 'admin' }, STATES.CANCELLED);
check(STATES.ACTIVE_FULL, EVENTS.EXTEND_REQUEST, { userId: 'u1' }, STATES.EXTENSION_PENDING);
check(STATES.EXTENSION_PENDING, EVENTS.EXTEND_APPROVED, { actorId: 'a1', actorRole: 'owner' }, STATES.ACTIVE_FULL);
check(STATES.RESOURCES_EXCEEDED, EVENTS.RESOURCE_RECOVERY, {}, STATES.ACTIVE_FULL);

const invalid = transition(STATES.UNSUBSCRIBED, EVENTS.CANCEL, {});
assert.equal(invalid.valid, false);
assert.equal(invalid.errorCode, 'INVALID_TRANSITION');
assert.equal(invalid.nextState, STATES.UNSUBSCRIBED);

const forgedAdmin = transition(STATES.VERIFICATION_PENDING, EVENTS.VERIFICATION_APPROVED, { admin: true });
assert.equal(forgedAdmin.valid, false);
assert.equal(forgedAdmin.errorCode, 'ADMIN_AUTH_REQUIRED');

const unknown = transition(STATES.ACTIVE_FULL, 'REFUND_REQUESTED_OLD', {});
assert.equal(unknown.errorCode, 'UNKNOWN_EVENT');

console.log('subscription acceptance: PASS (FSM, invalid transitions, admin authorization, refund, extension, recovery)');
