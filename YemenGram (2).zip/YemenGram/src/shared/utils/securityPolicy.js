// src/shared/utils/securityPolicy.js
// ميثاق السيادة الأمنية (Sovereign Security Policy - MASVS L2 Inspired) - v1.1 Cleaned

export const SECURITY_POLICY = {
  // الحد الأقصى لبقاء الجلسة صالحة بدون إدخال كلمة المرور (بالأيام)
  MAX_SESSION_DAYS: 7,

  // الحد الأقصى للمحاولات الخاطئة قبل القفل الصارم (بالدقائق)
  LOCKOUT_DURATION: 15,

  // التوقيت الزمني الصارم (بالميللي ثانية)
  TIME_DRIFT_THRESHOLD: 60000, // دقيقة واحدة

  // إعدادات التشفير
  ENCRYPTION_ALGORITHM: 'SHA-256',
};
