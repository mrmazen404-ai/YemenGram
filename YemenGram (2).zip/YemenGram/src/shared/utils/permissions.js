// src/shared/utils/permissions.js
// =============================================
// إدارة الصلاحيات والأذونات (Permissions Management)
// دوال للتحقق من صلاحيات المستخدم والوصول إلى الميزات
// =============================================

import { Platform } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';
import * as Notifications from 'expo-notifications';
import * as FileSystem from 'expo-file-system';
import { Logger } from './logger';

// =============================================
// 1. الثوابت
// =============================================

export const PERMISSION_TYPES = {
  CAMERA: 'camera',
  GALLERY: 'gallery',
  LOCATION: 'location',
  NOTIFICATIONS: 'notifications',
  STORAGE: 'storage',
  MICROPHONE: 'microphone',
  CONTACTS: 'contacts',
};

export const PERMISSION_STATUS = {
  GRANTED: 'granted',
  DENIED: 'denied',
  UNDETERMINED: 'undetermined',
  BLOCKED: 'blocked',
};

// =============================================
// 2. دوال التحقق من الصلاحيات
// =============================================

/**
 * التحقق من صلاحية الكاميرا
 * @returns {Promise<string>}
 */
export const checkCameraPermission = async () => {
  try {
    if (Platform.OS === 'android') {
      const { status } = await ImagePicker.getCameraPermissionsAsync();
      return status === 'granted' ? PERMISSION_STATUS.GRANTED : PERMISSION_STATUS.DENIED;
    } else {
      const { status } = await ImagePicker.getCameraPermissionsAsync();
      return status === 'granted' ? PERMISSION_STATUS.GRANTED :
             status === 'denied' ? PERMISSION_STATUS.BLOCKED :
             PERMISSION_STATUS.DENIED;
    }
  } catch (error) {
    Logger.error('checkCameraPermission failed:', error);
    return PERMISSION_STATUS.DENIED;
  }
};

/**
 * التحقق من صلاحية المعرض
 * @returns {Promise<string>}
 */
export const checkGalleryPermission = async () => {
  try {
    if (Platform.OS === 'android') {
      const { status } = await ImagePicker.getMediaLibraryPermissionsAsync();
      return status === 'granted' ? PERMISSION_STATUS.GRANTED : PERMISSION_STATUS.DENIED;
    } else {
      const { status } = await ImagePicker.getMediaLibraryPermissionsAsync();
      return status === 'granted' ? PERMISSION_STATUS.GRANTED :
             status === 'denied' ? PERMISSION_STATUS.BLOCKED :
             PERMISSION_STATUS.DENIED;
    }
  } catch (error) {
    Logger.error('checkGalleryPermission failed:', error);
    return PERMISSION_STATUS.DENIED;
  }
};

/**
 * التحقق من صلاحية الموقع
 * @returns {Promise<string>}
 */
export const checkLocationPermission = async () => {
  try {
    const { status } = await Location.getForegroundPermissionsAsync();
    return status === 'granted' ? PERMISSION_STATUS.GRANTED :
           status === 'denied' ? PERMISSION_STATUS.BLOCKED :
           PERMISSION_STATUS.DENIED;
  } catch (error) {
    Logger.error('checkLocationPermission failed:', error);
    return PERMISSION_STATUS.DENIED;
  }
};

/**
 * التحقق من صلاحية الإشعارات
 * @returns {Promise<string>}
 */
export const checkNotificationsPermission = async () => {
  try {
    const { status } = await Notifications.getPermissionsAsync();
    return status === 'granted' ? PERMISSION_STATUS.GRANTED :
           status === 'denied' ? PERMISSION_STATUS.BLOCKED :
           PERMISSION_STATUS.DENIED;
  } catch (error) {
    Logger.error('checkNotificationsPermission failed:', error);
    return PERMISSION_STATUS.DENIED;
  }
};

/**
 * التحقق من صلاحية التخزين
 * @returns {Promise<string>}
 */
export const checkStoragePermission = async () => {
  try {
    if (Platform.OS === 'android') {
      // استخدام FileSystem للتحقق من صلاحية التخزين
      const directory = FileSystem.documentDirectory;
      if (!directory) return PERMISSION_STATUS.DENIED;

      // محاولة كتابة ملف للتحقق من الصلاحية
      try {
        const testPath = `${directory}test.txt`;
        await FileSystem.writeAsStringAsync(testPath, 'test');
        await FileSystem.deleteAsync(testPath);
        return PERMISSION_STATUS.GRANTED;
      } catch {
        return PERMISSION_STATUS.DENIED;
      }
    } else {
      // iOS: التخزين يُطلب عبر المعرض
      const { status } = await ImagePicker.getMediaLibraryPermissionsAsync();
      return status === 'granted' ? PERMISSION_STATUS.GRANTED :
             status === 'denied' ? PERMISSION_STATUS.BLOCKED :
             PERMISSION_STATUS.DENIED;
    }
  } catch (error) {
    Logger.error('checkStoragePermission failed:', error);
    return PERMISSION_STATUS.DENIED;
  }
};

// =============================================
// 3. دوال طلب الصلاحيات
// =============================================

/**
 * طلب صلاحية الكاميرا
 * @param {Object} options - خيارات الطلب
 * @returns {Promise<string>}
 */
export const requestCameraPermission = async (options = {}) => {
  const { title, message } = options;
  try {
    if (Platform.OS === 'android') {
      const { status } = await ImagePicker.requestCameraPermissionsAsync();
      return status === 'granted' ? PERMISSION_STATUS.GRANTED : PERMISSION_STATUS.DENIED;
    } else {
      const { status } = await ImagePicker.requestCameraPermissionsAsync();
      return status === 'granted' ? PERMISSION_STATUS.GRANTED :
             status === 'denied' ? PERMISSION_STATUS.BLOCKED :
             PERMISSION_STATUS.DENIED;
    }
  } catch (error) {
    Logger.error('requestCameraPermission failed:', error);
    return PERMISSION_STATUS.DENIED;
  }
};

/**
 * طلب صلاحية المعرض
 * @param {Object} options - خيارات الطلب
 * @returns {Promise<string>}
 */
export const requestGalleryPermission = async (options = {}) => {
  const { title, message } = options;
  try {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    return status === 'granted' ? PERMISSION_STATUS.GRANTED :
           status === 'denied' ? PERMISSION_STATUS.BLOCKED :
           PERMISSION_STATUS.DENIED;
  } catch (error) {
    Logger.error('requestGalleryPermission failed:', error);
    return PERMISSION_STATUS.DENIED;
  }
};

/**
 * طلب صلاحية الموقع
 * @param {Object} options - خيارات الطلب
 * @returns {Promise<string>}
 */
export const requestLocationPermission = async (options = {}) => {
  const { title, message } = options;
  try {
    const { status } = await Location.requestForegroundPermissionsAsync();
    return status === 'granted' ? PERMISSION_STATUS.GRANTED :
           status === 'denied' ? PERMISSION_STATUS.BLOCKED :
           PERMISSION_STATUS.DENIED;
  } catch (error) {
    Logger.error('requestLocationPermission failed:', error);
    return PERMISSION_STATUS.DENIED;
  }
};

/**
 * طلب صلاحية الإشعارات
 * @param {Object} options - خيارات الطلب
 * @returns {Promise<string>}
 */
export const requestNotificationsPermission = async (options = {}) => {
  const { title, message } = options;
  try {
    const { status } = await Notifications.requestPermissionsAsync();
    return status === 'granted' ? PERMISSION_STATUS.GRANTED :
           status === 'denied' ? PERMISSION_STATUS.BLOCKED :
           PERMISSION_STATUS.DENIED;
  } catch (error) {
    Logger.error('requestNotificationsPermission failed:', error);
    return PERMISSION_STATUS.DENIED;
  }
};

// =============================================
// 4. دوال التحقق المتقدمة
// =============================================

/**
 * التحقق من جميع الصلاحيات
 * @param {Array} permissions - قائمة الصلاحيات
 * @returns {Promise<Object>}
 */
export const checkAllPermissions = async (permissions = null) => {
  const types = permissions || Object.values(PERMISSION_TYPES);
  const results = {};

  for (const type of types) {
    let result;
    switch (type) {
      case PERMISSION_TYPES.CAMERA:
        result = await checkCameraPermission();
        break;
      case PERMISSION_TYPES.GALLERY:
        result = await checkGalleryPermission();
        break;
      case PERMISSION_TYPES.LOCATION:
        result = await checkLocationPermission();
        break;
      case PERMISSION_TYPES.NOTIFICATIONS:
        result = await checkNotificationsPermission();
        break;
      case PERMISSION_TYPES.STORAGE:
        result = await checkStoragePermission();
        break;
      default:
        result = PERMISSION_STATUS.DENIED;
    }
    results[type] = result;
  }

  return results;
};

/**
 * التحقق من منح جميع الصلاحيات
 * @param {Array} permissions - قائمة الصلاحيات
 * @returns {Promise<boolean>}
 */
export const areAllPermissionsGranted = async (permissions = null) => {
  const results = await checkAllPermissions(permissions);
  return Object.values(results).every(status => status === PERMISSION_STATUS.GRANTED);
};

/**
 * الحصول على الصلاحيات المفقودة
 * @param {Array} permissions - قائمة الصلاحيات
 * @returns {Promise<Array>}
 */
export const getMissingPermissions = async (permissions = null) => {
  const results = await checkAllPermissions(permissions);
  const missing = [];
  for (const [type, status] of Object.entries(results)) {
    if (status !== PERMISSION_STATUS.GRANTED) {
      missing.push(type);
    }
  }
  return missing;
};

// =============================================
// 5. دوال المساعدة
// =============================================

/**
 * الحصول على نص حالة الصلاحية
 * @param {string} status - حالة الصلاحية
 * @returns {string}
 */
export const getPermissionStatusText = (status) => {
  const texts = {
    granted: 'ممنوحة',
    denied: 'مرفوضة',
    undetermined: 'غير محددة',
    blocked: 'محظورة',
  };
  return texts[status] || status;
};

/**
 * الحصول على لون حالة الصلاحية
 * @param {string} status - حالة الصلاحية
 * @returns {string}
 */
export const getPermissionStatusColor = (status) => {
  const colors = {
    granted: '#27AE60',
    denied: '#F39C12',
    undetermined: '#6B7280',
    blocked: '#E74C3C',
  };
  return colors[status] || '#6B7280';
};

/**
 * الحصول على أيقونة حالة الصلاحية
 * @param {string} status - حالة الصلاحية
 * @returns {string}
 */
export const getPermissionStatusIcon = (status) => {
  const icons = {
    granted: 'checkmark-circle',
    denied: 'close-circle',
    undetermined: 'help-circle',
    blocked: 'alert-circle',
  };
  return icons[status] || 'help-circle';
};

/**
 * التحقق من صلاحية معينة
 * @param {string} type - نوع الصلاحية
 * @returns {Promise<string>}
 */
export const checkPermission = (type) => {
  switch (type) {
    case PERMISSION_TYPES.CAMERA:
      return checkCameraPermission();
    case PERMISSION_TYPES.GALLERY:
      return checkGalleryPermission();
    case PERMISSION_TYPES.LOCATION:
      return checkLocationPermission();
    case PERMISSION_TYPES.NOTIFICATIONS:
      return checkNotificationsPermission();
    case PERMISSION_TYPES.STORAGE:
      return checkStoragePermission();
    default:
      return Promise.resolve(PERMISSION_STATUS.DENIED);
  }
};

/**
 * طلب صلاحية معينة
 * @param {string} type - نوع الصلاحية
 * @param {Object} options - خيارات الطلب
 * @returns {Promise<string>}
 */
export const requestPermission = (type, options = {}) => {
  switch (type) {
    case PERMISSION_TYPES.CAMERA:
      return requestCameraPermission(options);
    case PERMISSION_TYPES.GALLERY:
      return requestGalleryPermission(options);
    case PERMISSION_TYPES.LOCATION:
      return requestLocationPermission(options);
    case PERMISSION_TYPES.NOTIFICATIONS:
      return requestNotificationsPermission(options);
    default:
      return Promise.resolve(PERMISSION_STATUS.DENIED);
  }
};

// =============================================
// 6. كائن الصلاحيات الرئيسي
// =============================================

export const permissions = {
  // الثوابت
  TYPES: PERMISSION_TYPES,
  STATUS: PERMISSION_STATUS,

  // التحقق
  check: checkPermission,
  checkAll: checkAllPermissions,
  checkCamera: checkCameraPermission,
  checkGallery: checkGalleryPermission,
  checkLocation: checkLocationPermission,
  checkNotifications: checkNotificationsPermission,
  checkStorage: checkStoragePermission,

  // الطلب
  request: requestPermission,
  requestCamera: requestCameraPermission,
  requestGallery: requestGalleryPermission,
  requestLocation: requestLocationPermission,
  requestNotifications: requestNotificationsPermission,

  // متقدم
  areAllGranted: areAllPermissionsGranted,
  getMissing: getMissingPermissions,

  // مساعدة
  getStatusText: getPermissionStatusText,
  getStatusColor: getPermissionStatusColor,
  getStatusIcon: getPermissionStatusIcon,
};

export default permissions;