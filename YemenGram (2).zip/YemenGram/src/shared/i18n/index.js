// src/shared/i18n/index.js
// =============================================
// نقطة التصدير المركزية للترجمة
// =============================================

import ar from './ar';
import en from './en';

// =============================================
// 1. اللغات المتاحة
// =============================================

export const languages = {
  ar: { label: 'العربية', nativeLabel: 'العربية', dir: 'rtl', translation: ar },
  en: { label: 'English', nativeLabel: 'English', dir: 'ltr', translation: en },
};

export const defaultLanguage = 'ar';

export const supportedLanguages = ['ar', 'en'];

// =============================================
// 2. دوال الترجمة
// =============================================

/**
 * الحصول على الترجمة حسب اللغة
 * @param {string} language - كود اللغة (ar, en)
 * @returns {Object}
 */
export const getTranslation = (language = defaultLanguage) => {
  const lang = languages[language];
  if (!lang) return languages[defaultLanguage].translation;
  return lang.translation;
};

/**
 * دالة الترجمة
 * @param {string} key - مفتاح الترجمة
 * @param {string} language - اللغة
 * @param {Object} params - معاملات للاستبدال
 * @returns {string}
 */
export const t = (key, language = defaultLanguage, params = {}) => {
  const translation = getTranslation(language);
  const keys = key.split('.');
  let result = translation;

  for (const k of keys) {
    if (result && result[k] !== undefined) {
      result = result[k];
    } else {
      return key;
    }
  }

  if (typeof result === 'string') {
    // استبدال المعاملات
    for (const [paramKey, paramValue] of Object.entries(params)) {
      result = result.replace(`{{${paramKey}}}`, paramValue);
    }
    return result;
  }

  return key;
};

/**
 * الحصول على اتجاه اللغة
 * @param {string} language - كود اللغة
 * @returns {string} 'rtl' أو 'ltr'
 */
export const getLanguageDirection = (language = defaultLanguage) => {
  const lang = languages[language];
  if (!lang) return 'rtl';
  return lang.dir;
};

/**
 * الحصول على اسم اللغة
 * @param {string} language - كود اللغة
 * @returns {string}
 */
export const getLanguageLabel = (language = defaultLanguage) => {
  const lang = languages[language];
  if (!lang) return 'العربية';
  return lang.label;
};

// =============================================
// 3. كائن الترجمة الرئيسي
// =============================================

export default {
  languages,
  defaultLanguage,
  supportedLanguages,
  getTranslation,
  t,
  getLanguageDirection,
  getLanguageLabel,
};