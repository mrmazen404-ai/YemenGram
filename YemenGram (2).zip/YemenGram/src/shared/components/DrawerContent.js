// src/shared/components/DrawerContent.js
// القائمة الجانبية السيادية (The Sovereign Hyper-Premium Drawer)
// نسخة محمية ببروتوكول SafeGradient - تدعم مزامنة الأفاتار المطور

import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Image,
  Dimensions,
  Platform,
} from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { Colors } from '../utils/colors';
import { useAuth } from '../../shared/contexts/AuthContext';
import { useSubscriptionState } from '../../modules/subscriptions/hooks/useSubscriptionState';
import { LocalDB } from '../../modules/database/localDB';
import SafeGradient from './SafeGradient';

const { height } = Dimensions.get('window');



export default function DrawerContent(props) {
  const { navigation } = props;
  const { user, logout } = useAuth();
  const { subscription, canStartTrial, isTrial, isTrialExpired } = useSubscriptionState();

  const handlePremiumPress = async () => {
    triggerHaptic();

    // منطق التوجيه السيادي
    if (canStartTrial) {
      const hasSeen = await LocalDB.getSetting('has_seen_trial_intro');
      if (hasSeen === 'true') {
        navigation.navigate('PlansCatalog');
      } else {
        navigation.navigate('SubscriptionFreeTrialIntro');
      }
      return;
    }

    if (isTrial) {
      navigation.navigate('SubscriptionResources');
    } else if (isTrialExpired) {
      navigation.navigate('SubscriptionTrialExpired');
    } else {
      navigation.navigate('SubscriptionOverview');
    }
  };

  const menuSections = [
    {
      title: 'لوحة التحكم',
      items: [
        { label: 'الرئيسية', icon: 'grid-outline', screen: 'DashboardMain', color: Colors.gold },
        { label: 'الملف الشخصي', icon: 'person-circle-outline', screen: 'Profile', color: '#64B5F6' },
      ],
    },
    {
      title: 'الأقسام الإدارية',
      items: [
        { label: 'دليل الحسابات', icon: 'list-outline', screen: 'Accounts', color: '#81C784' },
        { label: 'المخزون والجرد', icon: 'cube-outline', screen: 'Inventory', color: '#FFB74D' },
        { label: 'إدارة الموردين', icon: 'business-outline', screen: 'Suppliers', color: '#BA68C8' },
        { label: 'الموارد البشرية', icon: 'people-outline', screen: 'Employees', color: '#F06292' },
      ],
    },
    {
      title: 'الرقابة والتقارير',
      items: [
        { label: 'مركز التقارير', icon: 'bar-chart-outline', screen: 'AdvancedReports', color: Colors.gold },
        { label: 'سجل التدقيق', icon: 'finger-print-outline', screen: 'AuditLog', color: '#90A4AE' },
      ],
    },
    {
      title: 'الإعدادات والأمان',
      items: [
        { label: 'مركز السيادة المالية', icon: 'shield-checkmark-outline', screen: 'SovereignSubscriptionHub', color: Colors.gold },
        { label: 'إعدادات النظام', icon: 'settings-outline', screen: 'Settings', color: '#9E9E9E' },
        { label: 'حول اليمن جرام', icon: 'information-circle-outline', screen: 'About', color: Colors.navy },
      ],
    },
  ];

  const triggerHaptic = () => {
    if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleLogout = async () => {
    triggerHaptic();
    try {
      // ✅ بمجرد تنفيذ logout، سيقوم AppNavigator بتحويل المستخدم تلقائياً لشاشة Login
      // بناءً على تغيير حالة isLoggedIn في AuthContext
      await logout();
    } catch (e) {
      console.log('Logout failed:', e.message);
    }
  };

  return (
    <View style={styles.root}>
      <SafeGradient colors={[Colors.navy, '#0D2137']} style={styles.header}>
        <View style={styles.headerOverlay} />

        <View style={styles.headerContent}>
          <View style={styles.userCore}>
            <View style={styles.avatarGlow}>
              <View style={[styles.avatarContainer, !user?.avatar && { backgroundColor: Colors.navy }]}>
                {user?.avatar && user.avatar !== 'default_pc' ? (
                  <Image source={{ uri: user.avatar }} style={{ width: '100%', height: '100%', borderRadius: 18 }} />
                ) : (
                  <Text style={styles.avatarText}>{user?.name?.charAt(0).toUpperCase() || 'ي'}</Text>
                )}
              </View>
              <View style={styles.activeDot} />
            </View>
            <View style={styles.userInfo}>
              <Text style={styles.userName}>{user?.name || 'المدير التنفيذي'}</Text>
              <View style={styles.roleBadge}>
                <Text style={styles.roleText}>إدارة عليا</Text>
              </View>
            </View>
          </View>

          <View style={styles.companySeal}>
             <Ionicons name="business" size={14} color={Colors.gold} />
             <Text style={styles.companyName}>{user?.company_name || 'YemenGram Enterprise'}</Text>
          </View>
        </View>
      </SafeGradient>

      <ScrollView style={styles.menuScroll} showsVerticalScrollIndicator={false} bounces={false}>
        {menuSections.map((section, secIndex) => (
          <View key={secIndex} style={styles.section}>
            <Text style={styles.sectionTitle}>{section.title}</Text>
            {section.items.map((item, itemIndex) => (
              <TouchableOpacity
                key={itemIndex}
                style={styles.menuItem}
                onPress={() => { triggerHaptic(); navigation.navigate(item.screen); }}
                activeOpacity={0.6}
              >
                <View style={[styles.iconBox, { shadowColor: item.color }]}>
                  <Ionicons name={item.icon} size={18} color={item.color} />
                </View>
                <Text style={styles.menuText}>{item.label}</Text>
                <Ionicons name="chevron-back" size={12} color="#E2E8F0" />
              </TouchableOpacity>
            ))}
          </View>
        ))}
      </ScrollView>

      <View style={styles.footer}>
        <View style={styles.footerTop}>
           <View style={styles.syncBadge}>
              <MaterialCommunityIcons name="database-check" size={14} color={Colors.green} />
              <Text style={styles.syncText}>البيانات مؤمنة محلياً</Text>
           </View>
           <Text style={styles.versionText}>v1.5.0 Premium</Text>
        </View>

        <TouchableOpacity
          style={styles.premiumBtn}
          onPress={() => {
            triggerHaptic();
            navigation.navigate('SovereignSubscriptionHub');
          }}
        >
          <SafeGradient
            colors={[Colors.gold, '#B8860B']}
            style={styles.premiumGradient}
            start={{x:0, y:0}} end={{x:1, y:0}}
          >
            <View style={styles.premiumContent}>
              <View style={styles.premiumIconBox}>
                <MaterialCommunityIcons name="crown" size={20} color={Colors.white} />
              </View>
              <Text style={styles.premiumText}>الاشتراك في المميز</Text>
            </View>
            <Ionicons name="chevron-back" size={16} color="rgba(255,255,255,0.7)" />
          </SafeGradient>
        </TouchableOpacity>

        <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout}>
          <SafeGradient
            colors={['#FFF5F5', '#FFF0F0']}
            style={styles.logoutGradient}
            start={{x:0, y:0}} end={{x:1, y:0}}
          >
            <Ionicons name="log-out-outline" size={20} color={Colors.red} />
            <Text style={styles.logoutText}>تسجيل خروج آمن</Text>
          </SafeGradient>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#FFFFFF' },
  header: { height: height * 0.22, justifyContent: 'flex-end', paddingBottom: 20 },
  headerOverlay: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.1)' },
  headerContent: { paddingHorizontal: 20 },
  userCore: { flexDirection: 'row-reverse', alignItems: 'center', gap: 15 },
  avatarGlow: { width: 65, height: 65, borderRadius: 22, backgroundColor: 'rgba(255,255,255,0.1)', justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: 'rgba(255,255,255,0.2)' },
  avatarContainer: { width: 55, height: 55, borderRadius: 18, backgroundColor: Colors.gold, justifyContent: 'center', alignItems: 'center' },
  avatarText: { fontSize: 24, fontFamily: 'Tajawal-Bold', color: '#FFF' },
  activeDot: { position: 'absolute', bottom: -2, right: -2, width: 14, height: 14, borderRadius: 7, backgroundColor: Colors.green, borderWidth: 3, borderColor: Colors.navy },
  userInfo: { flex: 1, alignItems: 'flex-end' },
  userName: { fontSize: 18, fontFamily: 'Tajawal-Bold', color: '#FFF' },
  roleBadge: { backgroundColor: 'rgba(255,255,255,0.15)', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 6, marginTop: 4 },
  roleText: { fontSize: 10, fontFamily: 'Tajawal-Bold', color: Colors.gold },
  companySeal: { flexDirection: 'row-reverse', alignItems: 'center', gap: 6, marginTop: 15, backgroundColor: 'rgba(0,0,0,0.2)', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 12, alignSelf: 'flex-start' },
  companyName: { fontSize: 12, fontFamily: 'Tajawal-Medium', color: 'rgba(255,255,255,0.7)' },
  menuScroll: { flex: 1, backgroundColor: '#F8FAFC' },
  privacyToggleCard: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', margin: 15, padding: 15, backgroundColor: '#FFF', borderRadius: 18, elevation: 3, shadowColor: '#000', shadowOpacity: 0.05 },
  privacyInfo: { flexDirection: 'row-reverse', alignItems: 'center', gap: 10 },
  privacyLabel: { fontSize: 13, fontFamily: 'Tajawal-Bold', color: Colors.navy },
  toggleBtn: { width: 44, height: 24, borderRadius: 12, backgroundColor: '#E2E8F0', padding: 2 },
  toggleBtnActive: { backgroundColor: Colors.navy },
  toggleCircle: { width: 20, height: 20, borderRadius: 10, backgroundColor: '#FFF' },
  toggleCircleActive: { alignSelf: 'flex-end' },
  section: { marginBottom: 20, paddingHorizontal: 15 },
  sectionTitle: { fontSize: 11, fontFamily: 'Tajawal-Bold', color: Colors.placeholder, textAlign: 'right', marginBottom: 10, marginRight: 10 },
  menuItem: { flexDirection: 'row-reverse', alignItems: 'center', paddingVertical: 10, paddingHorizontal: 12, backgroundColor: '#FFF', borderRadius: 14, marginBottom: 6, borderWidth: 1, borderColor: '#F1F5F9' },
  iconBox: { width: 34, height: 34, borderRadius: 10, backgroundColor: '#F8FAFC', justifyContent: 'center', alignItems: 'center', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4 },
  menuText: { flex: 1, marginRight: 12, fontSize: 14, fontFamily: 'Tajawal-Medium', color: Colors.dark, textAlign: 'right' },
  footer: { padding: 20, borderTopWidth: 1, borderTopColor: '#F1F5F9', backgroundColor: '#FFF' },
  footerTop: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15 },
  syncBadge: { flexDirection: 'row-reverse', alignItems: 'center', gap: 5 },
  syncText: { fontSize: 10, fontFamily: 'Tajawal-Medium', color: Colors.gray },
  versionText: { fontSize: 10, fontFamily: 'Tajawal-Bold', color: Colors.placeholder },
  logoutBtn: { borderRadius: 16, overflow: 'hidden' },
  logoutGradient: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', gap: 10, paddingVertical: 12 },
  logoutText: { fontSize: 14, fontFamily: 'Tajawal-Bold', color: Colors.red },

  // Premium Styles
  premiumBtn: { borderRadius: 16, overflow: 'hidden', marginBottom: 12, elevation: 3, shadowColor: Colors.gold, shadowOpacity: 0.2, shadowRadius: 5 },
  premiumGradient: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 15, paddingVertical: 12 },
  premiumContent: { flexDirection: 'row-reverse', alignItems: 'center', gap: 12 },
  premiumIconBox: { width: 32, height: 32, borderRadius: 10, backgroundColor: 'rgba(255,255,255,0.2)', justifyContent: 'center', alignItems: 'center' },
  premiumText: { fontSize: 15, fontFamily: 'Tajawal-Bold', color: Colors.white },
});
