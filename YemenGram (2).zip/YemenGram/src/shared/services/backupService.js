// src/shared/services/backupService.js
// =============================================
// خدمة النسخ الاحتياطي (Backup Service)
// المسؤولة عن إنشاء واستعادة النسخ الاحتياطية
// =============================================

import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import * as DocumentPicker from 'expo-document-picker';
import { Platform } from 'react-native';
import { LocalDB } from './storageService';
import { Logger } from '../utils/logger';
import { CryptoService } from './cryptoService';

// =============================================
// 1. الثوابت
// =============================================

const BACKUP_DIR = `${FileSystem.documentDirectory}backups/`;
const BACKUP_EXTENSION = '.ygbk'; // YemenGram Backup
// مفتاح النسخ الاحتياطي يُنشأ عشوائياً ويُحفظ داخل Keychain/Keystore عبر CryptoService.
// لا يوجد fallback ثابت؛ النسخة المحلية مرتبطة بالجهاز ما لم تُضف آلية تصدير مفتاح منفصلة.

const STATUS = {
  PENDING: 'pending',
  SUCCESS: 'success',
  FAILED: 'failed',
};

const TYPES = {
  LOCAL: 'local',
  GOOGLE_DRIVE: 'google_drive',
  CLOUD: 'cloud',
};

// =============================================
// 2. دوال المساعدة
// =============================================

/**
 * التأكد من وجود مجلد النسخ الاحتياطي
 * @returns {Promise<void>}
 */
const ensureBackupDir = async () => {
  const dirInfo = await FileSystem.getInfoAsync(BACKUP_DIR);
  if (!dirInfo.exists) {
    await FileSystem.makeDirectoryAsync(BACKUP_DIR, { intermediates: true });
    Logger.debug('📁 [Backup] تم إنشاء مجلد النسخ الاحتياطي');
  }
};

/**
 * توليد اسم ملف النسخ الاحتياطي
 * @returns {string}
 */
const generateBackupFilename = () => {
  const date = new Date();
  const timestamp =
    date.getFullYear() +
    String(date.getMonth() + 1).padStart(2, '0') +
    String(date.getDate()).padStart(2, '0') +
    '_' +
    String(date.getHours()).padStart(2, '0') +
    String(date.getMinutes()).padStart(2, '0');
  return `backup_${timestamp}${BACKUP_EXTENSION}`;
};

/**
 * الحصول على حجم الملف
 * @param {string} path - مسار الملف
 * @returns {Promise<number>}
 */
const getFileSize = async (path) => {
  try {
    const info = await FileSystem.getInfoAsync(path);
    return info.exists ? info.size || 0 : 0;
  } catch {
    return 0;
  }
};

// =============================================
// 3. دوال إنشاء النسخ الاحتياطي
// =============================================

/**
 * تصدير قاعدة البيانات إلى ملف
 * @param {string} filePath - مسار الملف
 * @returns {Promise<boolean>}
 */
export const exportDatabase = async (filePath) => {
  try {
    // جلب جميع البيانات من قاعدة البيانات
    const tables = await LocalDB.query(
      "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
    );

    const backupData = {
      version: '1.0.0',
      timestamp: Date.now(),
      platform: Platform.OS,
      tables: {},
    };

    for (const table of tables) {
      const data = await LocalDB.query(`SELECT * FROM ${table.name}`);
      backupData.tables[table.name] = data;
    }

    // تحويل إلى JSON
    const jsonData = JSON.stringify(backupData, null, 2);

    // تشفير البيانات
    const encrypted = await CryptoService.encryptData(jsonData);

    // حفظ الملف
    await FileSystem.writeAsStringAsync(filePath, encrypted, {
      encoding: FileSystem.EncodingType.UTF8,
    });

    Logger.info(`✅ [Backup] تم تصدير قاعدة البيانات إلى ${filePath}`);
    return true;
  } catch (error) {
    Logger.error('❌ [Backup] فشل تصدير قاعدة البيانات:', error);
    return false;
  }
};

/**
 * إنشاء نسخة احتياطية جديدة
 * @param {string} type - نوع النسخ الاحتياطي
 * @param {Object} options - خيارات إضافية
 * @returns {Promise<Object>}
 */
export const createBackup = async (type = TYPES.LOCAL, options = {}) => {
  const { description = '', encrypt = true } = options;

  try {
    await ensureBackupDir();

    const filename = generateBackupFilename();
    const filePath = `${BACKUP_DIR}${filename}`;

    // تسجيل بداية النسخ الاحتياطي
    const backupId = await LocalDB.execute(
      `INSERT INTO backup_history
       (filename, type, status, notes, created_at)
       VALUES (?, ?, ?, ?, ?)`,
      [filename, type, STATUS.PENDING, description, Date.now()]
    );

    // تصدير قاعدة البيانات
    const success = await exportDatabase(filePath);
    const size = await getFileSize(filePath);

    if (success) {
      await LocalDB.execute(
        `UPDATE backup_history
         SET status = ?, size = ?
         WHERE id = ?`,
        [STATUS.SUCCESS, size, backupId.lastInsertRowId]
      );

      Logger.info(`✅ [Backup] تم إنشاء النسخ الاحتياطي: ${filename} (${size} bytes)`);

      return {
        success: true,
        id: backupId.lastInsertRowId,
        filename,
        path: filePath,
        size,
        type,
        created_at: Date.now(),
      };
    } else {
      await LocalDB.execute(
        `UPDATE backup_history SET status = ? WHERE id = ?`,
        [STATUS.FAILED, backupId.lastInsertRowId]
      );
      throw new Error('فشل في إنشاء النسخ الاحتياطي');
    }
  } catch (error) {
    Logger.error('❌ [Backup] فشل إنشاء النسخ الاحتياطي:', error);
    throw error;
  }
};

// =============================================
// 4. دوال استعادة النسخ الاحتياطي
// =============================================

/**
 * استيراد قاعدة البيانات من ملف
 * @param {string} filePath - مسار الملف
 * @returns {Promise<boolean>}
 */
export const importDatabase = async (filePath) => {
  try {
    // قراءة الملف
    const encrypted = await FileSystem.readAsStringAsync(filePath, {
      encoding: FileSystem.EncodingType.UTF8,
    });

    // فك التشفير
    const jsonData = await CryptoService.decryptData(encrypted);
    const backupData = JSON.parse(jsonData);

    // التحقق من صحة البيانات
    if (!backupData.version || !backupData.tables) {
      throw new Error('ملف النسخ الاحتياطي غير صحيح');
    }

    const allowedTables = new Set([
      'user', 'session', 'settings', 'audit_log', 'sync_queue', 'accounts',
      'account_movements', 'customer_tiers', 'customers', 'customer_contacts',
      'customer_notes', 'customer_activities', 'suppliers', 'products',
      'product_categories', 'journal_entries', 'journal_details', 'invoices',
      'invoice_items', 'cash_accounts', 'checks', 'subscriptions', 'notifications',
      'employees', 'payroll', 'expenses', 'revenues', 'transfers', 'payments',
      'fixed_assets', 'asset_depreciation', 'backup_history', 'currencies',
      'vat_rates', 'default_accounts', 'system_updates', 'devices', 'receipts'
    ]);

    await LocalDB.execute('BEGIN TRANSACTION');
    try {
      for (const [tableName, rows] of Object.entries(backupData.tables)) {
        if (!allowedTables.has(tableName) || !Array.isArray(rows)) {
          throw new Error(`جدول غير مسموح في النسخة الاحتياطية: ${tableName}`);
        }
        await LocalDB.execute(`DELETE FROM ${tableName}`);
        for (const row of rows) {
          const columns = Object.keys(row);
          if (!columns.length || columns.some((column) => !/^[A-Za-z_][A-Za-z0-9_]*$/.test(column))) {
            throw new Error(`أعمدة غير صالحة في جدول ${tableName}`);
          }
          const placeholders = columns.map(() => '?').join(', ');
          await LocalDB.execute(
            `INSERT INTO ${tableName} (${columns.join(', ')}) VALUES (${placeholders})`,
            columns.map(col => row[col])
          );
        }
      }
      await LocalDB.execute('COMMIT');
    } catch (restoreError) {
      await LocalDB.execute('ROLLBACK');
      throw restoreError;
    }

    Logger.info(`✅ [Backup] تم استعادة قاعدة البيانات من ${filePath}`);
    return true;
  } catch (error) {
    Logger.error('❌ [Backup] فشل استيراد قاعدة البيانات:', error);
    return false;
  }
};

/**
 * استعادة نسخة احتياطية
 * @param {string} filePath - مسار الملف
 * @param {Object} options - خيارات إضافية
 * @returns {Promise<boolean>}
 */
export const restoreBackup = async (filePath, options = {}) => {
  const { confirm = false } = options;

  if (!confirm) {
    throw new Error('يجب تأكيد استعادة النسخ الاحتياطي');
  }

  try {
    Logger.info('🔄 [Backup] بدء استعادة النسخ الاحتياطي');

    // التحقق من وجود الملف
    const fileInfo = await FileSystem.getInfoAsync(filePath);
    if (!fileInfo.exists) {
      throw new Error('الملف غير موجود');
    }

    // استعادة البيانات
    const success = await importDatabase(filePath);

    if (success) {
      Logger.info('✅ [Backup] تم استعادة النسخ الاحتياطي بنجاح');
      return true;
    } else {
      throw new Error('فشل في استعادة النسخ الاحتياطي');
    }
  } catch (error) {
    Logger.error('❌ [Backup] فشل استعادة النسخ الاحتياطي:', error);
    throw error;
  }
};

// =============================================
// 5. دوال إدارة النسخ الاحتياطية
// =============================================

/**
 * الحصول على قائمة النسخ الاحتياطية
 * @param {string} type - نوع النسخ الاحتياطي
 * @param {number} limit - الحد الأقصى
 * @returns {Promise<Array>}
 */
export const getBackupList = async (type = null, limit = 50) => {
  try {
    let sql = 'SELECT * FROM backup_history WHERE 1=1';
    const params = [];

    if (type) {
      sql += ' AND type = ?';
      params.push(type);
    }

    sql += ' ORDER BY created_at DESC LIMIT ?';
    params.push(limit);

    return await LocalDB.query(sql, params);
  } catch (error) {
    Logger.error('❌ [Backup] فشل جلب قائمة النسخ الاحتياطية:', error);
    return [];
  }
};

/**
 * الحصول على آخر نسخة احتياطية
 * @param {string} type - نوع النسخ الاحتياطي
 * @returns {Promise<Object|null>}
 */
export const getLatestBackup = async (type = null) => {
  try {
    let sql = 'SELECT * FROM backup_history WHERE status = ?';
    const params = [STATUS.SUCCESS];

    if (type) {
      sql += ' AND type = ?';
      params.push(type);
    }

    sql += ' ORDER BY created_at DESC LIMIT 1';

    return await LocalDB.queryOne(sql, params);
  } catch (error) {
    Logger.error('❌ [Backup] فشل جلب آخر نسخة احتياطية:', error);
    return null;
  }
};

/**
 * حذف نسخة احتياطية
 * @param {number} backupId - معرف النسخة
 * @param {boolean} deleteFile - حذف الملف أيضاً
 * @returns {Promise<boolean>}
 */
export const deleteBackup = async (backupId, deleteFile = true) => {
  try {
    const backup = await LocalDB.queryOne(
      'SELECT * FROM backup_history WHERE id = ?',
      [backupId]
    );

    if (!backup) {
      throw new Error('النسخة الاحتياطية غير موجودة');
    }

    if (deleteFile && backup.filename) {
      const filePath = `${BACKUP_DIR}${backup.filename}`;
      const fileInfo = await FileSystem.getInfoAsync(filePath);
      if (fileInfo.exists) {
        await FileSystem.deleteAsync(filePath);
      }
    }

    await LocalDB.execute('DELETE FROM backup_history WHERE id = ?', [backupId]);

    Logger.info(`🗑️ [Backup] تم حذف النسخة الاحتياطية ${backupId}`);
    return true;
  } catch (error) {
    Logger.error('❌ [Backup] فشل حذف النسخة الاحتياطية:', error);
    return false;
  }
};

// =============================================
// 6. دوال المشاركة والاستيراد
// =============================================

/**
 * مشاركة ملف النسخ الاحتياطي
 * @param {number} backupId - معرف النسخة
 * @returns {Promise<boolean>}
 */
export const shareBackup = async (backupId) => {
  try {
    const backup = await LocalDB.queryOne(
      'SELECT * FROM backup_history WHERE id = ?',
      [backupId]
    );

    if (!backup) {
      throw new Error('النسخة الاحتياطية غير موجودة');
    }

    const filePath = `${BACKUP_DIR}${backup.filename}`;
    const fileInfo = await FileSystem.getInfoAsync(filePath);

    if (!fileInfo.exists) {
      throw new Error('ملف النسخ الاحتياطي غير موجود');
    }

    if (!await Sharing.isAvailableAsync()) {
      throw new Error('المشاركة غير متاحة على هذا الجهاز');
    }

    await Sharing.shareAsync(filePath, {
      mimeType: 'application/octet-stream',
      dialogTitle: 'مشاركة النسخ الاحتياطي',
    });

    Logger.info(`📤 [Backup] تم مشاركة النسخة الاحتياطية ${backupId}`);
    return true;
  } catch (error) {
    Logger.error('❌ [Backup] فشل مشاركة النسخة الاحتياطية:', error);
    return false;
  }
};

/**
 * استيراد نسخة احتياطية من جهاز المستخدم
 * @returns {Promise<Object>}
 */
export const importBackupFromDevice = async () => {
  try {
    const result = await DocumentPicker.getDocumentAsync({
      type: '*/*',
      copyToCacheDirectory: true,
    });

    if (result.canceled) {
      return { success: false, canceled: true };
    }

    const file = result.assets[0];
    const filePath = file.uri;

    // التحقق من امتداد الملف
    if (!file.name.endsWith(BACKUP_EXTENSION)) {
      throw new Error('الملف ليس نسخة احتياطية صالحة');
    }

    return {
      success: true,
      name: file.name,
      path: filePath,
      size: file.size || 0,
    };
  } catch (error) {
    Logger.error('❌ [Backup] فشل استيراد النسخة الاحتياطية:', error);
    throw error;
  }
};

// =============================================
// 7. دوال النسخ الاحتياطي التلقائي
// =============================================

/**
 * إنشاء نسخ احتياطي تلقائي
 * @returns {Promise<Object>}
 */
export const autoBackup = async () => {
  try {
    // التحقق من آخر نسخ احتياطي
    const lastBackup = await getLatestBackup();
    const now = Date.now();

    if (lastBackup) {
      const diff = now - lastBackup.created_at;
      const days = diff / (24 * 60 * 60 * 1000);

      // إذا كان آخر نسخ احتياطي أقل من يوم واحد، تخطي
      if (days < 1) {
        Logger.debug('⏭️ [Backup] تم تخطي النسخ الاحتياطي التلقائي (آخر نسخ قبل أقل من يوم)');
        return { success: true, skipped: true };
      }
    }

    // إنشاء نسخ احتياطي
    const result = await createBackup(TYPES.LOCAL, {
      description: 'نسخ احتياطي تلقائي',
    });

    // حذف النسخ الاحتياطية القديمة (أكثر من 30 يوماً)
    await cleanOldBackups(30);

    return { success: true, ...result };
  } catch (error) {
    Logger.error('❌ [Backup] فشل النسخ الاحتياطي التلقائي:', error);
    return { success: false, error: error.message };
  }
};

/**
 * تنظيف النسخ الاحتياطية القديمة
 * @param {number} days - عدد الأيام
 * @returns {Promise<number>}
 */
export const cleanOldBackups = async (days = 30) => {
  try {
    const cutoff = Date.now() - (days * 24 * 60 * 60 * 1000);

    const oldBackups = await LocalDB.query(
      'SELECT * FROM backup_history WHERE created_at < ?',
      [cutoff]
    );

    let count = 0;
    for (const backup of oldBackups) {
      // حذف الملف
      const filePath = `${BACKUP_DIR}${backup.filename}`;
      const fileInfo = await FileSystem.getInfoAsync(filePath);
      if (fileInfo.exists) {
        await FileSystem.deleteAsync(filePath);
      }

      // حذف السجل
      await LocalDB.execute('DELETE FROM backup_history WHERE id = ?', [backup.id]);
      count++;
    }

    Logger.info(`🧹 [Backup] تم تنظيف ${count} نسخة احتياطية قديمة`);
    return count;
  } catch (error) {
    Logger.error('❌ [Backup] فشل تنظيف النسخ الاحتياطية القديمة:', error);
    return 0;
  }
};

// =============================================
// 8. كائن الخدمة الرئيسي
// =============================================

export const backupService = {
  // إنشاء واستعادة
  create: createBackup,
  restore: restoreBackup,

  // تصدير واستيراد
  export: exportDatabase,
  import: importDatabase,

  // إدارة
  list: getBackupList,
  latest: getLatestBackup,
  delete: deleteBackup,
  share: shareBackup,

  // استيراد من جهاز
  importFromDevice: importBackupFromDevice,

  // تلقائي
  auto: autoBackup,
  clean: cleanOldBackups,

  // مساعدة
  generateFilename: generateBackupFilename,

  // الثوابت
  STATUS,
  TYPES,
  EXTENSION: BACKUP_EXTENSION,
};

export default backupService;