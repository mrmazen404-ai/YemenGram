import React from 'react';
import { TouchableOpacity, Text, StyleSheet, ActivityIndicator, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '../utils/colors';
export default function Button({
  // أساسيات
  title,
  onPress,
  loading,
  disabled,

  // أنواع
  variant = 'primary', // primary, secondary, danger, gold, ghost, success

  // حجم
  size = 'medium', // small, medium, large

  // أيقونة
  icon,
  iconPosition = 'left', // left, right

  // تخصيص
  style,
  textStyle,
  fullWidth = false,

  // أحداث
  onPressIn,
  onPressOut,
}) {
  const isDisabled = disabled || loading;

  // ===== الألوان حسب النوع =====
  const getColors = () => {
    switch (variant) {
      case 'primary':
        return {
          bg: Colors.navy,
          text: Colors.white,
          border: Colors.navy,
        };
      case 'secondary':
        return {
          bg: 'transparent',
          text: Colors.navy,
          border: Colors.navy,
        };
      case 'danger':
        return {
          bg: Colors.red,
          text: Colors.white,
          border: Colors.red,
        };
      case 'gold':
        return {
          bg: Colors.gold,
          text: Colors.white,
          border: Colors.gold,
        };
      case 'success':
        return {
          bg: Colors.green,
          text: Colors.white,
          border: Colors.green,
        };
      case 'ghost':
        return {
          bg: 'transparent',
          text: Colors.navy,
          border: 'transparent',
        };
      default:
        return {
          bg: Colors.navy,
          text: Colors.white,
          border: Colors.navy,
        };
    }
  };

  // ===== الحجم =====
  const getSize = () => {
    switch (size) {
      case 'small':
        return { height: 38, paddingHorizontal: 16, fontSize: 13, iconSize: 16 };
      case 'medium':
        return { height: 48, paddingHorizontal: 24, fontSize: 15, iconSize: 18 };
      case 'large':
        return { height: 56, paddingHorizontal: 32, fontSize: 17, iconSize: 20 };
      default:
        return { height: 48, paddingHorizontal: 24, fontSize: 15, iconSize: 18 };
    }
  };

  const colors = getColors();
  const sizeConfig = getSize();
  const isGhost = variant === 'ghost';
  const isSecondary = variant === 'secondary';

  // ===== الظل =====
  const getShadow = () => {
    if (isDisabled) return {};
    if (isGhost || isSecondary) return {};
    return {
      shadowColor: colors.bg,
      shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 0.2,
      shadowRadius: 8,
      elevation: 4,
    };
  };

  return (
    <TouchableOpacity
      style={[
        styles.button,
        {
          backgroundColor: isDisabled ? Colors.placeholder : colors.bg,
          borderColor: isDisabled ? Colors.border : colors.border,
          height: sizeConfig.height,
          paddingHorizontal: sizeConfig.paddingHorizontal,
          width: fullWidth ? '100%' : 'auto',
          borderWidth: (isSecondary || isGhost) ? 1.5 : 0,
          opacity: isDisabled ? 0.6 : 1,
        },
        getShadow(),
        style,
      ]}
      onPress={onPress}
      onPressIn={onPressIn}
      onPressOut={onPressOut}
      disabled={isDisabled}
      activeOpacity={0.85}
    >
      {loading ? (
        <ActivityIndicator color={isGhost || isSecondary ? colors.text : Colors.white} size="small" />
      ) : (
        <View style={styles.content}>
          {icon && iconPosition === 'left' && (
            <Ionicons
              name={icon}
              size={sizeConfig.iconSize}
              color={isDisabled ? Colors.gray : colors.text}
              style={styles.iconLeft}
            />
          )}
          <Text
            style={[
              styles.text,
              {
                color: isDisabled ? Colors.gray : colors.text,
                fontSize: sizeConfig.fontSize,
              },
              textStyle,
            ]}
          >
            {title}
          </Text>
          {icon && iconPosition === 'right' && (
            <Ionicons
              name={icon}
              size={sizeConfig.iconSize}
              color={isDisabled ? Colors.gray : colors.text}
              style={styles.iconRight}
            />
          )}
        </View>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },

  content: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },

  text: {
    fontFamily: 'Tajawal-Medium',
    textAlign: 'center',
  },

  iconLeft: {
    marginRight: 8,
  },

  iconRight: {
    marginLeft: 8,
  },
});