// src/models/AssetDepreciation.js
// =============================================
// نموذج سجل الإهلاك (Asset Depreciation Model)
// المسؤول عن تسجيل الإهلاكات الدورية للأصول الثابتة
// =============================================

import { Model } from '@nozbe/watermelondb';
import { field, date, readonly } from '@nozbe/watermelondb/decorators';
import { Q } from '@nozbe/watermelondb';

export default class AssetDepreciation extends Model {
  // ===== 1. اسم الجدول =====
  static table = 'asset_depreciation';

  // ===== 2. الحقول الأساسية =====

  // معرف الأصل الثابت
  @field('asset_id') assetId;

  // الفترة (مثال: 2026-01, 2026-Q1, 2026)
  @field('period') period;

  // قيمة الإهلاك في هذه الفترة
  @field('amount') amount;

  // الإهلاك المتراكم بعد هذه الفترة
  @field('accumulated') accumulated;

  // ===== 3. التواريخ التلقائية =====

  @readonly @date('created_at') createdAt;

  // ===== 4. العلاقات =====

  static associations = {
    // كل سجل إهلاك ينتمي إلى أصل واحد
    asset: { type: 'belongs_to', key: 'asset_id' },
  };

  // ===== 5. دوال مساعدة =====

  /**
   * جلب الأصل الثابت المرتبط
   * @returns {Promise<FixedAsset>}
   */
  async getAsset() {
    return this.collections.get('fixed_assets').find(this.assetId);
  }

  /**
   * الحصول على اسم الأصل الثابت
   * @returns {Promise<string>}
   */
  async getAssetName() {
    const asset = await this.getAsset();
    return asset ? asset.name : 'أصل غير معروف';
  }

  /**
   * الحصول على رمز الأصل الثابت
   * @returns {Promise<string>}
   */
  async getAssetCode() {
    const asset = await this.getAsset();
    return asset ? asset.code : '???';
  }

  /**
   * الحصول على اسم الأصل مع الرمز
   * @returns {Promise<string>}
   */
  async getAssetDisplayName() {
    const asset = await this.getAsset();
    return asset ? `${asset.code} - ${asset.name}` : '??? - غير معروف';
  }

  /**
   * الحصول على الفترة المنسقة
   * @returns {string}
   */
  getFormattedPeriod() {
    if (!this.period) return '';

    // محاولة تنسيق الفترة (مثال: 2026-01 → يناير 2026)
    if (this.period.length === 7 && this.period.includes('-')) {
      const [year, month] = this.period.split('-');
      const months = [
        'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
        'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر',
      ];
      const monthIndex = parseInt(month) - 1;
      return `${months[monthIndex] || month} ${year}`;
    }

    return this.period;
  }

  /**
   * الحصول على تاريخ السجل المنسق
   * @returns {string}
   */
  getFormattedDate() {
    if (!this.createdAt) return '';
    const date = new Date(this.createdAt);
    return date.toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  /**
   * الحصول على اسم السجل المعروض
   * @returns {Promise<string>}
   */
  async getDisplayName() {
    const assetName = await this.getAssetName();
    return `${assetName} - ${this.getFormattedPeriod()}`;
  }

  /**
   * التحقق من أن المبلغ موجب
   * @returns {boolean}
   */
  isValid() {
    return (this.amount || 0) > 0;
  }

  // ===== 6. دوال ثابتة =====

  /**
   * حساب إجمالي الإهلاك لمجموعة سجلات
   * @param {AssetDepreciation[]} depreciations
   * @returns {number}
   */
  static sumAmount(depreciations) {
    return depreciations.reduce((sum, d) => sum + (d.amount || 0), 0);
  }

  /**
   * تجميع سجلات الإهلاك حسب الفترة
   * @param {AssetDepreciation[]} depreciations
   * @returns {Object}
   */
  static groupByPeriod(depreciations) {
    const groups = {};
    for (const dep of depreciations) {
      if (!groups[dep.period]) {
        groups[dep.period] = [];
      }
      groups[dep.period].push(dep);
    }
    return groups;
  }

  /**
   * تجميع سجلات الإهلاك حسب الأصل
   * @param {AssetDepreciation[]} depreciations
   * @returns {Object}
   */
  static groupByAsset(depreciations) {
    const groups = {};
    for (const dep of depreciations) {
      if (!groups[dep.assetId]) {
        groups[dep.assetId] = [];
      }
      groups[dep.assetId].push(dep);
    }
    return groups;
  }

  /**
   * الحصول على آخر سجل إهلاك لمجموعة
   * @param {AssetDepreciation[]} depreciations
   * @returns {AssetDepreciation|null}
   */
  static getLatest(depreciations) {
    if (depreciations.length === 0) return null;
    return depreciations.reduce((a, b) => (a.createdAt > b.createdAt ? a : b));
  }

  /**
   * الحصول على أول سجل إهلاك لمجموعة
   * @param {AssetDepreciation[]} depreciations
   * @returns {AssetDepreciation|null}
   */
  static getFirst(depreciations) {
    if (depreciations.length === 0) return null;
    return depreciations.reduce((a, b) => (a.createdAt < b.createdAt ? a : b));
  }

  /**
   * حساب الإهلاك حسب الفترة المحددة
   * @param {AssetDepreciation[]} depreciations
   * @param {string} period
   * @returns {number}
   */
  static sumByPeriod(depreciations, period) {
    return depreciations
      .filter(d => d.period === period)
      .reduce((sum, d) => sum + (d.amount || 0), 0);
  }
}