import { useEffect, useRef } from 'react';
import { AppState } from 'react-native';
import { LocalDB } from '../../modules/database/localDB';
import { useAuth } from '../contexts/AuthContext';

export function useAppLock() {
  const { isLoggedIn, isAppLocked, setIsAppLocked } = useAuth();
  const backgroundTimestamp = useRef(null);
  const currentState = useRef(AppState.currentState);

  useEffect(() => {
    // لا نحتاج لمراقبة الحالة إذا لم يكن المستخدم مسجل دخول
    if (!isLoggedIn) return;

    const handleChange = async (nextState) => {
      // 1. الخروج إلى الخلفية: تسجيل وقت الخروج
      if (currentState.current === 'active' && nextState !== 'active') {
        backgroundTimestamp.current = Date.now();
      }

      // 2. العودة إلى التطبيق: التحقق من وقت القفل
      if (currentState.current !== 'active' && nextState === 'active') {
        if (backgroundTimestamp.current && !isAppLocked) {
          const elapsedSeconds = (Date.now() - backgroundTimestamp.current) / 1000;

          // جلب إعداد وقت القفل من قاعدة البيانات
          const lockTimeStr = await LocalDB.getSetting('pin_lock_time');
          const lockTimeMinutes = lockTimeStr ? parseInt(lockTimeStr, 10) : 5;
          const lockTimeSeconds = lockTimeMinutes * 60;

          // إذا تجاوز الوقت المسموح، قفل التطبيق فوراً
          if (elapsedSeconds >= lockTimeSeconds) {
            console.log(`🔐 [useAppLock] قفل التطبيق تلقائياً بعد ${elapsedSeconds.toFixed(0)} ثانية`);
            setIsAppLocked(true);
          }
        }
      }

      currentState.current = nextState;
    };

    const subscription = AppState.addEventListener('change', handleChange);
    return () => subscription?.remove?.();
  }, [isLoggedIn, isAppLocked, setIsAppLocked]);

  return { locked: isAppLocked, setLocked: setIsAppLocked };
}
