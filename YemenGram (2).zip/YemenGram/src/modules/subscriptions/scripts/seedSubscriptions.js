// placeholder seed script
console.log('seedSubscriptions placeholder');
