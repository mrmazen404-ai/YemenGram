/**
 * محرك الوقت السيادي (Sovereign Time Engine)
 * حماية النظام من تلاعب المستخدم بتوقيت الهاتف ومنع الاستخدام الأوفلاين الطويل
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import { Logger } from '../shared/utils/logger';

const TIME_OFFSET_KEY = 'yg_sovereign_time_offset';
const LAST_SYNC_KEY = 'yg_last_sovereign_sync';
const WORLD_TIME_API = 'https://worldtimeapi.org/api/timezone/Etc/UTC';
const FALLBACK_TIME_API = 'https://timeapi.io/api/Time/current/zone?timeZone=UTC';

export const TimeService = {
  offset: 0,
  isSynced: false,
  maxOfflineHours: 48, // الحد الأقصى للبقاء أوفلاين (سيادة المزامنة)

  /**
   * تهيئة المحرك عند بدء التطبيق
   */
  async initialize() {
    try {
      const storedOffset = await AsyncStorage.getItem(TIME_OFFSET_KEY);
      if (storedOffset) {
        this.offset = parseInt(storedOffset, 10);
      }

      // محاولة مزامنة فورية مع السيرفر
      await this.syncWithServer();
    } catch (e) {
      console.log('TimeService Init Fail:', e.message);
    }
  },

  /**
   * المزامنة مع مصادر الوقت العالمية
   */
  async syncWithServer() {
    // محاولة المصدر الأول
    let success = await this._fetchFromApi(WORLD_TIME_API, data => new Date(data.datetime).getTime());

    // محاولة المصدر الثاني إذا فشل الأول
    if (!success) {
      console.log('🔄 [TimeService] جاري المحاولة مع المصدر الاحتياطي...');
      success = await this._fetchFromApi(FALLBACK_TIME_API, data => new Date(data.dateTime).getTime());
    }

    if (success) {
      this.isSynced = true;
      await AsyncStorage.setItem(TIME_OFFSET_KEY, this.offset.toString());
      await this.updateLastSyncTimestamp();
    }
    return success;
  },

  /**
   * تحديث طابع آخر مزامنة ناجحة (سيادة المزامنة)
   */
  async updateLastSyncTimestamp() {
    await AsyncStorage.setItem(LAST_SYNC_KEY, Date.now().toString());
  },

  async _fetchFromApi(url, dateExtractor) {
    try {
      const startTime = Date.now();
      const response = await fetch(url, { timeout: 5000 });
      const data = await response.json();
      const endTime = Date.now();
      const latency = (endTime - startTime) / 2;
      const serverTime = dateExtractor(data) + latency;
      this.offset = serverTime - Date.now();
      return true;
    } catch (e) {
      return false;
    }
  },

  /**
   * الحصول على الوقت السيادي المعتمد
   */
  getSovereignTime() {
    return Date.now() + this.offset;
  },

  /**
   * فحص النزاهة الزمني (Manipulation & Desync)
   * @returns {Object} { isValid: boolean, reason: string }
   */
  async checkSovereignIntegrity() {
    const localTime = Date.now();
    const lastSync = await AsyncStorage.getItem(LAST_SYNC_KEY);

    // 1. فحص التلاعب اللحظي (Drift Detection)
    const driftThreshold = 120000; // 2 minutes
    const isManipulated = Math.abs(this.offset) > driftThreshold;

    if (isManipulated && this.isSynced) {
       return {
         isValid: false,
         reason: 'TIME_MANIPULATION',
         message: 'تم اكتشاف تلاعب في توقيت الهاتف. يرجى ضبط الوقت تلقائياً والمزامنة.'
       };
    }

    // 2. فحص الانقطاع الطويل (Desync Detection)
    if (lastSync) {
      const hoursSinceSync = (localTime - parseInt(lastSync)) / (1000 * 60 * 60);
      if (hoursSinceSync > this.maxOfflineHours) {
        return {
          isValid: false,
          reason: 'LONG_OFFLINE',
          message: `لم يتم التحقق من سيادة الوقت منذ أكثر من ${this.maxOfflineHours} ساعة. يرجى الاتصال بالإنترنت.`
        };
      }
    }

    return { isValid: true };
  }
};

export default TimeService;
