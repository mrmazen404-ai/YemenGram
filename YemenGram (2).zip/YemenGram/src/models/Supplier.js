// src/models/Supplier.js
// =============================================
// نموذج المورد (Supplier Model)
// المسؤول عن إدارة بيانات الموردين والمشتريات
// =============================================

import { Model } from '@nozbe/watermelondb';
import { field, date, readonly } from '@nozbe/watermelondb/decorators';
import { Q } from '@nozbe/watermelondb';

export default class Supplier extends Model {
  // ===== 1. اسم الجدول =====
  static table = 'suppliers';

  // ===== 2. الحقول الأساسية =====

  // معرف المستخدم (لفصل البيانات)
  @field('user_id') userId;

  // رمز المورد الفريد (SUP-0001)
  @field('code') code;

  // اسم المورد
  @field('name') name;

  // ===== 3. معلومات الاتصال =====

  @field('phone') phone;
  @field('email') email;
  @field('address') address;
  @field('tax_number') taxNumber;

  // ===== 4. المعلومات المالية =====

  // الرصيد الحالي للمورد
  @field('balance') balance;

  // الحساب المحاسبي للمورد (دائنون)
  @field('account_id') accountId;

  // ===== 5. معلومات إضافية =====

  @field('notes') notes;

  // ===== 6. حالة المورد =====

  @field('is_active') isActive;

  // ===== 7. التواريخ التلقائية =====

  @readonly @date('created_at') createdAt;
  @readonly @date('updated_at') updatedAt;

  // ===== 8. العلاقات =====

  static associations = {
    // كل مورد ينتمي إلى مستخدم واحد
    user: { type: 'belongs_to', key: 'user_id' },
    // كل مورد له حساب محاسبي واحد
    account: { type: 'belongs_to', key: 'account_id' },
    // مورد واحد → لديه عدة فواتير شراء
    invoices: { type: 'has_many', foreignKey: 'supplier_id' },
    // مورد واحد → لديه عدة مدفوعات
    payments: { type: 'has_many', foreignKey: 'supplier_id' },
  };

  // ===== 9. دوال مساعدة =====

  /**
   * الحصول على اسم المورد مع الرمز
   * @returns {string}
   */
  getDisplayName() {
    return `${this.code} - ${this.name}`;
  }

  /**
   * التحقق من نشاط المورد
   * @returns {boolean}
   */
  isActiveSupplier() {
    return this.isActive === 1 || this.isActive === true;
  }

  /**
   * جلب الحساب المحاسبي للمورد
   * @returns {Promise<Account>}
   */
  async getAccount() {
    if (!this.accountId) return null;
    return this.collections.get('accounts').find(this.accountId);
  }

  /**
   * جلب فواتير الشراء للمورد
   * @returns {Promise<Invoice[]>}
   */
  async getInvoices() {
    return this.collections.get('invoices').query(
      Q.where('supplier_id', this.id)
    ).fetch();
  }

  /**
   * جلب مدفوعات المورد
   * @returns {Promise<Payment[]>}
   */
  async getPayments() {
    return this.collections.get('payments').query(
      Q.where('supplier_id', this.id)
    ).fetch();
  }

  /**
   * حساب إجمالي المشتريات من المورد
   * @returns {Promise<number>}
   */
  async getTotalPurchases() {
    const invoices = await this.getInvoices();
    return invoices.reduce((sum, inv) => sum + (inv.net_total || 0), 0);
  }

  /**
   * حساب إجمالي المدفوعات للمورد
   * @returns {Promise<number>}
   */
  async getTotalPayments() {
    const payments = await this.getPayments();
    return payments.reduce((sum, p) => sum + (p.amount || 0), 0);
  }

  /**
   * حساب الرصيد المتبقي للمورد (المشتريات - المدفوعات)
   * @returns {Promise<number>}
   */
  async getBalance() {
    const totalPurchases = await this.getTotalPurchases();
    const totalPayments = await this.getTotalPayments();
    return totalPurchases - totalPayments;
  }
  /**
   * تحديث رصيد المورد
   * @param {number} newBalance
   */
  async updateBalance(newBalance) {
    await this.write(() => {
      this.balance = newBalance;
    });
  }
  /**
   * إضافة مبلغ إلى رصيد المورد (زيادة المطلوبات)
   * @param {number} amount
   */
  async addBalance(amount) {
    await this.write(() => {
      this.balance = (this.balance || 0) + amount;
    });
  }
  /**
   * خصم مبلغ من رصيد المورد (تسديد)
   * @param {number} amount
   */
  async deductBalance(amount) {
    await this.write(() => {
      this.balance = (this.balance || 0) - amount;
    });
  }

  /**
   * التحقق من وجود فواتير شراء للمورد
   * @returns {Promise<boolean>}
   */
  async hasInvoices() {
    const count = await this.collections.get('invoices').query(
      Q.where('supplier_id', this.id)
    ).fetchCount();
    return count > 0;
  }
}