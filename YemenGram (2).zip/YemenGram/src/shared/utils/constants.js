// src/shared/utils/constants.js
// ثوابت النظام المركزية (Global System Constants) - v2.0 Purified

import { Dimensions, Platform } from 'react-native';

const { width, height } = Dimensions.get('window');

export const APP = {
  NAME: 'يمن جرام',
  VERSION: '1.0.5',
  BUNDLE_ID: 'com.yemengram.app',
};

export const SECURITY = {
  SESSION_DURATION: 7 * 24 * 60 * 60 * 1000,
  MAX_LOGIN_ATTEMPTS: 5,
  LOCKOUT_DURATION: 15 * 60 * 1000,
  OTP_EXPIRY: 10 * 60 * 1000,
  OTP_MAX_ATTEMPTS: 3,
};

export const LAYOUT = {
  WIDTH: width,
  HEIGHT: height,
  IS_IOS: Platform.OS === 'ios',
  IS_ANDROID: Platform.OS === 'android',
  HEADER_HEIGHT: Platform.OS === 'ios' ? 100 : 80,
};

export const STORAGE_KEYS = {
  AUTH: {
    TOKEN: 'userToken',
    FINGERPRINT: 'deviceFingerprint',
    LAST_AUTH: 'last_full_auth_timestamp',
    SECRET: 'sovereign_secret',
  },
  SETTINGS: {
    CURRENCY: 'base_currency',
    LANGUAGE: 'language',
  }
};

export default {
  APP,
  SECURITY,
  LAYOUT,
  STORAGE_KEYS,
};
