// src/models/User.js
// =============================================
// نموذج المستخدم (User Model)
// المسؤول عن تعريف هيكل بيانات المستخدمين
// وعلاقاته مع بقية جداول النظام
// =============================================

import { Model } from '@nozbe/watermelondb';
import { field, date, readonly } from '@nozbe/watermelondb/decorators';

export default class User extends Model {
  // ===== 1. اسم الجدول في قاعدة البيانات =====
  static table = 'users';

  // ===== 2. تعريف الحقول (Columns) =====

  // المعرف الفريد القابل للقراءة من قبل المستخدم والدعم الفني
  @field('user_code') userCode;

  // الاسم الكامل للمستخدم
  @field('name') name;

  // البريد الإلكتروني (يُستخدم لتسجيل الدخول واستلام الإشعارات)
  @field('email') email;

  // رقم الهاتف (يُستخدم لتسجيل الدخول وإرسال الـ OTP)
  @field('phone') phone;

  // صورة المستخدم (تُخزن كـ Base64 أو رابط)
  @field('avatar') avatar;

  // صلاحية المستخدم (admin, accountant, sales, customer)
  @field('role') role;

  // معرف الشركة (لربط عدة مستخدمين بنفس الشركة في المستقبل)
  @field('company_id') companyId;

  // اسم الشركة المعروض
  @field('company_name') companyName;

  // العملة الأساسية للنظام (YER, SAR, USD)
  @field('base_currency') baseCurrency;

  // حالة الحظر (0 = غير محظور، 1 = محظور)
  @field('is_blocked') isBlocked;

  // سبب الحظر (للتوثيق)
  @field('blocked_reason') blockedReason;

  // تاريخ الحظر
  @field('blocked_at') blockedAt;

  // ===== 3. التواريخ التلقائية =====

  // تاريخ الإنشاء (يتم تعبئته تلقائياً عند الإضافة)
  @readonly @date('created_at') createdAt;

  // تاريخ آخر تحديث (يتم تعبئته تلقائياً عند التعديل)
  @readonly @date('updated_at') updatedAt;

  // ===== 4. العلاقات مع الجداول الأخرى =====

  static associations = {
    // مستخدم واحد → لديه عدة جلسات
    sessions: { type: 'has_many', foreignKey: 'user_id' },
    // مستخدم واحد → لديه عدة عملاء
    customers: { type: 'has_many', foreignKey: 'user_id' },
    // مستخدم واحد → لديه عدة فواتير
    invoices: { type: 'has_many', foreignKey: 'user_id' },
    // مستخدم واحد → لديه عدة مدفوعات
    payments: { type: 'has_many', foreignKey: 'user_id' },
    // مستخدم واحد → لديه عدة اشتراكات
    subscriptions: { type: 'has_many', foreignKey: 'user_id' },
  };

  // ===== 5. دوال مساعدة (Helper Methods) =====

  /**
   * الحصول على الاسم المعروض (مع الرقم الفريد)
   * @returns {string} - مثال: "YG_a7f3k9m2 - أحمد محمد"
   */
  getDisplayName() {
    return `${this.userCode} - ${this.name}`;
  }

  /**
   * التحقق من نشاط الحساب (غير محظور)
   * @returns {boolean}
   */
  isActive() {
    return this.isBlocked === 0 || this.isBlocked === false;
  }

  /**
   * الحصول على الدور باللغة العربية
   * @returns {string}
   */
  getRoleArabic() {
    const roles = {
      admin: 'مدير',
      accountant: 'محاسب',
      sales: 'مندوب مبيعات',
      customer: 'عميل',
    };
    return roles[this.role] || this.role;
  }

  /**
   * التحقق من أن المستخدم مدير
   * @returns {boolean}
   */
  isAdmin() {
    return this.role === 'admin';
  }

  /**
   * التحقق من أن المستخدم محاسب
   * @returns {boolean}
   */
  isAccountant() {
    return this.role === 'accountant';
  }
}