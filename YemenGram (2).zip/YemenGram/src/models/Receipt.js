/**
 * نموذج الإيصال السيادي (Sovereign Receipt Model)
 */

import { Model } from '@nozbe/watermelondb';
import { field, date, readonly } from '@nozbe/watermelondb/decorators';

export default class Receipt extends Model {
  static table = 'receipts';

  @field('user_id') userId;
  @field('subscription_id') subscriptionId;
  @field('transaction_number') transactionNumber;
  @field('image_url') imageUrl;
  @field('bank_name') bankName;
  @field('amount') amount;
  @field('status') status; // pending, approved, rejected
  @field('admin_notes') adminNotes;

  @readonly @date('created_at') createdAt;
  @readonly @date('updated_at') updatedAt;

  static associations = {
    user: { type: 'belongs_to', key: 'user_id' },
    subscription: { type: 'belongs_to', key: 'subscription_id' },
  };

  /**
   * الحصول على لون الحالة
   */
  getStatusColor() {
    switch (this.status) {
      case 'approved': return '#27AE60';
      case 'rejected': return '#E74C3C';
      default: return '#F39C12';
    }
  }

  /**
   * الحصول على اسم الحالة بالعربية
   */
  getStatusArabic() {
    switch (this.status) {
      case 'approved': return 'مقبول';
      case 'rejected': return 'مرفوض';
      default: return 'قيد المراجعة';
    }
  }
}
