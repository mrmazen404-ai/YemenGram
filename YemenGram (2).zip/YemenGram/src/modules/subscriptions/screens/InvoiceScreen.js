/**
 * شاشة الفواتير السيادية (Sovereign Invoices Screen)
 * عرض الفواتير المالية للاشتراكات مع إمكانية التحميل والمشاركة
 */

import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  Alert
} from 'react-native';
import { MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';
import LocalDB from '../../database/localDB';
import InvoiceService from '../services/InvoiceService';
import { useAuth } from '../../../shared/contexts/AuthContext';
import { Colors } from '../../../shared/utils/colors';

export default function InvoiceScreen() {
  const navigation = useNavigation();
  const { user } = useAuth();
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const loadInvoices = async () => {
    try {
      if (!user?.id) return;

      // جلب الفواتير (نحن نعتبر كل اشتراك "مفعل" فاتورة)
      const rows = await LocalDB.query(
        `SELECT id, plan, total, price, created_at, status
         FROM subscriptions
         WHERE user_id = ? AND status IN ('ACTIVE_FULL', 'ANNUAL_ACTIVE', 'MONTHLY_ACTIVE')
         ORDER BY created_at DESC`,
        [user.id]
      );

      setInvoices(rows || []);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadInvoices();
  }, []);

  const handleDownload = async (item) => {
    try {
      Alert.alert('جاري التحضير', 'يتم الآن توليد نسخة PDF من فاتورتك...');

      await InvoiceService.shareInvoice({
        user: user,
        subscription: item,
        invoiceNumber: `INV-SUB-${item.id.slice(-6).toUpperCase()}`,
        date: new Date(parseInt(item.created_at)).toLocaleDateString('ar-EG')
      });
    } catch (e) {
      Alert.alert('خطأ', 'فشل توليد الفاتورة، يرجى المحاولة لاحقاً.');
    }
  };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color={Colors.navy} /></View>;

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.headerNav}>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
           <Ionicons name="chevron-forward" size={24} color={Colors.navy} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>الفواتير السيادية</Text>
        <View style={{ width: 40 }} />
      </View>

      <View style={styles.header}>
         <Text style={styles.title}>أرشيف الفواتير</Text>
         <Text style={styles.subtitle}>يمكنك تحميل ومشاركة فواتيرك الرسمية في أي وقت.</Text>
      </View>

      <ScrollView
        contentContainerStyle={styles.list}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); loadInvoices(); }} />}
      >
        {invoices.length === 0 ? (
          <View style={styles.emptyBox}>
             <MaterialCommunityIcons name="file-document-outline" size={60} color="#E2E8F0" />
             <Text style={styles.emptyText}>لا توجد فواتير صادرة حالياً</Text>
          </View>
        ) : (
          invoices.map((item) => (
            <View key={item.id} style={styles.card}>
              <View style={styles.cardInfo}>
                <Text style={styles.invNumber}>INV-SUB-{item.id.slice(-6).toUpperCase()}</Text>
                <Text style={styles.invDate}>{new Date(parseInt(item.created_at)).toLocaleDateString('ar-EG')}</Text>
                <View style={styles.amountBadge}>
                   <Text style={styles.amountText}>{(item.total || item.price).toLocaleString()} ر.ي</Text>
                </View>
              </View>

              <TouchableOpacity style={styles.downloadBtn} onPress={() => handleDownload(item)}>
                 <Ionicons name="cloud-download-outline" size={24} color={Colors.gold} />
                 <Text style={styles.downloadText}>تحميل PDF</Text>
              </TouchableOpacity>
            </View>
          ))
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC' },
  headerNav: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingVertical: 15, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#F1F5F9' },
  backBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: '#F8FAFC', justifyContent: 'center', alignItems: 'center' },
  headerTitle: { fontSize: 18, fontFamily: 'Tajawal-Bold', color: Colors.navy },
  header: { padding: 25, backgroundColor: '#FFF' },
  title: { fontSize: 22, fontFamily: 'Tajawal-Bold', color: Colors.navy, textAlign: 'right' },
  subtitle: { fontSize: 13, fontFamily: 'Tajawal-Medium', color: '#64748B', textAlign: 'right', marginTop: 5 },
  list: { padding: 20 },
  card: {
    backgroundColor: '#FFF',
    borderRadius: 20,
    padding: 18,
    marginBottom: 15,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1,
    borderColor: '#F1F5F9',
    elevation: 2,
  },
  cardInfo: { flex: 1, alignItems: 'flex-end' },
  invNumber: { fontSize: 15, fontFamily: 'Tajawal-Bold', color: '#1E293B' },
  invDate: { fontSize: 12, fontFamily: 'Tajawal-Medium', color: '#94A3B8', marginTop: 4 },
  amountBadge: { backgroundColor: '#F1F5F9', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8, marginTop: 10 },
  amountText: { fontSize: 14, fontFamily: 'Tajawal-Bold', color: Colors.navy },
  downloadBtn: { alignItems: 'center', gap: 5 },
  downloadText: { fontSize: 10, fontFamily: 'Tajawal-Bold', color: Colors.gold },
  emptyBox: { alignItems: 'center', marginTop: 100 },
  emptyText: { marginTop: 15, fontSize: 14, fontFamily: 'Tajawal-Medium', color: '#94A3B8' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' }
});
