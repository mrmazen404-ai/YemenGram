/**
 * شاشة عرض الفترة المجانية (Free Trial Intro Screen)
 */

import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';
import { Colors } from '../../../shared/utils/colors';
import { SubscriptionCoreService } from '../index';
import { useSubscriptionState } from '../hooks/useSubscriptionState';
import LocalDB from '../../database/localDB';

export default function FreeTrialIntroScreen({ navigation }) {
  const { subscription, refresh } = useSubscriptionState();
  const [loading, setLoading] = React.useState(false);

  const handleStartTrial = async () => {
    try {
      setLoading(true);
      const service = new SubscriptionCoreService();
      await service.startTrial(subscription?.userId || 'guest');

      // حفظ علم المشاهدة في الإعدادات
      await LocalDB.saveSetting('has_seen_trial_intro', 'true');

      refresh();
      navigation.navigate('SubscriptionResources');
    } catch (error) {
      alert(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleLater = async () => {
    await LocalDB.saveSetting('has_seen_trial_intro', 'true');
    navigation.navigate('PlansCatalog');
  };

  const features = [
    { title: 'إدارة كاملة للعملاء', icon: 'account-group' },
    { title: 'إصدار فواتير غير محدود', icon: 'file-document-edit' },
    { title: 'مزامنة سحابية لحظية', icon: 'cloud-sync' },
    { title: 'تعدد الأجهزة (حتى 3)', icon: 'cellphone-link' },
  ];

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.header}>
        <MaterialCommunityIcons name="gift-outline" size={80} color={Colors.gold} />
        <Text style={styles.title}>هديتك السيادية: 30 يوماً مجاناً</Text>
        <Text style={styles.subtitle}>استمتع بكافة مميزات YemenGram Pro دون أي التزامات مالية.</Text>
      </View>

      <View style={styles.featuresCard}>
        {features.map((f, i) => (
          <View key={i} style={styles.featureItem}>
            <Ionicons name="checkmark-circle" size={20} color="#10B981" />
            <Text style={styles.featureText}>{f.title}</Text>
          </View>
        ))}
      </View>

      <View style={styles.actions}>
        <TouchableOpacity
          style={styles.primaryBtn}
          onPress={handleStartTrial}
          disabled={loading}
        >
          <Text style={styles.primaryText}>{loading ? 'جاري التفعيل...' : 'ابدأ الفترة المجانية الآن'}</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.secondaryBtn} onPress={handleLater}>
          <Text style={styles.secondaryText}>عرض الخطط المدفوعة</Text>
        </TouchableOpacity>
      </View>

      <Text style={styles.note}>
        * لا يلزم وجود بطاقة ائتمان. تنتهي الفترة تلقائياً بعد 30 يوماً.
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC' },
  content: { padding: 25, paddingTop: 60, alignItems: 'center' },
  header: { alignItems: 'center', marginBottom: 40 },
  title: { fontSize: 22, fontFamily: 'Tajawal-Bold', color: Colors.navy, textAlign: 'center', marginTop: 20 },
  subtitle: { fontSize: 14, fontFamily: 'Tajawal-Medium', color: '#64748B', textAlign: 'center', marginTop: 10, lineHeight: 22 },
  featuresCard: {
    backgroundColor: '#FFF',
    width: '100%',
    borderRadius: 24,
    padding: 25,
    borderWidth: 1,
    borderColor: '#F1F5F9',
    elevation: 4,
    marginBottom: 40,
  },
  featureItem: { flexDirection: 'row-reverse', alignItems: 'center', gap: 12, marginBottom: 15 },
  featureText: { fontSize: 14, fontFamily: 'Tajawal-Bold', color: '#334155' },
  actions: { width: '100%', gap: 15 },
  primaryBtn: { backgroundColor: Colors.navy, borderRadius: 16, paddingVertical: 18, alignItems: 'center', elevation: 5 },
  primaryText: { color: '#FFF', fontFamily: 'Tajawal-Bold', fontSize: 16 },
  secondaryBtn: { paddingVertical: 12, alignItems: 'center' },
  secondaryText: { color: Colors.gold, fontFamily: 'Tajawal-Bold', fontSize: 14 },
  note: { marginTop: 30, fontSize: 11, fontFamily: 'Tajawal-Medium', color: '#94A3B8', textAlign: 'center' }
});
