// src/shared/utils/shadows.js
// =============================================
// نظام الظلال الموحد (Shadows System)
// مجموعة من الثوابت والدوال لإدارة الظلال في التطبيق
// =============================================

import { Platform } from 'react-native';

// =============================================
// 1. الثوابت الأساسية
// =============================================

/**
 * مستويات الظلال المتاحة
 */
export const SHADOW_LEVELS = {
  /** لا ظل */
  NONE: 0,
  /** ظل خفيف جداً */
  EXTRA_LIGHT: 1,
  /** ظل خفيف */
  LIGHT: 2,
  /** ظل متوسط */
  MEDIUM: 3,
  /** ظل ثقيل */
  HEAVY: 4,
  /** ظل ثقيل جداً */
  EXTRA_HEAVY: 5,
};

// =============================================
// 2. تعريفات الظلال
// =============================================

/**
 * الظلال حسب المستوى
 */
export const shadows = {
  /** لا ظل */
  none: {
    shadowColor: 'transparent',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0,
    shadowRadius: 0,
    elevation: 0,
  },

  /** ظل خفيف جداً */
  extraLight: {
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },

  /** ظل خفيف */
  light: {
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },

  /** ظل متوسط */
  medium: {
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 8,
    elevation: 4,
  },

  /** ظل ثقيل */
  heavy: {
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.16,
    shadowRadius: 16,
    elevation: 8,
  },

  /** ظل ثقيل جداً */
  extraHeavy: {
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 16 },
    shadowOpacity: 0.2,
    shadowRadius: 32,
    elevation: 16,
  },
};

// =============================================
// 3. دوال إنشاء الظلال
// =============================================

/**
 * إنشاء ظل مخصص
 * @param {Object} options - خيارات الظل
 * @param {string} options.color - لون الظل
 * @param {number} options.offsetX - الإزاحة الأفقية
 * @param {number} options.offsetY - الإزاحة الرأسية
 * @param {number} options.opacity - شفافية الظل (0-1)
 * @param {number} options.radius - نصف قطر الظل
 * @param {number} options.elevation - مستوى الارتفاع (Android)
 * @returns {Object}
 */
export const createShadow = (options = {}) => {
  const {
    color = '#000000',
    offsetX = 0,
    offsetY = 4,
    opacity = 0.12,
    radius = 8,
    elevation = 4,
  } = options;

  return {
    shadowColor: color,
    shadowOffset: { width: offsetX, height: offsetY },
    shadowOpacity: opacity,
    shadowRadius: radius,
    elevation,
  };
};

/**
 * إنشاء ظل ملون
 * @param {string} color - لون الظل
 * @param {number} level - مستوى الظل
 * @returns {Object}
 */
export const createColoredShadow = (color, level = SHADOW_LEVELS.MEDIUM) => {
  const baseShadow = getShadow(level);
  return {
    ...baseShadow,
    shadowColor: color,
  };
};

/**
 * إنشاء ظل مع إزاحة مخصصة
 * @param {number} offsetX - الإزاحة الأفقية
 * @param {number} offsetY - الإزاحة الرأسية
 * @param {number} level - مستوى الظل
 * @returns {Object}
 */
export const createOffsetShadow = (offsetX, offsetY, level = SHADOW_LEVELS.MEDIUM) => {
  const baseShadow = getShadow(level);
  return {
    ...baseShadow,
    shadowOffset: { width: offsetX, height: offsetY },
  };
};

// =============================================
// 4. دوال الحصول على الظلال
// =============================================

/**
 * الحصول على ظل حسب المستوى
 * @param {number|string} level - مستوى الظل
 * @returns {Object}
 */
export const getShadow = (level) => {
  const levelMap = {
    0: 'none',
    1: 'extraLight',
    2: 'light',
    3: 'medium',
    4: 'heavy',
    5: 'extraHeavy',
    none: 'none',
    extraLight: 'extraLight',
    light: 'light',
    medium: 'medium',
    heavy: 'heavy',
    extraHeavy: 'extraHeavy',
  };

  const key = levelMap[level] || 'medium';
  return shadows[key] || shadows.medium;
};

/**
 * الحصول على ظل لـ iOS
 * @param {number} level - مستوى الظل
 * @returns {Object}
 */
export const getIOSShadow = (level = SHADOW_LEVELS.MEDIUM) => {
  const shadow = getShadow(level);
  return {
    shadowColor: shadow.shadowColor,
    shadowOffset: shadow.shadowOffset,
    shadowOpacity: shadow.shadowOpacity,
    shadowRadius: shadow.shadowRadius,
  };
};

/**
 * الحصول على ظل لـ Android
 * @param {number} level - مستوى الظل
 * @returns {Object}
 */
export const getAndroidShadow = (level = SHADOW_LEVELS.MEDIUM) => {
  const shadow = getShadow(level);
  return {
    elevation: shadow.elevation,
  };
};

/**
 * الحصول على ظل حسب المنصة
 * @param {number} level - مستوى الظل
 * @returns {Object}
 */
export const getPlatformShadow = (level = SHADOW_LEVELS.MEDIUM) => {
  if (Platform.OS === 'ios') {
    return getIOSShadow(level);
  }
  return getAndroidShadow(level);
};

// =============================================
// 5. دوال الظلال للبطاقات
// =============================================

/**
 * ظل البطاقة (قابل للضغط)
 * @param {number} level - مستوى الظل
 * @returns {Object}
 */
export const cardShadow = (level = SHADOW_LEVELS.LIGHT) => {
  return getShadow(level);
};

/**
 * ظل البطاقة عند الضغط
 * @param {number} level - مستوى الظل
 * @returns {Object}
 */
export const cardPressedShadow = (level = SHADOW_LEVELS.MEDIUM) => {
  return getShadow(level);
};

/**
 * ظل الزر
 * @param {number} level - مستوى الظل
 * @returns {Object}
 */
export const buttonShadow = (level = SHADOW_LEVELS.LIGHT) => {
  return getShadow(level);
};

/**
 * ظل المودال
 * @param {number} level - مستوى الظل
 * @returns {Object}
 */
export const modalShadow = (level = SHADOW_LEVELS.HEAVY) => {
  return getShadow(level);
};

/**
 * ظل القائمة المنسدلة
 * @param {number} level - مستوى الظل
 * @returns {Object}
 */
export const dropdownShadow = (level = SHADOW_LEVELS.MEDIUM) => {
  return getShadow(level);
};

// =============================================
// 6. دوال مساعدة
// =============================================

/**
 * دمج الظلال
 * @param {...Object} shadows - الظلال
 * @returns {Object}
 */
export const mergeShadows = (...shadows) => {
  return Object.assign({}, ...shadows);
};

/**
 * تحويل الظل إلى صيغة (string)
 * @param {Object} shadow - الظل
 * @returns {string}
 */
export const shadowToString = (shadow) => {
  const { shadowColor, shadowOffset, shadowOpacity, shadowRadius } = shadow;
  return `${shadowColor} ${shadowOffset.width}px ${shadowOffset.height}px ${shadowRadius}px rgba(0,0,0,${shadowOpacity})`;
};

// =============================================
// 7. كائن الظلال الرئيسي
// =============================================

export const shadowSystem = {
  // الثوابت
  levels: SHADOW_LEVELS,

  // الظلال الأساسية
  ...shadows,

  // دوال الإنشاء
  create: createShadow,
  createColored: createColoredShadow,
  createOffset: createOffsetShadow,

  // دوال الحصول
  get: getShadow,
  getIOS: getIOSShadow,
  getAndroid: getAndroidShadow,
  getPlatform: getPlatformShadow,

  // دوال البطاقات
  card: cardShadow,
  cardPressed: cardPressedShadow,
  button: buttonShadow,
  modal: modalShadow,
  dropdown: dropdownShadow,

  // دوال مساعدة
  merge: mergeShadows,
  toString: shadowToString,
};

export default shadowSystem;