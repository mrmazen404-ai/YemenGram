// src/shared/hooks/useCurrency.js
// =============================================
// Hook إدارة العملات (Currency Management)
// يدير العملات، أسعار الصرف، والتحويل بينها
// =============================================

import { useState, useEffect, useCallback, useMemo } from 'react';
import { LocalDB } from '../services/storageService';
import { Logger } from '../utils/logger';

// =============================================
// الثوابت
// =============================================

const SUPPORTED_CURRENCIES = {
  YER: { code: 'YER', name: 'ريال يمني', symbol: 'ريال', flag: '🇾🇪', decimal: 0 },
  SAR: { code: 'SAR', name: 'ريال سعودي', symbol: 'ر.س', flag: '🇸🇦', decimal: 2 },
  USD: { code: 'USD', name: 'دولار أمريكي', symbol: '$', flag: '🇺🇸', decimal: 2 },
};

const DEFAULT_CURRENCY = 'YER';
const EXCHANGE_RATE_CACHE_TTL = 5 * 60 * 1000; // 5 دقائق

// =============================================
// Hook الرئيسي
// =============================================

export function useCurrency(options = {}) {
  const {
    // ===== الأساسيات =====
    baseCurrency: initialBaseCurrency = DEFAULT_CURRENCY,
    autoLoad = true,

    // ===== التخزين المؤقت =====
    cacheEnabled = true,
    cacheTTL = EXCHANGE_RATE_CACHE_TTL,

    // ===== التخصيص =====
    fallbackRate = 1,
    debug = false,
  } = options;

  // ===== الحالة =====
  const [baseCurrency, setBaseCurrency] = useState(initialBaseCurrency);
  const [currencies, setCurrencies] = useState(SUPPORTED_CURRENCIES);
  const [exchangeRates, setExchangeRates] = useState({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [currencyList, setCurrencyList] = useState(Object.keys(SUPPORTED_CURRENCIES));

  // =============================================
  // 1. تحميل العملات
  // =============================================

  /**
   * تحميل العملات من قاعدة البيانات
   */
  const loadCurrencies = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      // محاولة جلب من قاعدة البيانات
      const dbCurrencies = await LocalDB.query('SELECT * FROM currencies WHERE is_active = 1');

      if (dbCurrencies && dbCurrencies.length > 0) {
        const formattedCurrencies = {};
        const list = [];
        for (const cur of dbCurrencies) {
          formattedCurrencies[cur.code] = {
            code: cur.code,
            name: cur.name,
            symbol: cur.symbol || cur.code,
            flag: cur.flag || '',
            decimal: cur.decimal || 2,
            exchange_rate: cur.exchange_rate || 1,
            is_base: cur.is_base === 1,
          };
          list.push(cur.code);
        }
        setCurrencies(formattedCurrencies);
        setCurrencyList(list);

        // تحديث العملة الأساسية
        const base = dbCurrencies.find(c => c.is_base === 1);
        if (base) {
          setBaseCurrency(base.code);
        }
      } else {
        // استخدام العملات الافتراضية
        setCurrencies(SUPPORTED_CURRENCIES);
        setCurrencyList(Object.keys(SUPPORTED_CURRENCIES));

        // حفظ العملات الافتراضية في قاعدة البيانات
        await seedCurrencies();
      }

      // تحميل أسعار الصرف
      await loadExchangeRates();

      if (debug) {
        console.log('💰 [useCurrency] تم تحميل العملات');
      }
    } catch (error) {
      console.log('❌ [useCurrency] خطأ في تحميل العملات:', error.message);
      setError(error.message);
      // استخدام العملات الافتراضية
      setCurrencies(SUPPORTED_CURRENCIES);
      setCurrencyList(Object.keys(SUPPORTED_CURRENCIES));
    } finally {
      setLoading(false);
    }
  }, [debug]);

  /**
   * تهيئة العملات الافتراضية
   */
  const seedCurrencies = useCallback(async () => {
    try {
      for (const [code, data] of Object.entries(SUPPORTED_CURRENCIES)) {
        const exists = await LocalDB.queryOne(
          'SELECT id FROM currencies WHERE code = ?',
          [code]
        );
        if (!exists) {
          await LocalDB.execute(
            `INSERT INTO currencies
             (id, code, name, symbol, exchange_rate, is_base, is_active)
             VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [
              `cur_${code}`,
              code,
              data.name,
              data.symbol,
              code === DEFAULT_CURRENCY ? 1 : 1,
              code === DEFAULT_CURRENCY ? 1 : 0,
              1,
            ]
          );
        }
      }
      if (debug) {
        console.log('💰 [useCurrency] تم تهيئة العملات الافتراضية');
      }
    } catch (error) {
      console.log('❌ [useCurrency] خطأ في تهيئة العملات:', error.message);
    }
  }, [debug]);

  /**
   * تحميل أسعار الصرف
   */
  const loadExchangeRates = useCallback(async () => {
    try {
      // محاولة جلب من الكاش
      if (cacheEnabled) {
        const cached = await LocalDB.getSetting('exchange_rates_cache');
        const cachedTime = await LocalDB.getSetting('exchange_rates_cache_time');

        if (cached && cachedTime) {
          const age = Date.now() - parseInt(cachedTime);
          if (age < cacheTTL) {
            const rates = JSON.parse(cached);
            setExchangeRates(rates);
            setLastUpdated(parseInt(cachedTime));
            if (debug) {
              console.log('💰 [useCurrency] استخدام أسعار الصرف المخزنة مؤقتاً');
            }
            return;
          }
        }
      }

      // جلب من قاعدة البيانات
      const dbRates = await LocalDB.query('SELECT code, exchange_rate FROM currencies WHERE is_active = 1');

      const rates = {};
      for (const row of dbRates) {
        rates[row.code] = row.exchange_rate || 1;
      }

      setExchangeRates(rates);
      setLastUpdated(Date.now());

      // تخزين في الكاش
      if (cacheEnabled) {
        await LocalDB.saveSetting('exchange_rates_cache', JSON.stringify(rates));
        await LocalDB.saveSetting('exchange_rates_cache_time', Date.now().toString());
      }

      if (debug) {
        console.log('💰 [useCurrency] تم تحميل أسعار الصرف');
      }
    } catch (error) {
      console.log('❌ [useCurrency] خطأ في تحميل أسعار الصرف:', error.message);
      // استخدام القيم الافتراضية
      const defaultRates = {};
      for (const code of Object.keys(SUPPORTED_CURRENCIES)) {
        defaultRates[code] = 1;
      }
      setExchangeRates(defaultRates);
    }
  }, [cacheEnabled, cacheTTL, debug]);

  // =============================================
  // 2. تحويل العملات
  // =============================================

  /**
   * تحويل مبلغ من عملة إلى أخرى
   */
  const convert = useCallback((amount, fromCurrency, toCurrency) => {
    if (!amount || amount === 0) return 0;
    if (fromCurrency === toCurrency) return amount;

    const fromRate = exchangeRates[fromCurrency] || 1;
    const toRate = exchangeRates[toCurrency] || 1;

    if (fromRate === 0 || toRate === 0) return amount;

    // التحويل: المبلغ × (سعر الهدف / سعر المصدر)
    const result = amount * (toRate / fromRate);
    return Math.round(result * 100) / 100;
  }, [exchangeRates]);

  /**
   * تحويل المبلغ مع التنسيق
   */
  const convertAndFormat = useCallback((amount, fromCurrency, toCurrency, options = {}) => {
    const converted = convert(amount, fromCurrency, toCurrency);
    return formatCurrency(converted, toCurrency, options);
  }, [convert]);

  /**
   * تحويل المبلغ إلى العملة الأساسية
   */
  const convertToBase = useCallback((amount, fromCurrency) => {
    return convert(amount, fromCurrency, baseCurrency);
  }, [convert, baseCurrency]);

  /**
   * تحويل المبلغ من العملة الأساسية
   */
  const convertFromBase = useCallback((amount, toCurrency) => {
    return convert(amount, baseCurrency, toCurrency);
  }, [convert, baseCurrency]);

  // =============================================
  // 3. تنسيق العملات
  // =============================================

  /**
   * تنسيق المبلغ مع العملة
   */
  const formatCurrency = useCallback((amount, currencyCode = baseCurrency, options = {}) => {
    const {
      showSymbol = true,
      showCode = false,
      decimalPlaces = null,
      useGrouping = true,
    } = options;

    const currency = currencies[currencyCode];
    if (!currency) {
      return `${amount} ${currencyCode}`;
    }

    const decimals = decimalPlaces !== null ? decimalPlaces : (currency.decimal || 2);
    const formatted = amount.toFixed(decimals);

    let result = '';
    if (showSymbol && currency.symbol) {
      result += `${currency.symbol} `;
    }
    result += useGrouping ? Number(formatted).toLocaleString() : formatted;
    if (showCode) {
      result += ` ${currency.code}`;
    }

    return result.trim();
  }, [currencies, baseCurrency]);

  /**
   * تنسيق المبلغ مع العملة (بسيط)
   */
  const formatCurrencySimple = useCallback((amount, currencyCode = baseCurrency) => {
    return formatCurrency(amount, currencyCode, { showSymbol: true, showCode: false });
  }, [formatCurrency, baseCurrency]);

  /**
   * تنسيق المبلغ مع رمز العملة فقط
   */
  const formatCurrencyWithSymbol = useCallback((amount, currencyCode = baseCurrency) => {
    const currency = currencies[currencyCode];
    const symbol = currency?.symbol || currencyCode;
    return `${symbol} ${Number(amount).toFixed(2)}`;
  }, [currencies, baseCurrency]);

  /**
   * تنسيق المبلغ مع كود العملة
   */
  const formatCurrencyWithCode = useCallback((amount, currencyCode = baseCurrency) => {
    return `${Number(amount).toFixed(2)} ${currencyCode}`;
  }, [baseCurrency]);

  // =============================================
  // 4. إدارة العملات
  // =============================================

  /**
   * تغيير العملة الأساسية
   */
  const setBaseCurrencyManually = useCallback(async (newBaseCurrency) => {
    if (!currencies[newBaseCurrency]) {
      throw new Error(`العملة ${newBaseCurrency} غير مدعومة`);
    }

    try {
      await LocalDB.execute(
        'UPDATE currencies SET is_base = 0 WHERE is_base = 1'
      );
      await LocalDB.execute(
        'UPDATE currencies SET is_base = 1 WHERE code = ?',
        [newBaseCurrency]
      );

      setBaseCurrency(newBaseCurrency);
      await LocalDB.saveSetting('base_currency', newBaseCurrency);

      if (debug) {
        console.log(`💰 [useCurrency] تم تغيير العملة الأساسية إلى ${newBaseCurrency}`);
      }
    } catch (error) {
      console.log('❌ [useCurrency] خطأ في تغيير العملة الأساسية:', error.message);
      throw error;
    }
  }, [currencies, debug]);

  /**
   * تحديث سعر صرف عملة
   */
  const updateExchangeRate = useCallback(async (currencyCode, newRate) => {
    if (!currencies[currencyCode]) {
      throw new Error(`العملة ${currencyCode} غير مدعومة`);
    }

    try {
      await LocalDB.execute(
        'UPDATE currencies SET exchange_rate = ? WHERE code = ?',
        [newRate, currencyCode]
      );

      // تحديث الحالة
      setExchangeRates(prev => ({
        ...prev,
        [currencyCode]: newRate,
      }));

      // تحديث الكاش
      if (cacheEnabled) {
        const rates = { ...exchangeRates, [currencyCode]: newRate };
        await LocalDB.saveSetting('exchange_rates_cache', JSON.stringify(rates));
        await LocalDB.saveSetting('exchange_rates_cache_time', Date.now().toString());
      }

      if (debug) {
        console.log(`💰 [useCurrency] تم تحديث سعر صرف ${currencyCode} إلى ${newRate}`);
      }
    } catch (error) {
      console.log('❌ [useCurrency] خطأ في تحديث سعر الصرف:', error.message);
      throw error;
    }
  }, [currencies, exchangeRates, cacheEnabled, debug]);

  /**
   * تحديث جميع أسعار الصرف
   */
  const updateAllExchangeRates = useCallback(async (newRates) => {
    try {
      for (const [code, rate] of Object.entries(newRates)) {
        if (currencies[code]) {
          await LocalDB.execute(
            'UPDATE currencies SET exchange_rate = ? WHERE code = ?',
            [rate, code]
          );
        }
      }

      setExchangeRates(newRates);

      if (cacheEnabled) {
        await LocalDB.saveSetting('exchange_rates_cache', JSON.stringify(newRates));
        await LocalDB.saveSetting('exchange_rates_cache_time', Date.now().toString());
      }

      if (debug) {
        console.log('💰 [useCurrency] تم تحديث جميع أسعار الصرف');
      }
    } catch (error) {
      console.log('❌ [useCurrency] خطأ في تحديث أسعار الصرف:', error.message);
      throw error;
    }
  }, [currencies, cacheEnabled, debug]);

  // =============================================
  // 5. دوال مساعدة
  // =============================================

  /**
   * الحصول على معلومات عملة
   */
  const getCurrencyInfo = useCallback((currencyCode) => {
    return currencies[currencyCode] || null;
  }, [currencies]);

  /**
   * الحصول على رمز العملة
   */
  const getCurrencySymbol = useCallback((currencyCode) => {
    const info = getCurrencyInfo(currencyCode);
    return info?.symbol || currencyCode;
  }, [getCurrencyInfo]);

  /**
   * الحصول على اسم العملة
   */
  const getCurrencyName = useCallback((currencyCode) => {
    const info = getCurrencyInfo(currencyCode);
    return info?.name || currencyCode;
  }, [getCurrencyInfo]);

  /**
   * الحصول على سعر صرف العملة
   */
  const getExchangeRate = useCallback((currencyCode) => {
    return exchangeRates[currencyCode] || 1;
  }, [exchangeRates]);

  /**
   * إعادة تحميل أسعار الصرف
   */
  const refreshRates = useCallback(async () => {
    await loadExchangeRates();
  }, [loadExchangeRates]);

  /**
   * إعادة تحميل جميع العملات
   */
  const refreshCurrencies = useCallback(async () => {
    await loadCurrencies();
  }, [loadCurrencies]);

  // =============================================
  // 6. تأثيرات (Effects)
  // =============================================

  // التحميل الأولي
  useEffect(() => {
    if (autoLoad) {
      loadCurrencies();
    }
  }, [autoLoad, loadCurrencies]);

  // تحميل العملة الأساسية من الإعدادات
  useEffect(() => {
    const loadBaseCurrency = async () => {
      const saved = await LocalDB.getSetting('base_currency');
      if (saved && currencies[saved]) {
        setBaseCurrency(saved);
      }
    };
    if (autoLoad) {
      loadBaseCurrency();
    }
  }, [autoLoad, currencies]);

  // =============================================
  // 7. القيمة المرجعة
  // =============================================

  return {
    // الحالة
    baseCurrency,
    currencies,
    exchangeRates,
    currencyList,
    loading,
    error,
    lastUpdated,

    // دوال التحويل
    convert,
    convertAndFormat,
    convertToBase,
    convertFromBase,

    // دوال التنسيق
    formatCurrency,
    formatCurrencySimple,
    formatCurrencyWithSymbol,
    formatCurrencyWithCode,

    // دوال الإدارة
    setBaseCurrency: setBaseCurrencyManually,
    updateExchangeRate,
    updateAllExchangeRates,
    refreshRates,
    refreshCurrencies,

    // دوال المساعدة
    getCurrencyInfo,
    getCurrencySymbol,
    getCurrencyName,
    getExchangeRate,
    getSupportedCurrencies: () => currencies,
  };
}

// =============================================
// Hook مساعد: تحويل العملات في النماذج
// =============================================

export function useCurrencyField(initialCurrency = DEFAULT_CURRENCY) {
  const [currency, setCurrency] = useState(initialCurrency);
  const [amount, setAmount] = useState(0);
  const [convertedAmount, setConvertedAmount] = useState(0);
  const [targetCurrency, setTargetCurrency] = useState(DEFAULT_CURRENCY);

  const { convert, formatCurrency, getExchangeRate } = useCurrency();

  useEffect(() => {
    if (amount && currency && targetCurrency) {
      const converted = convert(amount, currency, targetCurrency);
      setConvertedAmount(converted);
    }
  }, [amount, currency, targetCurrency, convert]);

  const updateAmount = useCallback((newAmount, fromCurrency = currency, toCurrency = targetCurrency) => {
    setAmount(newAmount);
    setCurrency(fromCurrency);
    setTargetCurrency(toCurrency);
    if (newAmount && fromCurrency && toCurrency) {
      const converted = convert(newAmount, fromCurrency, toCurrency);
      setConvertedAmount(converted);
    }
  }, [currency, targetCurrency, convert]);

  return {
    amount,
    currency,
    targetCurrency,
    convertedAmount,
    setAmount,
    setCurrency,
    setTargetCurrency,
    updateAmount,
    getExchangeRate: () => getExchangeRate(currency),
    format: (val) => formatCurrency(val, currency),
  };
}

export default useCurrency;