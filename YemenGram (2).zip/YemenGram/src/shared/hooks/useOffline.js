// src/shared/hooks/useOffline.js
// =============================================
// Hook مراقبة حالة الاتصال بالإنترنت (Offline/Online)
// يستخدم لتتبع حالة الشبكة وتنفيذ إجراءات عند التغيير
// =============================================

import { useState, useEffect, useCallback, useRef } from 'react';
import { NetInfo } from '@react-native-community/netinfo';
import { Platform } from 'react-native';

// =============================================
// الثوابت
// =============================================

const CHECK_INTERVAL = 30000; // 30 ثانية
const RETRY_INTERVAL = 5000; // 5 ثوانٍ

// =============================================
// Hook الرئيسي
// =============================================

export function useOffline(options = {}) {
  const {
    // ===== الأساسيات =====
    onOnline,           // دالة تُستدعى عند الاتصال
    onOffline,          // دالة تُستدعى عند الانقطاع
    onReconnect,        // دالة تُستدعى عند إعادة الاتصال بعد انقطاع

    // ===== التخصيص =====
    checkInterval = CHECK_INTERVAL,
    retryInterval = RETRY_INTERVAL,
    autoCheck = true,   // فحص تلقائي دوري

    // ===== التحميل =====
    initialCheck = true, // فحص أولي عند التحميل
  } = options;

  // ===== الحالة =====
  const [isConnected, setIsConnected] = useState(true);
  const [isInternetReachable, setIsInternetReachable] = useState(true);
  const [connectionType, setConnectionType] = useState(null);
  const [isChecking, setIsChecking] = useState(false);
  const [lastChecked, setLastChecked] = useState(null);
  const [offlineSince, setOfflineSince] = useState(null);
  const [reconnectAttempts, setReconnectAttempts] = useState(0);

  // ===== المراجع =====
  const checkTimer = useRef(null);
  const retryTimer = useRef(null);
  const isFirstCheck = useRef(true);
  const wasConnected = useRef(true);

  // =============================================
  // 1. دوال الفحص الأساسية
  // =============================================

  /**
   * فحص حالة الاتصال
   * @returns {Promise<{isConnected: boolean, isInternetReachable: boolean, type: string}>}
   */
  const checkConnection = useCallback(async () => {
    try {
      setIsChecking(true);
      const state = await NetInfo.fetch();

      const connected = state.isConnected === true;
      const reachable = state.isInternetReachable === true;
      const type = state.type || 'unknown';

      // تحديث الحالة
      setConnectionType(type);
      setIsConnected(connected);
      setIsInternetReachable(reachable);
      setLastChecked(new Date());

      // معالجة تغيير الحالة
      if (connected !== wasConnected.current) {
        if (connected) {
          // أصبح متصلاً
          console.log('📶 [useOffline] ✅ اتصال بالإنترنت');
          if (onOnline) onOnline({ type, reachable });

          // إذا كان هناك انقطاع سابق
          if (offlineSince) {
            const offlineDuration = Date.now() - offlineSince;
            console.log(`📶 [useOffline] ⏱️ انقطاع استمر ${Math.floor(offlineDuration / 1000)} ثانية`);
            if (onReconnect) onReconnect({
              duration: offlineDuration,
              attempts: reconnectAttempts,
              type,
            });
            setOfflineSince(null);
            setReconnectAttempts(0);
          }
        } else {
          // أصبح غير متصل
          console.log('📶 [useOffline] ❌ انقطاع الاتصال');
          setOfflineSince(Date.now());
          if (onOffline) onOffline({ type });
        }
        wasConnected.current = connected;
      }

      // إذا كان متصلاً ولكن الإنترنت غير متاح
      if (connected && !reachable) {
        console.log('📶 [useOffline] ⚠️ متصل بالشبكة ولكن لا يوجد إنترنت');
      }

      return { isConnected: connected, isInternetReachable: reachable, type };
    } catch (error) {
      console.log('❌ [useOffline] خطأ في فحص الاتصال:', error.message);
      return { isConnected: false, isInternetReachable: false, type: 'unknown' };
    } finally {
      setIsChecking(false);
      isFirstCheck.current = false;
    }
  }, [offlineSince, reconnectAttempts, onOnline, onOffline, onReconnect]);

  /**
   * إعادة محاولة الاتصال
   */
  const retryConnection = useCallback(async () => {
    console.log('🔄 [useOffline] محاولة إعادة الاتصال...');
    setReconnectAttempts(prev => prev + 1);
    const result = await checkConnection();

    if (!result.isConnected || !result.isInternetReachable) {
      // إذا فشلت، جدولة محاولة أخرى
      if (retryTimer.current) clearTimeout(retryTimer.current);
      retryTimer.current = setTimeout(() => {
        retryConnection();
      }, retryInterval);
    } else {
      console.log('✅ [useOffline] تمت إعادة الاتصال بنجاح');
      if (retryTimer.current) clearTimeout(retryTimer.current);
    }
  }, [checkConnection, retryInterval]);

  // =============================================
  // 2. تأثيرات (Effects)
  // =============================================

  // ----- 2.1 الفحص الأولي -----
  useEffect(() => {
    if (initialCheck) {
      checkConnection();
    }
  }, []);

  // ----- 2.2 مراقبة التغييرات -----
  useEffect(() => {
    const unsubscribe = NetInfo.addEventListener((state) => {
      const connected = state.isConnected === true;
      const reachable = state.isInternetReachable === true;
      const type = state.type || 'unknown';

      setIsConnected(connected);
      setIsInternetReachable(reachable);
      setConnectionType(type);
      setLastChecked(new Date());

      // معالجة التغيير التلقائي
      if (connected !== wasConnected.current) {
        if (connected) {
          console.log('📶 [useOffline] ✅ اتصال بالإنترنت (تلقائي)');
          if (onOnline) onOnline({ type, reachable });
          if (offlineSince) {
            const duration = Date.now() - offlineSince;
            if (onReconnect) onReconnect({ duration, attempts: reconnectAttempts, type });
            setOfflineSince(null);
            setReconnectAttempts(0);
          }
        } else {
          console.log('📶 [useOffline] ❌ انقطاع الاتصال (تلقائي)');
          setOfflineSince(Date.now());
          if (onOffline) onOffline({ type });
        }
        wasConnected.current = connected;
      }
    });

    return () => unsubscribe();
  }, [offlineSince, reconnectAttempts, onOnline, onOffline, onReconnect]);

  // ----- 2.3 الفحص الدوري التلقائي -----
  useEffect(() => {
    if (!autoCheck) return;

    checkTimer.current = setInterval(() => {
      checkConnection();
    }, checkInterval);

    return () => {
      if (checkTimer.current) clearInterval(checkTimer.current);
    };
  }, [autoCheck, checkInterval, checkConnection]);

  // ----- 2.4 تنظيف المؤقتات -----
  useEffect(() => {
    return () => {
      if (checkTimer.current) clearInterval(checkTimer.current);
      if (retryTimer.current) clearTimeout(retryTimer.current);
    };
  }, []);

  // =============================================
  // 3. دوال مساعدة
  // =============================================

  /**
   * الحصول على حالة الاتصال كـ Boolean
   */
  const getConnectionStatus = useCallback(() => {
    return isConnected && isInternetReachable;
  }, [isConnected, isInternetReachable]);

  /**
   * الحصول على وصف حالة الاتصال
   */
  const getConnectionStatusText = useCallback(() => {
    if (!isConnected) return 'غير متصل';
    if (!isInternetReachable) return 'متصل بدون إنترنت';
    return 'متصل';
  }, [isConnected, isInternetReachable]);

  /**
   * الحصول على لون حالة الاتصال
   */
  const getConnectionStatusColor = useCallback(() => {
    if (!isConnected || !isInternetReachable) return '#E74C3C';
    return '#27AE60';
  }, [isConnected, isInternetReachable]);

  /**
   * الحصول على أيقونة حالة الاتصال
   */
  const getConnectionStatusIcon = useCallback(() => {
    if (!isConnected) return 'wifi-outline';
    if (!isInternetReachable) return 'cloud-offline-outline';
    return 'wifi';
  }, [isConnected, isInternetReachable]);

  /**
   * الحصول على مدة الانقطاع (بالثواني)
   */
  const getOfflineDuration = useCallback(() => {
    if (!offlineSince) return 0;
    return Math.floor((Date.now() - offlineSince) / 1000);
  }, [offlineSince]);

  /**
   * الحصول على مدة الانقطاع كـ نص مقروء
   */
  const getOfflineDurationText = useCallback(() => {
    const seconds = getOfflineDuration();
    if (seconds < 60) return `${seconds} ثانية`;
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes} دقيقة`;
    const hours = Math.floor(minutes / 60);
    return `${hours} ساعة و ${minutes % 60} دقيقة`;
  }, [getOfflineDuration]);

  /**
   * إعادة تعيين محاولات إعادة الاتصال
   */
  const resetReconnectAttempts = useCallback(() => {
    setReconnectAttempts(0);
  }, []);

  /**
   * فحص الاتصال يدوياً
   */
  const refresh = useCallback(async () => {
    return await checkConnection();
  }, [checkConnection]);

  // =============================================
  // 4. القيمة المرجعة
  // =============================================

  return {
    // الحالة
    isConnected,
    isInternetReachable,
    connectionType,
    isChecking,
    lastChecked,
    offlineSince,
    reconnectAttempts,

    // دوال الفحص
    checkConnection,
    refresh,
    retryConnection,

    // دوال الحصول على المعلومات
    getConnectionStatus,
    getConnectionStatusText,
    getConnectionStatusColor,
    getConnectionStatusIcon,
    getOfflineDuration,
    getOfflineDurationText,

    // دوال إعادة التعيين
    resetReconnectAttempts,

    // دوال مساعدة
    isOnline: getConnectionStatus(),
    isOffline: !getConnectionStatus(),
  };
}

// =============================================
// Hook مخصص للاستخدام مع عمليات Offline
// =============================================

export function useOfflineAction(action, options = {}) {
  const {
    retryOnReconnect = true,
    maxRetries = 3,
    onSuccess,
    onError,
    onRetry,
  } = options;

  const [executing, setExecuting] = useState(false);
  const [error, setError] = useState(null);
  const [retryCount, setRetryCount] = useState(0);
  const [pendingAction, setPendingAction] = useState(null);

  const { isConnected, isInternetReachable, onReconnect } = useOffline({
    onReconnect: () => {
      if (retryOnReconnect && pendingAction) {
        console.log('🔄 [useOfflineAction] إعادة محاولة الإجراء عند الاتصال');
        executePendingAction();
      }
    },
  });

  const isOnline = isConnected && isInternetReachable;

  const executePendingAction = async () => {
    if (!pendingAction) return;
    setExecuting(true);
    try {
      const result = await pendingAction();
      if (onSuccess) onSuccess(result);
      setPendingAction(null);
      setRetryCount(0);
    } catch (err) {
      setError(err);
      if (onError) onError(err);
      if (retryCount < maxRetries) {
        setRetryCount(prev => prev + 1);
        if (onRetry) onRetry(retryCount + 1);
        // جدولة محاولة أخرى
        setTimeout(() => {
          executePendingAction();
        }, 2000 * (retryCount + 1));
      }
    } finally {
      setExecuting(false);
    }
  };

  const execute = useCallback(async (...args) => {
    setError(null);

    if (!isOnline) {
      // تخزين الإجراء لتنفيذه لاحقاً عند الاتصال
      setPendingAction(() => () => action(...args));
      console.log('📶 [useOfflineAction] ⏳ الإجراء معلق (غير متصل)');
      return { status: 'pending', message: 'في انتظار الاتصال' };
    }

    setExecuting(true);
    try {
      const result = await action(...args);
      if (onSuccess) onSuccess(result);
      return { status: 'success', result };
    } catch (err) {
      setError(err);
      if (onError) onError(err);
      return { status: 'error', error: err };
    } finally {
      setExecuting(false);
    }
  }, [action, isOnline, onSuccess, onError]);

  const cancelPending = useCallback(() => {
    setPendingAction(null);
    setRetryCount(0);
  }, []);

  return {
    execute,
    executing,
    error,
    retryCount,
    isOnline,
    hasPendingAction: !!pendingAction,
    cancelPending,
  };
}

export default useOffline;