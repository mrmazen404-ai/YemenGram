import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, Platform } from 'react-native';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';
import LocalDB from '../../database/localDB';
import SubscriptionDialog from '../components/SubscriptionDialog';
import { Colors } from '../../../shared/utils/colors';
import SubscriptionAnalytics from '../services/SubscriptionAnalytics';
import ResourceUsageBar from '../components/ResourceUsageBar';

// الخرائط الرسمية بناءً على مصفوفة السيادة
const PLAN_LABELS = {
  free: 'المجاني',
  trial: 'التجريبي',
  monthly: 'الشهري',
  annual: 'السنوي',
  enterprise: 'المؤسساتي',
};

const STATUS_MAP = {
  ACTIVE_FULL: { label: 'نشط (سيادة كاملة)', color: '#0F172A', icon: 'shield-check' },
  TRIAL_ACTIVE: { label: 'فترة تجريبية نشطة', color: '#D4A853', icon: 'clock-outline' },
  TRIAL_EXPIRED: { label: 'انتهت الفترة التجريبية', color: '#EF4444', icon: 'timer-off' },
  VERIFICATION_PENDING: { label: 'قيد التدقيق', color: '#3B82F6', icon: 'sync' },
  EXPIRED_GRACE: { label: 'منتهي (قراءة فقط)', color: '#94A3B8', icon: 'lock-outline' },
  RESOURCES_EXCEEDED: { label: 'تجاوز الموارد', color: '#EA580C', icon: 'alert-decagram' },
  SECURITY_SUSPENDED: { label: 'تعليق أمني', color: '#000000', icon: 'shield-off' },
  CANCELLED: { label: 'ملغي', color: '#B91C1C', icon: 'close-circle' },
  UNSUBSCRIBED: { label: 'غير مشترك', color: '#64748B', icon: 'information-circle' },
};

export default function SubscriptionOverview() {
  const navigation = useNavigation();
  const [userId, setUserId] = React.useState(null);
  const [subscription, setSubscription] = React.useState(null);
  const [usage, setUsage] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const [dialogVisible, setDialogVisible] = React.useState(false);

  const loadSubscription = React.useCallback(async () => {
    try {
      setLoading(true);
      const user = await LocalDB.getUser();
      if (!user?.id) {
        setLoading(false);
        return;
      }
      setUserId(user.id);

      const row = await LocalDB.queryOne(
        `SELECT * FROM subscriptions WHERE user_id = ? ORDER BY created_at DESC LIMIT 1`,
        [user.id]
      );

      if (row) {
        setSubscription({
          ...row,
          statusData: STATUS_MAP[row.status] || STATUS_MAP.UNSUBSCRIBED,
          endDateFormatted: row.end_date ? new Date(parseInt(row.end_date)).toLocaleDateString('ar-EG') : 'غير محدد',
        });

        // جلب استهلاك الموارد الحقيقي
        const usageData = await SubscriptionAnalytics.getResourceUsage(user.id);
        setUsage(usageData);
      }
    } catch (error) {
      console.error('Failed to load subscription:', error.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useFocusEffect(
    React.useCallback(() => {
      loadSubscription();
    }, [loadSubscription])
  );

  const currentStatus = subscription?.statusData || STATUS_MAP.UNSUBSCRIBED;

  const handleBack = () => {
    if (navigation.canGoBack()) {
      navigation.goBack();
    } else {
      navigation.navigate('DashboardMain');
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>

      {/* 🛡️ كبسولة الهوية السيادية */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backBtn} onPress={handleBack}>
           <Ionicons name="chevron-forward" size={24} color={Colors.navy} />
        </TouchableOpacity>
        <Text style={styles.title}>السيادة الرقمية</Text>
        <View style={styles.idCapsule}>
           <Text style={styles.idText}>ID: {userId ? userId.substring(0, 8).toUpperCase() : '---'}</Text>
        </View>
      </View>

      {/* 📊 بطاقة الحالة الملكية */}
      <View style={[styles.statusCard, { borderColor: currentStatus.color }]}>
        <View style={[styles.statusHeader, { backgroundColor: currentStatus.color }]}>
           <MaterialCommunityIcons name={currentStatus.icon} size={20} color="#FFF" />
           <Text style={styles.statusLabel}>{currentStatus.label}</Text>
        </View>

        <View style={styles.cardBody}>
           <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>الباقة الحالية:</Text>
              <Text style={styles.infoValue}>{PLAN_LABELS[subscription?.plan] || 'لا يوجد'}</Text>
           </View>
           <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>تاريخ الانتهاء:</Text>
              <Text style={styles.infoValue}>{subscription?.endDateFormatted || '---'}</Text>
           </View>

           {/* استهلاك الموارد الحقيقي */}
           <View style={styles.resourceSection}>
              <ResourceUsageBar
                label="العملاء"
                used={usage?.customers?.used || 0}
                limit={usage?.customers?.limit || 5}
                percentage={usage?.customers?.percentage || 0}
                color={currentStatus.color}
              />
              <ResourceUsageBar
                label="الفواتير"
                used={usage?.invoices?.used || 0}
                limit={usage?.invoices?.limit || 5}
                percentage={usage?.invoices?.percentage || 0}
                color={currentStatus.color}
              />
           </View>
        </View>
      </View>

      {/* 🛠️ قائمة الإجراءات السيادية */}
      <View style={styles.actionsGrid}>
        <TouchableOpacity
          style={styles.actionItem}
          onPress={() => navigation.navigate('PlansCatalog')}
        >
          <View style={[styles.iconCircle, { backgroundColor: '#F1F5F9' }]}>
            <Ionicons name="apps" size={24} color={Colors.navy} />
          </View>
          <Text style={styles.actionText}>كتالوج الخطط</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.actionItem}
          onPress={() => navigation.navigate('SubscriptionPayment')}
        >
          <View style={[styles.iconCircle, { backgroundColor: '#F0F9FF' }]}>
            <Ionicons name="receipt" size={24} color="#0284C7" />
          </View>
          <Text style={styles.actionText}>رفع إيصال</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.actionItem}
          onPress={() => navigation.navigate('SubscriptionExtension')}
        >
          <View style={[styles.iconCircle, { backgroundColor: '#FEF3C7' }]}>
            <Ionicons name="time" size={24} color="#D97706" />
          </View>
          <Text style={styles.actionText}>تمديد</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.actionItem}
          onPress={() => navigation.navigate('SubscriptionRenew')}
        >
          <View style={[styles.iconCircle, { backgroundColor: '#ECFDF5' }]}>
            <Ionicons name="refresh" size={24} color="#059669" />
          </View>
          <Text style={styles.actionText}>تجديد</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.actionItem}
          onPress={() => navigation.navigate('SubscriptionDeviceManagement')}
        >
          <View style={[styles.iconCircle, { backgroundColor: '#FFF7ED' }]}>
            <Ionicons name="phone-portrait" size={24} color="#EA580C" />
          </View>
          <Text style={styles.actionText}>الأجهزة</Text>
        </TouchableOpacity>
      </View>

      {/* ⚠️ منطق الإلغاء */}
      <TouchableOpacity
        style={styles.cancelLink}
        onPress={() => navigation.navigate('SubscriptionCancellation')}
      >
        <Text style={styles.cancelLinkText}>طلب إلغاء الاشتراك أو الاسترداد</Text>
      </TouchableOpacity>

      <SubscriptionDialog
        visible={dialogVisible}
        onClose={() => setDialogVisible(false)}
        userId={userId}
        navigation={navigation}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  content: {
    padding: 20,
    paddingTop: Platform.OS === 'ios' ? 60 : 40,
  },
  header: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 25,
  },
  title: {
    fontSize: 24,
    fontFamily: 'Tajawal-Bold',
    color: '#0F172A',
  },
  backBtn: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: '#FFF',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
  },
  idCapsule: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    backgroundColor: '#0F172A',
    borderRadius: 24,
    borderWidth: 1.5,
    borderColor: '#D4A853',
  },
  idText: {
    color: '#D4A853',
    fontSize: 10,
    fontFamily: 'Tajawal-Bold',
  },
  statusCard: {
    backgroundColor: '#FFF',
    borderRadius: 20,
    borderWidth: 1,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 15,
    elevation: 5,
    marginBottom: 25,
  },
  statusHeader: {
    flexDirection: 'row-reverse',
    padding: 12,
    alignItems: 'center',
    gap: 8,
  },
  statusLabel: {
    color: '#FFF',
    fontFamily: 'Tajawal-Bold',
    fontSize: 14,
  },
  cardBody: {
    padding: 20,
  },
  infoRow: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  infoLabel: {
    color: '#64748B',
    fontFamily: 'Tajawal-Medium',
    fontSize: 13,
  },
  infoValue: {
    color: '#0F172A',
    fontFamily: 'Tajawal-Bold',
    fontSize: 14,
  },
  resourceSection: {
    marginTop: 15,
    paddingTop: 15,
    borderTopWidth: 1,
    borderTopColor: '#F1F5F9',
  },
  resourceLabel: {
    color: '#64748B',
    fontSize: 11,
    fontFamily: 'Tajawal-Bold',
    marginBottom: 8,
    textAlign: 'right',
  },
  progressTrack: {
    height: 6,
    backgroundColor: '#F1F5F9',
    borderRadius: 10,
    flexDirection: 'row-reverse',
  },
  progressThumb: {
    height: '100%',
    borderRadius: 10,
  },
  actionsGrid: {
    flexDirection: 'row-reverse',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: 15,
  },
  actionItem: {
    width: '47%',
    backgroundColor: '#FFF',
    borderRadius: 16,
    padding: 15,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#F1F5F9',
  },
  iconCircle: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
  },
  actionText: {
    fontFamily: 'Tajawal-Bold',
    fontSize: 12,
    color: '#334155',
  },
  cancelLink: {
    marginTop: 30,
    alignItems: 'center',
  },
  cancelLinkText: {
    color: '#94A3B8',
    fontSize: 12,
    fontFamily: 'Tajawal-Medium',
    textDecorationLine: 'underline',
  }
});
