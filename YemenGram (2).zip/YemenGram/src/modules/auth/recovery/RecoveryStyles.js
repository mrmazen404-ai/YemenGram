// src/modules/auth/recovery/RecoveryStyles.js
// تصميم وحدة استعادة كلمة المرور - يمن جرام

import { StyleSheet, Dimensions, Platform } from 'react-native';
import { Colors } from '../../../shared/utils/colors';

const { width, height } = Dimensions.get('window');

export const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: Colors.white,
  },

  fullBackground: {
    flex: 1,
    width: '100%',
  },

  bgImage: {
    opacity: 0.12,
    resizeMode: 'cover',
    height: '40%',
  },

  // الشاشة الرئيسية (Entry Screen)
  container: {
    flexGrow: 1,
    paddingHorizontal: 24,
    paddingTop: Platform.OS === 'ios' ? 60 : 40,
    paddingBottom: 30,
    alignItems: 'center',
    justifyContent: 'center',
  },

  backBtn: {
    position: 'absolute',
    top: Platform.OS === 'ios' ? 60 : 40,
    right: 20, // ✅ RTL Right Position
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: Colors.white,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 10,
    elevation: 3,
    zIndex: 10,
  },

  iconSection: {
    alignItems: 'center',
    marginBottom: 40,
  },

  iconCircle: {
    width: 90,
    height: 90,
    borderRadius: 30,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: Colors.gold,
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.15,
    shadowRadius: 20,
    elevation: 8,
  },

  title: {
    fontSize: 26,
    fontFamily: 'Tajawal-Bold',
    color: Colors.dark,
    textAlign: 'right',
    marginBottom: 8,
  },

  subtitle: {
    fontSize: 14,
    fontFamily: 'Tajawal-Regular',
    color: Colors.gray,
    textAlign: 'right',
    paddingHorizontal: 10,
  },

  formCard: {
    width: '100%',
    backgroundColor: Colors.white,
    borderRadius: 28,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 20 },
    shadowOpacity: 0.1,
    shadowRadius: 40,
    elevation: 10,
  },

  mainBtn: {
    marginTop: 10,
    height: 54,
    borderRadius: 16,
  },

  bottomText: {
    marginTop: 30,
    fontSize: 11,
    fontFamily: 'Tajawal-Regular',
    color: '#D1D5DB',
    textAlign: 'center',
  },

  // دايلوج الباب السحاب (Sliding Vault)
  overlay: { flex: 1, backgroundColor: 'rgba(13, 27, 42, 0.7)', justifyContent: 'flex-end' },
  sheet: {
    backgroundColor: '#FFF', borderTopLeftRadius: 45, borderTopRightRadius: 45,
    paddingBottom: 40, minHeight: height * 0.75, width: '100%'
  },
  handle: { width: 45, height: 5, backgroundColor: '#E2E8F0', borderRadius: 3, alignSelf: 'center', marginTop: 15 },
  sheetContent: { paddingHorizontal: 30, paddingTop: 10, alignItems: 'center' },

  sheetControlRow: { flexDirection: 'row-reverse', justifyContent: 'space-between', width: '100%', marginBottom: 20, alignItems: 'center' },
  miniTextBtn: { padding: 5 },
  miniBtnText: { fontSize: 12, fontFamily: 'Tajawal-Bold' },
  closeBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: '#FFF5F5', justifyContent: 'center', alignItems: 'center' },

  sheetTitle: { fontSize: 22, fontFamily: 'Tajawal-Bold', color: Colors.dark, marginBottom: 10 },
  sheetDesc: { fontSize: 13, fontFamily: 'Tajawal-Regular', color: Colors.gray, textAlign: 'right', lineHeight: 20, marginBottom: 30 },

  // OTP RTL (من اليمين لليسار)
  otpContainer: { width: '100%', alignItems: 'center' },
  otpRowRTL: { flexDirection: 'row-reverse', gap: 8, marginBottom: 20 },
  otpBox: {
    width: 42, height: 58, borderRadius: 14, backgroundColor: '#F8FAFC',
    borderWidth: 2, borderColor: '#E2E8F0', textAlign: 'center',
    fontSize: 24, fontFamily: 'Tajawal-Bold', color: Colors.navy
  },
  otpBoxFilled: { borderColor: Colors.navy, backgroundColor: '#FFF' },
  otpBoxFocused: { borderColor: Colors.gold, shadowColor: Colors.gold, shadowOpacity: 0.1, shadowRadius: 5, elevation: 2 },

  resendBtn: { padding: 10, marginBottom: 20 },
  resendBtnText: { fontSize: 13, fontFamily: 'Tajawal-Bold', color: Colors.gold },

  errorFeedback: { color: Colors.red, marginTop: 10, fontFamily: 'Tajawal-Bold', textAlign: 'center', fontSize: 12 },

  // Password Inputs
  passGroup: { width: '100%', gap: 5 },

  // Strength Indicator
  strengthContainer: { width: '100%', marginTop: 5, marginBottom: 15, paddingHorizontal: 5 },
  strengthBarBg: { width: '100%', height: 4, backgroundColor: '#E2E8F0', borderRadius: 2, overflow: 'hidden' },
  strengthBarFill: { height: '100%', borderRadius: 2 },
  strengthLabel: { fontSize: 10, fontFamily: 'Tajawal-Bold', textAlign: 'right', marginTop: 4 },

  // Security Seals
  securitySeal: { flexDirection: 'row-reverse', alignItems: 'center', gap: 6, marginTop: 25 },
  sealText: { fontSize: 10, fontFamily: 'Tajawal-Bold', color: Colors.gold, letterSpacing: 1 },

  // Confirm Modal Content
  confirmContent: { alignItems: 'center', paddingVertical: 10 },
  confirmText: { fontSize: 14, fontFamily: 'Tajawal-Regular', color: Colors.gray, textAlign: 'center', lineHeight: 22 },
  emailBadge: {
    backgroundColor: '#F1F5F9', paddingHorizontal: 20, paddingVertical: 12,
    borderRadius: 12, marginTop: 15, borderWidth: 1, borderColor: '#E2E8F0'
  },
  emailText: { fontSize: 16, fontFamily: 'Tajawal-Bold', color: Colors.navy },

  // Success Step Styles
  successContainer: { alignItems: 'center', width: '100%', paddingVertical: 10 },
  successBadge: {
    width: 100, height: 100, borderRadius: 50, backgroundColor: '#FFFDF0',
    justifyContent: 'center', alignItems: 'center', marginBottom: 20,
    borderWidth: 2, borderColor: Colors.gold
  },
  successTitle: { fontSize: 20, fontFamily: 'Tajawal-Bold', color: Colors.dark, marginBottom: 12 },
  successDesc: { fontSize: 14, fontFamily: 'Tajawal-Regular', color: Colors.gray, textAlign: 'center', lineHeight: 22, marginBottom: 10 },
});
