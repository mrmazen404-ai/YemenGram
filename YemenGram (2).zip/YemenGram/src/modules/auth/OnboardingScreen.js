// src/modules/auth/OnboardingScreen.js
// =============================================
// شاشة الترحيب (Onboarding Screen)
// تظهر للمستخدمين الجدد للتعريف بالتطبيق
// =============================================

import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  StatusBar,
  Dimensions,
  Image,
  Animated,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors } from '../../shared/utils/colors';
import Button from '../../shared/components/Button';

const { width, height } = Dimensions.get('window');

// =============================================
// 1. بيانات الشرائح
// =============================================

const slides = [
  {
    id: '1',
    title: 'أهلاً بك في يمن جرام',
    subtitle: 'نظام محاسبي متكامل لإدارة أعمالك',
    icon: 'rocket',
    color: Colors.navy,
    image: require('../../shared/assets/images/onboarding1.png'),
  },
  {
    id: '2',
    title: 'إدارة العملاء والفواتير',
    subtitle: 'تابع عملاءك وفواتيرك ومدفوعاتك في مكان واحد',
    icon: 'people',
    color: Colors.gold,
    image: require('../../shared/assets/images/onboarding2.png'),
  },
  {
    id: '3',
    title: 'دليل الحسابات والتقارير',
    subtitle: 'تحكم في حساباتك واستخرج تقارير دقيقة',
    icon: 'stats-chart',
    color: Colors.green,
    image: require('../../shared/assets/images/onboarding3.png'),
  },
  {
    id: '4',
    title: 'يعمل بدون إنترنت',
    subtitle: 'أدير أعمالك في أي وقت ومن أي مكان',
    icon: 'cloud-offline',
    color: Colors.orange,
    image: require('../../shared/assets/images/onboarding4.png'),
  },
];

// =============================================
// 2. المكون الرئيسي
// =============================================

export default function OnboardingScreen({ navigation }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const flatListRef = useRef(null);
  const scrollX = useRef(new Animated.Value(0)).current;

  // ===== الانتقال إلى الشاشة التالية =====
  const goToNext = () => {
    if (currentIndex < slides.length - 1) {
      flatListRef.current?.scrollToIndex({
        index: currentIndex + 1,
        animated: true,
      });
    } else {
      // الانتقال إلى تسجيل الدخول
      navigation.replace('Login');
    }
  };

  // ===== تخطي الترحيب =====
  const skipOnboarding = () => {
    navigation.replace('Login');
  };

  // ===== تحديث الفهرس عند التمرير =====
  const onScroll = Animated.event(
    [{ nativeEvent: { contentOffset: { x: scrollX } } }],
    { useNativeDriver: false }
  );

  const onMomentumScrollEnd = (event) => {
    const index = Math.round(event.nativeEvent.contentOffset.x / width);
    setCurrentIndex(index);
  };

  // ===== عرض نقطة التقدم =====
  const renderDot = (index) => {
    const inputRange = [(index - 1) * width, index * width, (index + 1) * width];
    const opacity = scrollX.interpolate({
      inputRange,
      outputRange: [0.3, 1, 0.3],
      extrapolate: 'clamp',
    });
    const scale = scrollX.interpolate({
      inputRange,
      outputRange: [0.8, 1.2, 0.8],
      extrapolate: 'clamp',
    });

    return (
      <Animated.View
        key={index}
        style={[
          styles.dot,
          {
            opacity,
            transform: [{ scale }],
            backgroundColor: index === currentIndex ? Colors.gold : Colors.border,
          },
        ]}
      />
    );
  };

  // ===== عرض الشريحة =====
  const renderSlide = ({ item }) => {
    return (
      <View style={styles.slide}>
        <View style={styles.imageContainer}>
          <View style={[styles.iconWrapper, { backgroundColor: item.color + '15' }]}>
            <Ionicons name={item.icon} size={48} color={item.color} />
          </View>
          <Text style={styles.title}>{item.title}</Text>
          <Text style={styles.subtitle}>{item.subtitle}</Text>
        </View>
      </View>
    );
  };

  // ===== العرض =====
  return (
    <View style={styles.root}>
      <StatusBar barStyle="dark-content" backgroundColor={Colors.white} />

      {/* زر تخطي */}
      <TouchableOpacity style={styles.skipBtn} onPress={skipOnboarding} activeOpacity={0.6}>
        <Text style={styles.skipText}>تخطي</Text>
      </TouchableOpacity>

      {/* الشرائح */}
      <FlatList
        ref={flatListRef}
        data={slides}
        renderItem={renderSlide}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScroll={onScroll}
        onMomentumScrollEnd={onMomentumScrollEnd}
        keyExtractor={(item) => item.id}
        bounces={false}
      />

      {/* النقاط والأزرار */}
      <View style={styles.footer}>
        {/* النقاط */}
        <View style={styles.dotsContainer}>
          {slides.map((_, index) => renderDot(index))}
        </View>

        {/* الأزرار */}
        <View style={styles.buttonsContainer}>
          <TouchableOpacity style={styles.nextBtn} onPress={goToNext} activeOpacity={0.7}>
            <LinearGradient
              colors={[Colors.navy, '#0D2137']}
              style={styles.nextBtnGradient}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
            >
              <Text style={styles.nextBtnText}>
                {currentIndex === slides.length - 1 ? 'ابدأ الآن' : 'التالي'}
              </Text>
              <Ionicons
                name={currentIndex === slides.length - 1 ? 'checkmark' : 'arrow-forward'}
                size={20}
                color={Colors.white}
              />
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

// =============================================
// 3. الأنماط (Styles)
// =============================================
const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: Colors.white,
  },

  // ===== زر تخطي =====
  skipBtn: {
    position: 'absolute',
    top: 50,
    right: 20,
    paddingHorizontal: 16,
    paddingVertical: 8,
    zIndex: 10,
    backgroundColor: '#F5F6FA',
    borderRadius: 20,
  },
  skipText: {
    fontSize: 13,
    fontFamily: 'Tajawal-Medium',
    color: Colors.gray,
  },

  // ===== الشرائح =====
  slide: {
    width,
    height: height - 160,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 32,
  },

  imageContainer: {
    alignItems: 'center',
  },

  iconWrapper: {
    width: 120,
    height: 120,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.06,
    shadowRadius: 12,
    elevation: 4,
  },

  title: {
    fontSize: 26,
    fontFamily: 'Tajawal-Bold',
    color: Colors.dark,
    textAlign: 'center',
    marginBottom: 8,
  },

  subtitle: {
    fontSize: 15,
    fontFamily: 'Tajawal-Regular',
    color: Colors.gray,
    textAlign: 'center',
    lineHeight: 24,
    paddingHorizontal: 16,
  },

  // ===== التذييل =====
  footer: {
    paddingHorizontal: 24,
    paddingBottom: 40,
    alignItems: 'center',
  },

  dotsContainer: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 24,
  },

  dot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },

  buttonsContainer: {
    width: '100%',
  },

  nextBtn: {
    width: '100%',
    height: 52,
    borderRadius: 14,
    overflow: 'hidden',
  },

  nextBtnGradient: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
  },

  nextBtnText: {
    fontSize: 16,
    fontFamily: 'Tajawal-Medium',
    color: Colors.white,
  },
});