/**
 * بطاقة الباقة السيادية (Sovereign Plan Card)
 */

import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';
import { Colors } from '../../../shared/utils/colors';

export default function PlanCard({ plan, isSelected, onPress, disabled }) {
  if (!plan) return null;

  return (
    <TouchableOpacity
      activeOpacity={0.9}
      style={[
        styles.card,
        isSelected && { borderColor: plan.color || Colors.navy, borderWidth: 2, elevation: 8 },
        disabled && styles.disabled
      ]}
      onPress={onPress}
      disabled={disabled}
    >
      <View style={styles.header}>
        <View style={[styles.iconBox, { backgroundColor: (plan.color || Colors.navy) + '15' }]}>
          <MaterialCommunityIcons name="shield-star" size={24} color={plan.color || Colors.navy} />
        </View>
        <View style={styles.titleBox}>
          <Text style={styles.label}>{plan.label}</Text>
          <Text style={styles.price}>
            {plan.price > 0 ? `${plan.price.toLocaleString()} ر.ي` : 'مجانية'}
          </Text>
        </View>
        {isSelected && (
          <View style={[styles.checkBadge, { backgroundColor: plan.color || Colors.navy }]}>
            <Ionicons name="checkmark" size={14} color="#FFF" />
          </View>
        )}
      </View>

      <View style={styles.featureList}>
        {plan.features?.map((f, i) => (
          <View key={i} style={styles.featureItem}>
            <Ionicons name="checkmark-circle" size={16} color="#10B981" />
            <Text style={styles.featureText}>{f}</Text>
          </View>
        ))}
      </View>

      <View style={[styles.footer, { backgroundColor: isSelected ? (plan.color || Colors.navy) : '#F1F5F9' }]}>
        <Text style={[styles.footerText, isSelected && { color: '#FFF' }]}>
          {isSelected ? 'الباقة المختارة حالياً' : 'اختر هذه الخطة'}
        </Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#FFF',
    borderRadius: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    overflow: 'hidden',
    elevation: 3,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 10,
  },
  header: {
    flexDirection: 'row-reverse',
    padding: 20,
    alignItems: 'center',
    gap: 15,
  },
  iconBox: {
    width: 50,
    height: 50,
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },
  titleBox: { flex: 1, alignItems: 'flex-end' },
  label: { fontSize: 18, fontFamily: 'Tajawal-Bold', color: '#0F172A' },
  price: { fontSize: 16, fontFamily: 'Tajawal-Bold', color: '#D4A853', marginTop: 2 },
  checkBadge: { width: 22, height: 22, borderRadius: 11, justifyContent: 'center', alignItems: 'center' },
  featureList: { paddingHorizontal: 20, paddingBottom: 20 },
  featureItem: { flexDirection: 'row-reverse', alignItems: 'center', gap: 10, marginBottom: 8 },
  featureText: { fontSize: 13, fontFamily: 'Tajawal-Medium', color: '#475569' },
  footer: { paddingVertical: 12, alignItems: 'center' },
  footerText: { fontSize: 12, fontFamily: 'Tajawal-Bold', color: '#64748B' },
  disabled: { opacity: 0.6 }
});
