import { synchronize } from '@nozbe/watermelondb/sync';
import { database } from '../models';
import { LocalDB } from '../modules/database/localDB';
import SupabaseService from './supabaseClient';
import AsyncStorage from '@react-native-async-storage/async-storage';

const SYNC_KEY = 'lastSyncTimestamp';

// قائمة الجداول الشاملة للمزامنة السيادية (مترتبة حسب الاعتمادية لضمان عدم تعارض المفاتيح الخارجية Foreign Keys)
const CORE_TABLES = [
  'accounts',           // 1. الجداول المستقلة (الأبوية) أولاً
  'customer_tiers',
  'products',
  'suppliers',          // تعتمد على accounts
  'cash_accounts',      // تعتمد على accounts
  'employees',          // تعتمد على accounts
  'customers',          // تعتمد على accounts, customer_tiers
  'fixed_assets',       // تعتمد على accounts
  'journal_entries',
  'invoices',           // تعتمد على customers, suppliers, accounts
  'checks',             // تعتمد على customers, suppliers, cash_accounts
  'invoice_items',      // تعتمد على invoices, products
  'journal_details',    // تعتمد على journal_entries, accounts
  'account_movements',  // تعتمد على accounts, journal_entries, invoices
  'payments',           // تعتمد على customers, suppliers, employees, cash_accounts, checks
  'expenses',           // تعتمد على accounts, cash_accounts, checks
  'revenues',           // تعتمد على accounts, cash_accounts, checks
  'transfers',          // تعتمد على cash_accounts
  'payroll',            // تعتمد على employees
  'asset_depreciation', // تعتمد على fixed_assets
  'subscriptions'       // جداول النظام
];

export const syncService = {
  async sync() {
    try {
      // 1. التحقق من المستخدم الحالي وجلسة Supabase أو المحلي
      const userResult = await SupabaseService.getCurrentUser();
      let userId = null;

      if (!userResult.success || !userResult.user) {
        const localUser = await LocalDB.getUser();
        if (!localUser?.id) {
          // لم يسجل الدخول بعد (في شاشة البداية أو تسجيل الدخول)، نتخطى المزامنة بصمت وبدون أخطاء
          return { success: false, error: 'not_logged_in' };
        }
        userId = localUser.id;
      } else {
        userId = userResult.user.id;
      }

      console.log('🔄 [Sync] بدء المزامنة الشاملة مع Supabase للمستخدم:', userId);

      // 🔗 0. مزامنة بيانات المستخدم الأساسية أولاً لتفادي قيود المفتاح الخارجي (Foreign Key)
      try {
        const localUser = await LocalDB.getUser();
        if (localUser) {
          const { error: userError } = await SupabaseService.supabase.from('user').upsert({
            id: localUser.id,
            user_code: localUser.user_code || 'YG_DEFAULT',
            name: localUser.name || 'User',
            email: localUser.email || 'user@yemengram.com',
            phone: localUser.phone || '',
            role: localUser.role || 'user',
            company_name: localUser.company_name || 'YemenGram',
            updated_at: new Date().toISOString()
          }, { onConflict: 'id' });
          if (userError) throw new Error(userError.message);
        }
      } catch (userSyncErr) {
        console.warn('⚠️ [Sync] تحذير عند مزامنة المستخدم الأساسي:', userSyncErr.message);
      }

      // 2. جلب وقت آخر مزامنة
      const savedLastPull = await this.getLastSyncTime();

      // ⚡ إذا لم يكن محرك WatermelonDB متاحاً (في بيئة Expo Go)، نستخدم المزامنة المباشرة عبر SyncQueue
      if (!database) {
        console.log('⚡ [Sync] تشغيل المزامنة المباشرة (Fallback Mode - Expo Go)...');

        const pendingOps = await LocalDB.query(
          'SELECT * FROM sync_queue WHERE user_id = ? AND status = ? ORDER BY created_at ASC',
          [userId, 'pending']
        );

        for (const op of pendingOps) {
          try {
            const data = typeof op.data === 'string' ? JSON.parse(op.data) : op.data;
            if (op.action === 'insert' || op.action === 'update') {
              const { error: upsertErr } = await SupabaseService.supabase.from(op.table_name).upsert({
                ...data,
                user_id: userId,
                updated_at: new Date().toISOString()
              });
              if (upsertErr) throw new Error(upsertErr.message);
            } else if (op.action === 'delete') {
              const { error: delErr } = await SupabaseService.supabase.from(op.table_name).update({ deleted_at: new Date().toISOString() }).eq('id', op.record_id);
              if (delErr) throw new Error(delErr.message);
            }

            await LocalDB.execute('UPDATE sync_queue SET status = ?, synced_at = ? WHERE id = ?', ['synced', Date.now(), op.id]);
            console.log(`✅ [Sync Fallback] تمت مزامنة السجل بنجاح في جدول [${op.table_name}]`);
          } catch (opErr) {
            console.error(`❌ [Sync Fallback] فشل مزامنة العملية ${op.id} (${op.table_name}):`, opErr.message);
            await LocalDB.execute('UPDATE sync_queue SET attempts = attempts + 1 WHERE id = ?', [op.id]);
          }
        }

        await this.saveLastSyncTime(Date.now());
        console.log('✅ [Sync] تمت المزامنة المباشرة بنجاح');
        return { success: true };
      }

      // 3. تنفيذ المزامنة عبر WatermelonDB Sync Engine (في حال توفر البناء الأصلي)
      await synchronize({
        database,

        pullChanges: async ({ lastPulledAt: pullTimestamp }) => {
          console.log('📥 [Pull] جلب التغييرات الشاملة من Supabase...');
          const changes = {};
          const timestamp = Date.now();
          const effectiveLastPull = pullTimestamp || savedLastPull;
          const isoLastPull = new Date(effectiveLastPull || 0).toISOString();

          for (const tableName of CORE_TABLES) {
            try {
              const { data, error } = await SupabaseService.supabase
                .from(tableName)
                .select('*')
                .eq('user_id', userId)
                .gt('updated_at', isoLastPull);

              if (error) {
                console.warn(`⚠️ [Pull] خطأ في جلب جدول ${tableName}:`, error.message);
                changes[tableName] = { created: [], updated: [], deleted: [] };
                continue;
              }

              const records = data || [];
              changes[tableName] = {
                created: records.filter(r => !r.deleted_at && new Date(r.created_at).getTime() > (effectiveLastPull || 0)),
                updated: records.filter(r => !r.deleted_at && new Date(r.created_at).getTime() <= (effectiveLastPull || 0)),
                deleted: records.filter(r => r.deleted_at).map(r => r.id),
              };
            } catch (err) {
              console.warn(`⚠️ [Pull] استثناء في جدول ${tableName}:`, err.message);
              changes[tableName] = { created: [], updated: [], deleted: [] };
            }
          }

          console.log('✅ [Pull] تم جلب كافة التغييرات بنجاح');
          return { changes, timestamp };
        },

        pushChanges: async ({ changes }) => {
          console.log('📤 [Push] إرسال التغييرات الشاملة إلى Supabase...');

          for (const tableName of CORE_TABLES) {
            const tableChanges = changes[tableName];
            if (!tableChanges) continue;

            const { created = [], updated = [], deleted = [] } = tableChanges;

            // إرسال السجلات المنشأة حديثاً
            for (const record of created) {
              try {
                const { error } = await SupabaseService.supabase
                  .from(tableName)
                  .upsert({
                    ...record,
                    user_id: userId,
                    updated_at: new Date().toISOString(),
                  });
                if (error) throw new Error(error.message);
              } catch (e) {
                console.error(`❌ [Push] فشل إنشاء سجل في ${tableName}:`, e.message);
              }
            }

            // إرسال السجلات المحدثة
            for (const record of updated) {
              try {
                const { error } = await SupabaseService.supabase
                  .from(tableName)
                  .update({
                    ...record,
                    updated_at: new Date().toISOString(),
                  })
                  .eq('id', record.id);
                if (error) throw new Error(error.message);
              } catch (e) {
                console.error(`❌ [Push] فشل تحديث سجل في ${tableName}:`, e.message);
              }
            }

            // معالجة المحذوفات
            for (const id of deleted) {
              try {
                const { error } = await SupabaseService.supabase
                  .from(tableName)
                  .update({ deleted_at: new Date().toISOString() })
                  .eq('id', id);
                if (error) throw new Error(error.message);
              } catch (e) {
                console.error(`❌ [Push] فشل حذف سجل في ${tableName}:`, e.message);
              }
            }
          }

          console.log('✅ [Push] تم إرسال كافة التغييرات بنجاح');
        },

        migrationsEnabledAtVersion: 1,
        sendCreatedAsUpdated: true,
      });

      await this.saveLastSyncTime(Date.now());
      console.log('🎉 [Sync] تمت المزامنة الشاملة مع Supabase بنجاح تام');
      return { success: true };

    } catch (error) {
      console.error('❌ [Sync] فشل المزامنة الشاملة:', error.message);
      return { success: false, error: error.message };
    }
  },

  async getLastSyncTime() {
    const timestamp = await AsyncStorage.getItem(SYNC_KEY);
    return timestamp ? parseInt(timestamp, 10) : 0;
  },

  async saveLastSyncTime(timestamp) {
    await AsyncStorage.setItem(SYNC_KEY, String(timestamp));
  },
};

export default syncService;
