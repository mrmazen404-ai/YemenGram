/**
 * محرك الحالات السيادية الصارم للاشتراكات.
 * لا يعتمد على قيم صلاحيات يرسلها العميل، ولا يحول الحدث غير المسموح إلى نجاح صامت.
 */

export const STATES = Object.freeze({
  UNSUBSCRIBED: 'UNSUBSCRIBED',
  TRIAL_ACTIVE: 'TRIAL_ACTIVE',
  TRIAL_EXPIRED: 'TRIAL_EXPIRED',
  ACTIVE_FULL: 'ACTIVE_FULL',
  RESOURCES_EXCEEDED: 'RESOURCES_EXCEEDED',
  VERIFICATION_PENDING: 'VERIFICATION_PENDING',
  EXPIRED_GRACE: 'EXPIRED_GRACE',
  SECURITY_SUSPENDED: 'SECURITY_SUSPENDED',
  CANCELLED: 'CANCELLED',
  REFUND_PENDING: 'REFUND_PENDING',
  EXTENSION_PENDING: 'EXTENSION_PENDING',
});

export const EVENTS = Object.freeze({
  REQUEST_SUBSCRIPTION: 'REQUEST_SUBSCRIPTION',
  START_FREE_TRIAL: 'START_FREE_TRIAL',
  RECEIPT_SUBMITTED: 'RECEIPT_SUBMITTED',
  VERIFICATION_APPROVED: 'VERIFICATION_APPROVED',
  VERIFICATION_REJECTED: 'VERIFICATION_REJECTED',
  SUSPEND: 'SUSPEND',
  REINSTATE: 'REINSTATE',
  CANCEL: 'CANCEL',
  EXPIRE: 'EXPIRE',
  RESOURCE_OVERFLOW: 'RESOURCE_OVERFLOW',
  RESOURCE_RECOVERY: 'RESOURCE_RECOVERY',
  UPGRADE_REQUEST: 'UPGRADE_REQUEST',
  RENEW_REQUEST: 'RENEW_REQUEST',
  REFUND_REQUESTED: 'REFUND_REQUESTED',
  REFUND_APPROVED: 'REFUND_APPROVED',
  REFUND_REJECTED: 'REFUND_REJECTED',
  EXTEND_REQUEST: 'EXTEND_REQUEST',
  EXTEND_APPROVED: 'EXTEND_APPROVED',
  EXTEND_REJECTED: 'EXTEND_REJECTED',
});

const ADMIN_EVENTS = new Set([
  EVENTS.VERIFICATION_APPROVED,
  EVENTS.VERIFICATION_REJECTED,
  EVENTS.REINSTATE,
  EVENTS.SUSPEND,
  EVENTS.REFUND_APPROVED,
  EVENTS.REFUND_REJECTED,
  EVENTS.EXTEND_APPROVED,
]);

const isAuthorizedAdmin = (ctx) =>
  Boolean(ctx?.actorId && ['admin', 'owner', 'super_admin'].includes(ctx.actorRole));

const audit = (message) => ({ type: 'audit', message });

export function transition(state, event, ctx = {}) {
  const sideEffects = [];
  let nextState = state;
  let valid = true;
  let errorCode = null;
  let restoreState = ctx.previousState || null;

  if (!Object.values(STATES).includes(state)) {
    return { prevState: state, event, nextState: state, valid: false, errorCode: 'UNKNOWN_STATE', sideEffects: [] };
  }
  if (!Object.values(EVENTS).includes(event)) {
    return { prevState: state, event, nextState: state, valid: false, errorCode: 'UNKNOWN_EVENT', sideEffects: [] };
  }
  if (ADMIN_EVENTS.has(event) && !isAuthorizedAdmin(ctx)) {
    return { prevState: state, event, nextState: state, valid: false, errorCode: 'ADMIN_AUTH_REQUIRED', sideEffects: [] };
  }

  switch (state) {
    case STATES.UNSUBSCRIBED:
      if (event === EVENTS.REQUEST_SUBSCRIPTION) { nextState = ctx.plan === 'trial' ? STATES.TRIAL_ACTIVE : STATES.VERIFICATION_PENDING; sideEffects.push(audit('subscription_requested')); }
      else if (event === EVENTS.START_FREE_TRIAL) { nextState = STATES.TRIAL_ACTIVE; sideEffects.push(audit('trial_activated')); }
      else valid = false;
      break;
    case STATES.VERIFICATION_PENDING:
      if (event === EVENTS.RECEIPT_SUBMITTED) { nextState = STATES.VERIFICATION_PENDING; sideEffects.push(audit('receipt_submitted')); }
      else if (event === EVENTS.VERIFICATION_APPROVED) { nextState = STATES.ACTIVE_FULL; sideEffects.push(audit('verification_approved')); }
      else if (event === EVENTS.VERIFICATION_REJECTED) { nextState = STATES.UNSUBSCRIBED; sideEffects.push(audit('verification_rejected')); }
      else valid = false;
      break;
    case STATES.TRIAL_ACTIVE:
      if (event === EVENTS.EXPIRE) { nextState = STATES.TRIAL_EXPIRED; sideEffects.push(audit('trial_expired')); }
      else if (event === EVENTS.SUSPEND) { nextState = STATES.SECURITY_SUSPENDED; restoreState = state; sideEffects.push(audit('security_suspended')); }
      else if (event === EVENTS.CANCEL) { nextState = STATES.CANCELLED; sideEffects.push(audit('cancelled')); }
      else if (event === EVENTS.UPGRADE_REQUEST || event === EVENTS.RENEW_REQUEST) { nextState = STATES.VERIFICATION_PENDING; sideEffects.push(audit('payment_requested')); }
      else valid = false;
      break;
    case STATES.ACTIVE_FULL:
      if (event === EVENTS.EXPIRE) { nextState = STATES.EXPIRED_GRACE; sideEffects.push(audit('expired_grace_started')); }
      else if (event === EVENTS.SUSPEND) { nextState = STATES.SECURITY_SUSPENDED; restoreState = state; sideEffects.push(audit('security_suspended')); }
      else if (event === EVENTS.CANCEL) { nextState = STATES.CANCELLED; sideEffects.push(audit('cancelled')); }
      else if (event === EVENTS.RESOURCE_OVERFLOW) { nextState = STATES.RESOURCES_EXCEEDED; sideEffects.push(audit('resource_overflow')); }
      else if (event === EVENTS.UPGRADE_REQUEST || event === EVENTS.RENEW_REQUEST) { nextState = STATES.VERIFICATION_PENDING; sideEffects.push(audit('payment_requested')); }
      else if (event === EVENTS.REFUND_REQUESTED) { nextState = STATES.REFUND_PENDING; sideEffects.push(audit('refund_requested')); }
      else if (event === EVENTS.EXTEND_REQUEST) { nextState = STATES.EXTENSION_PENDING; sideEffects.push(audit('extension_requested')); }
      else valid = false;
      break;
    case STATES.RESOURCES_EXCEEDED:
      if (event === EVENTS.RESOURCE_RECOVERY) { nextState = STATES.ACTIVE_FULL; sideEffects.push(audit('resource_recovered')); }
      else if (event === EVENTS.UPGRADE_REQUEST || event === EVENTS.RENEW_REQUEST) { nextState = STATES.VERIFICATION_PENDING; sideEffects.push(audit('payment_requested')); }
      else if (event === EVENTS.EXPIRE) { nextState = STATES.EXPIRED_GRACE; sideEffects.push(audit('expired_grace_started')); }
      else valid = false;
      break;
    case STATES.EXPIRED_GRACE:
      if (event === EVENTS.REQUEST_SUBSCRIPTION || event === EVENTS.UPGRADE_REQUEST || event === EVENTS.RENEW_REQUEST) { nextState = STATES.VERIFICATION_PENDING; sideEffects.push(audit('renewal_requested')); }
      else if (event === EVENTS.EXPIRE) { nextState = STATES.UNSUBSCRIBED; sideEffects.push(audit('grace_expired')); }
      else valid = false;
      break;
    case STATES.TRIAL_EXPIRED:
      if (event === EVENTS.REQUEST_SUBSCRIPTION || event === EVENTS.UPGRADE_REQUEST || event === EVENTS.RENEW_REQUEST) { nextState = STATES.VERIFICATION_PENDING; sideEffects.push(audit('renewal_requested')); }
      else valid = false;
      break;
    case STATES.SECURITY_SUSPENDED:
      if (event === EVENTS.REINSTATE) { nextState = restoreState && restoreState !== STATES.SECURITY_SUSPENDED ? restoreState : STATES.ACTIVE_FULL; sideEffects.push(audit('security_reinstated')); }
      else valid = false;
      break;
    case STATES.CANCELLED:
      if (event === EVENTS.REQUEST_SUBSCRIPTION || event === EVENTS.RENEW_REQUEST) { nextState = STATES.VERIFICATION_PENDING; sideEffects.push(audit('resubscription_requested')); }
      else valid = false;
      break;
    case STATES.REFUND_PENDING:
      if (event === EVENTS.REFUND_APPROVED) { nextState = STATES.CANCELLED; sideEffects.push(audit('refund_approved')); }
      else if (event === EVENTS.REFUND_REJECTED) { nextState = STATES.ACTIVE_FULL; sideEffects.push(audit('refund_rejected')); }
      else valid = false;
      break;
    case STATES.EXTENSION_PENDING:
      if (event === EVENTS.EXTEND_APPROVED) { nextState = STATES.ACTIVE_FULL; sideEffects.push(audit('extension_approved')); }
      else if (event === EVENTS.EXTEND_REJECTED) { nextState = STATES.ACTIVE_FULL; sideEffects.push(audit('extension_rejected')); }
      else valid = false;
      break;
    default:
      valid = false;
  }

  if (!valid) {
    nextState = state;
    errorCode = 'INVALID_TRANSITION';
  }
  return { prevState: state, event, nextState, valid, errorCode, restoreState, sideEffects };
}

export default { STATES, EVENTS, transition };
