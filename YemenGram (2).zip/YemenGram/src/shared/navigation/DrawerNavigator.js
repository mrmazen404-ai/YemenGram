import React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';
import DashboardScreen from '../../modules/dashboard/screens/DashboardScreen';
import DrawerContent from '../../shared/components/DrawerContent';
import { Colors } from '../../shared/utils/colors';
import SettingsScreen from '../../modules/settings/screens/SettingsScreen';
import ProfileScreen from '../../modules/settings/profile/ProfileScreen';
import AuditScreen from '../../modules/audit/AuditScreen';
import AboutScreen from '../../modules/settings/screens/AboutScreen';
import SovereignSubscriptionHub from '../../modules/subscriptions/screens/SovereignSubscriptionHub';
import SubscriptionOverview from '../../modules/subscriptions/screens/SubscriptionOverview';
import PlansCatalog from '../../modules/subscriptions/screens/PlansCatalog';
import SubscriptionPaymentScreen from '../../modules/subscriptions/screens/SubscriptionPaymentScreen';
import ReceiptUploadScreen from '../../modules/subscriptions/screens/ReceiptUploadScreen';
import RenewScreen from '../../modules/subscriptions/screens/RenewScreen';
import ExtensionScreen from '../../modules/subscriptions/screens/ExtensionScreen';
import UpgradeScreen from '../../modules/subscriptions/screens/UpgradeScreen';
import MonthlyPlanScreen from '../../modules/subscriptions/screens/MonthlyPlanScreen';
import AnnualPlanScreen from '../../modules/subscriptions/screens/AnnualPlanScreen';
import EnterprisePlanScreen from '../../modules/subscriptions/screens/EnterprisePlanScreen';
import SubscriptionNotificationsScreen from '../../modules/subscriptions/screens/SubscriptionNotificationsScreen';
import ResourcesScreen from '../../modules/subscriptions/screens/ResourcesScreen';
import FreeTrialIntroScreen from '../../modules/subscriptions/screens/FreeTrialIntroScreen';
import TrialExpiredScreen from '../../modules/subscriptions/screens/TrialExpiredScreen';
import DeviceManagementScreen from '../../modules/subscriptions/screens/DeviceManagementScreen';
import VerificationPendingScreen from '../../modules/subscriptions/screens/VerificationPendingScreen';
import CancellationScreen from '../../modules/subscriptions/screens/CancellationScreen';
import RefundScreen from '../../modules/subscriptions/screens/RefundScreen';
import ReceiptsListScreen from '../../modules/subscriptions/screens/ReceiptsListScreen';
import SubscriptionErrorScreen from '../../modules/subscriptions/screens/SubscriptionErrorScreen';
import ArchivedAccessScreen from '../../modules/subscriptions/screens/ArchivedAccessScreen';
import SupportScreen from '../../modules/subscriptions/screens/SupportScreen';
import AdminRequestsList from '../../modules/subscriptions/screens/admin/AdminRequestsList';
import AdminRequestDetail from '../../modules/subscriptions/screens/admin/AdminRequestDetail';

const Drawer = createDrawerNavigator();
export default function DrawerNavigator() {
  return (
    <Drawer.Navigator
      drawerContent={(props) => <DrawerContent {...props} />}
      screenOptions={{
        headerShown: false,
        drawerPosition: 'right',
        drawerStyle: { width: 280, backgroundColor: Colors.white },
        drawerType: 'slide',
      }}
    >
      {/* ===== الرئيسية ===== */}
      <Drawer.Screen name="DashboardMain" component={DashboardScreen} />

      {/* ===== الاشتراكات ===== */}
      <Drawer.Screen name="SovereignSubscriptionHub" component={SovereignSubscriptionHub} />
      <Drawer.Screen name="SubscriptionOverview" component={SubscriptionOverview} />
      <Drawer.Screen name="PlansCatalog" component={PlansCatalog} />
      <Drawer.Screen name="SubscriptionPayment" component={SubscriptionPaymentScreen} />
      <Drawer.Screen name="ReceiptUploadScreen" component={ReceiptUploadScreen} />
      <Drawer.Screen name="SubscriptionRenew" component={RenewScreen} />
      <Drawer.Screen name="MonthlyPlan" component={MonthlyPlanScreen} />
      <Drawer.Screen name="AnnualPlan" component={AnnualPlanScreen} />
      <Drawer.Screen name="EnterprisePlan" component={EnterprisePlanScreen} />
      <Drawer.Screen name="SubscriptionUpgrade" component={UpgradeScreen} />
      <Drawer.Screen name="SubscriptionNotifications" component={SubscriptionNotificationsScreen} />
      <Drawer.Screen name="SubscriptionResources" component={ResourcesScreen} />
      <Drawer.Screen name="SubscriptionFreeTrialIntro" component={FreeTrialIntroScreen} />
      <Drawer.Screen name="SubscriptionTrialExpired" component={TrialExpiredScreen} />
      <Drawer.Screen name="SubscriptionDeviceManagement" component={DeviceManagementScreen} />
      <Drawer.Screen name="SubscriptionVerificationPending" component={VerificationPendingScreen} />
      <Drawer.Screen name="SubscriptionCancellation" component={CancellationScreen} />
      <Drawer.Screen name="SubscriptionRefund" component={RefundScreen} />
      <Drawer.Screen name="SubscriptionReceipts" component={ReceiptsListScreen} />
      <Drawer.Screen name="SubscriptionError" component={SubscriptionErrorScreen} />
      <Drawer.Screen name="Support" component={SupportScreen} />

      {/* ===== الإعدادات ===== */}
      <Drawer.Screen name="Settings" component={SettingsScreen} />
      <Drawer.Screen name="Profile" component={ProfileScreen} />
      <Drawer.Screen name="AuditLog" component={AuditScreen} />
      <Drawer.Screen name="About" component={AboutScreen} />
    </Drawer.Navigator>
  );
}
