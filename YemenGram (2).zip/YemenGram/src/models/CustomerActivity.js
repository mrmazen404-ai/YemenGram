// src/models/CustomerActivity.js
// =============================================
// نموذج أنشطة العميل (Customer Activity Model)
// المسؤول عن تسجيل جميع التفاعلات مع العميل
// =============================================

import { Model } from '@nozbe/watermelondb';
import { field, date, readonly } from '@nozbe/watermelondb/decorators';
import { Q } from '@nozbe/watermelondb';

export default class CustomerActivity extends Model {
  // ===== 1. اسم الجدول =====
  static table = 'customer_activities';

  // ===== 2. الحقول الأساسية =====

  // معرف العميل المرتبط بهذا النشاط
  @field('customer_id') customerId;

  // نوع النشاط (call, email, meeting, note, visit)
  @field('type') type;

  // وصف النشاط
  @field('description') description;

  // تاريخ النشاط (يمكن أن يكون مختلفاً عن تاريخ الإنشاء)
  @field('date') date;

  // من قام بتسجيل النشاط
  @field('created_by') createdBy;

  // ===== 3. التواريخ التلقائية =====

  @readonly @date('created_at') createdAt;

  // ===== 4. العلاقات =====

  static associations = {
    // كل نشاط ينتمي إلى عميل واحد
    customer: { type: 'belongs_to', key: 'customer_id' },
  };

  // ===== 5. دوال مساعدة =====

  /**
   * الحصول على اسم النوع باللغة العربية
   * @returns {string}
   */
  getTypeArabic() {
    const types = {
      call: 'مكالمة',
      email: 'بريد إلكتروني',
      meeting: 'اجتماع',
      note: 'ملاحظة',
      visit: 'زيارة',
    };
    return types[this.type] || this.type;
  }

  /**
   * الحصول على أيقونة النوع
   * @returns {string}
   */
  getTypeIcon() {
    const icons = {
      call: 'call',
      email: 'mail',
      meeting: 'people',
      note: 'document',
      visit: 'location',
    };
    return icons[this.type] || 'document';
  }

  /**
   * الحصول على لون النوع
   * @returns {string}
   */
  getTypeColor() {
    const colors = {
      call: '#27AE60',
      email: '#2196F3',
      meeting: '#9C27B0',
      note: '#607D8B',
      visit: '#FF9800',
    };
    return colors[this.type] || '#6B7280';
  }

  /**
   * جلب العميل المرتبط
   * @returns {Promise<Customer>}
   */
  async getCustomer() {
    return this.collections.get('customers').find(this.customerId);
  }

  /**
   * الحصول على اسم العميل
   * @returns {Promise<string>}
   */
  async getCustomerName() {
    const customer = await this.getCustomer();
    return customer ? customer.name : 'عميل غير معروف';
  }

  /**
   * الحصول على تاريخ النشاط بتنسيق مقروء
   * @returns {string}
   */
  getFormattedDate() {
    const dateValue = this.date || this.createdAt;
    if (!dateValue) return '';
    const date = new Date(dateValue);
    return date.toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  /**
   * الحصول على النشاط كاملاً مع النوع والتاريخ
   * @returns {string}
   */
  getFullActivity() {
    const typeStr = this.getTypeArabic();
    const dateStr = this.getFormattedDate();
    return `[${typeStr}] ${dateStr}: ${this.description || 'بدون وصف'}`;
  }

  /**
   * الحصول على وصف مختصر للنشاط
   * @param {number} maxLength
   * @returns {string}
   */
  getShortDescription(maxLength = 50) {
    if (!this.description) return '';
    if (this.description.length <= maxLength) return this.description;
    return this.description.slice(0, maxLength) + '...';
  }

  /**
   * الحصول على عدد الأيام منذ النشاط
   * @returns {number}
   */
  getDaysAgo() {
    const dateValue = this.date || this.createdAt;
    if (!dateValue) return 0;
    const now = Date.now();
    const diff = now - dateValue;
    return Math.floor(diff / (1000 * 60 * 60 * 24));
  }

  /**
   * الحصول على وصف "منذ متى" (مثل: "منذ 3 أيام")
   * @returns {string}
   */
  getTimeAgo() {
    const days = this.getDaysAgo();
    if (days === 0) return 'اليوم';
    if (days === 1) return 'أمس';
    if (days < 7) return `منذ ${days} أيام`;
    if (days < 30) return `منذ ${Math.floor(days / 7)} أسابيع`;
    if (days < 365) return `منذ ${Math.floor(days / 30)} أشهر`;
    return `منذ ${Math.floor(days / 365)} سنوات`;
  }

  // ===== 6. دوال ثابتة =====

  /**
   * الحصول على أنواع الأنشطة المتاحة
   * @returns {Array}
   */
  static getTypes() {
    return [
      { key: 'call', label: 'مكالمة', icon: 'call', color: '#27AE60' },
      { key: 'email', label: 'بريد إلكتروني', icon: 'mail', color: '#2196F3' },
      { key: 'meeting', label: 'اجتماع', icon: 'people', color: '#9C27B0' },
      { key: 'note', label: 'ملاحظة', icon: 'document', color: '#607D8B' },
      { key: 'visit', label: 'زيارة', icon: 'location', color: '#FF9800' },
    ];
  }

  /**
   * تجميع الأنشطة حسب النوع
   * @param {CustomerActivity[]} activities
   * @returns {Object}
   */
  static groupByType(activities) {
    const groups = {};
    for (const activity of activities) {
      if (!groups[activity.type]) {
        groups[activity.type] = [];
      }
      groups[activity.type].push(activity);
    }
    return groups;
  }

  /**
   * تجميع الأنشطة حسب الشهر
   * @param {CustomerActivity[]} activities
   * @returns {Object}
   */
  static groupByMonth(activities) {
    const groups = {};
    for (const activity of activities) {
      const date = new Date(activity.date || activity.createdAt);
      const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      if (!groups[key]) {
        groups[key] = [];
      }
      groups[key].push(activity);
    }
    return groups;
  }

  /**
   * الحصول على آخر نشاط في مجموعة
   * @param {CustomerActivity[]} activities
   * @returns {CustomerActivity|null}
   */
  static getLatest(activities) {
    if (activities.length === 0) return null;
    return activities.reduce((a, b) => (a.date > b.date ? a : b));
  }

  /**
   * الحصول على أول نشاط في مجموعة
   * @param {CustomerActivity[]} activities
   * @returns {CustomerActivity|null}
   */
  static getFirst(activities) {
    if (activities.length === 0) return null;
    return activities.reduce((a, b) => (a.date < b.date ? a : b));
  }
}