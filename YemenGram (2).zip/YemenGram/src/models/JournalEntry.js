// src/models/JournalEntry.js
// =============================================
// نموذج القيد اليومي (Journal Entry Model)
// المسؤول عن تسجيل القيود المحاسبية كوحدة متكاملة
// =============================================

import { Model } from '@nozbe/watermelondb';
import { field, date, readonly } from '@nozbe/watermelondb/decorators';
import { Q } from '@nozbe/watermelondb';

export default class JournalEntry extends Model {
  // ===== 1. اسم الجدول =====
  static table = 'journal_entries';

  // ===== 2. الحقول الأساسية =====

  // معرف المستخدم (لفصل البيانات)
  @field('user_id') userId;

  // رقم القيد (تلقائي متسلسل)
  @field('number') number;

  // تاريخ القيد
  @field('date') date;

  // وصف القيد
  @field('description') description;

  // إجمالي المدين (للتأكد من التوازن)
  @field('total_debit') totalDebit;

  // إجمالي الدائن (للتأكد من التوازن)
  @field('total_credit') totalCredit;

  // العملة
  @field('currency') currency;

  // حالة القيد (draft, posted, void)
  @field('status') status;

  // من قام بإنشاء القيد
  @field('created_by') createdBy;

  // ===== 3. التواريخ التلقائية =====

  @readonly @date('created_at') createdAt;
  @readonly @date('updated_at') updatedAt;

  // ===== 4. العلاقات =====

  static associations = {
    // قيد واحد → لديه عدة تفاصيل (حركات)
    details: { type: 'has_many', foreignKey: 'journal_entry_id' },
    // قيد واحد → ينتمي إلى مستخدم واحد
    user: { type: 'belongs_to', key: 'user_id' },
  };

  // ===== 5. دوال مساعدة =====

  /**
   * الحصول على حالة القيد باللغة العربية
   * @returns {string}
   */
  getStatusArabic() {
    const statuses = {
      draft: 'مسودة',
      posted: 'مرسل',
      void: 'ملغى',
    };
    return statuses[this.status] || this.status;
  }

  /**
   * الحصول على لون الحالة
   * @returns {string}
   */
  getStatusColor() {
    const colors = {
      draft: '#F39C12',
      posted: '#27AE60',
      void: '#E74C3C',
    };
    return colors[this.status] || '#6B7280';
  }

  /**
   * التحقق من توازن القيد (المدين = الدائن)
   * @returns {boolean}
   */
  isBalanced() {
    return (this.totalDebit || 0) === (this.totalCredit || 0);
  }

  /**
   * التحقق من أن القيد مرسل (posted)
   * @returns {boolean}
   */
  isPosted() {
    return this.status === 'posted';
  }

  /**
   * التحقق من أن القيد مسودة (draft)
   * @returns {boolean}
   */
  isDraft() {
    return this.status === 'draft';
  }

  /**
   * التحقق من أن القيد ملغى (void)
   * @returns {boolean}
   */
  isVoid() {
    return this.status === 'void';
  }

  /**
   * الحصول على الفرق بين المدين والدائن
   * @returns {number}
   */
  getDifference() {
    return (this.totalDebit || 0) - (this.totalCredit || 0);
  }

  /**
   * الحصول على اسم القيد المعروض
   * @returns {string}
   */
  getDisplayName() {
    return `قيد رقم ${this.number} - ${this.description || 'بدون وصف'}`;
  }

  /**
   * جلب تفاصيل القيد (الحركات)
   * @returns {Promise<JournalDetail[]>}
   */
  async getDetails() {
    return this.collections.get('journal_details').query(
      Q.where('journal_entry_id', this.id)
    ).fetch();
  }

  /**
   * جلب عدد تفاصيل القيد
   * @returns {Promise<number>}
   */
  async getDetailsCount() {
    return this.collections.get('journal_details').query(
      Q.where('journal_entry_id', this.id)
    ).fetchCount();
  }

  /**
   * حساب إجمالي المدين من التفاصيل
   * @returns {Promise<number>}
   */
  async calculateTotalDebit() {
    const details = await this.getDetails();
    return details.reduce((sum, d) => sum + (d.debit || 0), 0);
  }

  /**
   * حساب إجمالي الدائن من التفاصيل
   * @returns {Promise<number>}
   */
  async calculateTotalCredit() {
    const details = await this.getDetails();
    return details.reduce((sum, d) => sum + (d.credit || 0), 0);
  }

  /**
   * جلب المستخدم الذي أنشأ القيد
   * @returns {Promise<User>}
   */
  async getUser() {
    return this.collections.get('users').find(this.userId);
  }

  /**
   * الحصول على اسم منشئ القيد
   * @returns {Promise<string>}
   */
  async getCreatorName() {
    try {
      const user = await this.getUser();
      return user ? user.name : this.createdBy || 'غير معروف';
    } catch {
      return this.createdBy || 'غير معروف';
    }
  }

  /**
   * التحقق من وجود حركات مرتبطة بالقيد
   * @returns {Promise<boolean>}
   */
  async hasMovements() {
    const count = await this.collections.get('account_movements').query(
      Q.where('journal_entry_id', this.id)
    ).fetchCount();
    return count > 0;
  }

  /**
   * جلب جميع الحركات المحاسبية المرتبطة بالقيد
   * @returns {Promise<AccountMovement[]>}
   */
  async getMovements() {
    return this.collections.get('account_movements').query(
      Q.where('journal_entry_id', this.id)
    ).fetch();
  }

  // ===== 6. دوال ثابتة (Static Methods) =====

  /**
   * الحصول على رقم القيد التالي
   * @param {Database} database
   * @returns {Promise<number>}
   */
  static async getNextNumber(database) {
    const lastEntry = await database.get('journal_entries').query(
      Q.sortBy('number', Q.desc),
      Q.take(1)
    ).fetch();

    if (lastEntry.length === 0) {
      return 1;
    }

    return lastEntry[0].number + 1;
  }

  /**
   * إنشاء قيد جديد مع تفاصيله
   * @param {Database} database
   * @param {Object} data
   * @param {Array} details
   * @returns {Promise<JournalEntry>}
   */
  static async createWithDetails(database, data, details) {
    return await database.write(async () => {
      // 1. حساب الإجماليات
      let totalDebit = 0;
      let totalCredit = 0;

      for (const detail of details) {
        totalDebit += detail.debit || 0;
        totalCredit += detail.credit || 0;
      }

      // 2. إنشاء القيد
      const entry = await database.get('journal_entries').create(entry => {
        entry.userId = data.userId;
        entry.number = data.number;
        entry.date = data.date;
        entry.description = data.description;
        entry.totalDebit = totalDebit;
        entry.totalCredit = totalCredit;
        entry.currency = data.currency || 'YER';
        entry.status = data.status || 'draft';
        entry.createdBy = data.createdBy;
      });

      // 3. إنشاء التفاصيل
      for (const detail of details) {
        await database.get('journal_details').create(d => {
          d.journalEntryId = entry.id;
          d.accountId = detail.accountId;
          d.debit = detail.debit || 0;
          d.credit = detail.credit || 0;
          d.description = detail.description || '';
        });
      }

      return entry;
    });
  }
}