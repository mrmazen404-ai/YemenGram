/**
 * أدوات التحقق الخاصة بالاشتراكات (Subscription Validators)
 */

export const validateReceipt = (fileAsset) => {
  if (!fileAsset) return { isValid: false, error: 'يرجى اختيار ملف الإيصال.' };

  // 1. فحص النوع (الصور فقط)
  const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg'];
  const mimeType = fileAsset.mimeType || fileAsset.type;

  if (mimeType && !allowedTypes.includes(mimeType)) {
    return { isValid: false, error: 'نوع الملف غير مدعوم. يرجى رفع صورة (JPG/PNG).' };
  }

  // 2. فحص الحجم (بحد أقصى 5 ميجابايت)
  const maxSize = 5 * 1024 * 1024;
  if (fileAsset.fileSize > maxSize || fileAsset.size > maxSize) {
    return { isValid: false, error: 'حجم الصورة كبير جداً (الحد الأقصى 5MB).' };
  }

  return { isValid: true };
};

export const validateSubscriptionRequest = (userId, plan) => {
  if (!userId) return { isValid: false, error: 'يجب تسجيل الدخول لطلب اشتراك.' };
  if (!plan) return { isValid: false, error: 'يرجى اختيار باقة صالحة.' };
  return { isValid: true };
};

export default { validateReceipt, validateSubscriptionRequest };
