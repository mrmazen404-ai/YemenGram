
import { LocalDB } from '../../../shared/services/storageService';

export const AdminService = {
  /**
   * البحث عن مستخدم عبر الرقم الفريد
   */
  async findUserByCode(userCode) {
    if (!userCode) return null;
    
    try {
      const user = await LocalDB.queryOne(
        'SELECT * FROM user WHERE user_code = ?',
        [userCode.trim()]
      );
      return user;
    } catch (error) {
      console.log('❌ [findUserByCode] خطأ:', error.message);
      return null;
    }
  },

  /**
   * البحث عن مستخدمين (متعدد)
   */
  async findUsers(searchTerm) {
    if (!searchTerm || searchTerm.length < 2) return [];
    
    try {
      const users = await LocalDB.query(
        `SELECT * FROM user 
         WHERE user_code LIKE ? 
         OR name LIKE ? 
         OR email LIKE ? 
         OR phone LIKE ?
         ORDER BY name ASC
         LIMIT 20`,
        [
          `%${searchTerm}%`,
          `%${searchTerm}%`,
          `%${searchTerm}%`,
          `%${searchTerm}%`,
        ]
      );
      return users;
    } catch (error) {
      console.log('❌ [findUsers] خطأ:', error.message);
      return [];
    }
  },

  /**
   * جلب بيانات المستخدم كاملة مع اشتراكه
   */
  async getUserDetails(userId) {
    try {
      const user = await LocalDB.queryOne(
        'SELECT * FROM user WHERE id = ?',
        [userId]
      );
      
      if (!user) return null;
      
      const subscription = await LocalDB.queryOne(
        `SELECT * FROM subscriptions 
         WHERE user_id = ? 
         ORDER BY created_at DESC 
         LIMIT 1`,
        [userId]
      );
      
      return { user, subscription };
    } catch (error) {
      console.log('❌ [getUserDetails] خطأ:', error.message);
      return null;
    }
  },

  /**
   * البحث عن مستخدم عبر User Code وعرض بياناته
   */
  async getUserByCode(userCode) {
    const user = await this.findUserByCode(userCode);
    if (!user) return null;
    return await this.getUserDetails(user.id);
  },
};