// src/modules/auth/screens/OTPVerifyScreen.js
import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  Alert,
  ImageBackground,
  Animated,
  Easing,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '../../../shared/utils/colors';
import Button from '../../../shared/components/Button';
import Toast from '../../../shared/components/Toast';
import SecurityLoading from '../../../shared/components/SecurityLoading';
import Modal from '../../../shared/components/Modal';
import { useAuth } from '../../../shared/contexts/AuthContext';
import { LocalDB } from '../../database/localDB';
import * as Device from 'expo-device';

const HEADER_BG = require('../../../shared/assets/images/hint.png');

// =============================================
// 1. دوال التعقيم والتحقق
// =============================================

const sanitizeEmail = (email) => {
  if (!email) return '';
  return email.trim()
    .toLowerCase()
    .replace(/\s/g, '')
    .replace(/[<>{}()'"]/g, '');
};

const isValidOTP = (code) => {
  return /^[0-9]{6}$/.test(code);
};

// =============================================
// 2. Rate Limiting للتحقق
// =============================================

const MAX_OTP_ATTEMPTS = 5;
const OTP_LOCK_TIME = 15 * 60 * 1000; // 15 دقيقة

let otpAttempts = {};
let otpLockUntil = {};

const checkOTPRateLimit = (email) => {
  const key = email.toLowerCase();

  if (otpLockUntil[key] && Date.now() < otpLockUntil[key]) {
    const remaining = Math.ceil((otpLockUntil[key] - Date.now()) / 60000);
    throw new Error(`تم تجاوز عدد المحاولات، حاول بعد ${remaining} دقيقة`);
  }

  if (!otpAttempts[key]) {
    otpAttempts[key] = 0;
  }
  otpAttempts[key]++;

  if (otpAttempts[key] >= MAX_OTP_ATTEMPTS) {
    otpLockUntil[key] = Date.now() + OTP_LOCK_TIME;
    setTimeout(() => {
      delete otpAttempts[key];
      delete otpLockUntil[key];
    }, OTP_LOCK_TIME);
    throw new Error('تم تجاوز عدد المحاولات المسموح به، حاول بعد 15 دقيقة');
  }

  return true;
};

const resetOTPAttempts = (email) => {
  const key = email.toLowerCase();
  delete otpAttempts[key];
  delete otpLockUntil[key];
};

// =============================================
// 3. Rate Limiting لإعادة الإرسال
// =============================================

const MAX_RESEND_ATTEMPTS = 3;
const RESEND_LOCK_TIME = 30 * 60 * 1000; // 30 دقيقة

let resendAttempts = {};
let resendLockUntil = {};

const checkResendRateLimit = (email) => {
  const key = email.toLowerCase();

  if (resendLockUntil[key] && Date.now() < resendLockUntil[key]) {
    const remaining = Math.ceil((resendLockUntil[key] - Date.now()) / 60000);
    throw new Error(`تم تجاوز عدد محاولات إعادة الإرسال، حاول بعد ${remaining} دقيقة`);
  }

  if (!resendAttempts[key]) {
    resendAttempts[key] = 0;
  }
  resendAttempts[key]++;

  if (resendAttempts[key] >= MAX_RESEND_ATTEMPTS) {
    resendLockUntil[key] = Date.now() + RESEND_LOCK_TIME;
    setTimeout(() => {
      delete resendAttempts[key];
      delete resendLockUntil[key];
    }, RESEND_LOCK_TIME);
    throw new Error('تم تجاوز عدد محاولات إعادة الإرسال، حاول بعد 30 دقيقة');
  }

  return true;
};

const resetResendAttempts = (email) => {
  const key = email.toLowerCase();
  delete resendAttempts[key];
  delete resendLockUntil[key];
};

// =============================================
// 4. مقارنة آمنة (Constant Time)
// =============================================

const safeCompare = (a, b) => {
  if (!a || !b) return false;
  if (a.length !== b.length) return false;
  let result = 0;
  for (let i = 0; i < a.length; i++) {
    result |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }
  return result === 0;
};

// =============================================
// 5. المكون الرئيسي
// =============================================

export default function OTPVerifyScreen({ route, navigation }) {
  const { email } = route.params || {};
  const { verifyOTP, sendOTP } = useAuth();

  // ===== State =====
  const [code, setCode] = useState(['', '', '', '', '', '']);
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState({ visible: false, message: '', type: 'error' });
  const [resendTimer, setResendTimer] = useState(0);
  const [isVerifying, setIsVerifying] = useState(false);
  const [deviceInfo, setDeviceInfo] = useState({});
  const [focusedIndex, setFocusedIndex] = useState(0);

  const inputRefs = useRef([]);
  const pulseAnim = useRef(new Animated.Value(1)).current;

  // ===== أنيميشن النبض للأيقونة =====
  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.15, duration: 1500, useNativeDriver: true, easing: Easing.inOut(Easing.ease) }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 1500, useNativeDriver: true, easing: Easing.inOut(Easing.ease) }),
      ])
    ).start();
  }, []);

  // ===== الحصول على معلومات الجهاز =====
  useEffect(() => {
    const getDeviceInfo = async () => {
      try {
        setDeviceInfo({
          deviceName: Device.deviceName || 'غير معروف',
          os: `${Device.osName || ''} ${Device.osVersion || ''}`.trim() || 'غير معروف',
          brand: Device.brand || 'غير معروف',
        });
      } catch (error) {
        console.log('⚠️ فشل الحصول على معلومات الجهاز');
      }
    };
    getDeviceInfo();
  }, []);

  // ===== التركيز على الحقل الأول =====
  useEffect(() => {
    setTimeout(() => {
      inputRefs.current[0]?.focus();
    }, 300);
  }, []);

  // ===== مؤقت إعادة الإرسال =====
  useEffect(() => {
    if (resendTimer > 0) {
      const timer = setTimeout(() => setResendTimer(resendTimer - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [resendTimer]);

  // ===== معالجة تغيير الكود (RTL Logic) =====
  const handleCodeChange = (value, index) => {
    // دعم اللصق التلقائي (Clipboard Paste)
    if (value.length > 1) {
      const pastedCode = value.substring(0, 6).split('');
      const newCode = [...code];
      pastedCode.forEach((digit, i) => {
        if (i < 6) newCode[i] = digit.replace(/[^0-9]/g, '');
      });
      setCode(newCode);
      if (newCode.every(c => c !== '')) handleVerify(newCode.join(''));
      return;
    }

    const cleaned = value.replace(/[^0-9]/g, '');
    const newCode = [...code];
    newCode[index] = cleaned;
    setCode(newCode);

    // التركيز التلقائي (من اليمين لليسار Index 0 -> 5)
    if (cleaned && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }

    if (newCode.every(c => c !== '')) {
      handleVerify(newCode.join(''));
    }
  };

  // ===== معالجة الضغط على Backspace =====
  const handleKeyPress = (e, index) => {
    if (e.nativeEvent.key === 'Backspace' && !code[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const getStatusMessage = () => {
    if (resendTimer > 40) return 'جاري استلام ميثاق التحقق...';
    if (resendTimer > 20) return 'تحقق من مجلد الرسائل المزعجة (Spam)';
    if (resendTimer > 0) return 'بإمكانك طلب ميثاق جديد قريباً';
    return 'لم تصلك الرسالة؟';
  };

  // ===== التحقق من الكود =====
  const handleVerify = async (otpCode) => {
    if (isVerifying) return;

    // 1. التحقق من صحة الكود
    if (!isValidOTP(otpCode)) {
      setToast({
        visible: true,
        message: 'كود التحقق يجب أن يكون 6 أرقام',
        type: 'error',
      });
      return;
    }

    // 2. تعقيم البريد الإلكتروني
    const cleanEmail = sanitizeEmail(email);
    if (!cleanEmail) {
      setToast({
        visible: true,
        message: 'البريد الإلكتروني غير صحيح',
        type: 'error',
      });
      return;
    }

    // 3. التحقق من Rate Limiting
    try {
      checkOTPRateLimit(cleanEmail);
    } catch (error) {
      setToast({ visible: true, message: error.message, type: 'error' });
      setCode(['', '', '', '', '', '']);
      inputRefs.current[0]?.focus();
      return;
    }

    // 4. محاولة التحقق
    setIsVerifying(true);
    setLoading(true);

    try {
      // تسجيل محاولة التحقق
      await LocalDB.addAuditLog('otp_verify_attempt', 'auth', cleanEmail, {
        device: deviceInfo.deviceName,
        timestamp: new Date().toISOString(),
      });

      const result = await verifyOTP(cleanEmail, otpCode);
      
      // إعادة تعيين المحاولات عند النجاح
      resetOTPAttempts(cleanEmail);
      resetResendAttempts(cleanEmail);

      // تسجيل نجاح التحقق
      await LocalDB.addAuditLog('otp_verify_success', 'auth', cleanEmail, {
        device: deviceInfo.deviceName,
        timestamp: new Date().toISOString(),
      });

      setToast({
        visible: true,
        message: 'تم التحقق بنجاح!',
        type: 'success',
      });

      // ✅ فحص نوع التدفق (Flow) للانتقال للشاشة الصحيحة
      if (route.params?.flow === 'reset_password') {
        setTimeout(() => {
          navigation.navigate('ResetPassword', { email: cleanEmail, token: otpCode });
        }, 800);
      }

      // لا حاجة لـ navigation.replace('Dashboard') هنا للحالات الأخرى
      // لأن AppNavigator سيتكفل بالأمر تلقائياً عند تغيير الحالة في AuthContext

    } catch (error) {
      // تسجيل فشل التحقق
      await LocalDB.addAuditLog('otp_verify_failed', 'auth', cleanEmail, {
        reason: error.message || 'invalid_code',
        attempts: otpAttempts[cleanEmail] || 0,
        device: deviceInfo.deviceName,
        timestamp: new Date().toISOString(),
      });

      setToast({
        visible: true,
        message: error.message || 'كود التحقق غير صحيح',
        type: 'error',
      });

      // مسح الكود وإعادة التركيز
      setCode(['', '', '', '', '', '']);
      inputRefs.current[0]?.focus();
    } finally {
      setLoading(false);
      setIsVerifying(false);
    }
  };

  // ===== إعادة إرسال الكود =====
  const handleResend = async () => {
    if (resendTimer > 0) return;

    const cleanEmail = sanitizeEmail(email);
    if (!cleanEmail) {
      setToast({
        visible: true,
        message: 'البريد الإلكتروني غير صحيح',
        type: 'error',
      });
      return;
    }

    // التحقق من Rate Limiting لإعادة الإرسال
    try {
      checkResendRateLimit(cleanEmail);
    } catch (error) {
      setToast({ visible: true, message: error.message, type: 'error' });
      return;
    }

    setLoading(true);
    try {
      await sendOTP(cleanEmail);
      setResendTimer(60);
      setToast({
        visible: true,
        message: 'تم إعادة إرسال كود التحقق',
        type: 'success',
      });
    } catch (error) {
      setToast({
        visible: true,
        message: error.message || 'فشل إعادة إرسال الكود',
        type: 'error',
      });
    } finally {
      setLoading(false);
    }
  };

  // ===== العرض =====
  return (
    <KeyboardAvoidingView
      style={styles.root}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <Toast
        visible={toast.visible}
        message={toast.message}
        type={toast.type}
        onHide={() => setToast((prev) => ({ ...prev, visible: false }))}
      />

      <SecurityLoading visible={loading} status="جاري التحقق من الميثاق..." />

      <ImageBackground
        source={HEADER_BG}
        style={styles.fullBackground}
        imageStyle={styles.bgImage}
      >
        <View style={styles.container}>
          {/* زر الرجوع */}
          <TouchableOpacity
            style={styles.backBtn}
            onPress={() => navigation.goBack()}
            activeOpacity={0.6}
            disabled={isVerifying}
          >
            <Ionicons name="chevron-forward" size={24} color={Colors.dark} />
          </TouchableOpacity>

          {/* ===== الأيقونة والعنوان ===== */}
          <View style={styles.headerSection}>
            <Animated.View style={[styles.iconWrapper, { transform: [{ scale: pulseAnim }] }]}>
              <Ionicons name="mail-unread-outline" size={40} color={Colors.gold} />
            </Animated.View>
            <Text style={styles.title}> التحقق من مليكة الايميل</Text>
            <Text style={styles.subtitle}>أدخل الرمز المرسل إلى</Text>
            <Text style={styles.highlight}>{email}</Text>
          </View>

          {/* ===== إدخال الكود ===== */}
          <View style={styles.codeCard}>
            <View style={styles.codeRow}>
              {code.map((digit, index) => (
                <TextInput
                  key={index}
                  ref={(ref) => (inputRefs.current[index] = ref)}
                  style={[
                    styles.codeBox,
                    digit && styles.codeBoxFilled,
                    focusedIndex === index && styles.codeBoxFocused,
                  ]}
                  value={digit}
                  onChangeText={(v) => handleCodeChange(v, index)}
                  onKeyPress={(e) => handleKeyPress(e, index)}
                  onFocus={() => setFocusedIndex(index)}
                  keyboardType="number-pad"
                  maxLength={index === 0 && code[0] === '' ? 6 : 1} // دعم اللصق في أول حقل
                  selectTextOnFocus
                  textAlign="center"
                />
              ))}
            </View>

            <Button
              title={loading ? 'جاري ...' : 'تأكيد الهوية '}
              onPress={() => handleVerify(code.join(''))}
              loading={loading}
              disabled={code.some(c => c === '') || loading || isVerifying}
              style={styles.verifyBtn}
            />

            <TouchableOpacity
              onPress={handleResend}
              disabled={resendTimer > 0 || loading}
              activeOpacity={0.6}
              style={styles.resendBtn}
            >
              <Text style={[
                styles.resendText,
                (resendTimer > 0 || loading) && styles.resendDisabled,
              ]}>
                {resendTimer > 0
                  ? `إعادة إرسال  (${resendTimer} ثانية)`
                  : 'طلب كود جديد'}
              </Text>
            </TouchableOpacity>

            <Text style={styles.helpText}>
              {getStatusMessage()}
            </Text>
          </View>

          {/* ===== التذييل ===== */}
          <Text style={styles.bottomText}>يمن جرام ©  2026</Text>
        </View>
      </ImageBackground>
    </KeyboardAvoidingView>
  );
}

// =============================================
// 6. الأنماط (Styles)
// =============================================

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: Colors.white,
  },

  fullBackground: {
    flex: 1,
    width: '100%',
  },

  bgImage: {
    opacity: 0.12,
    resizeMode: 'cover',
    height: '40%',
  },

  container: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: Platform.OS === 'ios' ? 60 : 40,
    paddingBottom: 30,
    alignItems: 'center',
    justifyContent: 'center',
  },

  backBtn: {
    position: 'absolute',
    top: Platform.OS === 'ios' ? 60 : 40,
    right: 20, // ✅ RTL Right Position
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: Colors.white,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 10,
    elevation: 3,
    zIndex: 10,
  },

  headerSection: {
    alignItems: 'center',
    marginBottom: 40,
  },

  iconWrapper: {
    width: 90,
    height: 90,
    borderRadius: 30,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: Colors.gold,
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.15,
    shadowRadius: 20,
    elevation: 8,
  },

  title: {
    fontSize: 26,
    fontFamily: 'Tajawal-Bold',
    color: Colors.dark,
    textAlign: 'right',
    marginBottom: 8,
  },

  subtitle: {
    fontSize: 14,
    fontFamily: 'Tajawal-Regular',
    color: Colors.gray,
    textAlign: 'right',
  },

  highlight: {
    fontSize: 16,
    fontFamily: 'Tajawal-Bold',
    color: Colors.navy,
    textAlign: 'center',
    marginTop: 8,
    backgroundColor: '#F0F4F8',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 8,
    overflow: 'hidden',
  },

  codeCard: {
    width: '110%',
    backgroundColor: Colors.white,
    borderRadius: 28,
    padding: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 20 },
    shadowOpacity: 0.1,
    shadowRadius: 40,
    elevation: 10,
    alignItems: 'center',
  },

  codeRow: {
    flexDirection: 'row-reverse', // ✅ Manual RTL Direction
    gap: 8,
    marginBottom: 30,
  },

  codeBox: {
    width: 45,
    height: 58,
    borderRadius: 16,
    borderWidth: 2,
    borderColor: Colors.border,
    backgroundColor: '#F9FAFB',
    textAlign: 'center',
    fontSize: 24,
    fontFamily: 'Tajawal-Bold',
    color: Colors.dark,
  },

  codeBoxFilled: {
    borderColor: Colors.navy,
    backgroundColor: Colors.white,
  },

  codeBoxFocused: {
    borderColor: Colors.gold,
    backgroundColor: Colors.white,
    shadowColor: Colors.gold,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 4,
  },

  verifyBtn: {
    width: '90%',
    height: 54,
    borderRadius: 16,
  },

  resendBtn: {
    marginTop: 20,
    paddingVertical: 10,
  },

  resendText: {
    color: Colors.navy,
    fontSize: 14,
    fontFamily: 'Tajawal-Bold',
  },

  resendDisabled: {
    color: Colors.placeholder,
  },

  helpText: {
    fontSize: 12,
    fontFamily: 'Tajawal-Medium',
    color: '#9CA3AF',
    marginTop: 15,
    textAlign: 'center',
  },

  bottomText: {
    marginTop: 30,
    fontSize: 11,
    fontFamily: 'Tajawal-Regular',
    color: '#D1D5DB',
    textAlign: 'center',
  },
});
