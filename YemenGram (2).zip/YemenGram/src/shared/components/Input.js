// src/shared/components/Input.js
// مكون الإدخال - يمن جرام

import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  TextInput,
  Text,
  StyleSheet,
  Platform,
  TouchableOpacity,
  Animated,
} from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { Colors } from '../utils/colors';

export default function Input({
  icon,
  label,
  placeholder,
  value,
  onChangeText,
  secureTextEntry,
  error,
  success,
  disabled,
  loading,
  maxLength,
  showCounter,
  keyboardType = 'default',
  autoCapitalize = 'none',
  autoCorrect = false,
  returnKeyType = 'done',
  onFocus,
  onBlur,
  onSubmitEditing,
  style,
  inputStyle,
  containerStyle,
  showClear = true,
}) {
  const [focused, setFocused] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  // ===== Animations =====
  const labelAnim = useRef(new Animated.Value(value ? 1 : 0)).current;
  const borderAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(labelAnim, {
      toValue: (focused || value) ? 1 : 0,
      duration: 200,
      useNativeDriver: false,
    }).start();

    Animated.timing(borderAnim, {
      toValue: focused ? 1 : 0,
      duration: 300,
      useNativeDriver: false,
    }).start();
  }, [focused, value]);

  const triggerHaptic = (type = 'light') => {
    if (Platform.OS !== 'web') {
      if (type === 'error') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      else Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  const handleFocus = (e) => {
    setFocused(true);
    triggerHaptic();
    if (onFocus) onFocus(e);
  };

  const handleBlur = (e) => {
    setFocused(false);
    if (onBlur) onBlur(e);
  };

  const getBorderColor = () => {
    if (error) return Colors.red;
    if (success) return Colors.green;
    return borderAnim.interpolate({
      inputRange: [0, 1],
      outputRange: [Colors.border, Colors.gold]
    });
  };

  const labelStyle = {
    top: labelAnim.interpolate({
      inputRange: [0, 1],
      outputRange: [14, -10],
    }),
    fontSize: labelAnim.interpolate({
      inputRange: [0, 1],
      outputRange: [14, 11],
    }),
    color: labelAnim.interpolate({
      inputRange: [0, 1],
      outputRange: [Colors.gray, focused ? Colors.gold : Colors.navy],
    }),
    backgroundColor: (focused || value) ? '#FFFFFF' : 'transparent',
    paddingHorizontal: (focused || value) ? 6 : 0,
  };

  return (
    <View style={[styles.container, containerStyle]}>
      <Animated.View style={[
        styles.inputWrapper,
        { borderColor: getBorderColor() },
        focused && styles.inputWrapperFocused,
        error && styles.inputWrapperError,
        disabled && styles.disabled,
        style
      ]}>

        {/* أيقونة */}
        {icon && (
          <View style={styles.iconBox}>
            <Ionicons name={icon} size={18} color={focused ? Colors.gold : Colors.gray} />
          </View>
        )}

        {/* التايبوغرافي المتحرك (Floating Label) */}
        {label && (
          <Animated.Text style={[styles.floatingLabel, labelStyle]}>
            {label} {error && <Text style={{color: Colors.red}}>*</Text>}
          </Animated.Text>
        )}

        <TextInput
          style={[styles.input, inputStyle]}
          placeholder={focused ? '' : placeholder}
          placeholderTextColor={Colors.placeholder}
          value={value}
          onChangeText={onChangeText}
          onFocus={handleFocus}
          onBlur={handleBlur}
          onSubmitEditing={onSubmitEditing}
          secureTextEntry={secureTextEntry && !showPassword}
          keyboardType={keyboardType}
          autoCapitalize={autoCapitalize}
          autoCorrect={autoCorrect}
          returnKeyType={returnKeyType}
          maxLength={maxLength}
          editable={!disabled}
          selectionColor={Colors.gold}
          cursorColor={Colors.gold}
          textAlign="right"
        />

        {/* أزرار التحكم الجانبية */}
        <View style={styles.actions}>
          {showClear && value && !disabled && !secureTextEntry && (
            <TouchableOpacity onPress={() => onChangeText('')} style={styles.actionBtn}>
               <Ionicons name="close-circle" size={16} color={Colors.gray} />
            </TouchableOpacity>
          )}

          {secureTextEntry && !disabled && (
            <TouchableOpacity onPress={() => setShowPassword(!showPassword)} style={styles.actionBtn}>
               <Ionicons name={showPassword ? "eye-off" : "eye"} size={20} color={focused ? Colors.gold : Colors.gray} />
            </TouchableOpacity>
          )}

          {loading && <Animated.View><Ionicons name="refresh" size={16} color={Colors.gold} /></Animated.View>}
        </View>
      </Animated.View>

      {/* منطقة رسائل الخطأ */}
      {error && (
        <Animated.View style={styles.errorContainer}>
           <MaterialCommunityIcons name="alert-decagram" size={12} color={Colors.red} />
           <Text style={styles.errorText}>{error}</Text>
        </Animated.View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 15,
    width: '100%',
  },
  inputWrapper: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    height: 56,
    borderWidth: 1.5,
    borderRadius: 16,
    paddingHorizontal: 5,
    backgroundColor: '#FFFFFF',
    // تأثير الظل الخفيف للهيبة
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 5,
    elevation: 2,
  },
  inputWrapperFocused: {
    backgroundColor: '#FFFFFF',
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 4,
  },
  inputWrapperError: {
    borderColor: Colors.red,
    backgroundColor: '#FFF5F5',
  },
  iconBox: {
    width: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 5,
  },
  floatingLabel: {
    position: 'absolute',
    right: 50,
    fontFamily: 'Tajawal-Bold',
    zIndex: 1,
  },
  input: {
    flex: 1,
    height: '100%',
    fontFamily: 'Tajawal-Medium',
    fontSize: 12,
    color: Colors.dark,
    paddingTop: Platform.OS === 'android' ? 9 : 0,
    writingDirection: 'rtl', // ضمان اتجاه الكتابة العربية
  },
  actions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  actionBtn: {
    padding: 1,
  },
  errorContainer: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 5,
    marginTop: 6,
    paddingHorizontal: 8,
  },
  errorText: {
    color: Colors.red,
    fontSize: 13,
    fontFamily: 'Tajawal-Medium',
  },
  disabled: {
    backgroundColor: '#F8FAFC',
    borderColor: '#E2E8F0',
    opacity: 0.3,
  }
});
