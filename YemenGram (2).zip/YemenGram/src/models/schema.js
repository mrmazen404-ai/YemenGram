// src/models/schema.js
// =============================================
// مخطط قاعدة البيانات (Database Schema)
// تعريف جميع الجداول والأعمدة والعلاقات
// =============================================

import { appSchema, tableSchema } from '@nozbe/watermelondb';

export default appSchema({
  version: 7,
  tables: [

    // =============================================
    // 1. المستخدمون والجلسات (Users & Sessions)
    // =============================================

    tableSchema({
      name: 'users',
      columns: [
        { name: 'user_code', type: 'string', isIndexed: true },
        { name: 'name', type: 'string' },
        { name: 'email', type: 'string', isIndexed: true },
        { name: 'phone', type: 'string', isIndexed: true },
        { name: 'avatar', type: 'string' },
        { name: 'role', type: 'string' },
        { name: 'company_id', type: 'string' },
        { name: 'company_name', type: 'string' },
        { name: 'base_currency', type: 'string' },
        { name: 'is_blocked', type: 'boolean' },
        { name: 'blocked_reason', type: 'string' },
        { name: 'blocked_at', type: 'number' },
        { name: 'created_at', type: 'number' },
        { name: 'updated_at', type: 'number' },
      ],
    }),

    tableSchema({
      name: 'sessions',
      columns: [
        { name: 'user_id', type: 'string', isIndexed: true },
        { name: 'token', type: 'string' },
        { name: 'refresh_token', type: 'string' },
        { name: 'expires_at', type: 'number' },
        { name: 'created_at', type: 'number' },
      ],
    }),

    // =============================================
    // 2. الحسابات والحركات (Accounts & Movements)
    // =============================================

    tableSchema({
      name: 'accounts',
      columns: [
        { name: 'user_id', type: 'string', isIndexed: true },
        { name: 'code', type: 'string', isIndexed: true },
        { name: 'name', type: 'string', isIndexed: true },
        { name: 'type', type: 'string', isIndexed: true },
        { name: 'parent_id', type: 'string', isIndexed: true },
        { name: 'currency', type: 'string' },
        { name: 'balance', type: 'number' },
        { name: 'is_active', type: 'boolean' },
        { name: 'notes', type: 'string' },
        { name: 'created_at', type: 'number' },
        { name: 'updated_at', type: 'number' },
      ],
    }),

    tableSchema({
      name: 'account_movements',
      columns: [
        { name: 'account_id', type: 'string', isIndexed: true },
        { name: 'date', type: 'number', isIndexed: true },
        { name: 'journal_entry_id', type: 'string', isIndexed: true },
        { name: 'invoice_id', type: 'string', isIndexed: true },
        { name: 'reference', type: 'string' },
        { name: 'description', type: 'string' },
        { name: 'debit', type: 'number' },
        { name: 'credit', type: 'number' },
        { name: 'balance', type: 'number' },
        { name: 'created_at', type: 'number' },
      ],
    }),

    // =============================================
    // 3. القيود اليومية (Journal)
    // =============================================

    tableSchema({
      name: 'journal_entries',
      columns: [
        { name: 'user_id', type: 'string', isIndexed: true },
        { name: 'number', type: 'string', isIndexed: true },
        { name: 'date', type: 'number', isIndexed: true },
        { name: 'description', type: 'string' },
        { name: 'total_debit', type: 'number' },
        { name: 'total_credit', type: 'number' },
        { name: 'currency', type: 'string' },
        { name: 'status', type: 'string', isIndexed: true },
        { name: 'created_by', type: 'string' },
        { name: 'created_at', type: 'number' },
        { name: 'updated_at', type: 'number' },
      ],
    }),

    tableSchema({
      name: 'journal_details',
      columns: [
        { name: 'journal_entry_id', type: 'string', isIndexed: true },
        { name: 'account_id', type: 'string', isIndexed: true },
        { name: 'debit', type: 'number' },
        { name: 'credit', type: 'number' },
        { name: 'description', type: 'string' },
      ],
    }),

    // =============================================
    // 4. العملاء (Customers)
    // =============================================

    tableSchema({
      name: 'customers',
      columns: [
        { name: 'user_id', type: 'string', isIndexed: true },
        { name: 'code', type: 'string', isIndexed: true },
        { name: 'name', type: 'string', isIndexed: true },
        { name: 'type', type: 'string' },
        { name: 'phone', type: 'string', isIndexed: true },
        { name: 'email', type: 'string', isIndexed: true },
        { name: 'address', type: 'string' },
        { name: 'tax_number', type: 'string' },
        { name: 'credit_limit', type: 'number' },
        { name: 'balance', type: 'number' },
        { name: 'account_id', type: 'string', isIndexed: true },
        { name: 'tier_id', type: 'string', isIndexed: true },
        { name: 'currency', type: 'string' },
        { name: 'default_discount', type: 'number' },
        { name: 'payment_terms', type: 'number' },
        { name: 'opening_balance', type: 'number' },
        { name: 'category', type: 'string' },
        { name: 'preferred_payment_method', type: 'string' },
        { name: 'contact_person', type: 'string' },
        { name: 'contact_phone', type: 'string' },
        { name: 'assigned_to', type: 'string' },
        { name: 'source', type: 'string' },
        { name: 'tags', type: 'string' },
        { name: 'last_contact_date', type: 'number' },
        { name: 'notes', type: 'string' },
        { name: 'is_active', type: 'boolean' },
        { name: 'created_at', type: 'number' },
        { name: 'updated_at', type: 'number' },
      ],
    }),

    tableSchema({
      name: 'customer_contacts',
      columns: [
        { name: 'customer_id', type: 'string', isIndexed: true },
        { name: 'name', type: 'string' },
        { name: 'phone', type: 'string' },
        { name: 'email', type: 'string' },
        { name: 'position', type: 'string' },
        { name: 'is_primary', type: 'boolean' },
        { name: 'created_at', type: 'number' },
        { name: 'updated_at', type: 'number' },
      ],
    }),

    tableSchema({
      name: 'customer_notes',
      columns: [
        { name: 'customer_id', type: 'string', isIndexed: true },
        { name: 'note', type: 'string' },
        { name: 'created_by', type: 'string' },
        { name: 'created_at', type: 'number' },
      ],
    }),

    tableSchema({
      name: 'customer_activities',
      columns: [
        { name: 'customer_id', type: 'string', isIndexed: true },
        { name: 'type', type: 'string', isIndexed: true },
        { name: 'description', type: 'string' },
        { name: 'date', type: 'number', isIndexed: true },
        { name: 'created_by', type: 'string' },
        { name: 'created_at', type: 'number' },
      ],
    }),

    tableSchema({
      name: 'customer_tiers',
      columns: [
        { name: 'name', type: 'string', isIndexed: true },
        { name: 'level', type: 'number' },
        { name: 'description', type: 'string' },
        { name: 'is_active', type: 'boolean' },
        { name: 'created_at', type: 'number' },
        { name: 'updated_at', type: 'number' },
      ],
    }),

    // =============================================
    // 5. الموردين (Suppliers)
    // =============================================

    tableSchema({
      name: 'suppliers',
      columns: [
        { name: 'user_id', type: 'string', isIndexed: true },
        { name: 'code', type: 'string', isIndexed: true },
        { name: 'name', type: 'string', isIndexed: true },
        { name: 'phone', type: 'string' },
        { name: 'email', type: 'string' },
        { name: 'address', type: 'string' },
        { name: 'tax_number', type: 'string' },
        { name: 'account_id', type: 'string', isIndexed: true },
        { name: 'notes', type: 'string' },
        { name: 'is_active', type: 'boolean' },
        { name: 'created_at', type: 'number' },
        { name: 'updated_at', type: 'number' },
      ],
    }),

    // =============================================
    // 6. المنتجات والمخزون (Products)
    // =============================================

    tableSchema({
      name: 'products',
      columns: [
        { name: 'user_id', type: 'string', isIndexed: true },
        { name: 'code', type: 'string', isIndexed: true },
        { name: 'name', type: 'string', isIndexed: true },
        { name: 'category', type: 'string' },
        { name: 'unit', type: 'string' },
        { name: 'purchase_price', type: 'number' },
        { name: 'sale_price', type: 'number' },
        { name: 'quantity', type: 'number' },
        { name: 'min_quantity', type: 'number' },
        { name: 'account_id', type: 'string', isIndexed: true },
        { name: 'notes', type: 'string' },
        { name: 'is_active', type: 'boolean' },
        { name: 'created_at', type: 'number' },
        { name: 'updated_at', type: 'number' },
      ],
    }),

    tableSchema({
      name: 'product_categories',
      columns: [
        { name: 'name', type: 'string', isIndexed: true },
        { name: 'description', type: 'string' },
        { name: 'is_active', type: 'boolean' },
        { name: 'created_at', type: 'number' },
        { name: 'updated_at', type: 'number' },
      ],
    }),

    // =============================================
    // 7. الفواتير (Invoices)
    // =============================================

    tableSchema({
      name: 'invoices',
      columns: [
        { name: 'user_id', type: 'string', isIndexed: true },
        { name: 'number', type: 'string', isIndexed: true },
        { name: 'type', type: 'string', isIndexed: true },
        { name: 'date', type: 'number', isIndexed: true },
        { name: 'customer_id', type: 'string', isIndexed: true },
        { name: 'supplier_id', type: 'string', isIndexed: true },
        { name: 'account_id', type: 'string', isIndexed: true },
        { name: 'total', type: 'number' },
        { name: 'discount', type: 'number' },
        { name: 'tax', type: 'number' },
        { name: 'net_total', type: 'number' },
        { name: 'currency', type: 'string' },
        { name: 'status', type: 'string', isIndexed: true },
        { name: 'notes', type: 'string' },
        { name: 'created_at', type: 'number' },
        { name: 'updated_at', type: 'number' },
      ],
    }),

    tableSchema({
      name: 'invoice_items',
      columns: [
        { name: 'user_id', type: 'string', isIndexed: true },
        { name: 'invoice_id', type: 'string', isIndexed: true },
        { name: 'product_id', type: 'string', isIndexed: true },
        { name: 'description', type: 'string' },
        { name: 'quantity', type: 'number' },
        { name: 'unit_price', type: 'number' },
        { name: 'total', type: 'number' },
      ],
    }),

    // =============================================
    // 8. المدفوعات (Payments)
    // =============================================

    tableSchema({
      name: 'payments',
      columns: [
        { name: 'user_id', type: 'string', isIndexed: true },
        { name: 'number', type: 'string', isIndexed: true },
        { name: 'date', type: 'number', isIndexed: true },
        { name: 'type', type: 'string', isIndexed: true },
        { name: 'customer_id', type: 'string', isIndexed: true },
        { name: 'supplier_id', type: 'string', isIndexed: true },
        { name: 'expense_id', type: 'string' },
        { name: 'employee_id', type: 'string' },
        { name: 'amount', type: 'number' },
        { name: 'method', type: 'string' },
        { name: 'cash_account_id', type: 'string', isIndexed: true },
        { name: 'check_id', type: 'string' },
        { name: 'description', type: 'string' },
        { name: 'status', type: 'string', isIndexed: true },
        { name: 'created_by', type: 'string' },
        { name: 'created_at', type: 'number' },
        { name: 'updated_at', type: 'number' },
      ],
    }),

    tableSchema({
      name: 'expenses',
      columns: [
        { name: 'user_id', type: 'string', isIndexed: true },
        { name: 'number', type: 'string', isIndexed: true },
        { name: 'date', type: 'number', isIndexed: true },
        { name: 'account_id', type: 'string', isIndexed: true },
        { name: 'amount', type: 'number' },
        { name: 'category', type: 'string' },
        { name: 'description', type: 'string' },
        { name: 'payment_method', type: 'string' },
        { name: 'cash_account_id', type: 'string' },
        { name: 'check_id', type: 'string' },
        { name: 'receipt_image', type: 'string' },
        { name: 'created_by', type: 'string' },
        { name: 'created_at', type: 'number' },
        { name: 'updated_at', type: 'number' },
      ],
    }),

    tableSchema({
      name: 'revenues',
      columns: [
        { name: 'user_id', type: 'string', isIndexed: true },
        { name: 'number', type: 'string', isIndexed: true },
        { name: 'date', type: 'number', isIndexed: true },
        { name: 'account_id', type: 'string', isIndexed: true },
        { name: 'amount', type: 'number' },
        { name: 'source', type: 'string' },
        { name: 'description', type: 'string' },
        { name: 'payment_method', type: 'string' },
        { name: 'cash_account_id', type: 'string' },
        { name: 'check_id', type: 'string' },
        { name: 'created_by', type: 'string' },
        { name: 'created_at', type: 'number' },
        { name: 'updated_at', type: 'number' },
      ],
    }),

    tableSchema({
      name: 'transfers',
      columns: [
        { name: 'user_id', type: 'string', isIndexed: true },
        { name: 'number', type: 'string', isIndexed: true },
        { name: 'date', type: 'number', isIndexed: true },
        { name: 'from_account_id', type: 'string', isIndexed: true },
        { name: 'to_account_id', type: 'string', isIndexed: true },
        { name: 'amount', type: 'number' },
        { name: 'currency', type: 'string' },
        { name: 'description', type: 'string' },
        { name: 'status', type: 'string', isIndexed: true },
        { name: 'created_by', type: 'string' },
        { name: 'created_at', type: 'number' },
        { name: 'updated_at', type: 'number' },
      ],
    }),

    // =============================================
    // 9. النقد والبنوك (Cash & Banks)
    // =============================================

    tableSchema({
      name: 'cash_accounts',
      columns: [
        { name: 'user_id', type: 'string', isIndexed: true },
        { name: 'code', type: 'string', isIndexed: true },
        { name: 'name', type: 'string', isIndexed: true },
        { name: 'type', type: 'string' },
        { name: 'account_id', type: 'string', isIndexed: true },
        { name: 'bank_name', type: 'string' },
        { name: 'account_number', type: 'string' },
        { name: 'balance', type: 'number' },
        { name: 'currency', type: 'string' },
        { name: 'is_active', type: 'boolean' },
        { name: 'created_at', type: 'number' },
        { name: 'updated_at', type: 'number' },
      ],
    }),

    tableSchema({
      name: 'checks',
      columns: [
        { name: 'user_id', type: 'string', isIndexed: true },
        { name: 'number', type: 'string', isIndexed: true },
        { name: 'type', type: 'string' },
        { name: 'amount', type: 'number' },
        { name: 'date', type: 'number' },
        { name: 'due_date', type: 'number', isIndexed: true },
        { name: 'bank_name', type: 'string' },
        { name: 'customer_id', type: 'string', isIndexed: true },
        { name: 'supplier_id', type: 'string', isIndexed: true },
        { name: 'cash_account_id', type: 'string', isIndexed: true },
        { name: 'status', type: 'string', isIndexed: true },
        { name: 'notes', type: 'string' },
        { name: 'created_at', type: 'number' },
        { name: 'updated_at', type: 'number' },
      ],
    }),

    // =============================================
    // 10. الموارد البشرية (HR)
    // =============================================

    tableSchema({
      name: 'employees',
      columns: [
        { name: 'user_id', type: 'string', isIndexed: true },
        { name: 'code', type: 'string', isIndexed: true },
        { name: 'name', type: 'string', isIndexed: true },
        { name: 'phone', type: 'string' },
        { name: 'email', type: 'string' },
        { name: 'position', type: 'string' },
        { name: 'department', type: 'string' },
        { name: 'salary', type: 'number' },
        { name: 'hire_date', type: 'number' },
        { name: 'account_id', type: 'string', isIndexed: true },
        { name: 'is_active', type: 'boolean' },
        { name: 'created_at', type: 'number' },
        { name: 'updated_at', type: 'number' },
      ],
    }),

    tableSchema({
      name: 'payroll',
      columns: [
        { name: 'user_id', type: 'string', isIndexed: true },
        { name: 'employee_id', type: 'string', isIndexed: true },
        { name: 'month', type: 'string', isIndexed: true },
        { name: 'year', type: 'string', isIndexed: true },
        { name: 'basic_salary', type: 'number' },
        { name: 'allowances', type: 'number' },
        { name: 'deductions', type: 'number' },
        { name: 'net_salary', type: 'number' },
        { name: 'status', type: 'string', isIndexed: true },
        { name: 'created_at', type: 'number' },
        { name: 'updated_at', type: 'number' },
      ],
    }),

    // =============================================
    // 11. الأصول الثابتة (Fixed Assets)
    // =============================================

    tableSchema({
      name: 'fixed_assets',
      columns: [
        { name: 'user_id', type: 'string', isIndexed: true },
        { name: 'code', type: 'string', isIndexed: true },
        { name: 'name', type: 'string', isIndexed: true },
        { name: 'category', type: 'string' },
        { name: 'purchase_date', type: 'number' },
        { name: 'purchase_cost', type: 'number' },
        { name: 'salvage_value', type: 'number' },
        { name: 'useful_life', type: 'number' },
        { name: 'depreciation_method', type: 'string' },
        { name: 'current_value', type: 'number' },
        { name: 'accumulated_depreciation', type: 'number' },
        { name: 'account_id', type: 'string', isIndexed: true },
        { name: 'notes', type: 'string' },
        { name: 'is_active', type: 'boolean' },
        { name: 'created_at', type: 'number' },
        { name: 'updated_at', type: 'number' },
      ],
    }),

    tableSchema({
      name: 'asset_depreciation',
      columns: [
        { name: 'asset_id', type: 'string', isIndexed: true },
        { name: 'period', type: 'string', isIndexed: true },
        { name: 'amount', type: 'number' },
        { name: 'accumulated', type: 'number' },
        { name: 'created_at', type: 'number' },
      ],
    }),

    // =============================================
    // 12. النظام (System)
    // =============================================

    tableSchema({
      name: 'settings',
      columns: [
        { name: 'key', type: 'string', isIndexed: true },
        { name: 'value', type: 'string' },
        { name: 'updated_at', type: 'number' },
      ],
    }),

    tableSchema({
      name: 'notifications',
      columns: [
        { name: 'user_id', type: 'string', isIndexed: true },
        { name: 'type', type: 'string' },
        { name: 'title', type: 'string' },
        { name: 'message', type: 'string' },
        { name: 'read', type: 'boolean' },
        { name: 'action', type: 'string' },
        { name: 'action_data', type: 'string' },
        { name: 'created_at', type: 'number' },
      ],
    }),

    tableSchema({
      name: 'subscriptions',
      columns: [
        { name: 'user_id', type: 'string', isIndexed: true },
        { name: 'status', type: 'string', isIndexed: true },
        { name: 'plan', type: 'string', isIndexed: true },
        { name: 'start_date', type: 'number' },
        { name: 'end_date', type: 'number', isIndexed: true },
        { name: 'trial_end_date', type: 'number' },
        { name: 'grace_period_end', type: 'number' },
        { name: 'max_devices', type: 'number' },
        { name: 'registered_devices', type: 'number' },
        { name: 'max_customers', type: 'number' },
        { name: 'max_invoices', type: 'number' },
        { name: 'max_storage', type: 'number' },
        { name: 'auto_renew', type: 'boolean' },
        { name: 'renewal_count', type: 'number' },
        { name: 'price', type: 'number' },
        { name: 'currency', type: 'string' },
        { name: 'discount', type: 'number' },
        { name: 'tax', type: 'number' },
        { name: 'total', type: 'number' },
        { name: 'payment_method', type: 'string' },
        { name: 'payment_reference', type: 'string' },
        { name: 'payment_proof', type: 'string' },
        { name: 'verification_requested_at', type: 'number' },
        { name: 'verification_approved_at', type: 'number' },
        { name: 'verification_rejected_at', type: 'number' },
        { name: 'cancelled_at', type: 'number' },
        { name: 'cancellation_reason', type: 'string' },
        { name: 'refund_requested_at', type: 'number' },
        { name: 'refund_status', type: 'string' },
        { name: 'suspended_at', type: 'number' },
        { name: 'suspension_reason', type: 'string' },
        { name: 'archived_at', type: 'number' },
        { name: 'created_at', type: 'number' },
        { name: 'updated_at', type: 'number' },
      ],
    }),

    tableSchema({
      name: 'audit_log',
      columns: [
        { name: 'user_id', type: 'string', isIndexed: true },
        { name: 'action', type: 'string', isIndexed: true },
        { name: 'table_name', type: 'string' },
        { name: 'record_id', type: 'string' },
        { name: 'details', type: 'string' },
        { name: 'created_at', type: 'number', isIndexed: true },
      ],
    }),

    tableSchema({
      name: 'backup_history',
      columns: [
        { name: 'filename', type: 'string' },
        { name: 'size', type: 'number' },
        { name: 'type', type: 'string' },
        { name: 'status', type: 'string' },
        { name: 'notes', type: 'string' },
        { name: 'created_at', type: 'number', isIndexed: true },
      ],
    }),

    // =============================================
    // 13. المزامنة (Sync)
    // =============================================

    tableSchema({
      name: 'sync_queue',
      columns: [
        { name: 'user_id', type: 'string', isIndexed: true },
        { name: 'action', type: 'string' },
        { name: 'table_name', type: 'string' },
        { name: 'record_id', type: 'string' },
        { name: 'data', type: 'string' },
        { name: 'status', type: 'string', isIndexed: true },
        { name: 'attempts', type: 'number' },
        { name: 'created_at', type: 'number', isIndexed: true },
        { name: 'synced_at', type: 'number' },
      ],
    }),

    // =============================================
    // 14. العملات والضرائب (Currencies & VAT)
    // =============================================

    tableSchema({
      name: 'currencies',
      columns: [
        { name: 'code', type: 'string', isIndexed: true },
        { name: 'name', type: 'string' },
        { name: 'symbol', type: 'string' },
        { name: 'exchange_rate', type: 'number' },
        { name: 'is_base', type: 'boolean' },
        { name: 'is_active', type: 'boolean' },
        { name: 'created_at', type: 'number' },
        { name: 'updated_at', type: 'number' },
      ],
    }),

    tableSchema({
      name: 'vat_rates',
      columns: [
        { name: 'code', type: 'string', isIndexed: true },
        { name: 'rate', type: 'number' },
        { name: 'description', type: 'string' },
        { name: 'is_default', type: 'boolean' },
        { name: 'is_active', type: 'boolean' },
        { name: 'created_at', type: 'number' },
        { name: 'updated_at', type: 'number' },
      ],
    }),

    // =============================================
    // 15. الحسابات الافتراضية (Default Accounts)
    // =============================================

    tableSchema({
      name: 'default_accounts',
      columns: [
        { name: 'key', type: 'string', isIndexed: true },
        { name: 'account_id', type: 'string', isIndexed: true },
        { name: 'description', type: 'string' },
        { name: 'created_at', type: 'number' },
        { name: 'updated_at', type: 'number' },
      ],
    }),

    tableSchema({
      name: 'receipts',
      columns: [
        { name: 'user_id', type: 'string', isIndexed: true },
        { name: 'subscription_id', type: 'string', isIndexed: true },
        { name: 'transaction_number', type: 'string', isIndexed: true },
        { name: 'image_url', type: 'string' },
        { name: 'bank_name', type: 'string' },
        { name: 'amount', type: 'number' },
        { name: 'status', type: 'string', isIndexed: true }, // pending, approved, rejected
        { name: 'admin_notes', type: 'string' },
        { name: 'created_at', type: 'number' },
        { name: 'updated_at', type: 'number' },
      ],
    }),
  ],
});