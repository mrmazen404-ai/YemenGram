// src/shared/components/Card.js
// مكون البطاقة (Card) - يمن جرام (Sovereign Edition)

import React from 'react';
import { View, StyleSheet, TouchableOpacity, Platform } from 'react-native';
import { Colors } from '../utils/colors';

export default function Card({
  children,
  style,
  onPress,
  variant = 'default', // default, elevated, outlined, golden
  padding = 20,
  borderRadius = 20,
  disabled = false,
}) {
  const Container = onPress ? TouchableOpacity : View;

  const getVariantStyle = () => {
    switch (variant) {
      case 'elevated':
        return styles.elevated;
      case 'outlined':
        return styles.outlined;
      case 'golden':
        return styles.golden;
      default:
        return styles.default;
    }
  };

  return (
    <Container
      style={[
        styles.card,
        getVariantStyle(),
        { padding, borderRadius },
        style
      ]}
      onPress={onPress}
      disabled={disabled}
      activeOpacity={0.7}
    >
      {children}
    </Container>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: Colors.white,
    overflow: 'hidden',
  },
  default: {
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 5,
  },
  elevated: {
    elevation: 8,
    shadowColor: Colors.navy,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 10,
  },
  outlined: {
    borderWidth: 1.5,
    borderColor: Colors.border,
  },
  golden: {
    borderWidth: 1.5,
    borderColor: Colors.gold,
    elevation: 4,
    shadowColor: Colors.gold,
    shadowOpacity: 0.1,
    shadowRadius: 8,
  },
});