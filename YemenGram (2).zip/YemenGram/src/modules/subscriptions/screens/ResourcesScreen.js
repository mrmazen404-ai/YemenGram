/**
 * شاشة استهلاك الموارد السيادية (Sovereign Resources Screen)
 * تعرض نسب الاستهلاك الحقيقية للمنشأة
 */

import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  SafeAreaView
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import SubscriptionAnalytics from '../services/SubscriptionAnalytics';
import ResourceUsageBar from '../components/ResourceUsageBar';
import { useSubscriptionState } from '../hooks/useSubscriptionState';
import { Colors } from '../../../shared/utils/colors';
import { MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';

export default function ResourcesScreen() {
  const navigation = useNavigation();
  const { subscription, isLoading: isStateLoading } = useSubscriptionState();
  const [usage, setUsage] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const [refreshing, setRefreshing] = React.useState(false);

  const loadData = async () => {
    try {
      if (!subscription?.userId) return;
      const data = await SubscriptionAnalytics.getResourceUsage(subscription.userId);
      setUsage(data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  React.useEffect(() => {
    if (!isStateLoading) loadData();
  }, [subscription, isStateLoading]);

  const onRefresh = () => {
    setRefreshing(true);
    loadData();
  };

  if (loading || isStateLoading) {
    return <View style={styles.center}><ActivityIndicator size="large" color={Colors.navy} /></View>;
  }

  const resourceItems = [
    { label: 'العملاء المسجلين', key: 'customers', icon: 'account-group' },
    { label: 'الفواتير المصدرة', key: 'invoices', icon: 'file-document-edit' },
    { label: 'الأجهزة المرتبطة', key: 'devices', icon: 'cellphone-link' },
  ];

  return (
    <SafeAreaView style={styles.container}>
      {/* 🛡️ الهيدر */}
      <View style={styles.headerNav}>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
           <Ionicons name="chevron-forward" size={24} color={Colors.navy} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>استهلاك الموارد</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        <View style={styles.header}>
          <MaterialCommunityIcons name="chart-arc" size={32} color={Colors.gold} />
          <Text style={styles.title}>مراقبة الاستهلاك</Text>
          <Text style={styles.subtitle}>مراقبة لحظية لحدود باقة {subscription?.plan?.toUpperCase()}</Text>
        </View>

        <View style={styles.card}>
          {resourceItems.map((item) => (
            <ResourceUsageBar
              key={item.key}
              label={item.label}
              used={usage?.[item.key]?.used || 0}
              limit={usage?.[item.key]?.limit || 1}
              percentage={usage?.[item.key]?.percentage || 0}
              color={Colors.navy}
            />
          ))}
        </View>

        <View style={styles.warningBox}>
           <MaterialCommunityIcons name="information" size={20} color="#64748B" />
           <Text style={styles.warningText}>
             عند وصولك لـ 100% من الموارد، سيمنع النظام إضافة أي سجلات جديدة لحماية سلامة البيانات.
           </Text>
        </View>

        <TouchableOpacity
          style={styles.upgradeBtn}
          onPress={() => navigation.navigate('SubscriptionUpgrade')}
        >
          <Text style={styles.upgradeBtnText}>ترقية الباقة لزيادة الموارد</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC' },
  headerNav: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingVertical: 15, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#F1F5F9' },
  backBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: '#F8FAFC', justifyContent: 'center', alignItems: 'center' },
  headerTitle: { fontSize: 18, fontFamily: 'Tajawal-Bold', color: Colors.navy },
  content: { padding: 20, paddingBottom: 40 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { alignItems: 'center', marginBottom: 30, marginTop: 20 },
  title: { fontSize: 24, fontFamily: 'Tajawal-Bold', color: '#0F172A', marginTop: 10 },
  subtitle: { fontSize: 13, fontFamily: 'Tajawal-Medium', color: '#64748B' },
  card: {
    backgroundColor: '#FFF',
    borderRadius: 24,
    padding: 25,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#F1F5F9',
    elevation: 4,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 15,
  },
  warningBox: {
    flexDirection: 'row-reverse',
    gap: 10,
    padding: 15,
    backgroundColor: '#F1F5F9',
    borderRadius: 15,
    marginBottom: 25,
  },
  warningText: { flex: 1, fontSize: 11, fontFamily: 'Tajawal-Medium', color: '#64748B', textAlign: 'right', lineHeight: 18 },
  upgradeBtn: {
    backgroundColor: Colors.navy,
    borderRadius: 15,
    paddingVertical: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.gold,
  },
  upgradeBtnText: { color: '#FFF', fontFamily: 'Tajawal-Bold', fontSize: 15 },
});
