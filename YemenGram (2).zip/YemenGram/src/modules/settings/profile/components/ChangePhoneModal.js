// src/modules/settings/profile/components/ChangePhoneModal.js
// بروتوكول تغيير رقم الهاتف السيادي (Sovereign Phone Change Modal)

import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Keyboard } from 'react-native';
import Modal from '../../../../shared/components/Modal';
import Input from '../../../../shared/components/Input';
import { useAuth } from '../../../../shared/contexts/AuthContext';
import { Colors } from '../../../../shared/utils/colors';
import { ProfileService } from '../ProfileService';
import AuthService from '../../../auth/services/authService';
import * as Haptics from 'expo-haptics';

export default function ChangePhoneModal({ visible, onClose, onNotify }) {
  const { user, updateUserData } = useAuth();
  const [step, setStep] = useState(1); // 1: Input Phone, 2: Confirmation, 3: Password Challenge
  const [newPhone, setNewPhone] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const triggerHaptic = (style = Haptics.ImpactFeedbackStyle.Light) => {
    Haptics.impactAsync(style);
  };

  // تصفير الحالة عند الإغلاق
  useEffect(() => {
    if (!visible) {
      setStep(1);
      setNewPhone('');
      setPassword('');
      setError('');
      Keyboard.dismiss();
    }
  }, [visible]);

  const validatePhone = (phone) => {
    const cleaned = phone.replace(/[^0-9]/g, '');
    if (cleaned.length !== 9) {
      return 'يجب أن يتكون الرقم من 9 أرقام';
    }
    const prefix = cleaned.substring(0, 2);
    const validPrefixes = ['77', '70', '71', '78', '73'];
    if (!validPrefixes.includes(prefix)) {
      return 'رقم هاتف غير مدعوم. يرجى إدخال رقم يمني صحيح (77, 70, 71, 78, 73)';
    }
    return null;
  };

  const handleNextStep = async () => {
    if (step === 1) {
      const validationError = validatePhone(newPhone);
      if (validationError) {
        setError(validationError);
        triggerHaptic(Haptics.ImpactFeedbackStyle.Medium);
        return;
      }

      setLoading(true);
      setError('');
      try {
        await ProfileService.validateNewPhone(newPhone);
        triggerHaptic(Haptics.ImpactFeedbackStyle.Medium);
        setStep(2);
      } catch (err) {
        setError(err.message);
        triggerHaptic(Haptics.ImpactFeedbackStyle.Medium);
      } finally {
        setLoading(false);
      }
    } else if (step === 2) {
      setStep(3);
    } else if (step === 3) {
      handleFinalize();
    }
  };

  const handleFinalize = async () => {
    if (!password) {
      setError('يرجى إدخال كلمة المرور لتأكيد الهوية');
      return;
    }

    setLoading(true);
    setError('');

    try {
      // 1. التحقق من كلمة المرور
      const authResult = await AuthService.login(user.email, password);

      if (authResult.success) {
        // 2. تحديث الرقم في قاعدة البيانات
        await ProfileService.updatePhone(user.id, newPhone);

        // 3. تحديث حالة التطبيق اللحظية
        updateUserData({ phone: newPhone });

        triggerHaptic(Haptics.ImpactFeedbackStyle.Heavy);
        onNotify?.({ message: 'تم تحديث رقم الهاتف بنجاح', type: 'success' });
        onClose();
      }
    } catch (err) {
      setError(err.message === 'بيانات الدخول غير صحيحة' ? 'كلمة المرور غير صحيحة' : err.message);
      triggerHaptic(Haptics.ImpactFeedbackStyle.Medium);
    } finally {
      setLoading(false);
    }
  };

  const getTitle = () => {
    switch (step) {
      case 1: return "تغيير رقم الهاتف";
      case 2: return "تأكيد الرقم";
      case 3: return "تأكيد الهوية";
      default: return "";
    }
  };

  const getMessage = () => {
    switch (step) {
      case 1: return "أدخل رقم الهاتف اليمني الجديد (9 أرقام)";
      case 2: return `هل أنت متأكد من تغيير الرقم إلى: ${newPhone}؟`;
      case 3: return "يرجى إدخال كلمة المرور لإتمام عملية التغيير";
      default: return "";
    }
  };

  return (
    <Modal
      visible={visible}
      title={getTitle()}
      message={getMessage()}
      confirmText={step === 3 ? "تأكيد وتغيير" : step === 2 ? "تأكيد" : "التالي"}
      cancelText="إلغاء"
      onConfirm={handleNextStep}
      onCancel={() => (step > 1 ? setStep(step - 1) : onClose())}
      confirmLoading={loading}
    >
      <View style={styles.content}>
        {step === 1 && (
          <Input
            label="رقم الهاتف الجديد"
            icon="call-outline"
            value={newPhone}
            onChangeText={(v) => {
              setNewPhone(v.replace(/[^0-9]/g, '').slice(0, 9));
              if (error) setError('');
            }}
            keyboardType="number-pad"
            maxLength={9}
            error={error}
            placeholder="77XXXXXXX"
          />
        )}

        {step === 3 && (
          <Input
            label="كلمة المرور"
            icon="lock-closed-outline"
            secureTextEntry
            value={password}
            onChangeText={setPassword}
            error={error}
          />
        )}

        {step === 2 && error !== '' && (
           <Text style={styles.errorText}>{error}</Text>
        )}
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  content: { marginTop: 10, width: '100%' },
  errorText: { color: Colors.red, fontSize: 12, marginTop: 5, fontFamily: 'Tajawal-Bold', textAlign: 'center' }
});
