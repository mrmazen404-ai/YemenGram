/**
 * كتالوج الخطط السيادية (Sovereign Plans Catalog)
 * يعرض الخيارات المتاحة للاشتراك بناءً على الثوابت الرسمية
 */

import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { PLANS } from '../constants/plans';
import PlanCard from '../components/PlanCard';
import SubscriptionDialog from '../components/SubscriptionDialog';
import { useSubscriptionState } from '../hooks/useSubscriptionState';
import { Colors } from '../../../shared/utils/colors';
import { Ionicons } from '@expo/vector-icons';

export default function PlansCatalog() {
  const navigation = useNavigation();
  const { subscription, isActive, isLoading } = useSubscriptionState();
  const [selectedPlanKey, setSelectedPlan] = React.useState('monthly');
  const [dialogVisible, setDialogVisible] = React.useState(false);

  // تحويل كائن PLANS إلى مصفوفة للعرض
  const plansList = Object.values(PLANS).filter(p => p.id !== 'free'); // إخفاء المجانية من الكتالوج (تعطى تلقائياً)

  if (isLoading) {
    return <View style={styles.center}><ActivityIndicator size="large" color={Colors.navy} /></View>;
  }

  const handleConfirm = () => {
    switch (selectedPlanKey) {
      case 'monthly':
        navigation.navigate('MonthlyPlan');
        break;
      case 'annual':
        navigation.navigate('AnnualPlan');
        break;
      case 'enterprise':
        navigation.navigate('EnterprisePlan');
        break;
      default:
        setDialogVisible(true);
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
           <Ionicons name="chevron-forward" size={24} color={Colors.navy} />
        </TouchableOpacity>
        <Text style={styles.title}>كتالوج السيادة المالية</Text>
        <View style={{ width: 40 }} />
      </View>
      <Text style={styles.subtitle}>اختر الخطة التي تمنح منشأتك القوة والتحكم</Text>

      {plansList.map((plan) => (
        <PlanCard
          key={plan.id}
          plan={plan}
          isSelected={selectedPlanKey === plan.id}
          onPress={() => setSelectedPlan(plan.id)}
          disabled={subscription?.plan === plan.id && isActive}
        />
      ))}

      <TouchableOpacity
        style={styles.primaryButton}
        onPress={handleConfirm}
      >
        <Text style={styles.primaryText}>عرض تفاصيل العقد</Text>
      </TouchableOpacity>

      <SubscriptionDialog
        visible={dialogVisible}
        onClose={() => setDialogVisible(false)}
        userId={subscription?.userId}
        plan={selectedPlanKey}
        navigation={navigation}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC' },
  content: { padding: 20, paddingBottom: 40 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15, marginTop: 10 },
  backBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: '#FFF', justifyContent: 'center', alignItems: 'center', elevation: 2 },
  title: { fontSize: 24, fontFamily: 'Tajawal-Bold', color: '#0F172A', textAlign: 'right' },
  subtitle: { fontSize: 13, fontFamily: 'Tajawal-Medium', color: '#64748B', textAlign: 'right', marginBottom: 25 },
  primaryButton: {
    backgroundColor: Colors.navy,
    borderRadius: 15,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 10,
    elevation: 4,
  },
  primaryText: { color: '#FFF', fontFamily: 'Tajawal-Bold', fontSize: 16 },
});
