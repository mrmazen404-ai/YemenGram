// src/shared/components/SearchBar.js
// مكون شريط البحث (SearchBar) - يمن جرام (Sovereign Edition)

import React, { useState } from 'react';
import { View, TextInput, StyleSheet, TouchableOpacity, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { Colors } from '../utils/colors';

export default function SearchBar({
  placeholder = 'ابحث هنا...',
  value,
  onChangeText,
  onClear,
  style,
  containerStyle,
  autoFocus = false,
}) {
  const [focused, setFocused] = useState(false);

  const triggerHaptic = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  const handleClear = () => {
    triggerHaptic();
    if (onClear) onClear();
    else if (onChangeText) onChangeText('');
  };

  return (
    <View style={[styles.container, containerStyle]}>
      <View style={[
        styles.searchWrapper,
        focused && styles.searchWrapperFocused,
        style
      ]}>
        <Ionicons
          name="search"
          size={20}
          color={focused ? Colors.gold : Colors.placeholder}
          style={styles.searchIcon}
        />

        <TextInput
          style={styles.input}
          placeholder={placeholder}
          placeholderTextColor={Colors.placeholder}
          value={value}
          onChangeText={onChangeText}
          onFocus={() => {
            setFocused(true);
            triggerHaptic();
          }}
          onBlur={() => setFocused(false)}
          autoFocus={autoFocus}
          selectionColor={Colors.gold}
          cursorColor={Colors.gold}
          textAlign="right"
          returnKeyType="search"
        />

        {value ? (
          <TouchableOpacity onPress={handleClear} style={styles.clearBtn}>
            <Ionicons name="close-circle" size={18} color={Colors.gray} />
          </TouchableOpacity>
        ) : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    paddingHorizontal: 5,
  },
  searchWrapper: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    height: 50,
    backgroundColor: '#F1F5F9',
    borderRadius: 15,
    paddingHorizontal: 15,
    borderWidth: 1.5,
    borderColor: 'transparent',
  },
  searchWrapperFocused: {
    backgroundColor: Colors.white,
    borderColor: Colors.gold,
    elevation: 4,
    shadowColor: Colors.gold,
    shadowOpacity: 0.1,
    shadowRadius: 8,
  },
  searchIcon: {
    marginLeft: 10,
  },
  input: {
    flex: 1,
    height: '100%',
    fontFamily: 'Tajawal-Medium',
    fontSize: 14,
    color: Colors.dark,
    paddingTop: Platform.OS === 'android' ? 4 : 0,
  },
  clearBtn: {
    padding: 5,
  },
});