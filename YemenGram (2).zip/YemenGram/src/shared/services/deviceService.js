// src/shared/services/deviceService.js
// =============================================
// محرك البصمة السيادية (Sovereign Fingerprint Engine)
// توليد معرف عتادي فريد غير قابل للنسخ أو التزوير
// =============================================

import * as Device from 'expo-device';
import * as SecureStore from 'expo-secure-store';
import * as Crypto from 'expo-crypto';
import { Platform } from 'react-native';

const SOVEREIGN_ID_KEY = 'sovereign_hardware_id';

export const DeviceService = {
  /**
   * جلب البصمة السيادية للجهاز
   * تجمع بين معرف عتادي ثابت ومفتاح مشفر مخزن في الـ SecureStore
   */
  async getSovereignFingerprint() {
    try {
      // 1. جلب أو توليد المعرف المخزن في الخزنة العتادية (Persistent Unique ID)
      let storedId = await SecureStore.getItemAsync(SOVEREIGN_ID_KEY);

      if (!storedId) {
        storedId = Array.from(await Crypto.getRandomBytesAsync(32)).map((byte) => byte.toString(16).padStart(2, '0')).join('');
        await SecureStore.setItemAsync(SOVEREIGN_ID_KEY, storedId);
      }

      // 2. جمع بيانات العتاد (Hardware Metadata)
      const hardwarePayload = {
        model: Device.modelName,
        brand: Device.brand,
        manufacturer: Device.manufacturer,
        osName: Device.osName,
        osVersion: Device.osVersion,
        isDevice: Device.isDevice,
        platform: Platform.OS,
        persistent_key: storedId // المفتاح الذي لا يخرج من الجهاز
      };

      // 3. إنتاج الهاش السيادي (SHA-256)
      const rawString = JSON.stringify(hardwarePayload);
      const fingerprint = await Crypto.digestStringAsync(
        Crypto.CryptoDigestAlgorithm.SHA256,
        rawString
      );

      return fingerprint;
    } catch (error) {
      console.error('❌ [DeviceService] فشل توليد البصمة:', error);
      throw new Error('فشل التحقق من هوية الجهاز الفيزيائية');
    }
  },

  /**
   * جلب معلومات لجهاز المختصرة للعرض
   */
  async getDeviceMetadata() {
    return `${Device.brand} ${Device.modelName} (${Device.osName} ${Device.osVersion})`;
  }
};

export default DeviceService;
