// src/models/Invoice.js
// =============================================
// نموذج الفاتورة (Invoice Model)
// المسؤول عن إدارة فواتير المبيعات والمشتريات والمرتجعات
// =============================================

import { Model } from '@nozbe/watermelondb';
import { field, date, readonly } from '@nozbe/watermelondb/decorators';
import { Q } from '@nozbe/watermelondb';

export default class Invoice extends Model {
  // ===== 1. اسم الجدول =====
  static table = 'invoices';

  // ===== 2. الحقول الأساسية =====

  // معرف المستخدم (لفصل البيانات)
  @field('user_id') userId;

  // رقم الفاتورة (تلقائي متسلسل)
  @field('number') number;

  // نوع الفاتورة (sale, purchase, return_sale, return_purchase)
  @field('type') type;

  // تاريخ الفاتورة
  @field('date') date;

  // ===== 3. الأطراف =====

  // معرف العميل (للمبيعات والمرتجعات)
  @field('customer_id') customerId;

  // معرف المورد (للمشتريات)
  @field('supplier_id') supplierId;

  // ===== 4. المعلومات المالية =====

  // الحساب المحاسبي (الافتراضي)
  @field('account_id') accountId;

  // المجموع الفرعي (قبل الخصم والضريبة)
  @field('total') total;

  // قيمة الخصم
  @field('discount') discount;

  // قيمة الضريبة
  @field('tax') tax;

  // المجموع النهائي (بعد الخصم والضريبة)
  @field('net_total') netTotal;

  // العملة
  @field('currency') currency;

  // ===== 5. الحالة =====

  // حالة الفاتورة (draft, posted, void)
  @field('status') status;

  // ===== 6. معلومات إضافية =====

  @field('notes') notes;

  // ===== 7. التواريخ التلقائية =====

  @readonly @date('created_at') createdAt;
  @readonly @date('updated_at') updatedAt;

  // ===== 8. العلاقات =====

  static associations = {
    // كل فاتورة تنتمي إلى مستخدم واحد
    user: { type: 'belongs_to', key: 'user_id' },
    // كل فاتورة قد تنتمي إلى عميل (للمبيعات)
    customer: { type: 'belongs_to', key: 'customer_id' },
    // كل فاتورة قد تنتمي إلى مورد (للمشتريات)
    supplier: { type: 'belongs_to', key: 'supplier_id' },
    // كل فاتورة لها حساب محاسبي واحد
    account: { type: 'belongs_to', key: 'account_id' },
    // فاتورة واحدة → لديه عدة عناصر
    items: { type: 'has_many', foreignKey: 'invoice_id' },
    // فاتورة واحدة → لديه عدة حركات محاسبية
    movements: { type: 'has_many', foreignKey: 'invoice_id' },
  };

  // ===== 9. دوال مساعدة =====

  /**
   * الحصول على نوع الفاتورة باللغة العربية
   * @returns {string}
   */
  getTypeArabic() {
    const types = {
      sale: 'فاتورة مبيعات',
      purchase: 'فاتورة مشتريات',
      return_sale: 'مرتجع مبيعات',
      return_purchase: 'مرتجع مشتريات',
    };
    return types[this.type] || this.type;
  }

  /**
   * الحصول على اتجاه الفاتورة (دائن/مدين)
   * @returns {string}
   */
  getDirection() {
    const directions = {
      sale: 'دائن (إيراد)',
      purchase: 'مدين (مصروف)',
      return_sale: 'مدين (تخفيض إيراد)',
      return_purchase: 'دائن (تخفيض مصروف)',
    };
    return directions[this.type] || 'غير محدد';
  }

  /**
   * الحصول على حالة الفاتورة باللغة العربية
   * @returns {string}
   */
  getStatusArabic() {
    const statuses = {
      draft: 'مسودة',
      posted: 'مرسلة',
      void: 'ملغية',
    };
    return statuses[this.status] || this.status;
  }

  /**
   * الحصول على لون الحالة
   * @returns {string}
   */
  getStatusColor() {
    const colors = {
      draft: '#F39C12',
      posted: '#27AE60',
      void: '#E74C3C',
    };
    return colors[this.status] || '#6B7280';
  }

  /**
   * التحقق من أن الفاتورة مرسلة (posted)
   * @returns {boolean}
   */
  isPosted() {
    return this.status === 'posted';
  }

  /**
   * التحقق من أن الفاتورة مسودة (draft)
   * @returns {boolean}
   */
  isDraft() {
    return this.status === 'draft';
  }

  /**
   * التحقق من أن الفاتورة ملغية (void)
   * @returns {boolean}
   */
  isVoid() {
    return this.status === 'void';
  }

  /**
   * التحقق من أن الفاتورة مبيعات
   * @returns {boolean}
   */
  isSale() {
    return this.type === 'sale';
  }

  /**
   * التحقق من أن الفاتورة مشتريات
   * @returns {boolean}
   */
  isPurchase() {
    return this.type === 'purchase';
  }

  /**
   * التحقق من أن الفاتورة مرتجع
   * @returns {boolean}
   */
  isReturn() {
    return this.type === 'return_sale' || this.type === 'return_purchase';
  }

  /**
   * جلب العميل المرتبط (إن وجد)
   * @returns {Promise<Customer|null>}
   */
  async getCustomer() {
    if (!this.customerId) return null;
    return this.collections.get('customers').find(this.customerId);
  }

  /**
   * جلب المورد المرتبط (إن وجد)
   * @returns {Promise<Supplier|null>}
   */
  async getSupplier() {
    if (!this.supplierId) return null;
    return this.collections.get('suppliers').find(this.supplierId);
  }

  /**
   * جلب اسم العميل أو المورد
   * @returns {Promise<string>}
   */
  async getPartyName() {
    if (this.customerId) {
      const customer = await this.getCustomer();
      return customer ? customer.name : 'عميل غير معروف';
    }
    if (this.supplierId) {
      const supplier = await this.getSupplier();
      return supplier ? supplier.name : 'مورد غير معروف';
    }
    return 'غير محدد';
  }

  /**
   * جلب عناصر الفاتورة
   * @returns {Promise<InvoiceItem[]>}
   */
  async getItems() {
    return this.collections.get('invoice_items').query(
      Q.where('invoice_id', this.id)
    ).fetch();
  }

  /**
   * جلب عدد عناصر الفاتورة
   * @returns {Promise<number>}
   */
  async getItemsCount() {
    return this.collections.get('invoice_items').query(
      Q.where('invoice_id', this.id)
    ).fetchCount();
  }

  /**
   * جلب الحركات المحاسبية المرتبطة
   * @returns {Promise<AccountMovement[]>}
   */
  async getMovements() {
    return this.collections.get('account_movements').query(
      Q.where('invoice_id', this.id)
    ).fetch();
  }

  /**
   * حساب إجمالي العناصر (للتأكد من صحة الحسابات)
   * @returns {Promise<number>}
   */
  async calculateItemsTotal() {
    const items = await this.getItems();
    return items.reduce((sum, item) => sum + (item.total || 0), 0);
  }

  /**
   * التحقق من صحة الفاتورة (المجموع = مجموع العناصر)
   * @returns {Promise<boolean>}
   */
  async validate() {
    const itemsTotal = await this.calculateItemsTotal();
    const discount = this.discount || 0;
    const tax = this.tax || 0;
    const expectedTotal = itemsTotal - discount + tax;
    return Math.abs(expectedTotal - (this.netTotal || 0)) < 0.01;
  }

  /**
   * الحصول على اسم الفاتورة المعروض
   * @returns {string}
   */
  getDisplayName() {
    return `${this.number} - ${this.getTypeArabic()}`;
  }

  /**
   * الحصول على اسم العميل/المورد بالكامل
   * @returns {Promise<string>}
   */
  async getFullPartyName() {
    const name = await this.getPartyName();
    const type = this.isSale() ? 'عميل' : 'مورد';
    return `${type}: ${name}`;
  }

  // ===== 10. دوال ثابتة =====

  /**
   * الحصول على رقم الفاتورة التالي
   * @param {Database} database
   * @param {string} type
   * @returns {Promise<string>}
   */
  static async getNextNumber(database, type) {
    const prefix = {
      sale: 'INV',
      purchase: 'PRC',
      return_sale: 'RTS',
      return_purchase: 'RTP',
    }[type] || 'INV';

    const lastInvoice = await database.get('invoices').query(
      Q.where('type', type),
      Q.sortBy('number', Q.desc),
      Q.take(1)
    ).fetch();

    if (lastInvoice.length === 0) {
      return `${prefix}-0001`;
    }

    const lastNumber = lastInvoice[0].number;
    const numericPart = parseInt(lastNumber.split('-')[1] || '0000');
    const nextNumber = numericPart + 1;
    return `${prefix}-${String(nextNumber).padStart(4, '0')}`;
  }

  /**
   * تجميع الفواتير حسب النوع
   * @param {Invoice[]} invoices
   * @returns {Object}
   */
  static groupByType(invoices) {
    const groups = {};
    for (const invoice of invoices) {
      if (!groups[invoice.type]) {
        groups[invoice.type] = [];
      }
      groups[invoice.type].push(invoice);
    }
    return groups;
  }

  /**
   * تجميع الفواتير حسب الحالة
   * @param {Invoice[]} invoices
   * @returns {Object}
   */
  static groupByStatus(invoices) {
    const groups = {};
    for (const invoice of invoices) {
      if (!groups[invoice.status]) {
        groups[invoice.status] = [];
      }
      groups[invoice.status].push(invoice);
    }
    return groups;
  }

  /**
   * حساب إجمالي المبيعات من مجموعة فواتير
   * @param {Invoice[]} invoices
   * @returns {number}
   */
  static sumNetTotal(invoices) {
    return invoices.reduce((sum, inv) => sum + (inv.netTotal || 0), 0);
  }
}