// src/models/SyncQueue.js
// =============================================
// نموذج قائمة المزامنة (Sync Queue Model)
// المسؤول عن إدارة عمليات المزامنة مع الخادم السحابي
// =============================================

import { Model } from '@nozbe/watermelondb';
import { field, date, readonly } from '@nozbe/watermelondb/decorators';
import { Q } from '@nozbe/watermelondb';
export default class SyncQueue extends Model {
  // ===== 1. اسم الجدول =====
  static table = 'sync_queue';
  // ===== 2. الحقول الأساسية =====
  // معرف المستخدم
  @field('user_id') userId;

  // نوع العملية (insert, update, delete)
  @field('action') action;

  // اسم الجدول المتأثر
  @field('table_name') tableName;

  // معرف السجل المتأثر
  @field('record_id') recordId;

  // البيانات الكاملة (JSON)
  @field('data') data;

  // حالة المزامنة (pending, synced, failed)
  @field('status') status;

  // عدد محاولات المزامنة
  @field('attempts') attempts;

  // تاريخ المزامنة (عند النجاح)
  @field('synced_at') syncedAt;

  // ===== 3. التواريخ التلقائية =====

  @readonly @date('created_at') createdAt;

  // ===== 4. العلاقات =====

  static associations = {
    // كل عملية مزامنة تنتمي إلى مستخدم واحد
    user: { type: 'belongs_to', key: 'user_id' },
  };

  // ===== 5. دوال مساعدة =====

  /**
   * الحصول على نوع العملية باللغة العربية
   * @returns {string}
   */
  getActionArabic() {
    const actions = {
      insert: 'إضافة',
      update: 'تعديل',
      delete: 'حذف',
    };
    return actions[this.action] || this.action;
  }

  /**
   * الحصول على حالة المزامنة باللغة العربية
   * @returns {string}
   */
  getStatusArabic() {
    const statuses = {
      pending: 'معلق',
      synced: 'متزامن',
      failed: 'فشل',
    };
    return statuses[this.status] || this.status;
  }

  /**
   * الحصول على لون الحالة
   * @returns {string}
   */
  getStatusColor() {
    const colors = {
      pending: '#F39C12',
      synced: '#27AE60',
      failed: '#E74C3C',
    };
    return colors[this.status] || '#6B7280';
  }

  /**
   * الحصول على أيقونة الحالة
   * @returns {string}
   */
  getStatusIcon() {
    const icons = {
      pending: 'sync',
      synced: 'checkmark-circle',
      failed: 'alert-circle',
    };
    return icons[this.status] || 'document';
  }

  /**
   * الحصول على البيانات كـ JSON
   * @returns {Object|null}
   */
  getData() {
    if (!this.data) return null;
    try {
      return JSON.parse(this.data);
    } catch {
      return null;
    }
  }

  /**
   * الحصول على اسم الجدول باللغة العربية
   * @returns {string}
   */
  getTableNameArabic() {
    const tables = {
      user: 'المستخدمين',
      customers: 'العملاء',
      suppliers: 'الموردين',
      products: 'المنتجات',
      invoices: 'الفواتير',
      invoice_items: 'تفاصيل الفواتير',
      payments: 'المدفوعات',
      expenses: 'المصروفات',
      revenues: 'الإيرادات',
      transfers: 'التحويلات',
      accounts: 'الحسابات',
      account_movements: 'حركات الحسابات',
      journal_entries: 'القيود اليومية',
      journal_details: 'تفاصيل القيود',
      cash_accounts: 'الحسابات النقدية',
      checks: 'الشيكات',
      employees: 'الموظفين',
      payroll: 'الرواتب',
      fixed_assets: 'الأصول الثابتة',
      asset_depreciation: 'إهلاك الأصول',
      customer_contacts: 'جهات اتصال العملاء',
      customer_notes: 'ملاحظات العملاء',
      customer_activities: 'أنشطة العملاء',
      customer_tiers: 'مستويات العملاء',
      product_categories: 'فئات المنتجات',
      notifications: 'الإشعارات',
      subscriptions: 'الاشتراكات',
      settings: 'الإعدادات',
      sync_queue: 'المزامنة',
    };
    return tables[this.tableName] || this.tableName;
  }

  /**
   * الحصول على اسم العملية المعروض
   * @returns {string}
   */
  getDisplayName() {
    const action = this.getActionArabic();
    const table = this.getTableNameArabic();
    const status = this.getStatusArabic();
    return `${action} (${table}) - ${status}`;
  }

  /**
   * التحقق من أن العملية معلقة
   * @returns {boolean}
   */
  isPending() {
    return this.status === 'pending';
  }

  /**
   * التحقق من أن العملية متزامنة
   * @returns {boolean}
   */
  isSynced() {
    return this.status === 'synced';
  }

  /**
   * التحقق من أن العملية فاشلة
   * @returns {boolean}
   */
  isFailed() {
    return this.status === 'failed';
  }

  /**
   * تحديد العملية كمزامنة
   */
  async markAsSynced() {
    await this.write(() => {
      this.status = 'synced';
      this.syncedAt = Date.now();
    });
  }

  /**
   * تحديد العملية كفاشلة
   * @param {number} maxAttempts
   */
  async markAsFailed(maxAttempts = 5) {
    await this.write(() => {
      this.status = 'failed';
      this.attempts = (this.attempts || 0) + 1;
    });
  }

  /**
   * إعادة محاولة المزامنة
   */
  async retry() {
    await this.write(() => {
      this.status = 'pending';
      this.attempts = (this.attempts || 0) + 1;
    });
  }

  /**
   * الحصول على عدد محاولات المزامنة
   * @returns {number}
   */
  getAttemptCount() {
    return this.attempts || 0;
  }

  /**
   * التحقق من تجاوز الحد الأقصى للمحاولات
   * @param {number} maxAttempts
   * @returns {boolean}
   */
  hasExceededAttempts(maxAttempts = 5) {
    return (this.attempts || 0) >= maxAttempts;
  }

  // ===== 6. دوال ثابتة =====

  /**
   * إنشاء عملية مزامنة جديدة
   * @param {Database} database
   * @param {string} userId
   * @param {string} action
   * @param {string} tableName
   * @param {string} recordId
   * @param {any} data
   * @returns {Promise<SyncQueue>}
   */
  static async createSyncOperation(database, userId, action, tableName, recordId, data) {
    return await database.write(async () => {
      return await database.get('sync_queue').create(sync => {
        sync.userId = userId;
        sync.action = action;
        sync.tableName = tableName;
        sync.recordId = recordId || null;
        sync.data = JSON.stringify(data);
        sync.status = 'pending';
        sync.attempts = 0;
        sync.syncedAt = null;
      });
    });
  }

  /**
   * الحصول على العمليات المعلقة
   * @param {Database} database
   * @param {string} userId
   * @param {number} limit
   * @returns {Promise<SyncQueue[]>}
   */
  static async getPendingOperations(database, userId, limit = 100) {
    return database.get('sync_queue').query(
      Q.where('user_id', userId),
      Q.where('status', 'pending'),
      Q.sortBy('created_at', Q.asc),
      Q.take(limit)
    ).fetch();
  }

  /**
   * الحصول على العمليات الفاشلة
   * @param {Database} database
   * @param {string} userId
   * @param {number} limit
   * @returns {Promise<SyncQueue[]>}
   */
  static async getFailedOperations(database, userId, limit = 100) {
    return database.get('sync_queue').query(
      Q.where('user_id', userId),
      Q.where('status', 'failed'),
      Q.sortBy('created_at', Q.desc),
      Q.take(limit)
    ).fetch();
  }

  /**
   * الحصول على عدد العمليات المعلقة
   * @param {Database} database
   * @param {string} userId
   * @returns {Promise<number>}
   */
  static async getPendingCount(database, userId) {
    const operations = await database.get('sync_queue').query(
      Q.where('user_id', userId),
      Q.where('status', 'pending')
    ).fetch();
    return operations.length;
  }

  /**
   * حذف العمليات المتزامنة القديمة
   * @param {Database} database
   * @param {string} userId
   * @param {number} olderThanDays
   * @returns {Promise<number>}
   */
  static async deleteOldSyncedOperations(database, userId, olderThanDays = 7) {
    const cutoffDate = Date.now() - (olderThanDays * 24 * 60 * 60 * 1000);

    const oldOps = await database.get('sync_queue').query(
      Q.where('user_id', userId),
      Q.where('status', 'synced'),
      Q.where('synced_at', Q.lt(cutoffDate))
    ).fetch();

    await database.write(async () => {
      for (const op of oldOps) {
        await op.destroyPermanently();
      }
    });

    return oldOps.length;
  }

  /**
   * إعادة محاولة العمليات الفاشلة
   * @param {Database} database
   * @param {string} userId
   * @param {number} maxAttempts
   * @returns {Promise<number>}
   */
  static async retryFailedOperations(database, userId, maxAttempts = 5) {
    const failedOps = await database.get('sync_queue').query(
      Q.where('user_id', userId),
      Q.where('status', 'failed'),
      Q.where('attempts', Q.lt(maxAttempts))
    ).fetch();

    await database.write(async () => {
      for (const op of failedOps) {
        await op.update(() => {
          op.status = 'pending';
        });
      }
    });

    return failedOps.length;
  }

  /**
   * حذف جميع عمليات المستخدم
   * @param {Database} database
   * @param {string} userId
   * @returns {Promise<number>}
   */
  static async deleteAllUserOperations(database, userId) {
    const operations = await database.get('sync_queue').query(
      Q.where('user_id', userId)
    ).fetch();

    await database.write(async () => {
      for (const op of operations) {
        await op.destroyPermanently();
      }
    });

    return operations.length;
  }

  /**
   * الحصول على إحصائيات المزامنة
   * @param {Database} database
   * @param {string} userId
   * @returns {Promise<Object>}
   */
  static async getStats(database, userId) {
    const operations = await database.get('sync_queue').query(
      Q.where('user_id', userId)
    ).fetch();

    const stats = {
      total: operations.length,
      pending: 0,
      synced: 0,
      failed: 0,
      byAction: {},
      byTable: {},
      totalAttempts: 0,
    };

    for (const op of operations) {
      // حسب الحالة
      if (op.status === 'pending') stats.pending++;
      else if (op.status === 'synced') stats.synced++;
      else if (op.status === 'failed') stats.failed++;

      // حسب الإجراء
      if (!stats.byAction[op.action]) {
        stats.byAction[op.action] = 0;
      }
      stats.byAction[op.action]++;

      // حسب الجدول
      if (op.tableName) {
        if (!stats.byTable[op.tableName]) {
          stats.byTable[op.tableName] = 0;
        }
        stats.byTable[op.tableName]++;
      }

      // إجمالي المحاولات
      stats.totalAttempts += op.attempts || 0;
    }

    return stats;
  }

  /**
   * تجميع العمليات حسب الحالة
   * @param {SyncQueue[]} operations
   * @returns {Object}
   */
  static groupByStatus(operations) {
    const groups = {};
    for (const op of operations) {
      if (!groups[op.status]) {
        groups[op.status] = [];
      }
      groups[op.status].push(op);
    }
    return groups;
  }

  /**
   * تجميع العمليات حسب الإجراء
   * @param {SyncQueue[]} operations
   * @returns {Object}
   */
  static groupByAction(operations) {
    const groups = {};
    for (const op of operations) {
      if (!groups[op.action]) {
        groups[op.action] = [];
      }
      groups[op.action].push(op);
    }
    return groups;
  }

  /**
   * تجميع العمليات حسب الجدول
   * @param {SyncQueue[]} operations
   * @returns {Object}
   */
  static groupByTable(operations) {
    const groups = {};
    for (const op of operations) {
      if (!groups[op.tableName]) {
        groups[op.tableName] = [];
      }
      groups[op.tableName].push(op);
    }
    return groups;
  }
}