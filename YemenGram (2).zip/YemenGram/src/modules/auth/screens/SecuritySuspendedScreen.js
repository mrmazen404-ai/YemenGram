/**
 * شاشة التعليق الأمني السيادي (Sovereign Security Suspended Screen)
 * تظهر عند اكتشاف تلاعب بالوقت أو انقطاع طويل للمزامنة
 */

import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, BackHandler, SafeAreaView } from 'react-native';
import { MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';
import { Colors } from '../../../shared/utils/colors';
import { TimeService } from '../../../services/timeService';

export default function SecuritySuspendedScreen({ route, navigation }) {
  const message = route?.params?.message || 'تم تعليق الوصول لأسباب أمنية.';

  const handleBack = () => {
    navigation.navigate('DashboardMain');
  };

  const handleRetry = async () => {
    // محاولة إعادة المزامنة مع السيرفر
    const success = await TimeService.syncWithServer();
    if (success) {
       // إذا نجح، قد نحتاج لإعادة تشغيل التطبيق أو تحديث الحالة
       // هنا نعتمد على أن التطبيق سيقوم بإعادة الفحص عند إعادة التشغيل
       alert('تمت المزامنة بنجاح. يرجى إعادة تشغيل التطبيق.');
    } else {
       alert('فشلت المزامنة. يرجى التأكد من اتصال الإنترنت وضبط الوقت تلقائياً.');
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* 🛡️ الهيدر */}
      <View style={styles.headerNav}>
        <TouchableOpacity style={styles.backBtn} onPress={handleBack}>
           <Ionicons name="close" size={24} color="#FFF" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>التعليق الأمني</Text>
        <View style={{ width: 40 }} />
      </View>

      <View style={styles.content}>
        <MaterialCommunityIcons name="shield-off-outline" size={100} color={Colors.red} />
        <Text style={styles.title}>تعليق أمني سيادي</Text>
        <Text style={styles.desc}>{message}</Text>

        <View style={styles.infoBox}>
          <Text style={styles.infoTitle}>لماذا أرى هذه الشاشة؟</Text>
          <Text style={styles.infoText}>• تم اكتشاف تلاعب في تاريخ أو وقت الهاتف.</Text>
          <Text style={styles.infoText}>• أو لم يتم ربط النظام بالسحابة منذ أكثر من 48 ساعة.</Text>
          <Text style={styles.infoText}>• لحماية بياناتك المالية، تم قفل الإدخال مؤقتاً.</Text>
        </View>

        <TouchableOpacity style={styles.retryBtn} onPress={handleRetry}>
          <Text style={styles.retryText}>محاولة المزامنة والفتح</Text>
        </TouchableOpacity>
      </View>

      <Text style={styles.footer}>YemenGram Security Shield v2.0</Text>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0D1B2A', justifyContent: 'center' },
  headerNav: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingVertical: 15, backgroundColor: '#0D1B2A', borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.05)' },
  backBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: 'rgba(255,255,255,0.05)', justifyContent: 'center', alignItems: 'center' },
  headerTitle: { fontSize: 16, fontFamily: 'Tajawal-Bold', color: '#FFF' },
  content: { alignItems: 'center', paddingHorizontal: 30 },
  title: { fontSize: 24, fontFamily: 'Tajawal-Bold', color: '#FFF', marginTop: 20 },
  desc: { fontSize: 14, fontFamily: 'Tajawal-Medium', color: Colors.red, textAlign: 'center', marginTop: 10, lineHeight: 22 },
  infoBox: { backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: 20, padding: 20, marginTop: 30, width: '100%' },
  infoTitle: { fontSize: 15, fontFamily: 'Tajawal-Bold', color: Colors.gold, marginBottom: 10, textAlign: 'right' },
  infoText: { fontSize: 13, fontFamily: 'Tajawal-Medium', color: '#CBD5E1', textAlign: 'right', marginBottom: 8 },
  retryBtn: { marginTop: 40, backgroundColor: Colors.navy, borderRadius: 15, paddingVertical: 18, width: '100%', alignItems: 'center', borderWidth: 1, borderColor: Colors.gold },
  retryText: { color: '#FFF', fontFamily: 'Tajawal-Bold', fontSize: 16 },
  footer: { position: 'absolute', bottom: 40, alignSelf: 'center', color: 'rgba(255,255,255,0.3)', fontSize: 10, fontFamily: 'Tajawal-Medium' }
});
