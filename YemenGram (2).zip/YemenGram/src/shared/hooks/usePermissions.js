// src/shared/hooks/usePermissions.js
// =============================================
// Hook إدارة الصلاحيات (Permissions Management)
// يدير صلاحيات المستخدم والتحقق من الوصول
// =============================================

import { useState, useEffect, useCallback, useMemo } from 'react';
import { Platform, PermissionsAndroid } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';
import * as Notifications from 'expo-notifications';
import { Logger } from '../utils/logger';

// =============================================
// الثوابت
// =============================================

const PERMISSION_TYPES = {
  CAMERA: 'camera',
  GALLERY: 'gallery',
  LOCATION: 'location',
  NOTIFICATIONS: 'notifications',
  CONTACTS: 'contacts',
  STORAGE: 'storage',
  MICROPHONE: 'microphone',
};

const PERMISSION_STATUS = {
  GRANTED: 'granted',
  DENIED: 'denied',
  UNDETERMINED: 'undetermined',
  BLOCKED: 'blocked',
};

// =============================================
// Hook الرئيسي
// =============================================

export function usePermissions(options = {}) {
  const {
    // ===== الأساسيات =====
    autoCheck = true,
    onPermissionGranted = null,
    onPermissionDenied = null,
    onPermissionBlocked = null,

    // ===== التخصيص =====
    debug = false,
  } = options;

  // ===== الحالة =====
  const [permissions, setPermissions] = useState({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // =============================================
  // 1. دوال التحقق من الصلاحيات
  // =============================================

  /**
   * التحقق من صلاحية الكاميرا
   */
  const checkCameraPermission = useCallback(async () => {
    try {
      if (Platform.OS === 'android') {
        const granted = await PermissionsAndroid.check(
          PermissionsAndroid.PERMISSIONS.CAMERA
        );
        return granted ? PERMISSION_STATUS.GRANTED : PERMISSION_STATUS.DENIED;
      } else {
        const { status } = await ImagePicker.getCameraPermissionsAsync();
        return status === 'granted'
          ? PERMISSION_STATUS.GRANTED
          : status === 'denied'
            ? PERMISSION_STATUS.BLOCKED
            : PERMISSION_STATUS.DENIED;
      }
    } catch (error) {
      Logger.error('checkCameraPermission failed:', error);
      return PERMISSION_STATUS.DENIED;
    }
  }, []);

  /**
   * التحقق من صلاحية المعرض
   */
  const checkGalleryPermission = useCallback(async () => {
    try {
      if (Platform.OS === 'android') {
        const granted = await PermissionsAndroid.check(
          PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE
        );
        return granted ? PERMISSION_STATUS.GRANTED : PERMISSION_STATUS.DENIED;
      } else {
        const { status } = await ImagePicker.getMediaLibraryPermissionsAsync();
        return status === 'granted'
          ? PERMISSION_STATUS.GRANTED
          : status === 'denied'
            ? PERMISSION_STATUS.BLOCKED
            : PERMISSION_STATUS.DENIED;
      }
    } catch (error) {
      Logger.error('checkGalleryPermission failed:', error);
      return PERMISSION_STATUS.DENIED;
    }
  }, []);

  /**
   * التحقق من صلاحية الموقع
   */
  const checkLocationPermission = useCallback(async () => {
    try {
      const { status } = await Location.getForegroundPermissionsAsync();
      return status === 'granted'
        ? PERMISSION_STATUS.GRANTED
        : status === 'denied'
          ? PERMISSION_STATUS.BLOCKED
          : PERMISSION_STATUS.DENIED;
    } catch (error) {
      Logger.error('checkLocationPermission failed:', error);
      return PERMISSION_STATUS.DENIED;
    }
  }, []);

  /**
   * التحقق من صلاحية الإشعارات
   */
  const checkNotificationsPermission = useCallback(async () => {
    try {
      const { status } = await Notifications.getPermissionsAsync();
      return status === 'granted'
        ? PERMISSION_STATUS.GRANTED
        : status === 'denied'
          ? PERMISSION_STATUS.BLOCKED
          : PERMISSION_STATUS.DENIED;
    } catch (error) {
      Logger.error('checkNotificationsPermission failed:', error);
      return PERMISSION_STATUS.DENIED;
    }
  }, []);

  /**
   * التحقق من صلاحية التخزين
   */
  const checkStoragePermission = useCallback(async () => {
    try {
      if (Platform.OS === 'android') {
        const granted = await PermissionsAndroid.check(
          PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE
        );
        return granted ? PERMISSION_STATUS.GRANTED : PERMISSION_STATUS.DENIED;
      } else {
        // iOS: التخزين يُطلب عبر المعرض
        const { status } = await ImagePicker.getMediaLibraryPermissionsAsync();
        return status === 'granted'
          ? PERMISSION_STATUS.GRANTED
          : status === 'denied'
            ? PERMISSION_STATUS.BLOCKED
            : PERMISSION_STATUS.DENIED;
      }
    } catch (error) {
      Logger.error('checkStoragePermission failed:', error);
      return PERMISSION_STATUS.DENIED;
    }
  }, []);

  // =============================================
  // 2. دوال طلب الصلاحيات
  // =============================================

  /**
   * طلب صلاحية الكاميرا
   */
  const requestCameraPermission = useCallback(async () => {
    try {
      setLoading(true);
      let result;

      if (Platform.OS === 'android') {
        result = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.CAMERA,
          {
            title: 'صلاحية الكاميرا',
            message: 'يحتاج التطبيق إلى صلاحية الكاميرا لالتقاط الصور',
            buttonNeutral: 'اسألني لاحقاً',
            buttonNegative: 'إلغاء',
            buttonPositive: 'موافق',
          }
        );
        const granted = result === PermissionsAndroid.RESULTS.GRANTED;
        const status = granted ? PERMISSION_STATUS.GRANTED : PERMISSION_STATUS.DENIED;
        updatePermission(PERMISSION_TYPES.CAMERA, status);
        return status;
      } else {
        const { status } = await ImagePicker.requestCameraPermissionsAsync();
        const permissionStatus = status === 'granted'
          ? PERMISSION_STATUS.GRANTED
          : status === 'denied'
            ? PERMISSION_STATUS.BLOCKED
            : PERMISSION_STATUS.DENIED;
        updatePermission(PERMISSION_TYPES.CAMERA, permissionStatus);
        return permissionStatus;
      }
    } catch (error) {
      Logger.error('requestCameraPermission failed:', error);
      return PERMISSION_STATUS.DENIED;
    } finally {
      setLoading(false);
    }
  }, []);

  /**
   * طلب صلاحية المعرض
   */
  const requestGalleryPermission = useCallback(async () => {
    try {
      setLoading(true);

      if (Platform.OS === 'android') {
        const result = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE,
          {
            title: 'صلاحية المعرض',
            message: 'يحتاج التطبيق إلى صلاحية المعرض لاختيار الصور',
            buttonNeutral: 'اسألني لاحقاً',
            buttonNegative: 'إلغاء',
            buttonPositive: 'موافق',
          }
        );
        const granted = result === PermissionsAndroid.RESULTS.GRANTED;
        const status = granted ? PERMISSION_STATUS.GRANTED : PERMISSION_STATUS.DENIED;
        updatePermission(PERMISSION_TYPES.GALLERY, status);
        return status;
      } else {
        const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
        const permissionStatus = status === 'granted'
          ? PERMISSION_STATUS.GRANTED
          : status === 'denied'
            ? PERMISSION_STATUS.BLOCKED
            : PERMISSION_STATUS.DENIED;
        updatePermission(PERMISSION_TYPES.GALLERY, permissionStatus);
        return permissionStatus;
      }
    } catch (error) {
      Logger.error('requestGalleryPermission failed:', error);
      return PERMISSION_STATUS.DENIED;
    } finally {
      setLoading(false);
    }
  }, []);

  /**
   * طلب صلاحية الموقع
   */
  const requestLocationPermission = useCallback(async () => {
    try {
      setLoading(true);
      const { status } = await Location.requestForegroundPermissionsAsync();
      const permissionStatus = status === 'granted'
        ? PERMISSION_STATUS.GRANTED
        : status === 'denied'
          ? PERMISSION_STATUS.BLOCKED
          : PERMISSION_STATUS.DENIED;
      updatePermission(PERMISSION_TYPES.LOCATION, permissionStatus);
      return permissionStatus;
    } catch (error) {
      Logger.error('requestLocationPermission failed:', error);
      return PERMISSION_STATUS.DENIED;
    } finally {
      setLoading(false);
    }
  }, []);

  /**
   * طلب صلاحية الإشعارات
   */
  const requestNotificationsPermission = useCallback(async () => {
    try {
      setLoading(true);
      const { status } = await Notifications.requestPermissionsAsync();
      const permissionStatus = status === 'granted'
        ? PERMISSION_STATUS.GRANTED
        : status === 'denied'
          ? PERMISSION_STATUS.BLOCKED
          : PERMISSION_STATUS.DENIED;
      updatePermission(PERMISSION_TYPES.NOTIFICATIONS, permissionStatus);
      return permissionStatus;
    } catch (error) {
      Logger.error('requestNotificationsPermission failed:', error);
      return PERMISSION_STATUS.DENIED;
    } finally {
      setLoading(false);
    }
  }, []);

  // =============================================
  // 3. دوال التحقق العامة
  // =============================================

  /**
   * التحقق من صلاحية معينة
   */
  const checkPermission = useCallback(async (type) => {
    switch (type) {
      case PERMISSION_TYPES.CAMERA:
        return await checkCameraPermission();
      case PERMISSION_TYPES.GALLERY:
        return await checkGalleryPermission();
      case PERMISSION_TYPES.LOCATION:
        return await checkLocationPermission();
      case PERMISSION_TYPES.NOTIFICATIONS:
        return await checkNotificationsPermission();
      case PERMISSION_TYPES.STORAGE:
        return await checkStoragePermission();
      default:
        return PERMISSION_STATUS.DENIED;
    }
  }, [
    checkCameraPermission,
    checkGalleryPermission,
    checkLocationPermission,
    checkNotificationsPermission,
    checkStoragePermission,
  ]);

  /**
   * طلب صلاحية معينة
   */
  const requestPermission = useCallback(async (type) => {
    switch (type) {
      case PERMISSION_TYPES.CAMERA:
        return await requestCameraPermission();
      case PERMISSION_TYPES.GALLERY:
        return await requestGalleryPermission();
      case PERMISSION_TYPES.LOCATION:
        return await requestLocationPermission();
      case PERMISSION_TYPES.NOTIFICATIONS:
        return await requestNotificationsPermission();
      default:
        return PERMISSION_STATUS.DENIED;
    }
  }, [
    requestCameraPermission,
    requestGalleryPermission,
    requestLocationPermission,
    requestNotificationsPermission,
  ]);

  /**
   * تحديث حالة الصلاحية في الحالة
   */
  const updatePermission = useCallback((type, status) => {
    setPermissions(prev => ({
      ...prev,
      [type]: status,
    }));

    if (status === PERMISSION_STATUS.GRANTED) {
      if (onPermissionGranted) onPermissionGranted(type);
    } else if (status === PERMISSION_STATUS.DENIED) {
      if (onPermissionDenied) onPermissionDenied(type);
    } else if (status === PERMISSION_STATUS.BLOCKED) {
      if (onPermissionBlocked) onPermissionBlocked(type);
    }

    if (debug) {
      console.log(`🔐 [usePermissions] ${type}: ${status}`);
    }
  }, [onPermissionGranted, onPermissionDenied, onPermissionBlocked, debug]);

  /**
   * التحقق من جميع الصلاحيات
   */
  const checkAllPermissions = useCallback(async () => {
    setLoading(true);
    try {
      const results = await Promise.all([
        checkCameraPermission(),
        checkGalleryPermission(),
        checkLocationPermission(),
        checkNotificationsPermission(),
        checkStoragePermission(),
      ]);

      const types = [
        PERMISSION_TYPES.CAMERA,
        PERMISSION_TYPES.GALLERY,
        PERMISSION_TYPES.LOCATION,
        PERMISSION_TYPES.NOTIFICATIONS,
        PERMISSION_TYPES.STORAGE,
      ];

      const newPermissions = {};
      types.forEach((type, index) => {
        newPermissions[type] = results[index];
      });

      setPermissions(newPermissions);
      return newPermissions;
    } catch (error) {
      Logger.error('checkAllPermissions failed:', error);
      setError(error.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, [
    checkCameraPermission,
    checkGalleryPermission,
    checkLocationPermission,
    checkNotificationsPermission,
    checkStoragePermission,
  ]);

  /**
   * طلب جميع الصلاحيات
   */
  const requestAllPermissions = useCallback(async () => {
    setLoading(true);
    try {
      const results = await Promise.all([
        requestCameraPermission(),
        requestGalleryPermission(),
        requestLocationPermission(),
        requestNotificationsPermission(),
      ]);

      const types = [
        PERMISSION_TYPES.CAMERA,
        PERMISSION_TYPES.GALLERY,
        PERMISSION_TYPES.LOCATION,
        PERMISSION_TYPES.NOTIFICATIONS,
      ];

      const newPermissions = {};
      types.forEach((type, index) => {
        newPermissions[type] = results[index];
      });

      setPermissions(newPermissions);
      return newPermissions;
    } catch (error) {
      Logger.error('requestAllPermissions failed:', error);
      setError(error.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, [
    requestCameraPermission,
    requestGalleryPermission,
    requestLocationPermission,
    requestNotificationsPermission,
  ]);

  // =============================================
  // 4. دوال مساعدة
  // =============================================

  /**
   * التحقق من منح صلاحية معينة
   */
  const isGranted = useCallback((type) => {
    return permissions[type] === PERMISSION_STATUS.GRANTED;
  }, [permissions]);

  /**
   * التحقق من رفض صلاحية معينة
   */
  const isDenied = useCallback((type) => {
    return permissions[type] === PERMISSION_STATUS.DENIED;
  }, [permissions]);

  /**
   * التحقق من حظر صلاحية معينة
   */
  const isBlocked = useCallback((type) => {
    return permissions[type] === PERMISSION_STATUS.BLOCKED;
  }, [permissions]);

  /**
   * التحقق من عدم تحديد صلاحية معينة
   */
  const isUndetermined = useCallback((type) => {
    return permissions[type] === PERMISSION_STATUS.UNDETERMINED;
  }, [permissions]);

  /**
   * الحصول على نص حالة الصلاحية
   */
  const getPermissionStatusText = useCallback((type) => {
    const status = permissions[type];
    switch (status) {
      case PERMISSION_STATUS.GRANTED: return 'ممنوحة';
      case PERMISSION_STATUS.DENIED: return 'مرفوضة';
      case PERMISSION_STATUS.BLOCKED: return 'محظورة';
      case PERMISSION_STATUS.UNDETERMINED: return 'غير محددة';
      default: return 'غير معروفة';
    }
  }, [permissions]);

  /**
   * الحصول على لون حالة الصلاحية
   */
  const getPermissionStatusColor = useCallback((type) => {
    const status = permissions[type];
    switch (status) {
      case PERMISSION_STATUS.GRANTED: return '#27AE60';
      case PERMISSION_STATUS.DENIED: return '#F39C12';
      case PERMISSION_STATUS.BLOCKED: return '#E74C3C';
      default: return '#6B7280';
    }
  }, [permissions]);

  // =============================================
  // 5. تأثيرات (Effects)
  // =============================================

  // التحقق التلقائي عند التحميل
  useEffect(() => {
    if (autoCheck) {
      checkAllPermissions();
    }
  }, [autoCheck, checkAllPermissions]);

  // =============================================
  // 6. القيمة المرجعة
  // =============================================

  return {
    // الحالة
    permissions,
    loading,
    error,

    // دوال التحقق
    checkPermission,
    checkAllPermissions,
    checkCameraPermission,
    checkGalleryPermission,
    checkLocationPermission,
    checkNotificationsPermission,
    checkStoragePermission,

    // دوال الطلب
    requestPermission,
    requestAllPermissions,
    requestCameraPermission,
    requestGalleryPermission,
    requestLocationPermission,
    requestNotificationsPermission,

    // دوال المساعدة
    isGranted,
    isDenied,
    isBlocked,
    isUndetermined,
    getPermissionStatusText,
    getPermissionStatusColor,

    // الثوابت
    PERMISSION_TYPES,
    PERMISSION_STATUS,
  };
}

// =============================================
// Hook مساعد: صلاحية معينة
// =============================================

export function usePermission(type, options = {}) {
  const {
    autoCheck = true,
    onGranted = null,
    onDenied = null,
  } = options;

  const [status, setStatus] = useState(PERMISSION_STATUS.UNDETERMINED);
  const [loading, setLoading] = useState(false);

  const { checkPermission, requestPermission } = usePermissions();

  const check = useCallback(async () => {
    setLoading(true);
    try {
      const result = await checkPermission(type);
      setStatus(result);
      if (result === PERMISSION_STATUS.GRANTED && onGranted) onGranted();
      if (result === PERMISSION_STATUS.DENIED && onDenied) onDenied();
      return result;
    } finally {
      setLoading(false);
    }
  }, [type, checkPermission, onGranted, onDenied]);

  const request = useCallback(async () => {
    setLoading(true);
    try {
      const result = await requestPermission(type);
      setStatus(result);
      if (result === PERMISSION_STATUS.GRANTED && onGranted) onGranted();
      if (result === PERMISSION_STATUS.DENIED && onDenied) onDenied();
      return result;
    } finally {
      setLoading(false);
    }
  }, [type, requestPermission, onGranted, onDenied]);

  useEffect(() => {
    if (autoCheck) {
      check();
    }
  }, [autoCheck, check]);

  return {
    status,
    loading,
    isGranted: status === PERMISSION_STATUS.GRANTED,
    isDenied: status === PERMISSION_STATUS.DENIED,
    isBlocked: status === PERMISSION_STATUS.BLOCKED,
    check,
    request,
  };
}

export default usePermissions;