// src/modules/settings/profile/avatar/AvatarService.js
// محرك الهوية البصرية (Avatar Processing Logic)

import { LocalDB } from '../../../database/localDB';
import { Logger } from '../../../../shared/utils/logger';

export const AvatarService = {
  /**
   * تحديث صورة المستخدم في قاعدة البيانات
   */
  async updateUserAvatar(userId, base64Image) {
    try {
      console.log('🖼️ [AvatarService] تحديث الأفاتار في قاعدة البيانات لـ:', userId);

      await LocalDB.execute(
        'UPDATE user SET avatar = ? WHERE id = ?',
        [base64Image, userId]
      );

      // تسجيل الحدث أمنياً
      await LocalDB.addAuditLog('avatar_update', 'user', userId, {
        timestamp: new Date().toISOString()
      });

      return true;
    } catch (error) {
      Logger.error('AvatarUpdateFailed', error.message);
      throw new Error('فشل تحديث الهوية البصرية');
    }
  }
};
