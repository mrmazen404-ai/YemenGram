import React from 'react';
import { View, Text, Button, Modal, StyleSheet } from 'react-native';
import SubscriptionCoreService from '../services/SubscriptionCoreService';

export default function SubscriptionDialog({ visible, onClose, userId, plan, onSubscribed, navigation }) {
  const handleSubscribe = async () => {
    const subscriptionId = `sub_${userId || 'guest'}_${Date.now()}`;
    const service = new SubscriptionCoreService();

    try {
      const result = await service.processEvent(subscriptionId, 'REQUEST_SUBSCRIPTION', {
        userId,
        plan: plan || 'monthly',
        idempotencyKey: `${subscriptionId}:request`,
        data: {
          selectedPlan: plan || 'monthly',
          requestedAt: Date.now(),
        },
      });

      if (onSubscribed) {
        onSubscribed({ success: true, subscriptionId, result });
      }

      if (navigation) {
        navigation.navigate('ReceiptUploadScreen', { subscriptionId });
      }

      if (onClose) {
        onClose();
      }
    } catch (error) {
      if (onSubscribed) {
        onSubscribed({ success: false, error: error.message || 'subscribe_failed' });
      }
    }
  };

  return (
    <Modal transparent visible={visible} animationType="slide" onRequestClose={onClose}>
      <View style={styles.backdrop}>
        <View style={styles.card}>
          <Text style={styles.title}>Subscribe</Text>
          <Text style={styles.planName}>{plan || 'Monthly Plan'}</Text>
          <Text style={styles.message}>Your subscription request will be created and queued for verification.</Text>

          <View style={styles.actions}>
            <Button title="Cancel" onPress={onClose} />
            <Button title="Subscribe" onPress={handleSubscribe} />
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.35)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  card: {
    width: '100%',
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 20,
  },
  title: {
    fontSize: 22,
    fontWeight: '700',
    marginBottom: 8,
  },
  planName: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 8,
  },
  message: {
    fontSize: 14,
    color: '#444',
    marginBottom: 20,
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
});
