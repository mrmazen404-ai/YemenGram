// App.js
// =============================================
// يمن جرام - نقطة البداية
// =============================================
import React, { useEffect, useState, useRef } from 'react';
import { useFonts } from 'expo-font';
import { View, ActivityIndicator, Text, TouchableOpacity, StatusBar, I18nManager } from 'react-native';
import { AuthProvider } from './src/shared/contexts/AuthContext';
import { Provider } from 'react-redux';
import { store } from './src/store';
import AppNavigator from './src/shared/navigation/AppNavigator';

// ✅ تفعيل دعم اللغة العربية (RTL) بشكل سيادي
if (!I18nManager.isRTL) {
  I18nManager.allowRTL(true);
  I18nManager.forceRTL(true);
}

// ✅ استيراد LocalDB بدلاً من runMigrations مباشرة
import { LocalDB } from './src/modules/database/localDB';
import { TimeService } from './src/services/timeService';
import { HardwareGuard } from './src/modules/subscriptions/utils/HardwareGuard';
import { syncService } from './src/services/syncService';
import NetInfo from '@react-native-community/netinfo';

import { Colors } from './src/shared/utils/colors';
import { Logger } from './src/shared/utils/logger';
// =============================================
// المكون الرئيسي
// =============================================

export default function App() {
  const [fontsLoaded] = useFonts({
    'Tajawal-Bold': require('./src/shared/assets/fonts/Tajawal-Bold.ttf'),
    'Tajawal-Medium': require('./src/shared/assets/fonts/Tajawal-Medium.ttf'),
    'Tajawal-Regular': require('./src/shared/assets/fonts/Tajawal-Regular.ttf'),
  });

  const [dbReady, setDbReady] = useState(false);
  const [dbError, setDbError] = useState(null);
  const [step, setStep] = useState('التهيئة');
  const isMounted = useRef(true);
  const syncIntervalRef = useRef(null);

  // ===== تهيئة التطبيق =====
  useEffect(() => {
    const initialize = async () => {
      try {
        setStep('فحص أمان البيئة');
        const [isEmulator, isRooted] = await Promise.all([
          HardwareGuard.isEmulator(),
          HardwareGuard.isRooted()
        ]);

        if (isEmulator || isRooted) {
          throw new Error('بيئة غير آمنة: يمن جرام يتطلب جهازاً حقيقياً وموثوقاً للعمل.');
        }

        setStep('تهيئة قاعدة البيانات');
        await LocalDB.init();

        // 🛡️ إنفاذ قفل الأجهزة الصارم
        setStep('التحقق من بصمة الجهاز');
        const user = await LocalDB.getUser();
        if (user?.id) {
           const sub = await LocalDB.queryOne('SELECT max_devices FROM subscriptions WHERE user_id = ? ORDER BY created_at DESC LIMIT 1', [user.id]);
           const maxAllowed = sub?.max_devices || 1;
           const isAllowed = await HardwareGuard.validateDeviceAccess(user.id, maxAllowed);

           if (!isAllowed) {
             throw new Error(`سيادة الأجهزة: لقد تجاوزت الحد المسموح به للأجهزة (${maxAllowed}). يرجى حذف جهاز قديم أو ترقية الباقة.`);
           }
        }

        setStep('مزامنة الوقت السيادي');
        await TimeService.initialize();

        // 🔄 بدء مزامنة البيانات السيادية الشاملة في الخلفية فور الإقلاع
        (async () => {
           try {
             const user = await LocalDB.getUser();
             if (user?.id) {
               await syncService.sync();
             }
           } catch (e) { console.log('Background Sync Initial Fail:', e.message); }
        })();

        // ⏱️ إعداد مزامنة دورية في الخلفية كل 5 دقائق
        syncIntervalRef.current = setInterval(async () => {
          try {
            const user = await LocalDB.getUser();
            if (user?.id) {
              console.log('🔄 [Background Sync] بدء المزامنة الدورية...');
              await syncService.sync();
            }
          } catch (e) {
            console.log('❌ [Background Sync Interval Error]:', e.message);
          }
        }, 5 * 60 * 1000);

        setStep('جاهز');
        if (isMounted.current) {
          setDbReady(true);
        }
      } catch (error) {
        if (Logger && typeof Logger.error === 'function') {
          Logger.error('AppInit', error.message);
        }
        if (isMounted.current) {
          setDbError(error.message);
          setDbReady(true);
        }
      }
    };

    initialize();

    return () => {
      isMounted.current = false;
      if (syncIntervalRef.current) {
        clearInterval(syncIntervalRef.current);
      }
    };
  }, []);

  // 🌐 مراقبة حالة الشبكة والاتصال للمزامنة الفورية عند العودة أونلاين
  useEffect(() => {
    const unsubscribe = NetInfo.addEventListener(state => {
      if (state.isConnected) {
        console.log('🌐 [NetInfo] عودة الاتصال بالإنترنت، بدء المزامنة الفورية...');
        (async () => {
          try {
            const user = await LocalDB.getUser();
            if (user?.id) {
              await syncService.sync();
            }
          } catch (e) {
            console.log('❌ [NetInfo Sync Error]:', e.message);
          }
        })();
      }
    });

    return () => {
      unsubscribe();
    };
  }, []);

  // ===== عرض التحميل =====
  if (!fontsLoaded || !dbReady) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: Colors.lightGray }}>
        <ActivityIndicator size="large" color={Colors.navy} />
        {step && (
          <Text style={{ marginTop: 12, fontSize: 14, color: Colors.gray }}>
            {step}...
          </Text>
        )}
      </View>
    );
  }

  // ===== عرض الخطأ =====
  if (dbError) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: Colors.white, padding: 20 }}>
        <Text style={{ fontSize: 18, color: Colors.red, textAlign: 'center' }}>
          ⚠️ فشل تهيئة التطبيق
        </Text>
        <Text style={{ fontSize: 14, color: Colors.gray, textAlign: 'center', marginTop: 8 }}>
          {dbError}
        </Text>
        <TouchableOpacity
          style={{ marginTop: 20, backgroundColor: Colors.navy, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 8 }}
          onPress={() => {
            setDbError(null);
            setDbReady(false);
            setStep('إعادة المحاولة');
            const retry = async () => {
              try {
                await LocalDB.init();
                setDbReady(true);
              } catch (error) {
                setDbError(error.message);
                setDbReady(true);
              }
            };
            retry();
          }}
        >
          <Text style={{ color: Colors.white, fontSize: 14 }}>إعادة المحاولة</Text>
        </TouchableOpacity>
      </View>
    );
  }
  // ===== التطبيق الرئيسي =====
  return (
    <Provider store={store}>
      <AuthProvider>
        <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />
        <AppNavigator />
      </AuthProvider>
    </Provider>
  );
}