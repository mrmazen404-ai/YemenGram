import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet, ScrollView, Alert } from 'react-native';
import { useRoute, useNavigation } from '@react-navigation/native';
import { useAuth } from '../../../../shared/contexts/AuthContext';
import SubscriptionCoreService from '../../services/SubscriptionCoreService';
import { LocalDB } from '../../../database/localDB';

const ADMIN_ROLES = new Set(['admin', 'owner', 'super_admin']);

export default function AdminRequestDetail() {
  const route = useRoute();
  const navigation = useNavigation();
  const { user: actor } = useAuth();
  const [request, setRequest] = React.useState(route?.params?.request || null);
  const [localStatus, setLocalStatus] = React.useState(request?.status || 'VERIFICATION_PENDING');

  React.useEffect(() => {
    const load = async () => {
      if (request || !route?.params?.requestId) return;
      const row = await LocalDB.queryOne(
        `SELECT s.id, s.user_id, s.status, s.plan, s.total, s.price, s.payment_proof, s.verification_requested_at, s.created_at,
                u.name AS user_name, u.email AS user_email, u.phone AS user_phone
         FROM subscriptions s LEFT JOIN user u ON u.id = s.user_id WHERE s.id = ?`, [route.params.requestId]
      );
      if (row) {
        setRequest({ id: row.id, userId: row.user_id, userName: row.user_name || 'مستخدم', email: row.user_email || '', phone: row.user_phone || '', plan: row.plan || 'monthly', status: row.status || 'VERIFICATION_PENDING', amount: row.total || row.price || 0, submittedAt: new Date(row.verification_requested_at || row.created_at || Date.now()).toLocaleString('ar-EG'), receiptUrl: row.payment_proof || null });
        setLocalStatus(row.status || 'VERIFICATION_PENDING');
      }
    };
    load().catch(() => {});
  }, [request, route?.params?.requestId]);

  const ensureAdmin = () => {
    if (!actor?.id || !ADMIN_ROLES.has(actor.role)) throw new Error('ADMIN_AUTH_REQUIRED');
  };

  const applyDecision = async (approved) => {
    if (!request) return;
    try {
      ensureAdmin();
      const event = approved ? 'VERIFICATION_APPROVED' : 'VERIFICATION_REJECTED';
      const result = await new SubscriptionCoreService().processEvent(request.id, event, {
        userId: request.userId,
        actorId: actor.id,
        actorRole: actor.role,
        plan: request.plan,
        idempotencyKey: `${request.id}:${event}:${actor.id}`,
      });
      if (result?.duplicate) throw new Error('تمت معالجة القرار مسبقاً.');
      await LocalDB.execute('UPDATE receipts SET status = ?, updated_at = ? WHERE subscription_id = ? AND status = \'pending\'', [approved ? 'approved' : 'rejected', Date.now(), request.id], { system: true });
      await LocalDB.execute(
        `INSERT INTO notifications (user_id, type, title, message, read, created_at) VALUES (?, ?, ?, ?, 0, datetime('now'))`,
        [request.userId, 'subscription', approved ? 'تم تفعيل الاشتراك' : 'تم رفض الإيصال', approved ? `تمت الموافقة على باقة ${request.plan}.` : 'تعذر التحقق من إيصال الدفع.'],
        { system: true }
      );
      setLocalStatus(approved ? 'ACTIVE_FULL' : 'UNSUBSCRIBED');
      Alert.alert(approved ? 'تمت الموافقة' : 'تم الرفض', 'تم حفظ القرار وتسجيله.');
      navigation.goBack();
    } catch (error) { Alert.alert('فشل', error?.message || 'تعذر حفظ القرار'); }
  };

  if (!request) return <View style={styles.empty}><Text style={styles.emptyText}>لا يوجد طلب</Text></View>;
  return <ScrollView style={styles.container} contentContainerStyle={styles.content}>
    <Text style={styles.title}>تفاصيل طلب الاشتراك</Text>
    <View style={styles.card}><Text style={styles.label}>اسم المستخدم</Text><Text style={styles.value}>{request.userName}</Text><Text style={styles.label}>الخطة</Text><Text style={styles.value}>{request.plan}</Text><Text style={styles.label}>المبلغ</Text><Text style={styles.value}>{Number(request.amount || 0).toFixed(0)}</Text><Text style={styles.label}>الحالة</Text><Text style={styles.value}>{localStatus}</Text></View>
    {request.receiptUrl ? <Image source={{ uri: request.receiptUrl }} style={styles.image} resizeMode="cover" /> : null}
    <View style={styles.actions}><TouchableOpacity style={styles.approveButton} onPress={() => applyDecision(true)}><Text style={styles.approveText}>موافقة</Text></TouchableOpacity><TouchableOpacity style={styles.rejectButton} onPress={() => applyDecision(false)}><Text style={styles.rejectText}>رفض</Text></TouchableOpacity></View>
  </ScrollView>;
}
const styles = StyleSheet.create({ container: { flex: 1, backgroundColor: '#f3f4f6' }, content: { padding: 20, paddingBottom: 40 }, title: { fontSize: 26, fontWeight: '800', color: '#111827', marginBottom: 16 }, card: { backgroundColor: '#fff', borderRadius: 16, padding: 16, marginBottom: 16 }, label: { fontSize: 12, color: '#6b7280', marginTop: 8 }, value: { fontSize: 16, color: '#111827', fontWeight: '700', marginTop: 4 }, image: { width: '100%', height: 260, borderRadius: 16, backgroundColor: '#e5e7eb', marginBottom: 18 }, actions: { flexDirection: 'row', justifyContent: 'space-between', gap: 12 }, approveButton: { flex: 1, backgroundColor: '#16a34a', borderRadius: 12, paddingVertical: 14, alignItems: 'center' }, approveText: { color: '#fff', fontWeight: '700', fontSize: 16 }, rejectButton: { flex: 1, backgroundColor: '#dc2626', borderRadius: 12, paddingVertical: 14, alignItems: 'center' }, rejectText: { color: '#fff', fontWeight: '700', fontSize: 16 }, empty: { flex: 1, justifyContent: 'center', alignItems: 'center' }, emptyText: { fontSize: 18, color: '#374151' } });
