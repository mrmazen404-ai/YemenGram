/**
 * هوك التنبيهات الاستباقية (Sovereign Dunning Hook)
 * المسؤول عن مراقبة اقتراب انتهاء الاشتراك وتوليد الرسائل التحذيرية
 */

import { useSelector } from 'react-redux';
import { useMemo } from 'react';

export const useSubscriptionDunning = () => {
  const subscription = useSelector((state) => state.subscription?.data);

  const dunningInfo = useMemo(() => {
    if (!subscription || !subscription.endDate) return null;

    const now = Date.now();
    const daysRemaining = subscription.daysRemaining;

    // 1. بروتوكول التنبيهات (T-X)
    if (daysRemaining <= 0) {
      return {
        level: 'CRITICAL',
        message: 'تم تحويل النظام لوضع القراءة فقط. يرجى التجديد فوراً لاستعادة السيادة المالية.',
        color: '#EF4444',
        icon: 'lock-alert'
      };
    }

    if (daysRemaining <= 1) {
      return {
        level: 'HIGH',
        message: 'غداً سيتحول النظام لوضع القراءة فقط. جدد اشتراكك الآن لتجنب التوقف.',
        color: '#EF4444',
        icon: 'alert-octagon'
      };
    }

    if (daysRemaining <= 3) {
      return {
        level: 'HIGH',
        message: `باقي ${daysRemaining} أيام فقط. جدد الآن واحصل على تمديد تجريبي 7 أيام مجاناً.`,
        color: '#F97316',
        icon: 'alert'
      };
    }

    if (daysRemaining <= 7) {
      return {
        level: 'MEDIUM',
        message: 'باقي أسبوع واحد على انتهاء السيادة المالية. التجديد السريع متاح الآن.',
        color: '#F59E0B',
        icon: 'clock-alert'
      };
    }

    if (daysRemaining <= 30) {
      return {
        level: 'INFO',
        message: `باقي ${daysRemaining} يوم على انتهاء اشتراكك. جدد الآن واحصل على خصم 10%.`,
        color: '#3B82F6',
        icon: 'information'
      };
    }

    return null;
  }, [subscription]);

  return { dunningInfo, subscription };
};

export default useSubscriptionDunning;
