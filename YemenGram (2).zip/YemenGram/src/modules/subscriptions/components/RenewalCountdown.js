/**
 * عداد تنازلي للتجديد (Renewal Countdown Component)
 */

import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Colors } from '../../../shared/utils/colors';

export default function RenewalCountdown({ days }) {
  const getLevelColor = () => {
    if (days <= 3) return '#EF4444';
    if (days <= 7) return '#F97316';
    return Colors.gold;
  };

  return (
    <View style={styles.container}>
      <View style={[styles.circle, { borderColor: getLevelColor() }]}>
        <Text style={[styles.days, { color: getLevelColor() }]}>{days}</Text>
        <Text style={styles.label}>أيام متبقية</Text>
      </View>
      <Text style={styles.note}>سيتحول النظام لوضع القراءة فقط عند انتهاء العداد.</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { alignItems: 'center', padding: 20 },
  circle: {
    width: 130,
    height: 130,
    borderRadius: 65,
    borderWidth: 6,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 15,
    backgroundColor: '#FFF',
    elevation: 5,
  },
  days: { fontSize: 42, fontFamily: 'Tajawal-Bold' },
  label: { fontSize: 12, fontFamily: 'Tajawal-Bold', color: '#64748B' },
  note: { fontSize: 11, fontFamily: 'Tajawal-Medium', color: '#94A3B8', textAlign: 'center' }
});
