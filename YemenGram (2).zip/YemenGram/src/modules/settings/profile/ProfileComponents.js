// src/modules/settings/profile/ProfileComponents.js
// المكونات السيادية الفاخرة (Major Corporation Components)

import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, Modal, TextInput, ActivityIndicator } from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { Colors } from '../../../shared/utils/colors';
import { styles } from './ProfileStyles';

// 1. مؤشر النزاهة الأمنية
export const SecurityMeter = ({ score }) => {
  const getColor = (s) => {
    if (s < 50) return Colors.red;
    if (s < 80) return Colors.gold;
    return Colors.green;
  };
  return (
    <View style={styles.securityCard}>
      <View style={styles.securityHeader}>
        <View style={styles.securityTitleRow}>
          <MaterialCommunityIcons name="shield-check" size={20} color={getColor(score)} />
          <Text style={styles.securityTitle}>قوة حماية الحساب</Text>
        </View>
        <Text style={[styles.securityPercent, { color: getColor(score) }]}>{score}%</Text>
      </View>
      <View style={styles.progressTrack}>
        <View style={[styles.progressFill, { width: `${score}%`, backgroundColor: getColor(score) }]} />
      </View>
    </View>
  );
};

// 2. حقل معلومات "نخبوي"
export const EliteInput = ({ label, value, isMasked, onEdit, icon }) => (
  <TouchableOpacity style={styles.inputRow} onPress={onEdit} activeOpacity={0.6} disabled={!onEdit}>
    <View style={styles.inputIconBox}><Ionicons name={icon} size={18} color={Colors.navy} /></View>
    <View style={styles.inputContent}>
      <Text style={styles.inputLabelText}>{label}</Text>
      <Text style={[styles.inputValueText, isMasked && styles.maskedValue]}>
        {isMasked ? value.replace(/.(?=.{4})/g, '•') : value}
      </Text>
    </View>
    {onEdit && <View style={{ opacity: 0.3 }}><Ionicons name="chevron-back" size={14} color={Colors.dark} /></View>}
  </TouchableOpacity>
);

// 3. دايلوج تأكيد النية (Mini Action Sheet)
export const MiniConfirmSheet = ({ visible, onCancel, onConfirm, title, desc }) => (
  <Modal visible={visible} transparent animationType="fade">
    <View style={styles.modalOverlay}>
      <View style={styles.bottomSheet}>
        <View style={styles.sheetHandle} />
        <Text style={styles.sheetTitle}>{title}</Text>
        <Text style={styles.sheetDesc}>{desc}</Text>
        <View style={styles.sheetActionRow}>
          <TouchableOpacity style={styles.confirmBtn} onPress={onConfirm}><Text style={styles.confirmBtnText}>تأكيد</Text></TouchableOpacity>
          <TouchableOpacity style={styles.cancelBtn} onPress={onCancel}><Text style={styles.cancelBtnText}>تراجع</Text></TouchableOpacity>
        </View>
      </View>
    </View>
  </Modal>
);

// 4. دايلوج إدخال الرقم الاحترافي (المصلح - بروتوكول الدقة)
export const ProfessionalPhoneModal = ({ visible, onCancel, onConfirm, loading }) => {
  const [phone, setPhone] = useState('');
  const [provider, setProvider] = useState({ name: 'انتظار الرقم...', color: Colors.placeholder, icon: 'cellphone' });
  const [isValid, setIsValid] = useState(false);

  // ✅ خوارزمية كشف المشغل اليمني المحدثة (تشمل 78)
  useEffect(() => {
    const clean = phone.replace(/\s/g, '');

    if (clean.startsWith('77') || clean.startsWith('78')) {
      setProvider({ name: 'Yemen Mobile', color: Colors.navy, icon: 'shield-check' });
    } else if (clean.startsWith('73')) {
      setProvider({ name: 'YOU Network', color: '#FFD700', icon: 'flash' });
    } else if (clean.startsWith('71')) {
      setProvider({ name: 'Sabafon', color: Colors.red, icon: 'antenna' });
    } else if (clean.startsWith('70')) {
      setProvider({ name: 'Y Network', color: Colors.green, icon: 'connection' });
    } else {
      setProvider({ name: 'ادخل رقم يمني صحيح', color: Colors.placeholder, icon: 'alert-circle' });
    }

    // السماح فقط إذا كان الطول 9 والبادئة صحيحة
    setIsValid(clean.length === 9 && /^(77|73|71|70|78)/.test(clean));
  }, [phone]);

  const handleTextChange = (text) => {
    const cleaned = text.replace(/[^0-9]/g, '');
    if (cleaned.length <= 9) setPhone(cleaned);
  };

  return (
    <Modal visible={visible} transparent animationType="slide">
      <View style={styles.modalOverlay}>
        <View style={styles.bottomSheet}>
          <View style={styles.sheetHandle} />
          <Text style={styles.sheetTitle}>تغيير رقم الهوية الرقمية</Text>

          <View style={[styles.providerBadge, { backgroundColor: provider.color + '15' }]}>
             <MaterialCommunityIcons name={provider.icon} size={14} color={provider.color} />
             <Text style={[styles.providerText, { color: provider.color }]}>{provider.name}</Text>
          </View>

          <TextInput
            style={[styles.professionalInput, isValid && { borderColor: Colors.green }]}
            placeholder="77XXXXXXX"
            value={phone}
            onChangeText={handleTextChange}
            keyboardType="phone-pad"
            maxLength={9}
            autoFocus
          />

          <Text style={styles.sheetDesc}>سيتم استدعاء بصمة النظام لتفويض هذا الرقم الجديد</Text>

          <View style={styles.sheetActionRow}>
            <TouchableOpacity
              style={[styles.confirmBtn, (!isValid || loading) && { opacity: 0.4 }]}
              onPress={() => isValid && onConfirm(phone)}
              disabled={!isValid || loading}
            >
              {loading ? <ActivityIndicator color="#FFF" /> : <Text style={styles.confirmBtnText}>تغيير وتفويض</Text>}
            </TouchableOpacity>
            <TouchableOpacity style={styles.cancelBtn} onPress={() => { setPhone(''); onCancel(); }} disabled={loading}>
              <Text style={styles.cancelBtnText}>إلغاء</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
};

// 5. مدير الجلسات النخبوي
export const EliteSession = ({ session, onTerminate }) => (
  <View style={styles.sessionItem}>
    <View style={styles.sessionIcon}><MaterialCommunityIcons name={session.device === 'Web Dashboard' ? 'laptop' : 'cellphone-check'} size={22} color={Colors.navy} /></View>
    <View style={styles.sessionInfo}>
      <Text style={styles.sessionDevice}>{session.device}</Text>
      <Text style={[styles.sessionStatus, !session.current && { color: Colors.gray }]}>{session.status} • IP: {session.ip}</Text>
    </View>
    {!session.current && <TouchableOpacity style={styles.terminateBtn} onPress={onTerminate}><Ionicons name="close-circle-outline" size={18} color={Colors.red} /></TouchableOpacity>}
  </View>
);
