import { LocalDB } from './storageService';
import { AccountsService } from '../../modules/accounts/services/accountsService';
// =============================================
// خدمة القيود اليومية (Journal Service)
// =============================================
export const JournalService = {
  // =============================================
  // 1. CRUD الأساسي
  // =============================================

  /**
   * إضافة قيد جديد مع تحديث الأرصدة
   */
  async create(data) {
    const { date, description, entries, currency = 'YER', created_by } = data;

    // التحقق من البيانات
    if (!entries || entries.length === 0) {
      throw new Error('يجب إضافة تفاصيل القيد');
    }

    // حساب الإجماليات والتحقق من التوازن
    let totalDebit = 0;
    let totalCredit = 0;

    for (const entry of entries) {
      const debit = parseFloat(entry.debit) || 0;
      const credit = parseFloat(entry.credit) || 0;

      if (!entry.account_id) {
        throw new Error('جميع الحسابات مطلوبة');
      }

      if (debit === 0 && credit === 0) {
        throw new Error('كل صف يجب أن يحتوي على مبلغ (مدين أو دائن)');
      }

      if (debit > 0 && credit > 0) {
        throw new Error('الصف لا يمكن أن يكون مديناً ودائناً معاً');
      }

      totalDebit += debit;
      totalCredit += credit;
    }

    if (totalDebit !== totalCredit) {
      throw new Error(`القيد غير متوازن (مدين: ${totalDebit}، دائن: ${totalCredit})`);
    }

    // توليد رقم القيد
    const numberResult = await LocalDB.queryOne(
      'SELECT MAX(number) as max FROM journal_entries'
    );
    const nextNumber = (numberResult?.max || 0) + 1;

    const id = `je_${Date.now()}`;

    // حفظ القيد
    await LocalDB.execute(
      `INSERT INTO journal_entries
       (id, number, date, description, total_debit, total_credit, currency, status, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        id,
        nextNumber,
        date || new Date().toISOString().split('T')[0],
        description || '',
        totalDebit,
        totalCredit,
        currency,
        'posted',
        created_by || null,
      ]
    );

    // حفظ تفاصيل القيد وتحديث الأرصدة
    const accountIds = [];

    for (const entry of entries) {
      const debit = parseFloat(entry.debit) || 0;
      const credit = parseFloat(entry.credit) || 0;

      await LocalDB.execute(
        `INSERT INTO journal_details
         (journal_entry_id, account_id, debit, credit, description)
         VALUES (?, ?, ?, ?, ?)`,
        [id, entry.account_id, debit, credit, entry.description || '']
      );

      // تسجيل الحركة في account_movements
      await AccountsService.addMovement({
        account_id: entry.account_id,
        date: date || new Date().toISOString().split('T')[0],
        journal_entry_id: id,
        description: description || entry.description || '',
        debit: debit,
        credit: credit,
      });

      // تحديث رصيد الحساب
      await AccountsService.updateBalance(entry.account_id);

      accountIds.push(entry.account_id);
    }

    return {
      success: true,
      id,
      number: nextNumber,
      message: 'تم حفظ القيد بنجاح',
    };
  },

  /**
   * جلب قيد بالـ ID
   */
  async getById(id) {
    const entry = await LocalDB.queryOne(
      'SELECT * FROM journal_entries WHERE id = ?',
      [id]
    );

    if (!entry) return null;

    const details = await LocalDB.query(
      'SELECT * FROM journal_details WHERE journal_entry_id = ?',
      [id]
    );

    return { ...entry, details };
  },

  /**
   * جلب قيد بالرقم
   */
  async getByNumber(number) {
    const entry = await LocalDB.queryOne(
      'SELECT * FROM journal_entries WHERE number = ?',
      [number]
    );

    if (!entry) return null;

    const details = await LocalDB.query(
      'SELECT * FROM journal_details WHERE journal_entry_id = ?',
      [entry.id]
    );

    return { ...entry, details };
  },

  /**
   * جلب جميع القيود
   */
  async getAll(filters = {}) {
    let sql = 'SELECT * FROM journal_entries WHERE 1=1';
    const params = [];

    if (filters.fromDate) {
      sql += ' AND date >= ?';
      params.push(filters.fromDate);
    }

    if (filters.toDate) {
      sql += ' AND date <= ?';
      params.push(filters.toDate);
    }

    if (filters.status) {
      sql += ' AND status = ?';
      params.push(filters.status);
    }

    if (filters.account_id) {
      sql += ` AND id IN (
        SELECT journal_entry_id FROM journal_details WHERE account_id = ?
      )`;
      params.push(filters.account_id);
    }

    sql += ' ORDER BY date DESC, number DESC';

    const entries = await LocalDB.query(sql, params);

    // جلب تفاصيل كل قيد
    const result = [];
    for (const entry of entries) {
      const details = await LocalDB.query(
        'SELECT * FROM journal_details WHERE journal_entry_id = ?',
        [entry.id]
      );
      result.push({ ...entry, details });
    }

    return result;
  },

  /**
   * تحديث قيد
   */
  async update(id, data) {
    const existing = await this.getById(id);
    if (!existing) throw new Error('القيد غير موجود');

    if (existing.status === 'posted') {
      throw new Error('لا يمكن تعديل قيد مرسل');
    }

    const { date, description, entries, currency } = data;

    // حساب الإجماليات والتحقق من التوازن
    let totalDebit = 0;
    let totalCredit = 0;

    if (entries) {
      for (const entry of entries) {
        const debit = parseFloat(entry.debit) || 0;
        const credit = parseFloat(entry.credit) || 0;

        if (!entry.account_id) throw new Error('جميع الحسابات مطلوبة');
        if (debit === 0 && credit === 0) {
          throw new Error('كل صف يجب أن يحتوي على مبلغ');
        }

        totalDebit += debit;
        totalCredit += credit;
      }

      if (totalDebit !== totalCredit) {
        throw new Error('القيد غير متوازن');
      }
    }

    // تحديث القيد
    const updates = [];
    const params = [];

    if (date) { updates.push('date = ?'); params.push(date); }
    if (description !== undefined) { updates.push('description = ?'); params.push(description); }
    if (currency) { updates.push('currency = ?'); params.push(currency); }
    if (entries) { updates.push('total_debit = ?'); params.push(totalDebit); }
    if (entries) { updates.push('total_credit = ?'); params.push(totalCredit); }

    if (updates.length === 0) {
      return { success: true, message: 'لا توجد تغييرات' };
    }

    params.push(id);
    await LocalDB.execute(
      `UPDATE journal_entries SET ${updates.join(', ')}, updated_at = datetime('now') WHERE id = ?`,
      params
    );

    // إذا تغيرت التفاصيل
    if (entries) {
      // حذف التفاصيل القديمة
      const oldDetails = await LocalDB.query(
        'SELECT * FROM journal_details WHERE journal_entry_id = ?',
        [id]
      );

      await LocalDB.execute(
        'DELETE FROM journal_details WHERE journal_entry_id = ?',
        [id]
      );

      // إضافة التفاصيل الجديدة
      for (const entry of entries) {
        const debit = parseFloat(entry.debit) || 0;
        const credit = parseFloat(entry.credit) || 0;

        await LocalDB.execute(
          `INSERT INTO journal_details
           (journal_entry_id, account_id, debit, credit, description)
           VALUES (?, ?, ?, ?, ?)`,
          [id, entry.account_id, debit, credit, entry.description || '']
        );
      }

      // إعادة حساب جميع الأرصدة
      const allAccountIds = [...new Set([
        ...oldDetails.map(d => d.account_id),
        ...entries.map(e => e.account_id),
      ])];

      for (const accountId of allAccountIds) {
        await AccountsService.updateBalance(accountId);
      }
    }

    return { success: true, message: 'تم تحديث القيد' };
  },

  /**
   * حذف قيد
   */
  async delete(id) {
    const existing = await this.getById(id);
    if (!existing) throw new Error('القيد غير موجود');

    if (existing.status === 'posted') {
      throw new Error('لا يمكن حذف قيد مرسل');
    }

    // جلب تفاصيل القيد لتحديث الأرصدة
    const details = await LocalDB.query(
      'SELECT * FROM journal_details WHERE journal_entry_id = ?',
      [id]
    );

    // حذف القيد
    await LocalDB.execute('DELETE FROM journal_details WHERE journal_entry_id = ?', [id]);
    await LocalDB.execute('DELETE FROM journal_entries WHERE id = ?', [id]);

    // إعادة حساب الأرصدة
    const accountIds = [...new Set(details.map(d => d.account_id))];
    for (const accountId of accountIds) {
      await AccountsService.updateBalance(accountId);
    }

    return { success: true, message: 'تم حذف القيد' };
  },

  /**
   * ترحيل قيد (تغيير الحالة إلى posted)
   */
  async post(id) {
    const existing = await this.getById(id);
    if (!existing) throw new Error('القيد غير موجود');

    if (existing.status === 'posted') {
      return { success: true, message: 'القيد مرسل بالفعل' };
    }

    await LocalDB.execute(
      'UPDATE journal_entries SET status = "posted", updated_at = datetime("now") WHERE id = ?',
      [id]
    );

    return { success: true, message: 'تم ترحيل القيد' };
  },

  /**
   * إلغاء ترحيل قيد (تغيير الحالة إلى draft)
   */
  async unpost(id) {
    const existing = await this.getById(id);
    if (!existing) throw new Error('القيد غير موجود');

    if (existing.status === 'draft') {
      return { success: true, message: 'القيد غير مرسل بالفعل' };
    }

    await LocalDB.execute(
      'UPDATE journal_entries SET status = "draft", updated_at = datetime("now") WHERE id = ?',
      [id]
    );

    return { success: true, message: 'تم إلغاء ترحيل القيد' };
  },

  /**
   * إلغاء قيد (تغيير الحالة إلى void)
   */
  async void(id) {
    const existing = await this.getById(id);
    if (!existing) throw new Error('القيد غير موجود');

    if (existing.status === 'void') {
      return { success: true, message: 'القيد ملغي بالفعل' };
    }

    await LocalDB.execute(
      'UPDATE journal_entries SET status = "void", updated_at = datetime("now") WHERE id = ?',
      [id]
    );

    return { success: true, message: 'تم إلغاء القيد' };
  },

  /**
   * الحصول على ملخص القيود حسب الفترة
   */
  async getSummary(fromDate, toDate) {
    const result = await LocalDB.queryOne(
      `SELECT
        COUNT(*) as total_entries,
        SUM(total_debit) as total_debit,
        SUM(total_credit) as total_credit
       FROM journal_entries
       WHERE date >= ? AND date <= ? AND status = 'posted'`,
      [fromDate, toDate]
    );

    return {
      total_entries: result?.total_entries || 0,
      total_debit: result?.total_debit || 0,
      total_credit: result?.total_credit || 0,
    };
  },

  /**
   * الحصول على آخر عدد من القيود
   */
  async getRecent(limit = 10) {
    const entries = await LocalDB.query(
      'SELECT * FROM journal_entries ORDER BY date DESC, number DESC LIMIT ?',
      [limit]
    );

    const result = [];
    for (const entry of entries) {
      const details = await LocalDB.query(
        'SELECT * FROM journal_details WHERE journal_entry_id = ?',
        [entry.id]
      );
      result.push({ ...entry, details });
    }

    return result;
  },
};