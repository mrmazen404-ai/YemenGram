/**
 * بصمة تدقيق محلية غير موثوقة.
 * لا يوجد سر داخل تطبيق العميل؛ الاعتماد الجنائي النهائي يجب أن يتم خادمياً.
 */
import * as Crypto from 'expo-crypto';

const canonical = (payload) => typeof payload === 'string' ? payload : JSON.stringify(payload);
export const sign = async (payload) => Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256, canonical(payload));
export const verify = async (payload, signature) => Boolean(signature) && (await sign(payload)) === signature;
export default { sign, verify };
