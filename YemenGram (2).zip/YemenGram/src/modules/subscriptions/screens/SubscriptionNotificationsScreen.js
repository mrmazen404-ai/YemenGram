import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
} from 'react-native';
import LocalDB from '../../database/localDB';

export default function SubscriptionNotificationsScreen() {
  const [items, setItems] = React.useState([]);

  React.useEffect(() => {
    (async () => {
      try {
        const user = await LocalDB.getUser();
        if (!user?.id) {
          setItems([]);
          return;
        }

        const rows = await LocalDB.query(
          'SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 10',
          [user.id]
        );
        setItems(rows || []);
      } catch (error) {
        setItems([]);
      }
    })();
  }, []);

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.title}>الإشعارات</Text>

      {items.length === 0 ? (
        <View style={styles.emptyCard}>
          <Text style={styles.emptyText}>لا توجد إشعارات في الوقت الحالي</Text>
        </View>
      ) : (
        items.map((item) => (
          <View key={item.id} style={styles.card}>
            <Text style={styles.type}>{item.type || 'info'}</Text>
            <Text style={styles.message}>{item.title || 'إشعار'}</Text>
            <Text style={styles.body}>{item.message || ''}</Text>
            <Text style={styles.time}>{item.created_at || ''}</Text>
          </View>
        ))
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f5f5' },
  content: { padding: 20, paddingBottom: 32 },
  title: { fontSize: 28, fontWeight: '800', color: '#111827', marginBottom: 18 },
  emptyCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 18,
    alignItems: 'center',
  },
  emptyText: { color: '#6b7280', fontSize: 15 },
  card: {
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  type: {
    fontSize: 12,
    color: '#0f766e',
    fontWeight: '700',
    marginBottom: 8,
    textTransform: 'uppercase',
  },
  message: { fontSize: 16, color: '#111827', fontWeight: '700', marginBottom: 6 },
  body: { fontSize: 13, color: '#4b5563', lineHeight: 20 },
  time: { marginTop: 8, fontSize: 12, color: '#6b7280' },
});

