// Web fallback: Expo Web uses LocalDB; WatermelonDB's Node adapter must never enter the browser bundle.
export const database = null;
export const getDatabase = () => null;
export default getDatabase;
