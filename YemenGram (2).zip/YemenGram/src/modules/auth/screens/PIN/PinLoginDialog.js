// src/modules/auth/screens/PIN/PinLoginDialog.js
// واجهة تسجيل الدخول بالرمز السري (Zero-Error Sleek Edition)
// تم تحسينها لتعمل كـ Overlay ثابت لضمان استجابة اللمس 100%

import React, { useState, useRef, useEffect, memo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Dimensions,
  Platform,
  StatusBar,
  Alert,
  BackHandler,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import * as LocalAuthentication from 'expo-local-authentication';
import * as Haptics from 'expo-haptics';
import { Colors } from '../../../../shared/utils/colors';
import { useAuth } from '../../../../shared/contexts/AuthContext';
import { LocalDB } from '../../../../shared/services/storageService';
import Loading from '../../../../shared/components/Loading';

const { width, height } = Dimensions.get('window');
const PIN_LENGTH = 6;
const MAX_ATTEMPTS = 5;
const LOCK_TIME_SECONDS = 300;

const PinLoginDialog = memo(({ visible, onSuccess, onWipe }) => {
const { verifyPIN, isBiometricEnabled } = useAuth();

  // ===== State =====
  const [pin, setPin] = useState('');
  const [error, setError] = useState({ active: false, message: '' });
  const [attempts, setAttempts] = useState(0);
  const [lockTimer, setLockTimer] = useState(0);
  const [loading, setLoading] = useState(false);
  const [biometric, setBiometric] = useState({ supported: false, type: '', enabled: false });

  // ===== Animations =====
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;
  const shakeAnim = useRef(new Animated.Value(0)).current;

  // ===== Effects =====
  useEffect(() => {
    if (visible) {
      checkInitialSecurity();
      animateIn();

      // منع زر الرجوع في الأندرويد أثناء قفل التطبيق
      const backHandler = BackHandler.addEventListener('hardwareBackPress', () => true);
      return () => backHandler.remove();
    }
  }, [visible]);

  useEffect(() => {
    let interval;
    if (lockTimer > 0) {
      interval = setInterval(() => setLockTimer(p => Math.max(0, prev - 1)), 1000);
    } else if (lockTimer === 0 && attempts >= MAX_ATTEMPTS) {
      setAttempts(0);
      setError({ active: false, message: '' });
    }
    return () => interval && clearInterval(interval);
  }, [lockTimer]);

  const animateIn = () => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 300, useNativeDriver: true }),
      Animated.spring(slideAnim, { toValue: 0, tension: 80, friction: 12, useNativeDriver: true }),
    ]).start();
  };

  const triggerHaptic = (type = 'selection') => {
    if (Platform.OS === 'web') return;
    if (type === 'error') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    else if (type === 'success') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    else Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const doShake = () => {
    triggerHaptic('error');
    Animated.sequence([
      Animated.timing(shakeAnim, { toValue: 10, duration: 40, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -10, duration: 40, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 5, duration: 40, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 0, duration: 40, useNativeDriver: true }),
    ]).start();
  };

  const checkInitialSecurity = async () => {
    try {
      const [hw, en, bioEnabled] = await Promise.all([
        LocalAuthentication.hasHardwareAsync(),
        LocalAuthentication.isEnrolledAsync(),
        isBiometricEnabled()
      ]);
      const types = await LocalAuthentication.supportedAuthenticationTypesAsync();
      const type = types.includes(LocalAuthentication.AuthenticationType.FACIAL_RECOGNITION) ? 'face' : 'finger';
      setBiometric({ supported: hw && en, type, enabled: bioEnabled });
      if (bioEnabled && hw && en && lockTimer === 0) setTimeout(handleBiometricAuth, 600);
    } catch (e) {}
  };

  const handleKeyPress = (num) => {
    if (loading || lockTimer > 0) return;
    triggerHaptic();
    if (num === 'delete') {
      setPin(p => p.slice(0, -1));
      setError({ active: false, message: '' });
      return;
    }
    const newPin = pin + num;
    if (newPin.length <= PIN_LENGTH) setPin(newPin);
    if (newPin.length === PIN_LENGTH) processLogin(newPin);
  };

  const processLogin = async (enteredPin) => {
    setLoading(true);
    try {
      const isValid = await verifyPIN(enteredPin);
      if (isValid) {
        triggerHaptic('success');
        setPin('');
        if (onSuccess) onSuccess();
      } else {
        const nextAttempts = attempts + 1;
        setAttempts(nextAttempts);
        setPin('');
        doShake();
        if (nextAttempts >= MAX_ATTEMPTS) {
          setLockTimer(LOCK_TIME_SECONDS);
          setError({ active: true, message: 'تم قفل الدخول مؤقتاً' });
        } else {
          setError({ active: true, message: `الرمز غير صحيح (بقي ${MAX_ATTEMPTS - nextAttempts} محاولات)` });
        }
      }
    } catch (e) {
      setError({ active: true, message: 'خطأ في نظام الأمان' });
    } finally {
      setLoading(false);
    }
  };

  const handleBiometricAuth = async () => {
    if (lockTimer > 0) return;
    const result = await LocalAuthentication.authenticateAsync({ promptMessage: 'تأكيد الهوية' });
    if (result.success) {
      triggerHaptic('success');
      if (onSuccess) onSuccess();
    }
  };

  if (!visible) return null;

  return (
    <View style={styles.absoluteContainer}>
      <StatusBar barStyle="light-content" backgroundColor="rgba(0,0,0,0.6)" />
      <Animated.View style={[styles.overlay, { opacity: fadeAnim }]}>
        <Animated.View style={[styles.card, { transform: [{ translateY: slideAnim }, { translateX: shakeAnim }] }]}>

          <View style={styles.header}>
            <Text style={styles.headerTitle}>دخول آمن</Text>
            {attempts >= 3 && (
              <TouchableOpacity onPress={() => {
                Alert.alert('تنبيه', 'هل تود مسح البيانات؟', [{text:'إلغاء'}, {text:'مسح', style:'destructive', onPress: onWipe}]);
              }}>
                <Ionicons name="trash-outline" size={16} color={Colors.red} />
              </TouchableOpacity>
            )}
          </View>

          <View style={styles.content}>
            <View style={[styles.iconCircle, lockTimer > 0 && {backgroundColor: '#FFF0F0'}]}>
              <Ionicons name={lockTimer > 0 ? "timer" : "lock-closed"} size={22} color={lockTimer > 0 ? Colors.red : Colors.navy} />
            </View>
            <Text style={styles.title}>{lockTimer > 0 ? 'يرجى الانتظار' : 'مرحباً بك'}</Text>

            <View style={styles.dotsRow}>
              {Array.from({ length: PIN_LENGTH }).map((_, i) => (
                <View key={i} style={[styles.dot, pin.length > i && styles.dotFilled, error.active && pin.length > i && styles.dotError]} />
              ))}
            </View>

            {error.active && <Text style={styles.errorText}>{error.message}</Text>}

            <View style={styles.keypad}>
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 'bio', 0, 'delete'].map((k, i) => (
                <TouchableOpacity
                  key={i}
                  style={[styles.key, k === '' && styles.keyEmpty, k === 'delete' && styles.keyDelete]}
                  onPress={() => k === 'bio' ? handleBiometricAuth() : k !== '' && handleKeyPress(k)}
                  disabled={lockTimer > 0 || (k === 'bio' && !biometric.enabled)}
                >
                  {k === 'delete' ? <Ionicons name="backspace-outline" size={20} color={Colors.dark} /> :
                   k === 'bio' ? <Ionicons name={biometric.type === 'face' ? "scan" : "finger-print"} size={22} color={Colors.navy} /> :
                   <Text style={styles.keyText}>{k}</Text>}
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </Animated.View>
      </Animated.View>
      {loading && <Loading visible={true} />}
    </View>
  );
});

const styles = StyleSheet.create({
  absoluteContainer: { ...StyleSheet.absoluteFillObject, zIndex: 9999, elevation: 99 },
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.65)', justifyContent: 'center', alignItems: 'center' },
  card: { width: width * 0.82, maxWidth: 320, backgroundColor: '#FFFFFF', borderRadius: 28, padding: 16, elevation: 20 },
  header: { flexDirection: 'row-reverse', justifyContent: 'space-between', marginBottom: 10 },
  headerTitle: { fontSize: 11, fontFamily: 'Tajawal-Bold', color: Colors.placeholder },
  content: { alignItems: 'center' },
  iconCircle: { width: 50, height: 50, borderRadius: 15, backgroundColor: '#F1F5F9', justifyContent: 'center', alignItems: 'center', marginBottom: 8 },
  title: { fontSize: 18, fontFamily: 'Tajawal-Bold', color: Colors.dark, marginBottom: 15 },
  dotsRow: { flexDirection: 'row-reverse', gap: 10, marginBottom: 10 },
  dot: { width: 12, height: 12, borderRadius: 6, borderWidth: 1.5, borderColor: '#E2E8F0' },
  dotFilled: { backgroundColor: Colors.navy, borderColor: Colors.navy },
  dotError: { backgroundColor: Colors.red, borderColor: Colors.red },
  errorText: { color: Colors.red, fontSize: 10, fontFamily: 'Tajawal-Bold', marginBottom: 10 },
  keypad: { width: '100%', flexDirection: 'row-reverse', flexWrap: 'wrap', justifyContent: 'center', gap: 10 },
  key: { width: '28%', height: 52, borderRadius: 14, backgroundColor: '#F8FAFC', justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: '#F1F5F9' },
  keyEmpty: { backgroundColor: 'transparent', borderWidth: 0 },
  keyDelete: { backgroundColor: '#FFF5F5' },
  keyText: { fontSize: 22, fontFamily: 'Tajawal-Bold', color: Colors.navy },
});

export default PinLoginDialog;
