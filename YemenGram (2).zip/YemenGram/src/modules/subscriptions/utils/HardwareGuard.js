/**
 * حارس العتاد السيادي (Sovereign Hardware Guard)
 * المسؤول عن استخراج بصمة الجهاز وفحص أمان البيئة
 */

import * as Device from 'expo-device';
import * as SecureStore from 'expo-secure-store';
import { Platform } from 'react-native';
import { LocalDB } from '../../database/localDB';

const HWID_KEY = 'yg_sovereign_hwid';

/**
 * دالة تحويل بسيطة لـ Base64 لضمان التوافق مع React Native
 */
const toBase64 = (str) => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
  let encoded = '';
  for (let i = 0; i < str.length; i += 3) {
    const c1 = str.charCodeAt(i);
    const c2 = str.charCodeAt(i + 1) || 0;
    const c3 = str.charCodeAt(i + 2) || 0;

    const b1 = (c1 >> 2) & 0x3F;
    const b2 = ((c1 & 0x3) << 4) | ((c2 >> 4) & 0xF);
    const b3 = ((c2 & 0xF) << 2) | ((c3 >> 6) & 0x3);
    const b4 = c3 & 0x3F;

    encoded += chars[b1] + chars[b2] + (i + 1 < str.length ? chars[b3] : '=') + (i + 2 < str.length ? chars[b4] : '=');
  }
  return encoded;
};

export const HardwareGuard = {
  /**
   * الحصول على بصمة الجهاز الفريدة (Hardware ID)
   * يتم توليدها مرة واحدة وتخزينها في SecureStore لضمان الثبات
   */
  async getSovereignId() {
    try {
      let hwid = await SecureStore.getItemAsync(HWID_KEY);

      if (!hwid) {
        // توليد بصمة بناءً على مواصفات العتاد + عشوائية محمية
        const fingerprint = `${Device.brand}-${Device.modelName}-${Device.osInternalBuildId || Date.now()}`;
        hwid = toBase64(fingerprint).substring(0, 32);
        await SecureStore.setItemAsync(HWID_KEY, hwid);
      }

      return hwid;
    } catch (e) {
      return null;
    }
  },

  /**
   * فحص هل الجهاز محاكي (Emulator Detection)
   */
  async isEmulator() {
    if (__DEV__) return false; // السماح للمطورين بالعمل على المحاكي
    return !Device.isDevice;
  },

  /**
   * فحص الروت (Root Detection) - بصيغة سيادية مبسطة
   */
  async isRooted() {
    // Expo لا يوفر كشف root كاملاً؛ لا ندّعي نتيجة غير موثوقة.
    // يجب ربط ذلك في نسخة الإنتاج بـ Play Integrity/App Attest أو مكتبة Native مدققة.
    return false;
  },

  /**
   * التحقق من قانونية الجهاز الحالي وصلاحية الدخول بناءً على حدود الباقة
   * @param {string} userId - معرف المستخدم
   * @param {number} maxDevices - الحد الأقصى للأجهزة المسموح بها
   * @returns {Promise<boolean>} - true إذا كان الجهاز مسموحاً له بالدخول
   */
  async validateDeviceAccess(userId, maxDevices = 1) {
    try {
      const hwid = await this.getSovereignId();
      if (!hwid) return false;

      // 1. هل الجهاز الحالي مسجل مسبقاً؟
      const isRegistered = await LocalDB.queryOne(
        'SELECT id FROM devices WHERE user_id = ? AND device_id = ?',
        [userId, hwid]
      );

      if (isRegistered) {
        // تحديث آخر ظهور
        await LocalDB.execute(
          'UPDATE devices SET last_seen = datetime("now") WHERE device_id = ?',
          [hwid]
        );
        return true;
      }

      // 2. إذا لم يكن مسجلاً، كم عدد الأجهزة الحالية؟
      const countResult = await LocalDB.queryOne(
        'SELECT COUNT(*) as total FROM devices WHERE user_id = ?',
        [userId]
      );
      const currentCount = countResult?.total || 0;

      // 3. منع الدخول إذا تجاوز الحد
      if (currentCount >= maxDevices) {
        console.warn(`🛡️ [HardwareGuard] رفض الدخول: تم تجاوز حد الأجهزة (${currentCount}/${maxDevices})`);
        return false;
      }

      // 4. تسجيل الجهاز الجديد تلقائياً إذا كان ضمن الحد
      const meta = await this.getDeviceMetadata();
      await LocalDB.execute(
        `INSERT INTO devices (id, user_id, device_id, name, model, brand, os) VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [`dev_${Date.now()}`, userId, hwid, meta.deviceName || meta.model, meta.model, meta.brand, meta.os]
      );

      return true;
    } catch (e) {
      console.error('Device Validation Failure:', e.message);
      // Fail-closed: فشل التحقق لا يسمح بتجاوز حد الأجهزة.
      return false;
    }
  },

  /**
   * الحصول على بيانات الجهاز للمزامنة
   */
  async getDeviceMetadata() {
    return {
      brand: Device.brand,
      model: Device.modelName,
      os: Device.osName,
      osVersion: Device.osVersion,
      isDevice: Device.isDevice,
      deviceName: Device.deviceName,
    };
  }
};

export default HardwareGuard;
