// src/modules/dashboard/components/VaultCard.js
// بطاقة الخزنة السيادية - النسخة المخصصة للسلايدر (v7.0 Sovereign Slider-Ready)

import React, { useState } from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet, Dimensions } from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { Colors } from '../../../shared/utils/colors';
import SafeGradient from '../../../shared/components/SafeGradient';

const { width } = Dimensions.get('window');
const scale = (size) => (width / 375) * size;

const VaultCard = ({ cardWidth }) => {
  const [showBalance, setShowBalance] = useState(true);

  const mockData = {
    totalYER: '45,820,000',
    totalUSD: '18,500',
    totalSAR: '68,200',
    revenueDay: '1.2M',
    expensesDay: '450K',
    integrityLevel: 'MASVS L2',
    syncStatus: 'Synced',
  };

  return (
    <SafeGradient colors={[Colors.navy, '#0A192F', '#0D2137']} style={styles.card}>
      <Image
        source={require('../../../shared/assets/images/hint.png')}
        style={styles.overlay}
        resizeMode="repeat"
      />

      {/* الصف العلوي */}
      <View style={styles.headerRow}>
        <View style={styles.identity}>
          <MaterialCommunityIcons name="shield-check" size={14} color={Colors.gold} />
          <Text style={styles.companyName}>YemenGram Dashboard</Text>
          <View style={styles.securityBadge}>
            <Text style={styles.securityText}>{mockData.integrityLevel}</Text>
          </View>
        </View>

        <View style={styles.miniCurrencies}>
          <Text style={styles.miniVal}>{showBalance ? mockData.totalUSD : '••••'} $</Text>
          <View style={styles.miniDivider} />
          <Text style={styles.miniVal}>{showBalance ? mockData.totalSAR : '••••'} ﷼</Text>
        </View>
      </View>

      {/* المركز المالي */}
      <View style={styles.mainBalance}>
        <View style={styles.balanceHeader}>
          <Text style={styles.balanceLabel}>إجمالي السيولة المتاحة</Text>
          <TouchableOpacity onPress={() => setShowBalance(!showBalance)}>
            <Ionicons name={showBalance ? "eye-outline" : "eye-off-outline"} size={16} color="rgba(255,255,255,0.3)" />
          </TouchableOpacity>
        </View>

        <View style={styles.valueRow}>
          <Text
            style={styles.mainValue}
            numberOfLines={1}
            adjustsFontSizeToFit
          >
            {showBalance ? mockData.totalYER : '••••••••••'}
          </Text>
          <Text style={styles.mainCurrency}>YER</Text>
        </View>
      </View>

      {/* النبض التشغيلي */}
      <View style={styles.pulseRow}>
        <View style={styles.pulseItem}>
          <View style={[styles.pulseIcon, { backgroundColor: 'rgba(74, 222, 128, 0.08)' }]}>
            <Ionicons name="trending-up" size={12} color="#4ADE80" />
          </View>
          <Text style={styles.pulseLabel}>لكم:</Text>
          <Text style={[styles.pulseValue, { color: '#4ADE80' }]}>{showBalance ? mockData.revenueDay : '••'}</Text>
        </View>

        <View style={styles.verticalDivider} />

        <View style={styles.pulseItem}>
          <View style={[styles.pulseIcon, { backgroundColor: 'rgba(248, 113, 113, 0.08)' }]}>
            <Ionicons name="trending-down" size={12} color="#F87171" />
          </View>
          <Text style={styles.pulseLabel}>عليكم:</Text>
          <Text style={[styles.pulseValue, { color: '#F87171' }]}>{showBalance ? mockData.expensesDay : '••'}</Text>
        </View>

        <View style={styles.syncIndicator}>
          <View style={styles.syncDot} />
          <Text style={styles.syncText}>{mockData.syncStatus}</Text>
        </View>
      </View>
    </SafeGradient>
  );
};

const styles = StyleSheet.create({
  card: {
    width: '100%', // جعل البطاقة تأخذ كامل عرض الحاوية لضمان التمركز
    height: scale(165),
    borderRadius: scale(22),
    padding: scale(14),
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.06)',
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.07,
    tintColor: Colors.white,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: scale(12),
  },
  identity: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: scale(6),
  },
  companyName: {
    fontSize: 11,
    fontFamily: 'Tajawal-Bold',
    color: Colors.white,
  },
  securityBadge: {
    backgroundColor: 'rgba(212, 168, 83, 0.15)',
    paddingHorizontal: 6,
    paddingVertical: 1,
    borderRadius: 6,
    borderWidth: 0.5,
    borderColor: 'rgba(212, 168, 83, 0.3)',
  },
  securityText: {
    fontSize: 7,
    fontFamily: 'Tajawal-Bold',
    color: Colors.gold,
  },
  miniCurrencies: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: scale(8),
    backgroundColor: 'rgba(0,0,0,0.15)',
    paddingHorizontal: scale(10),
    paddingVertical: scale(4),
    borderRadius: scale(10),
  },
  miniVal: {
    fontSize: 10,
    fontFamily: 'Tajawal-Bold',
    color: 'rgba(255,255,255,0.7)',
  },
  miniDivider: {
    width: 1,
    height: 8,
    backgroundColor: 'rgba(255,255,255,0.1)',
  },
  mainBalance: {
    alignItems: 'flex-end',
    marginBottom: 12,
  },
  balanceHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 2,
  },
  balanceLabel: {
    fontSize: 9,
    fontFamily: 'Tajawal-Medium',
    color: 'rgba(255,255,255,0.4)',
  },
  valueRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 6,
  },
  mainValue: {
    fontSize: scale(30),
    fontFamily: 'Tajawal-Bold',
    color: Colors.white,
    letterSpacing: 0.5,
    maxWidth: '85%',
  },
  mainCurrency: {
    fontSize: 12,
    fontFamily: 'Tajawal-Bold',
    color: Colors.gold,
    marginBottom: 6,
  },
  pulseRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: scale(10),
    borderTopWidth: 0.5,
    borderTopColor: 'rgba(255,255,255,0.08)',
    gap: scale(12),
  },
  pulseItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: scale(6),
  },
  pulseIcon: {
    width: 20,
    height: 20,
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center',
  },
  pulseLabel: {
    fontSize: 9,
    fontFamily: 'Tajawal-Medium',
    color: 'rgba(255,255,255,0.4)',
  },
  pulseValue: {
    fontSize: 12,
    fontFamily: 'Tajawal-Bold',
  },
  verticalDivider: {
    width: 1,
    height: 12,
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  syncIndicator: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    gap: 4,
  },
  syncDot: {
    width: 4,
    height: 4,
    borderRadius: 2,
    backgroundColor: '#4ADE80',
  },
  syncText: {
    fontSize: 8,
    fontFamily: 'Tajawal-Bold',
    color: '#4ADE80',
    opacity: 0.7,
  },
});

export default VaultCard;
