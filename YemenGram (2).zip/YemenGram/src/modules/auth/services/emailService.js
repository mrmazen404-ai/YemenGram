const SERVICE_ID = 'service_z5hw54a';
const PUBLIC_KEY = 'FfdIx_XYfT_JVG_7D';
const PRIVATE_KEY = 'e3fa4zWc4Rvdqy2np98EC';

const TEMPLATES = {
  otp: 'template_zxqet76',
  reset: 'template_r7ebel5',
};

export async function sendOTPEmail(email, code) {
  try {
      console.log('sendOTP received email:', email);
    const response = await fetch('https://api.emailjs.com/api/v1.0/email/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        service_id: SERVICE_ID,
        template_id: TEMPLATES.otp,
        user_id: PUBLIC_KEY,
        accessToken: PRIVATE_KEY,
        template_params: {
          email: email,
          otp_code: code,
        },
      }),
    });

    const result = await response.text();
    console.log('EmailJS result:', result);
    return response.ok;
  } catch (error) {
    console.log('EmailJS error:', error);
    return false;
  }
}

export async function sendResetEmail(email, resetLink) {
  try {
    const response = await fetch('https://api.emailjs.com/api/v1.0/email/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        service_id: SERVICE_ID,
        template_id: TEMPLATES.reset,
        user_id: PUBLIC_KEY,
        accessToken: PRIVATE_KEY,
        template_params: {
          to_email: email,
          reset_link: resetLink,
        },
      }),
    });

    return response.ok;
  } catch (error) {
    console.log('EmailJS error:', error);
    return false;
  }
}