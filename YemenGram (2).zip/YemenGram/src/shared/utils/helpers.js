/**
 * =============================================
 * دوال مساعدة (Helpers)
 * =============================================
 */

import { LocalDB } from '../services/storageService';

/**
 * توليد رقم مستخدم فريد
 * الصيغة: YG_XXXXXXXX
 */
export const generateUserCode = () => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let code = '';
  for (let i = 0; i < 8; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `YG_${code}`;
};

/**
 * التحقق من أن الرقم غير مكرر
 */
export const isUserCodeUnique = async (code) => {
  try {
    const result = await LocalDB.queryOne(
      'SELECT id FROM user WHERE user_code = ?',
      [code]
    );
    return !result;
  } catch (error) {
    console.log('⚠️ [isUserCodeUnique] خطأ في التحقق:', error.message);
    return false;
  }
};

/**
 * توليد رقم فريد بشكل مضمون
 */
export const generateUniqueUserCode = async () => {
  let attempts = 0;
  let code;
  let isUnique = false;

  while (!isUnique && attempts < 10) {
    code = generateUserCode();
    isUnique = await isUserCodeUnique(code);
    attempts++;
    console.log(`🔑 [generateUniqueUserCode] محاولة ${attempts}: ${code} - ${isUnique ? '✅ فريد' : '❌ مكرر'}`);
  }

  if (!isUnique) {
    // في حالة فشل التوليد بعد 10 محاولات، نستخدم timestamp
    code = `YG_${Date.now().toString(36).toUpperCase()}`;
    console.log(`⚠️ [generateUniqueUserCode] استخدام timestamp: ${code}`);
  }

  return code;
};

/**
 * نسخ النص إلى الحافظة
 */
export const copyToClipboard = (text) => {
  // سيتم استخدامها في الملف الشخصي
  console.log(`📋 [copyToClipboard] تم نسخ: ${text}`);
};