/**
 * شاشة الخطة السنوية السيادية (Sovereign Annual Plan Screen)
 */

import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, SafeAreaView } from 'react-native';
import { MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';
import { Colors } from '../../../shared/utils/colors';

export default function AnnualPlanScreen({ navigation }) {
  const handleBack = () => {
    if (navigation.canGoBack()) {
      navigation.goBack();
    } else {
      navigation.navigate('PlansCatalog');
    }
  };

  const features = [
    { title: 'دعم حتى 10 أجهزة متزامنة', icon: 'devices' },
    { title: 'إدارة 500 عميل بنشاط كامل', icon: 'account-group' },
    { title: 'إصدار فواتير غير محدود', icon: 'file-document-edit' },
    { title: 'مزامنة سحابية فائقة السرعة', icon: 'cloud-sync' },
    { title: 'تقارير محاسبية ومالية متقدمة', icon: 'chart-areaspline' },
    { title: 'دعم فني ذو أولوية (VIP)', icon: 'crown' },
  ];

  return (
    <SafeAreaView style={styles.root}>
      <ScrollView style={styles.container} contentContainerStyle={styles.content}>

        <View style={styles.header}>
          <TouchableOpacity style={styles.backBtn} onPress={handleBack}>
            <Ionicons name="chevron-forward" size={24} color={Colors.navy} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>تفاصيل العقد السنوي</Text>
          <View style={{ width: 40 }} />
        </View>

        <View style={styles.priceCard}>
           <Text style={styles.planName}>الخطة السنوية (توفير 20%)</Text>
           <View style={styles.amountRow}>
              <Text style={styles.currency}>ر.ي</Text>
              <Text style={styles.amount}>30,000</Text>
              <Text style={styles.period}>/ سنوياً</Text>
           </View>
           <View style={styles.badge}>
              <Text style={styles.badgeText}>خيار النخبة الاقتصادي</Text>
           </View>
        </View>

        <Text style={styles.sectionTitle}>مزايا النخبة السنوية:</Text>

        <View style={styles.featureGrid}>
          {features.map((f, i) => (
            <View key={i} style={styles.featureItem}>
              <View style={styles.iconCircle}>
                <MaterialCommunityIcons name={f.icon} size={20} color={Colors.navy} />
              </View>
              <Text style={styles.featureText}>{f.title}</Text>
            </View>
          ))}
        </View>

        <View style={styles.termsBox}>
           <Text style={styles.termsTitle}>ميثاق الاشتراك السنوي:</Text>
           <Text style={styles.termsText}>• يشمل كافة التحديثات الأمنية والوظيفية مجاناً.</Text>
           <Text style={styles.termsText}>• نسخة احتياطية سحابية يومية مؤمنة.</Text>
           <Text style={styles.termsText}>• الأولوية في دعم وتطوير الميزات المطلوبة.</Text>
        </View>

        <TouchableOpacity
          style={styles.subscribeBtn}
          onPress={() => navigation.navigate('SubscriptionPayment', { plan: 'annual', amount: 30000 })}
        >
          <Text style={styles.subscribeBtnText}>الموافقة والبدء بالسيادة السنوية</Text>
          <Ionicons name="arrow-back" size={20} color="#FFF" />
        </TouchableOpacity>

      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#F8FAFC' },
  container: { flex: 1 },
  content: { padding: 20, paddingBottom: 40 },
  header: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', marginBottom: 30 },
  backBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: '#FFF', justifyContent: 'center', alignItems: 'center', elevation: 2 },
  headerTitle: { fontSize: 18, fontFamily: 'Tajawal-Bold', color: Colors.navy },
  priceCard: {
    backgroundColor: '#1E293B',
    borderRadius: 30,
    padding: 30,
    alignItems: 'center',
    marginBottom: 30,
    elevation: 10,
  },
  planName: { fontSize: 16, fontFamily: 'Tajawal-Medium', color: Colors.gold, marginBottom: 10 },
  amountRow: { flexDirection: 'row-reverse', alignItems: 'baseline', gap: 5 },
  amount: { fontSize: 42, fontFamily: 'Tajawal-Bold', color: '#FFF' },
  currency: { fontSize: 18, fontFamily: 'Tajawal-Bold', color: Colors.gold },
  period: { fontSize: 14, fontFamily: 'Tajawal-Medium', color: 'rgba(255,255,255,0.5)' },
  badge: { backgroundColor: Colors.gold, paddingHorizontal: 15, paddingVertical: 5, borderRadius: 10, marginTop: 20 },
  badgeText: { fontSize: 12, fontFamily: 'Tajawal-Bold', color: '#1E293B' },
  sectionTitle: { fontSize: 16, fontFamily: 'Tajawal-Bold', color: '#334155', marginBottom: 20, textAlign: 'right' },
  featureGrid: { gap: 15, marginBottom: 35 },
  featureItem: { flexDirection: 'row-reverse', alignItems: 'center', gap: 15 },
  iconCircle: { width: 40, height: 40, borderRadius: 12, backgroundColor: '#FFF', justifyContent: 'center', alignItems: 'center', elevation: 2 },
  featureText: { fontSize: 14, fontFamily: 'Tajawal-Medium', color: '#475569', flex: 1, textAlign: 'right' },
  termsBox: { backgroundColor: '#F1F5F9', borderRadius: 20, padding: 20, marginBottom: 35 },
  termsTitle: { fontSize: 13, fontFamily: 'Tajawal-Bold', color: Colors.navy, marginBottom: 10, textAlign: 'right' },
  termsText: { fontSize: 11, fontFamily: 'Tajawal-Medium', color: '#64748B', textAlign: 'right', marginBottom: 5 },
  subscribeBtn: {
    backgroundColor: Colors.navy,
    borderRadius: 20,
    paddingVertical: 20,
    flexDirection: 'row-reverse',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 15,
  },
  subscribeBtnText: { color: '#FFF', fontFamily: 'Tajawal-Bold', fontSize: 16 },
});
