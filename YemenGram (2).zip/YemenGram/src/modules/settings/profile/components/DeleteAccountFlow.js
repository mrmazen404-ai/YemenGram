// src/modules/settings/profile/components/DeleteAccountFlow.js
// بروتوكول التطهير النهائي (Irreversible Deletion Protocol - v1.1 Hardened)

import React, { useState, useRef, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TextInput, Alert, Animated, Keyboard } from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import Modal from '../../../../shared/components/Modal';
import Input from '../../../../shared/components/Input';
import Button from '../../../../shared/components/Button';
import SecurityLoading from '../../../../shared/components/SecurityLoading';
import { Colors } from '../../../../shared/utils/colors';
import { useAuth } from '../../../../shared/contexts/AuthContext';
import { useNavigation } from '@react-navigation/native'; // ✅ إضافة نظام التنقل

export const DeleteAccountFlow = ({ visible, onClose }) => {
  const { user, sendOTP, verifyOTP, deleteAccount } = useAuth();
  const navigation = useNavigation(); // ✅ ربط محرك التنقل
  const [step, setStep] = useState('warning'); // warning, otp, final
  const [otpCode, setOtpCode] = useState(['', '', '', '', '', '']);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [focusedIndex, setFocusedIndex] = useState(0);

  const inputRefs = useRef([]);

  const resetAndClose = () => {
    Keyboard.dismiss(); // ✅ تطهير لوحة المفاتيح فوراً
    setStep('warning');
    setOtpCode(['', '', '', '', '', '']);
    setError('');
    onClose();
  };

  const handleNextFromWarning = async () => {
    handleRequestOTP();
  };

  const handleRequestOTP = async () => {
    setLoading(true);
    try {
      await sendOTP(user.email);
      setStep('otp');
      setError('');
    } catch (e) {
      setError('فشل إرسال رمز التحقق');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOTP = async () => {
    const code = otpCode.join('');
    if (code.length < 6) return;

    Keyboard.dismiss(); // ✅ تطهير لوحة المفاتيح قبل الختم النهائي
    setLoading(true);
    try {
      const result = await verifyOTP(user.email, code);
      if (result.success) {
        setStep('final');
      }
    } catch (e) {
      setError('الرمز غير صحيح');
    } finally {
      setLoading(false);
    }
  };

  const handleFinalPurge = async () => {
    setLoading(true);
    try {
      await deleteAccount();
      // ملاحظة: لا نحتاج لعمل navigation.reset يدوياً هنا
      // لأن AppNavigator سيكتشف حالة purgeSuccess وينقلك تلقائياً
      onClose();
    } catch (e) {
      Alert.alert('خطأ حرج', 'فشل تنفيذ عملية الحذف النهائية');
    } finally {
      setLoading(false);
    }
  };

  const handleOTPChange = (v, i) => {
    const cleaned = v.replace(/[^0-9]/g, '');
    const newCode = [...otpCode];
    newCode[i] = cleaned;
    setOtpCode(newCode);
    if (cleaned && i < 5) inputRefs.current[i+1]?.focus();
    if (newCode.every(c => c !== '')) setError('');
  };

  return (
    <>
      <SecurityLoading visible={loading} status="جاري المعالجة..." />

      {/* 1. بوابة التحذير */}
      <Modal
        visible={visible && step === 'warning'}
        title="حذف الحساب نهائياً"
        type="danger"
        confirmText="استمر"
        cancelText="تراجع"
        onConfirm={handleNextFromWarning}
        onCancel={resetAndClose}
      >
        <View style={styles.warningBox}>
          <Text style={styles.warningText}>تنبيه حرج: سيتم مسح كافة البيانات:</Text>
          <View style={styles.bulletList}>
            <Text style={styles.bullet}>• مسح شامل لكافة العملاء والحسابات والتقارير.</Text>
            <Text style={styles.bullet}>• حذف النسخ الاحتياطية نهائياً ولا يمكن استرجاعها.</Text>
          </View>
          <Text style={styles.responsibilityText}>أنت المسؤول الوحيد عن هذا الإجراء.</Text>
        </View>
      </Modal>

      {/* 2. بوابة OTP */}
      <Modal
        visible={visible && step === 'otp'}
        title="تأكيد البريد الإلكتروني"
        confirmText="تأكيد الرمز"
        cancelText="إلغاء"
        onConfirm={handleVerifyOTP}
        onCancel={resetAndClose}
      >
        <View style={styles.otpSection}>
          <Text style={styles.otpDesc}>أدخل الرمز المرسل لبريدك للمتابعة</Text>
          <View style={styles.otpRow}>
            {otpCode.map((d, i) => (
              <TextInput
                key={i}
                ref={r => inputRefs.current[i] = r}
                style={[
                  styles.otpBox,
                  d !== '' && styles.otpBoxFilled,
                  focusedIndex === i && styles.otpBoxFocused
                ]}
                value={d}
                onChangeText={v => handleOTPChange(v, i)}
                onFocus={() => setFocusedIndex(i)}
                keyboardType="number-pad"
                maxLength={1}
                textAlign="center"
              />
            ))}
          </View>
          {error !== '' && <Text style={styles.errorText}>{error}</Text>}
        </View>
      </Modal>

      {/* 4. الختم النهائي */}
      <Modal
        visible={visible && step === 'final'}
        title="ختم الإعدام الرقمي"
        type="danger"
        confirmText="حذف نهائي ومؤكد"
        cancelText="إلغاء فوراً"
        onConfirm={handleFinalPurge}
        onCancel={resetAndClose}
      >
        <View style={styles.finalBox}>
          <Ionicons name="skull-outline" size={48} color={Colors.red} />
          <Text style={styles.finalText}>هل أنت متأكد للمرة الأخيرة؟</Text>
          <Text style={styles.finalSub}>لا يمكن التراجع بعد ضغط الزر التالي.</Text>
        </View>
      </Modal>
    </>
  );
};

const styles = StyleSheet.create({
  warningBox: { padding: 3, },
  warningText: { fontSize: 13, fontFamily: 'Tajawal-Bold', color: Colors.dark, textAlign: 'right', marginBottom: 10 },
  bulletList: { gap: 5, marginBottom: 15 },
  bullet: { fontSize: 13, fontFamily: 'Tajawal-Regular', color: Colors.gray, textAlign: 'right' },
  responsibilityText: { fontSize: 12, fontFamily: 'Tajawal-Bold', color: Colors.red, textAlign: 'center', marginTop: 10 },

  otpSection: { alignItems: 'center',justifyContent: 'center', paddingHorizontal:20, paddingVertical: 30, width: '100%' },
  otpDesc: { fontSize: 14, fontFamily: 'Tajawal-Medium', color: Colors.gray, marginBottom: 20 },
  otpRow: { flexDirection: 'row-reverse', gap: 2, justifyContent: 'center', width: '110%' },
  otpBox: {
    width: 30,
    height: 45,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: Colors.border,
    fontSize: 14,
    fontFamily: 'Tajawal-Bold',
    backgroundColor: '#F9FAFB',
    color: Colors.dark
  },
  otpBoxFilled: { borderColor: Colors.navy, backgroundColor: Colors.white },
  otpBoxFocused: { borderColor: Colors.gold, shadowColor: Colors.gold, shadowOpacity: 0.1, shadowRadius: 5, elevation: 2 },
  errorText: { color: Colors.red, fontSize: 12, marginTop: 15, fontFamily: 'Tajawal-Bold' },

  finalBox: { alignItems: 'center', paddingVertical: 15 },
  finalText: { fontSize: 18, fontFamily: 'Tajawal-Bold', color: Colors.dark, marginTop: 15 },
  finalSub: { fontSize: 13, fontFamily: 'Tajawal-Regular', color: Colors.gray, marginTop: 5 }
});
