/**
 * هوك حالة الاشتراك المركزي (Sovereign Subscription State Hook)
 * المرجع الوحيد لكافة الشاشات لمعرفة وضع العميل الحالي
 */

import { useSelector, useDispatch } from 'react-redux';
import { useEffect, useCallback } from 'react';
import { fetchActiveSubscription } from '../../../store/subscriptionSlice';
import { useAuth } from '../../../shared/contexts/AuthContext';

export const useSubscriptionState = () => {
  const { user } = useAuth();
  const dispatch = useDispatch();
  const subscription = useSelector((state) => state.subscription?.data);
  const loading = useSelector((state) => state.subscription?.loading);
  const error = useSelector((state) => state.subscription?.error);

  const refresh = useCallback(() => {
    if (user?.id) {
      dispatch(fetchActiveSubscription(user.id));
    }
  }, [user?.id, dispatch]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  return {
    subscription,
    isLoading: loading,
    error,
    refresh,
    // مساعدات الوصول السريع
    isReadOnly: subscription?.isReadOnly || false,
    isActive: ['ACTIVE_FULL', 'TRIAL_ACTIVE'].includes(subscription?.status),
    isTrial: subscription?.status === 'TRIAL_ACTIVE',
    isTrialExpired: subscription?.status === 'TRIAL_EXPIRED',
    isExpired: ['EXPIRED_GRACE', 'TRIAL_EXPIRED'].includes(subscription?.status),
    isPending: subscription?.status === 'VERIFICATION_PENDING',
    daysRemaining: subscription?.daysRemaining || 0,
    canStartTrial: !subscription || (subscription.status === 'UNSUBSCRIBED' && subscription.plan !== 'trial'),
    planInfo: subscription ? {
      label: subscription.planArabic,
      id: subscription.plan,
    } : null
  };
};
export default useSubscriptionState;
