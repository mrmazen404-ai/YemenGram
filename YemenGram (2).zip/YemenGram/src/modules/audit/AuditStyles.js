// src/modules/audit/AuditStyles.js
// الدليل التصميمي: نبض السيادة (Sovereign Light Identity)
// مزامنة كاملة مع هوية YemenGram الرسمية

import { StyleSheet, Dimensions, Platform } from 'react-native';
import { Colors } from '../../shared/utils/colors';

const { width } = Dimensions.get('window');

export const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#F8FAFC' },

  // Header المتسق مع النظام
  header: {
    flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: 20, paddingTop: Platform.OS === 'ios' ? 55 : 45, paddingBottom: 15,
    backgroundColor: '#FFFFFF', borderBottomWidth: 1, borderBottomColor: '#E2E8F0',
    elevation: 4, shadowColor: '#000', shadowOpacity: 0.05
  },
  backBtn: { width: 42, height: 42, borderRadius: 14, backgroundColor: '#F8FAFC', justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: '#EDF2F7' },
  headerTitle: { fontSize: 16, fontFamily: 'Tajawal-Bold', color: Colors.navy },
  refreshBtn: { width: 42, height: 42, borderRadius: 14, backgroundColor: Colors.navy + '08', justifyContent: 'center', alignItems: 'center' },

  scrollBody: { paddingBottom: 60 },

  // لوحة الذكاء (Sovereign Card)
  intelligenceCard: {
    margin: 18, padding: 22, backgroundColor: '#FFFFFF',
    borderRadius: 35, borderWidth: 1, borderColor: '#E2E8F0',
    elevation: 8, shadowColor: '#000', shadowOpacity: 0.03
  },
  integrityRow: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  integrityLabel: { fontSize: 13, fontFamily: 'Tajawal-Bold', color: Colors.gray },
  integrityValue: { fontSize: 34, fontFamily: 'Tajawal-Bold', color: Colors.green },

  chartContainer: {
    height: 140, width: '100%', backgroundColor: '#F8FAFC',
    borderRadius: 22, overflow: 'hidden', borderWidth: 1, borderColor: '#EDF2F7',
    justifyContent: 'center'
  },

  // شريط التحكم (Sovereign Command Bar)
  commandBar: {
    flexDirection: 'row-reverse', justifyContent: 'space-between',
    alignItems: 'center', marginHorizontal: 20, marginBottom: 25
  },
  filterGroup: { flexDirection: 'row-reverse', gap: 8 },
  chip: {
    paddingHorizontal: 15, paddingVertical: 8, borderRadius: 12,
    backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#E2E8F0'
  },
  chipActive: { backgroundColor: Colors.navy, borderColor: Colors.navy },
  chipText: { fontSize: 10, fontFamily: 'Tajawal-Bold', color: Colors.gray },
  chipTextActive: { color: '#FFFFFF' },

  exportBtn: {
    width: 44, height: 44, borderRadius: 15,
    backgroundColor: Colors.gold + '15', justifyContent: 'center', alignItems: 'center',
    borderWidth: 1, borderColor: Colors.gold + '20'
  },

  sectionLabel: { fontSize: 12, fontFamily: 'Tajawal-Bold', color: Colors.placeholder, marginBottom: 15, textAlign: 'right', letterSpacing: 2, marginRight: 25 },

  logCard: {
    marginHorizontal: 18, backgroundColor: '#FFFFFF', borderRadius: 30,
    borderWidth: 1, borderColor: '#E2E8F0', paddingVertical: 10
  },
  logItem: {
    flexDirection: 'row-reverse', alignItems: 'center',
    paddingHorizontal: 20, paddingVertical: 18,
    borderBottomWidth: 1, borderBottomColor: '#F8FAFC'
  },
  logIconBox: { width: 44, height: 44, borderRadius: 16, justifyContent: 'center', alignItems: 'center' },
  logInfo: { flex: 1, marginRight: 15, alignItems: 'flex-end' },
  logAction: { fontSize: 14, fontFamily: 'Tajawal-Bold', color: Colors.dark },
  logTime: { fontSize: 10, fontFamily: 'Tajawal-Regular', color: Colors.gray, marginTop: 4 },

  statusBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6, backgroundColor: '#F1F5F9' },
  statusText: { fontSize: 9, fontFamily: 'Tajawal-Bold', color: Colors.navy },

  footerNote: { fontSize: 9, fontFamily: 'Tajawal-Bold', color: Colors.placeholder, letterSpacing: 3, textAlign: 'center', marginTop: 40, paddingBottom: 50 },
});
