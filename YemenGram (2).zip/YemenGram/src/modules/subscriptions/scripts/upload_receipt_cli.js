// placeholder CLI upload
console.log('upload_receipt_cli placeholder');
