// src/store/index.js
import { configureStore } from '@reduxjs/toolkit';
import subscriptionReducer from './subscriptionSlice';

// سيتم تفعيل البقية عند الحاجة، حالياً نركز على السيادة المالية
export const store = configureStore({
  reducer: {
    subscription: subscriptionReducer,
    // auth: authReducer,
    // sync: syncReducer,
    // journal: journalReducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: false, // للسماح بالتعامل مع التواريخ والكائنات المعقدة أحياناً
    }),
});

export default store;
