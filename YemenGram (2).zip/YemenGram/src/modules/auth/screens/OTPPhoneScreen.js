import React, { useState, useRef, useEffect } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, KeyboardAvoidingView, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '../../../shared/utils/colors';
import Button from '../../../shared/components/Button';
import Toast from '../../../shared/components/Toast';
import Loading from '../../../shared/components/Loading';
import { useAuth } from '../../../shared/contexts/AuthContext';
export default function OTPPhoneScreen({ route, navigation }) {
  const { phone } = route.params || {};
  const { verifyOTP, sendOTP } = useAuth();
  const [code, setCode] = useState(['', '', '', '', '', '']);
  const [loading, setLoading] = useState(false); // ✅ State للـ Loading
  const [toast, setToast] = useState({ visible: false, message: '', type: 'error' });
  const [resendTimer, setResendTimer] = useState(0);
  const inputRefs = useRef([]);

  useEffect(() => {
    if (resendTimer > 0) {
      const timer = setTimeout(() => setResendTimer(resendTimer - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [resendTimer]);

  const handleCodeChange = (value, index) => {
    if (value.length > 1) return;
    const newCode = [...code];
    newCode[index] = value;
    setCode(newCode);
    if (value && index < 5) inputRefs.current[index + 1]?.focus();
    if (newCode.every(c => c !== '')) handleVerify(newCode.join(''));
  };

  const handleKeyPress = (e, index) => {
    if (e.nativeEvent.key === 'Backspace' && !code[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handleVerify = async (otpCode) => {
    if (!phone) { setToast({ visible: true, message: 'رقم الهاتف غير متوفر', type: 'error' }); return; }

    setLoading(true); // ✅ إظهار Loading
    try {
      await verifyOTP(phone, otpCode);
      setToast({ visible: true, message: 'تم تأكيد الرقم بنجاح!', type: 'success' });
      setTimeout(() => navigation.navigate('Login'), 800);
    } catch (error) {
      setToast({ visible: true, message: error.message, type: 'error' });
      setCode(['', '', '', '', '', '']);
      inputRefs.current[0]?.focus();
    } finally {
      setLoading(false); // ✅ إخفاء Loading
    }
  };

  const handleResend = async () => {
    if (resendTimer > 0 || !phone) return;
    try {
      await sendOTP(phone);
      setResendTimer(30);
      setToast({ visible: true, message: 'تم إرسال الكود', type: 'success' });
    } catch (error) {
      setToast({ visible: true, message: error.message, type: 'error' });
    }
  };

  return (
    <KeyboardAvoidingView style={styles.root} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <Toast visible={toast.visible} message={toast.message} type={toast.type} onHide={() => setToast(prev => ({ ...prev, visible: false }))} />

      {/* ✅ التحميل السحري السيادي */}
      <Loading visible={loading} />

      <View style={styles.container}>
        {/* زر الرجوع */}
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()} activeOpacity={0.6}>
          <Ionicons name="arrow-back" size={22} color={Colors.dark} />
        </TouchableOpacity>

        {/* === قسم الشعار === */}
        <View style={styles.headerSection}>
          <View style={styles.iconWrapper}>
            <Ionicons name="call-outline" size={40} color={Colors.navy} />
          </View>
          <Text style={styles.title}>تأكيد رقم الهاتف</Text>
          <Text style={styles.subtitle}>
            أدخل كود التحقق المرسل إلى
          </Text>
          <Text style={styles.highlight}>{phone}</Text>
        </View>

        {/* === قسم الكود === */}
        <View style={styles.codeCard}>
          <View style={styles.codeRow}>
            {code.map((digit, index) => (
              <TextInput
                key={index}
                ref={ref => inputRefs.current[index] = ref}
                style={[styles.codeBox, digit && styles.codeBoxFilled]}
                value={digit}
                onChangeText={v => handleCodeChange(v, index)}
                onKeyPress={e => handleKeyPress(e, index)}
                keyboardType="number-pad"
                maxLength={1}
                selectTextOnFocus
              />
            ))}
          </View>

          <Button
            title={loading ? 'جاري التحقق...' : 'تأكيد'}
            onPress={() => handleVerify(code.join(''))}
            loading={loading}
            disabled={code.some(c => c === '') || loading}
            style={styles.verifyBtn}
          />

          <TouchableOpacity
            onPress={handleResend}
            disabled={resendTimer > 0}
            activeOpacity={0.6}
            style={styles.resendBtn}
          >
            <Text style={[styles.resendText, resendTimer > 0 && styles.resendDisabled]}>
              {resendTimer > 0 ? `إعادة الإرسال (${resendTimer} ثانية)` : 'إعادة إرسال الكود'}
            </Text>
          </TouchableOpacity>
        </View>

        {/* === تذييل === */}
        <Text style={styles.bottomText}>YemenGram © 2026</Text>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: Colors.lightGray,
  },
  container: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: Platform.OS === 'ios' ? 60 : 40,
    paddingBottom: 30,
    alignItems: 'center',
    justifyContent: 'center',
  },

  backBtn: {
    position: 'absolute',
    top: Platform.OS === 'ios' ? 60 : 40,
    left: 20,
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: Colors.white,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 6,
    elevation: 2,
    zIndex: 10,
  },

  headerSection: {
    alignItems: 'center',
    marginBottom: 32,
  },
  iconWrapper: {
    width: 80,
    height: 80,
    borderRadius: 24,
    backgroundColor: '#F5F6FA',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 3,
  },
  title: {
    fontSize: 22,
    fontFamily: 'Tajawal-Bold',
    color: Colors.dark,
    textAlign: 'center',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 13,
    fontFamily: 'Tajawal-Regular',
    color: Colors.gray,
    textAlign: 'center',
    marginTop: 2,
  },
  highlight: {
    fontSize: 15,
    fontFamily: 'Tajawal-Bold',
    color: Colors.navy,
    textAlign: 'center',
    marginTop: 6,
  },

  codeCard: {
    width: '100%',
    backgroundColor: Colors.white,
    borderRadius: 20,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 3,
    alignItems: 'center',
  },
  codeRow: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 24,
  },
  codeBox: {
    width: 44,
    height: 52,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: Colors.border,
    backgroundColor: Colors.white,
    textAlign: 'center',
    fontSize: 22,
    fontFamily: 'Tajawal-Bold',
    color: Colors.dark,
  },
  codeBoxFilled: {
    borderColor: Colors.gold,
    backgroundColor: '#FEFDF9',
  },
  verifyBtn: {
    width: '100%',
  },
  resendBtn: {
    marginTop: 16,
    paddingVertical: 8,
  },
  resendText: {
    color: Colors.navy,
    fontSize: 13,
    fontFamily: 'Tajawal-Medium',
  },
  resendDisabled: {
    color: Colors.gray,
  },

  bottomText: {
    marginTop: 24,
    fontSize: 10,
    fontFamily: 'Tajawal-Regular',
    color: Colors.placeholder,
  },
});