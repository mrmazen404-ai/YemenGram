# YemenGram Agent Guide (Sovereign Edition)

## Project Context
YemenGram is a high-security, elite business management and accounting application built with React Native and Expo. It adheres to the **Digital Sovereignty (السيادة الرقمية)** philosophy, combining banking-grade security (**MASVS L2**) with a premium, high-end user experience.

## Critical Instructions
- **Digital Sovereignty**: The app is designed to be "aware" of its identity. This includes **Manual RTL Support** (enforced via `I18nManager` and `app.json`) and **Multi-Source Time Sync** to prevent fraud.
- **Expo Version**: The project targets **Expo SDK 52/56**. Always refer to the versioned documentation: [Expo Docs](https://docs.expo.dev/).
- **Language**: English for code/logic, Arabic for UI strings and comments.
- **Security First**: Every feature must pass the "Sovereign Test": No sensitive data in logs, no insecure storage, and strict input sanitization.

## Tech Stack
- **Framework**: React Native 0.76 / Expo SDK 52 (Moving to 56)
- **Database**: 
    - **Local**: WatermelonDB / SQLite (WAL Mode enabled for data integrity).
    - **Remote**: Supabase (Cloud Sync).
- **Navigation**: React Navigation 7 (Native Stacks).
- **State Management**: Redux Toolkit.
- **UI/UX**: Reanimated, SVG, Linear Gradient, Haptic Feedback (`expo-haptics`).
- **Typography**: `Tajawal` (Regular, Medium, Bold) - The official corporate font.

## Security Architecture (The Sovereign Stack)
- **Environment Shield**: Root and Emulator detection to prevent execution in hostile environments.
- **Data Integrity**: SQLite Prepared Statements to prevent injection; HMAC-SHA256 for request signing.
- **Audit Logging**: Every security-sensitive action is recorded in a forensic `Audit_Log`.
- **Session Management**: 7-day session limits with mandatory periodic re-authentication.

## UI/UX Standards (Visual Sovereignty)
- **Branding**: Consistent use of `hint.png` (usually at 12% opacity) and the Golden design language.
- **Sovereign Components**:
    - `Input.js`: Must feature Floating Labels, Golden Glow, and Haptic Feedback.
    - `Sovereign ID Capsule`: User IDs should be displayed in deep navy containers with a 1.5px gold border and 24px border radius.
- **Interactive**: All critical buttons/actions must provide `Haptic Feedback`.

## Development Patterns
- **Database Initialization**: `LocalDB.init()` in `App.js` handles schema (35 tables) and migrations.
- **RTL Enforcement**: Ensure `supportsRTL: true` in `app.json` and handle forced RTL layout in the boot cycle.
- **Sanitization**: All user inputs (Name, Email, Phone) MUST be sanitized using project-standard regex before processing.
- **Offline First**: All logic must interact with WatermelonDB models; `syncService` handles background synchronization.
- **Performance**: Use `FlashList` for long lists and `Reanimated` for smooth UI transitions.

## Project Structure
- `src/modules/`: Domain-specific features (Auth, Inventory, Journal, HR, etc.).
- `src/services/`: Core logic (Sync, Supabase Client, Time Sync).
- `src/shared/`: Reusable components, hooks, contexts, and utilities.
- `src/models/`: WatermelonDB schemas and class definitions.
- `src/store/`: Redux slices and middleware.
