// src/models/Expense.js
// =============================================
// نموذج المصروف (Expense Model)
// المسؤول عن تسجيل المصروفات المنفصلة (غير المرتبطة بفاتورة شراء)
// =============================================

import { Model } from '@nozbe/watermelondb';
import { field, date, readonly } from '@nozbe/watermelondb/decorators';
import { Q } from '@nozbe/watermelondb';

export default class Expense extends Model {
  // ===== 1. اسم الجدول =====
  static table = 'expenses';

  // ===== 2. الحقول الأساسية =====

  // معرف المستخدم (لفصل البيانات)
  @field('user_id') userId;

  // رقم السند
  @field('number') number;

  // تاريخ المصروف
  @field('date') date;

  // معرف الحساب المحاسبي (مصروفات)
  @field('account_id') accountId;

  // المبلغ
  @field('amount') amount;

  // فئة المصروف (إيجار، كهرباء، رواتب، ...)
  @field('category') category;

  // وصف المصروف
  @field('description') description;

  // ===== 3. طريقة الدفع =====

  // طريقة الدفع (cash, bank, check)
  @field('payment_method') paymentMethod;

  // الحساب النقدي/البنكي المستخدم
  @field('cash_account_id') cashAccountId;

  // معرف الشيك (إذا كانت طريقة الدفع شيك)
  @field('check_id') checkId;

  // صورة الإيصال (Base64 أو رابط)
  @field('receipt_image') receiptImage;

  // ===== 4. من قام بالإنشاء =====

  @field('created_by') createdBy;

  // ===== 5. التواريخ التلقائية =====

  @readonly @date('created_at') createdAt;
  @readonly @date('updated_at') updatedAt;

  // ===== 6. العلاقات =====

  static associations = {
    // كل مصروف ينتمي إلى مستخدم واحد
    user: { type: 'belongs_to', key: 'user_id' },
    // كل مصروف له حساب محاسبي واحد
    account: { type: 'belongs_to', key: 'account_id' },
    // كل مصروف قد ينتمي إلى حساب نقدي/بنكي
    cashAccount: { type: 'belongs_to', key: 'cash_account_id' },
    // كل مصروف قد ينتمي إلى شيك
    check: { type: 'belongs_to', key: 'check_id' },
  };

  // ===== 7. دوال مساعدة =====

  /**
   * الحصول على طريقة الدفع باللغة العربية
   * @returns {string}
   */
  getPaymentMethodArabic() {
    const methods = {
      cash: 'نقدي',
      bank: 'تحويل بنكي',
      check: 'شيك',
    };
    return methods[this.payment_method] || this.payment_method;
  }

  /**
   * جلب الحساب المحاسبي
   * @returns {Promise<Account>}
   */
  async getAccount() {
    return this.collections.get('accounts').find(this.accountId);
  }

  /**
   * جلب اسم الحساب المحاسبي
   * @returns {Promise<string>}
   */
  async getAccountName() {
    const account = await this.getAccount();
    return account ? account.name : 'حساب غير معروف';
  }

  /**
   * جلب الحساب النقدي/البنكي (إن وجد)
   * @returns {Promise<CashAccount|null>}
   */
  async getCashAccount() {
    if (!this.cashAccountId) return null;
    return this.collections.get('cash_accounts').find(this.cashAccountId);
  }

  /**
   * جلب الشيك المرتبط (إن وجد)
   * @returns {Promise<Check|null>}
   */
  async getCheck() {
    if (!this.checkId) return null;
    return this.collections.get('checks').find(this.checkId);
  }

  /**
   * الحصول على اسم المصروف المعروض
   * @returns {string}
   */
  getDisplayName() {
    return `${this.number} - ${this.category || 'مصروف'}`;
  }

  /**
   * التحقق من وجود صورة الإيصال
   * @returns {boolean}
   */
  hasReceipt() {
    return !!(this.receiptImage && this.receiptImage.length > 0);
  }

  // ===== 8. دوال ثابتة =====

  /**
   * الحصول على رقم المصروف التالي
   * @param {Database} database
   * @returns {Promise<string>}
   */
  static async getNextNumber(database) {
    const lastExpense = await database.get('expenses').query(
      Q.sortBy('number', Q.desc),
      Q.take(1)
    ).fetch();

    if (lastExpense.length === 0) {
      return 'EXP-0001';
    }

    const lastNumber = lastExpense[0].number;
    const numericPart = parseInt(lastNumber.split('-')[1] || '0000');
    const nextNumber = numericPart + 1;
    return `EXP-${String(nextNumber).padStart(4, '0')}`;
  }

  /**
   * حساب إجمالي المصروفات
   * @param {Expense[]} expenses
   * @returns {number}
   */
  static sumAmount(expenses) {
    return expenses.reduce((sum, e) => sum + (e.amount || 0), 0);
  }

  /**
   * تجميع المصروفات حسب الفئة
   * @param {Expense[]} expenses
   * @returns {Object}
   */
  static groupByCategory(expenses) {
    const groups = {};
    for (const expense of expenses) {
      const category = expense.category || 'غير مصنف';
      if (!groups[category]) {
        groups[category] = [];
      }
      groups[category].push(expense);
    }
    return groups;
  }

  /**
   * تجميع المصروفات حسب طريقة الدفع
   * @param {Expense[]} expenses
   * @returns {Object}
   */
  static groupByPaymentMethod(expenses) {
    const groups = {};
    for (const expense of expenses) {
      const method = expense.payment_method || 'غير محدد';
      if (!groups[method]) {
        groups[method] = [];
      }
      groups[method].push(expense);
    }
    return groups;
  }

  /**
   * تجميع المصروفات حسب الشهر
   * @param {Expense[]} expenses
   * @returns {Object}
   */
  static groupByMonth(expenses) {
    const groups = {};
    for (const expense of expenses) {
      const date = new Date(expense.date);
      const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      if (!groups[key]) {
        groups[key] = [];
      }
      groups[key].push(expense);
    }
    return groups;
  }
}