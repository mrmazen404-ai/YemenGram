// src/shared/navigation/AppNavigator.js
// ميثاق التنقل السيادي (Sovereign Navigation Pact)
// التحديث: الانتقال الذري الموحد (Atomic Transition Fix)

import React, { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useAuth } from '../contexts/AuthContext';
import { navigationRef } from './NavigationService';

// ===== الشاشات والوحدات =====
import SplashScreen from '../../modules/auth/screens/SplashScreen';
import LoginScreen from '../../modules/auth/screens/LoginScreen';
import RegisterScreen from '../../modules/auth/screens/RegisterScreen';
import OTPVerifyScreen from '../../modules/auth/screens/OTPVerifyScreen';
import RecoveryScreen from '../../modules/auth/recovery/RecoveryScreen';
import AccountDeletedScreen from '../../modules/auth/screens/AccountDeletedScreen'; // ✅ استيراد شاشة الفناء
import SecuritySuspendedScreen from '../../modules/auth/screens/SecuritySuspendedScreen';
import DrawerNavigator from './DrawerNavigator';
import AuditScreen from '../../modules/audit/AuditScreen';
import ProfileScreen from '../../modules/settings/profile/ProfileScreen';
import SettingsScreen from '../../modules/settings/screens/SettingsScreen';
import SovereignSubscriptionHub from '../../modules/subscriptions/screens/SovereignSubscriptionHub';
import SubscriptionOverview from '../../modules/subscriptions/screens/SubscriptionOverview';
import PlansCatalog from '../../modules/subscriptions/screens/PlansCatalog';
import SubscriptionPaymentScreen from '../../modules/subscriptions/screens/SubscriptionPaymentScreen';
import ReceiptUploadScreen from '../../modules/subscriptions/screens/ReceiptUploadScreen';
import SubscriptionInvoiceScreen from '../../modules/subscriptions/screens/InvoiceScreen';
import SubscriptionTransactionsScreen from '../../modules/subscriptions/screens/TransactionsScreen';
import SubscriptionRenewScreen from '../../modules/subscriptions/screens/RenewScreen';
import SubscriptionExtensionScreen from '../../modules/subscriptions/screens/ExtensionScreen';
import SubscriptionUpgradeScreen from '../../modules/subscriptions/screens/UpgradeScreen';
import MonthlyPlanScreen from '../../modules/subscriptions/screens/MonthlyPlanScreen';
import AnnualPlanScreen from '../../modules/subscriptions/screens/AnnualPlanScreen';
import EnterprisePlanScreen from '../../modules/subscriptions/screens/EnterprisePlanScreen';
import SubscriptionNotificationsScreen from '../../modules/subscriptions/screens/SubscriptionNotificationsScreen';
import SubscriptionResourcesScreen from '../../modules/subscriptions/screens/ResourcesScreen';
import SubscriptionDeviceManagementScreen from '../../modules/subscriptions/screens/DeviceManagementScreen';
import SubscriptionVerificationPendingScreen from '../../modules/subscriptions/screens/VerificationPendingScreen';
import SubscriptionCancellationScreen from '../../modules/subscriptions/screens/CancellationScreen';
import SubscriptionRefundScreen from '../../modules/subscriptions/screens/RefundScreen';
import SubscriptionReceiptsListScreen from '../../modules/subscriptions/screens/ReceiptsListScreen';
import SubscriptionErrorScreen from '../../modules/subscriptions/screens/SubscriptionErrorScreen';
import ArchivedAccessScreen from '../../modules/subscriptions/screens/ArchivedAccessScreen';
import SubscriptionSupportScreen from '../../modules/subscriptions/screens/SupportScreen';
import FreeTrialIntroScreen from '../../modules/subscriptions/screens/FreeTrialIntroScreen';
import TrialExpiredScreen from '../../modules/subscriptions/screens/TrialExpiredScreen';
import AdminRequestsList from '../../modules/subscriptions/screens/admin/AdminRequestsList';
import AdminRequestDetail from '../../modules/subscriptions/screens/admin/AdminRequestDetail';

const Stack = createNativeStackNavigator();

export default function AppNavigator({ fontsLoaded }) {
  const { isLoggedIn, reAuthRequired, purgeSuccess, securityLock } = useAuth();
  const [bootstrapped, setBootstrapped] = useState(false);

  return (
    <NavigationContainer ref={navigationRef}>
      <Stack.Navigator screenOptions={{ headerShown: false, animation: 'fade' }}>

        {/* 1. مرحلة التهيئة (Bootstrap Phase) */}
        {!bootstrapped ? (
          <Stack.Screen name="Splash">
            {(props) => (
              <SplashScreen
                {...props}
                onReady={() => setBootstrapped(true)}
                fontsLoaded={fontsLoaded}
              />
            )}
          </Stack.Screen>
        ) : securityLock?.isLocked ? (
          // 1.2 حالة التعليق الأمني السيادي (الوقت أو المزامنة)
          <Stack.Screen name="SecuritySuspended">
            {(props) => <SecuritySuspendedScreen {...props} route={{ params: { message: securityLock.message } }} />}
          </Stack.Screen>
        ) : purgeSuccess ? (
          // 1.5 حالة الفناء الرقمي (الأولوية القصوى)
          <Stack.Screen name="AccountDeleted" component={AccountDeletedScreen} />
        ) : (
          // 2. مرحلة التشغيل الفعلي (Active Operation Phase)
          isLoggedIn && !reAuthRequired ? (
            // ===== شاشات القائد (مسجل وسيادي) =====
            <>
              <Stack.Screen name="Dashboard" component={DrawerNavigator} />
              <Stack.Screen name="Profile" component={ProfileScreen} />
              <Stack.Screen name="Settings" component={SettingsScreen} />
              <Stack.Screen name="AuditLog" component={AuditScreen} />

              {/* 🛡️ وحدة الاشتراكات السيادية (مرتبة ومنظمة بالكامل) */}
              {/* أ. شاشة المركز الرئيسي (Hub) */}
              <Stack.Screen name="SovereignSubscriptionHub" component={SovereignSubscriptionHub} />
              <Stack.Screen name="SubscriptionOverview" component={SubscriptionOverview} />

              {/* ب. مجموعة الباقات والترقية (Plans & Upgrades) */}
              <Stack.Screen name="PlansCatalog" component={PlansCatalog} />
              <Stack.Screen name="MonthlyPlan" component={MonthlyPlanScreen} />
              <Stack.Screen name="AnnualPlan" component={AnnualPlanScreen} />
              <Stack.Screen name="EnterprisePlan" component={EnterprisePlanScreen} />
              <Stack.Screen name="SubscriptionFreeTrialIntro" component={FreeTrialIntroScreen} />
              <Stack.Screen name="SubscriptionUpgrade" component={SubscriptionUpgradeScreen} />
              <Stack.Screen name="SubscriptionPayment" component={SubscriptionPaymentScreen} />
              <Stack.Screen name="ReceiptUploadScreen" component={ReceiptUploadScreen} />
              <Stack.Screen name="SubscriptionVerificationPending" component={SubscriptionVerificationPendingScreen} />

              {/* ج. مجموعة الإدارة المالية (Billing & Finance) */}
              <Stack.Screen name="SubscriptionInvoice" component={SubscriptionInvoiceScreen} />
              <Stack.Screen name="SubscriptionReceipts" component={SubscriptionReceiptsListScreen} />
              <Stack.Screen name="SubscriptionTransactions" component={SubscriptionTransactionsScreen} />
              <Stack.Screen name="SubscriptionRenew" component={SubscriptionRenewScreen} />

              {/* د. مجموعة الموارد والعتاد (Resources & Hardware) */}
              <Stack.Screen name="SubscriptionResources" component={SubscriptionResourcesScreen} />
              <Stack.Screen name="SubscriptionDeviceManagement" component={SubscriptionDeviceManagementScreen} />

              {/* هـ. مجموعة الدعم والسياسات والحالات الحرجة (Support & Policies) */}
              <Stack.Screen name="SubscriptionExtension" component={SubscriptionExtensionScreen} />
              <Stack.Screen name="SubscriptionRefund" component={SubscriptionRefundScreen} />
              <Stack.Screen name="SubscriptionCancellation" component={SubscriptionCancellationScreen} />
              <Stack.Screen name="Support" component={SubscriptionSupportScreen} />
              <Stack.Screen name="SubscriptionTrialExpired" component={TrialExpiredScreen} />
              <Stack.Screen name="SubscriptionError" component={SubscriptionErrorScreen} />
              <Stack.Screen name="SubscriptionNotifications" component={SubscriptionNotificationsScreen} />
              <Stack.Screen name="ArchivedAccess" component={ArchivedAccessScreen} />

              {/* و. لوحة تحكم المشرف (Admin Workflow) */}
              <Stack.Screen name="AdminRequestsList" component={AdminRequestsList} />
              <Stack.Screen name="AdminRequestDetail" component={AdminRequestDetail} />
            </>
          ) : (
            // ===== شاشات البوابة (غير مسجل أو يحتاج إعادة مصادقة) =====
            <>
              <Stack.Screen name="Login" component={LoginScreen} />
              <Stack.Screen name="Register" component={RegisterScreen} />
              <Stack.Screen name="OTPVerify" component={OTPVerifyScreen} />
              <Stack.Screen name="ForgotPassword" component={RecoveryScreen} />
              <Stack.Screen name="AccountDeleted" component={AccountDeletedScreen} />
            </>
          )
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}
