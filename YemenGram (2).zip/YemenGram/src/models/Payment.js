// src/models/Payment.js
// =============================================
// نموذج الدفعة (Payment Model)
// المسؤول عن إدارة سندات القبض والصرف والمدفوعات
// =============================================

import { Model } from '@nozbe/watermelondb';
import { field, date, readonly } from '@nozbe/watermelondb/decorators';
import { Q } from '@nozbe/watermelondb';

export default class Payment extends Model {
  // ===== 1. اسم الجدول =====
  static table = 'payments';

  // ===== 2. الحقول الأساسية =====

  // معرف المستخدم (لفصل البيانات)
  @field('user_id') userId;

  // رقم السند (تلقائي متسلسل)
  @field('number') number;

  // تاريخ الدفعة
  @field('date') date;

  // نوع الدفعة (customer, supplier, expense, salary)
  @field('type') type;

  // ===== 3. الأطراف =====

  // معرف العميل (لدفعات العملاء)
  @field('customer_id') customerId;

  // معرف المورد (لدفعات الموردين)
  @field('supplier_id') supplierId;

  // معرف المصروف (لدفعات المصروفات)
  @field('expense_id') expenseId;

  // معرف الموظف (لدفعات الرواتب)
  @field('employee_id') employeeId;

  // ===== 4. المعلومات المالية =====

  // المبلغ
  @field('amount') amount;

  // طريقة الدفع (cash, bank, check)
  @field('method') method;

  // ===== 5. مراجع الحسابات =====

  // الحساب النقدي/البنكي المستخدم
  @field('cash_account_id') cashAccountId;

  // معرف الشيك (إذا كانت طريقة الدفع شيك)
  @field('check_id') checkId;

  // ===== 6. معلومات إضافية =====

  @field('description') description;

  // ===== 7. الحالة =====

  // حالة الدفعة (pending, completed, void)
  @field('status') status;

  // ===== 8. من قام بالإنشاء =====

  @field('created_by') createdBy;

  // ===== 9. التواريخ التلقائية =====

  @readonly @date('created_at') createdAt;
  @readonly @date('updated_at') updatedAt;

  // ===== 10. العلاقات =====

  static associations = {
    // كل دفعة تنتمي إلى مستخدم واحد
    user: { type: 'belongs_to', key: 'user_id' },
    // كل دفعة قد تنتمي إلى عميل
    customer: { type: 'belongs_to', key: 'customer_id' },
    // كل دفعة قد تنتمي إلى مورد
    supplier: { type: 'belongs_to', key: 'supplier_id' },
    // كل دفعة قد تنتمي إلى حساب نقدي/بنكي
    cashAccount: { type: 'belongs_to', key: 'cash_account_id' },
    // كل دفعة قد تنتمي إلى شيك
    check: { type: 'belongs_to', key: 'check_id' },
  };

  // ===== 11. دوال مساعدة =====

  /**
   * الحصول على نوع الدفعة باللغة العربية
   * @returns {string}
   */
  getTypeArabic() {
    const types = {
      customer: 'دفعة عميل',
      supplier: 'دفعة مورد',
      expense: 'دفعة مصروف',
      salary: 'دفعة راتب',
    };
    return types[this.type] || this.type;
  }

  /**
   * الحصول على طريقة الدفع باللغة العربية
   * @returns {string}
   */
  getMethodArabic() {
    const methods = {
      cash: 'نقدي',
      bank: 'تحويل بنكي',
      check: 'شيك',
    };
    return methods[this.method] || this.method;
  }

  /**
   * الحصول على حالة الدفعة باللغة العربية
   * @returns {string}
   */
  getStatusArabic() {
    const statuses = {
      pending: 'معلقة',
      completed: 'مكتملة',
      void: 'ملغية',
    };
    return statuses[this.status] || this.status;
  }

  /**
   * الحصول على لون الحالة
   * @returns {string}
   */
  getStatusColor() {
    const colors = {
      pending: '#F39C12',
      completed: '#27AE60',
      void: '#E74C3C',
    };
    return colors[this.status] || '#6B7280';
  }

  /**
   * التحقق من أن الدفعة مكتملة
   * @returns {boolean}
   */
  isCompleted() {
    return this.status === 'completed';
  }

  /**
   * التحقق من أن الدفعة معلقة
   * @returns {boolean}
   */
  isPending() {
    return this.status === 'pending';
  }

  /**
   * التحقق من أن الدفعة ملغية
   * @returns {boolean}
   */
  isVoid() {
    return this.status === 'void';
  }

  /**
   * التحقق من أن الدفعة للعميل
   * @returns {boolean}
   */
  isCustomer() {
    return this.type === 'customer';
  }

  /**
   * التحقق من أن الدفعة للمورد
   * @returns {boolean}
   */
  isSupplier() {
    return this.type === 'supplier';
  }

  /**
   * جلب العميل المرتبط (إن وجد)
   * @returns {Promise<Customer|null>}
   */
  async getCustomer() {
    if (!this.customerId) return null;
    return this.collections.get('customers').find(this.customerId);
  }

  /**
   * جلب المورد المرتبط (إن وجد)
   * @returns {Promise<Supplier|null>}
   */
  async getSupplier() {
    if (!this.supplierId) return null;
    return this.collections.get('suppliers').find(this.supplierId);
  }

  /**
   * جلب الحساب النقدي/البنكي المرتبط
   * @returns {Promise<CashAccount|null>}
   */
  async getCashAccount() {
    if (!this.cashAccountId) return null;
    return this.collections.get('cash_accounts').find(this.cashAccountId);
  }

  /**
   * جلب الشيك المرتبط (إن وجد)
   * @returns {Promise<Check|null>}
   */
  async getCheck() {
    if (!this.checkId) return null;
    return this.collections.get('checks').find(this.checkId);
  }

  /**
   * الحصول على اسم الطرف (عميل/مورد)
   * @returns {Promise<string>}
   */
  async getPartyName() {
    if (this.customerId) {
      const customer = await this.getCustomer();
      return customer ? customer.name : 'عميل غير معروف';
    }
    if (this.supplierId) {
      const supplier = await this.getSupplier();
      return supplier ? supplier.name : 'مورد غير معروف';
    }
    if (this.employeeId) {
      const employee = await this.collections.get('employees').find(this.employeeId);
      return employee ? employee.name : 'موظف غير معروف';
    }
    return 'غير محدد';
  }

  /**
   * الحصول على اتجاه الدفعة (قبض/صرف)
   * @returns {string}
   */
  getDirection() {
    if (this.type === 'customer' || this.type === 'revenue') {
      return 'قبض (وارد)';
    }
    if (this.type === 'supplier' || this.type === 'expense' || this.type === 'salary') {
      return 'صرف (صادر)';
    }
    return 'غير محدد';
  }

  /**
   * الحصول على اسم الدفعة المعروض
   * @returns {string}
   */
  getDisplayName() {
    return `${this.number} - ${this.getTypeArabic()}`;
  }

  // ===== 12. دوال ثابتة =====

  /**
   * الحصول على رقم السند التالي
   * @param {Database} database
   * @param {string} type
   * @returns {Promise<string>}
   */
  static async getNextNumber(database, type) {
    const prefix = {
      customer: 'RCV',
      supplier: 'PAY',
      expense: 'EXP',
      salary: 'SAL',
    }[type] || 'PAY';

    const lastPayment = await database.get('payments').query(
      Q.where('type', type),
      Q.sortBy('number', Q.desc),
      Q.take(1)
    ).fetch();

    if (lastPayment.length === 0) {
      return `${prefix}-0001`;
    }

    const lastNumber = lastPayment[0].number;
    const numericPart = parseInt(lastNumber.split('-')[1] || '0000');
    const nextNumber = numericPart + 1;
    return `${prefix}-${String(nextNumber).padStart(4, '0')}`;
  }

  /**
   * حساب إجمالي المدفوعات لمجموعة
   * @param {Payment[]} payments
   * @returns {number}
   */
  static sumAmount(payments) {
    return payments.reduce((sum, p) => sum + (p.amount || 0), 0);
  }

  /**
   * تجميع المدفوعات حسب النوع
   * @param {Payment[]} payments
   * @returns {Object}
   */
  static groupByType(payments) {
    const groups = {};
    for (const payment of payments) {
      if (!groups[payment.type]) {
        groups[payment.type] = [];
      }
      groups[payment.type].push(payment);
    }
    return groups;
  }

  /**
   * تجميع المدفوعات حسب طريقة الدفع
   * @param {Payment[]} payments
   * @returns {Object}
   */
  static groupByMethod(payments) {
    const groups = {};
    for (const payment of payments) {
      if (!groups[payment.method]) {
        groups[payment.method] = [];
      }
      groups[payment.method].push(payment);
    }
    return groups;
  }

  /**
   * حساب إجمالي القبض (دفعات العملاء)
   * @param {Payment[]} payments
   * @returns {number}
   */
  static sumReceipts(payments) {
    return payments
      .filter(p => p.type === 'customer')
      .reduce((sum, p) => sum + (p.amount || 0), 0);
  }

  /**
   * حساب إجمالي الصرف (دفعات الموردين، المصروفات، الرواتب)
   * @param {Payment[]} payments
   * @returns {number}
   */
  static sumPayments(payments) {
    return payments
      .filter(p => p.type === 'supplier' || p.type === 'expense' || p.type === 'salary')
      .reduce((sum, p) => sum + (p.amount || 0), 0);
  }

  /**
   * حساب صافي التدفق النقدي (القبض - الصرف)
   * @param {Payment[]} payments
   * @returns {number}
   */
  static netCashFlow(payments) {
    return this.sumReceipts(payments) - this.sumPayments(payments);
  }
}