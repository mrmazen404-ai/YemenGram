// src/models/Product.js
// =============================================
// نموذج المنتج (Product Model)
// المسؤول عن إدارة المنتجات والمخزون
// =============================================

import { Model } from '@nozbe/watermelondb';
import { field, date, readonly } from '@nozbe/watermelondb/decorators';
import { Q } from '@nozbe/watermelondb';

export default class Product extends Model {
  // ===== 1. اسم الجدول =====
  static table = 'products';

  // ===== 2. الحقول الأساسية =====

  // معرف المستخدم (لفصل البيانات)
  @field('user_id') userId;

  // رمز المنتج الفريد (PRD-0001)
  @field('code') code;

  // اسم المنتج
  @field('name') name;

  // فئة المنتج
  @field('category') category;

  // وحدة القياس (قطعة، كيلو، متر، ...)
  @field('unit') unit;

  // ===== 3. المعلومات المالية =====

  // سعر الشراء
  @field('purchase_price') purchasePrice;

  // سعر البيع
  @field('sale_price') salePrice;

  // ===== 4. معلومات المخزون =====

  // الكمية الحالية في المخزون
  @field('quantity') quantity;

  // الحد الأدنى للكمية (تنبيه عند الوصول)
  @field('min_quantity') minQuantity;

  // ===== 5. المفاتيح الخارجية =====

  // الحساب المحاسبي للمنتج (المخزون)
  @field('account_id') accountId;

  // ===== 6. معلومات إضافية =====

  @field('notes') notes;

  // ===== 7. حالة المنتج =====

  @field('is_active') isActive;

  // ===== 8. التواريخ التلقائية =====

  @readonly @date('created_at') createdAt;
  @readonly @date('updated_at') updatedAt;

  // ===== 9. العلاقات =====

  static associations = {
    // كل منتج ينتمي إلى مستخدم واحد
    user: { type: 'belongs_to', key: 'user_id' },
    // كل منتج له حساب محاسبي واحد (المخزون)
    account: { type: 'belongs_to', key: 'account_id' },
    // منتج واحد → لديه عدة عناصر في الفواتير
    invoiceItems: { type: 'has_many', foreignKey: 'product_id' },
  };

  // ===== 10. دوال مساعدة =====

  /**
   * الحصول على اسم المنتج مع الرمز
   * @returns {string}
   */
  getDisplayName() {
    return `${this.code} - ${this.name}`;
  }

  /**
   * التحقق من نشاط المنتج
   * @returns {boolean}
   */
  isActiveProduct() {
    return this.isActive === 1 || this.isActive === true;
  }

  /**
   * التحقق من أن الكمية منخفضة (تحت الحد الأدنى)
   * @returns {boolean}
   */
  isLowStock() {
    return this.minQuantity > 0 && this.quantity <= this.minQuantity;
  }

  /**
   * التحقق من أن الكمية متوفرة (أكبر من الصفر)
   * @returns {boolean}
   */
  isInStock() {
    return this.quantity > 0;
  }

  /**
   * التحقق من أن الكمية كافية لطلبية معينة
   * @param {number} requestedQuantity
   * @returns {boolean}
   */
  hasEnoughStock(requestedQuantity) {
    return this.quantity >= requestedQuantity;
  }

  /**
   * حساب قيمة المخزون (الكمية × سعر الشراء)
   * @returns {number}
   */
  getStockValue() {
    return this.quantity * (this.purchasePrice || 0);
  }

  /**
   * حساب هامش الربح
   * @returns {number}
   */
  getProfitMargin() {
    if (!this.purchasePrice || this.purchasePrice === 0) return 0;
    return ((this.salePrice - this.purchasePrice) / this.purchasePrice) * 100;
  }

  /**
   * الحصول على حالة المخزون
   * @returns {string}
   */
  getStockStatus() {
    if (this.quantity <= 0) return 'نفذ';
    if (this.isLowStock()) return 'منخفض';
    return 'متوفر';
  }

  /**
   * الحصول على لون حالة المخزون
   * @returns {string}
   */
  getStockStatusColor() {
    const colors = {
      'نفذ': '#E74C3C',
      'منخفض': '#F39C12',
      'متوفر': '#27AE60',
    };
    return colors[this.getStockStatus()] || '#6B7280';
  }

  /**
   * جلب الحساب المحاسبي للمنتج
   * @returns {Promise<Account>}
   */
  async getAccount() {
    if (!this.accountId) return null;
    return this.collections.get('accounts').find(this.accountId);
  }

  /**
   * جلب عناصر الفواتير المرتبطة بالمنتج
   * @returns {Promise<InvoiceItem[]>}
   */
  async getInvoiceItems() {
    return this.collections.get('invoice_items').query(
      Q.where('product_id', this.id)
    ).fetch();
  }

  /**
   * حساب إجمالي المبيعات للمنتج
   * @returns {Promise<number>}
   */
  async getTotalSales() {
    const items = await this.getInvoiceItems();
    return items.reduce((sum, item) => sum + (item.total || 0), 0);
  }

  /**
   * حساب إجمالي الكمية المباعة
   * @returns {Promise<number>}
   */
  async getTotalQuantitySold() {
    const items = await this.getInvoiceItems();
    return items.reduce((sum, item) => sum + (item.quantity || 0), 0);
  }

  /**
   * تحديث كمية المنتج
   * @param {number} newQuantity
   */
  async updateQuantity(newQuantity) {
    await this.write(() => {
      this.quantity = newQuantity;
    });
  }

  /**
   * إضافة كمية إلى المخزون
   * @param {number} amount
   */
  async addStock(amount) {
    await this.write(() => {
      this.quantity = (this.quantity || 0) + amount;
    });
  }

  /**
   * خصم كمية من المخزون
   * @param {number} amount
   */
  async deductStock(amount) {
    if (!this.hasEnoughStock(amount)) {
      throw new Error('الكمية غير كافية في المخزون');
    }
    await this.write(() => {
      this.quantity = (this.quantity || 0) - amount;
    });
  }

  /**
   * حساب قيمة المخزون الإجمالية
   * @param {Product[]} products
   * @returns {number}
   */
  static getTotalStockValue(products) {
    return products.reduce((sum, p) => sum + p.getStockValue(), 0);
  }

  /**
   * الحصول على المنتجات منخفضة المخزون
   * @param {Product[]} products
   * @returns {Product[]}
   */
  static getLowStockProducts(products) {
    return products.filter(p => p.isLowStock());
  }

  /**
   * الحصول على المنتجات النافذة
   * @param {Product[]} products
   * @returns {Product[]}
   */
  static getOutOfStockProducts(products) {
    return products.filter(p => p.quantity <= 0);
  }

  /**
   * تجميع المنتجات حسب الفئة
   * @param {Product[]} products
   * @returns {Object}
   */
  static groupByCategory(products) {
    const groups = {};
    for (const product of products) {
      const category = product.category || 'غير مصنف';
      if (!groups[category]) {
        groups[category] = [];
      }
      groups[category].push(product);
    }
    return groups;
  }
}