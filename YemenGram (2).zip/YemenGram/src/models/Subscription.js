// src/models/Subscription.js
// =============================================
// نموذج الاشتراك السيادي (Sovereign Subscription Model)
// المسؤول عن إدارة اشتراكات المستخدمين والخطط والسيادة الرقمية
// =============================================

import { Model } from '@nozbe/watermelondb';
import { field, date, readonly } from '@nozbe/watermelondb/decorators';
import { Q } from '@nozbe/watermelondb';
import TimeService from '../services/timeService';

export default class Subscription extends Model {
  // ===== 1. اسم الجدول =====
  static table = 'subscriptions';

  // ===== 2. الحقول الأساسية (Sovereign 10/10 Schema) =====

  @field('user_id') userId;
  @field('status') status;
  @field('plan') plan;
  @field('start_date') startDate;
  @field('end_date') endDate;
  @field('trial_end_date') trialEndDate;
  @field('grace_period_end') gracePeriodEnd;

  // حدود الموارد
  @field('max_devices') maxDevices;
  @field('registered_devices') registeredDevices;
  @field('max_customers') maxCustomers;
  @field('max_invoices') maxInvoices;
  @field('max_storage') maxStorage;

  // إدارة التجديد والمالية
  @field('auto_renew') autoRenew;
  @field('renewal_count') renewalCount;
  @field('price') price;
  @field('currency') currency;
  @field('discount') discount;
  @field('tax') tax;
  @field('total') total;

  // تفاصيل الدفع والتدقيق
  @field('payment_method') paymentMethod;
  @field('payment_reference') paymentReference;
  @field('payment_proof') paymentProof;
  @field('verification_requested_at') verificationRequestedAt;
  @field('verification_approved_at') verificationApprovedAt;
  @field('verification_rejected_at') verificationRejectedAt;

  // أحداث دورة الحياة
  @field('cancelled_at') cancelledAt;
  @field('cancellation_reason') cancellationReason;
  @field('refund_requested_at') refundRequestedAt;
  @field('refund_status') refundStatus;
  @field('suspended_at') suspendedAt;
  @field('suspension_reason') suspensionReason;
  @field('archived_at') archivedAt;

  // التواريخ التلقائية
  @readonly @date('created_at') createdAt;
  @readonly @date('updated_at') updatedAt;

  // ===== 3. العلاقات =====

  static associations = {
    user: { type: 'belongs_to', key: 'user_id' },
  };

  // ===== 4. دوال مساعدة (Helper Methods) =====

  /**
   * الحصول على اسم الخطة باللغة العربية
   */
  getPlanArabic() {
    const plans = {
      free: 'مجاني',
      trial: 'تجريبي',
      monthly: 'شهري',
      annual: 'سنوي',
      enterprise: 'مؤسساتي',
    };
    return plans[this.plan] || this.plan;
  }

  /**
   * الحصول على لون الحالة بناءً على المصفوفة السيادية
   */
  getStatusColor() {
    const colors = {
      ACTIVE_FULL: '#0F172A', // كحلي ملكي
      TRIAL_ACTIVE: '#D4A853', // ذهبي
      VERIFICATION_PENDING: '#3B82F6', // أزرق (نبض)
      EXPIRED_GRACE: '#94A3B8', // رمادي
      RESOURCES_EXCEEDED: '#EA580C', // برتقالي محروق
      SECURITY_SUSPENDED: '#000000', // أسود
      CANCELLED: '#B91C1C', // أحمر
      UNSUBSCRIBED: '#64748B', // رمادي خافت
    };
    return colors[this.status] || '#6B7280';
  }

  /**
   * التحقق من أن الاشتراك نشط برمجياً
   */
  isActiveSubscription() {
    const activeStates = ['TRIAL_ACTIVE', 'ACTIVE_FULL'];
    return activeStates.includes(this.status);
  }

  /**
   * التحقق من الصلاحية (نشط وغير منتهي)
   */
  isValid(currentDate = TimeService.getSovereignTime()) {
    if (this.status === 'SECURITY_SUSPENDED') return false;
    if (this.plan === 'enterprise' && this.isActiveSubscription()) return true;
    if (!this.endDate) return this.isActiveSubscription();
    // استخدام التوقيت السيادي الموثوق
    return this.isActiveSubscription() && this.endDate > currentDate;
  }

  /**
   * الحصول على الأيام المتبقية
   */
  getDaysRemaining(currentDate = TimeService.getSovereignTime()) {
    if (!this.endDate) return 0;
    const diff = this.endDate - currentDate;
    return Math.max(0, Math.ceil(diff / (1000 * 60 * 60 * 24)));
  }

  /**
   * التحقق مما إذا كان الاشتراك في وضع القراءة فقط
   * (Sovereign Read-Only Guard)
   */
  isReadOnly() {
    const readOnlyStates = [
      'EXPIRED',
      'SECURITY_SUSPENDED',
      'VERIFICATION_PENDING',
      'EXPIRED_GRACE',
      'RESOURCES_EXCEEDED',
      'CANCELLED',
      'UNSUBSCRIBED'
    ];
    return readOnlyStates.includes(this.status) || !this.isValid();
  }

  // ===== 5. دوال ثابتة (Static Methods) =====

  /**
   * إنشاء اشتراك جديد مع إعدادات الباقة السيادية الرسمية
   */
  static async createSubscription(database, userId, plan, data = {}) {
    const now = TimeService.getSovereignTime();

    // إعدادات المصفوفة الرسمية (Official Sovereign Matrix)
    const planConfigs = {
      free: { maxDevices: 1, maxCustomers: 5, maxInvoices: 5, duration: 9999, price: 0 },
      trial: { maxDevices: 1, maxCustomers: 50, maxInvoices: 50, duration: 30, price: 0 },
      monthly: { maxDevices: 3, maxCustomers: 100, maxInvoices: 500, duration: 30, price: 3000 },
      annual: { maxDevices: 10, maxCustomers: 500, maxInvoices: 5000, duration: 365, price: 30000 },
      enterprise: { maxDevices: 999, maxCustomers: 9999, maxInvoices: 99999, duration: 365, price: 90000 },
    };

    const config = planConfigs[plan] || planConfigs.free;
    const durationMs = config.duration * 24 * 60 * 60 * 1000;

    return await database.write(async () => {
      // إبطال الاشتراكات السابقة للسيادة
      const existing = await database.get('subscriptions').query(
        Q.where('user_id', userId)
      ).fetch();

      for (const sub of existing) {
        await sub.update(() => {
          sub.status = 'EXPIRED';
        });
      }

      // إنشاء الجديد مع ربط بصمة الجهاز (Hardware ID)
      return await database.get('subscriptions').create(sub => {
        sub.userId = userId;
        sub.plan = plan;
        // الباقات المدفوعة تبدأ بـ VERIFICATION_PENDING لضمان الدفع
        sub.status = (plan === 'trial') ? 'TRIAL_ACTIVE' :
                     (plan === 'free' ? 'ACTIVE_FULL' : 'VERIFICATION_PENDING');
        sub.startDate = now;
        sub.endDate = now + durationMs;
        sub.maxDevices = config.maxDevices;
        sub.maxCustomers = config.maxCustomers;
        sub.maxInvoices = config.maxInvoices;
        sub.currency = 'YER';
        sub.price = config.price;
        sub.total = data.total || config.price;

        // ربط بصمة الجهاز إذا توفرت
        if (data.deviceId) sub.paymentReference = `HWID:${data.deviceId}`;

        Object.assign(sub, data);
      });
    });
  }

  /**
   * الحصول على الاشتراك النشط
   */
  static async getActiveSubscription(database, userId) {
    const subs = await database.get('subscriptions').query(
      Q.where('user_id', userId),
      Q.where('status', Q.notEq('EXPIRED'))
    ).fetch();

    // البحث عن الأكثر صلاحية
    return subs.find(s => s.isActiveSubscription()) || subs[0] || null;
  }
}
