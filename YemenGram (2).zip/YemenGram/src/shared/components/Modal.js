import React, { useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal as RNModal,
  TouchableOpacity,
  TouchableWithoutFeedback,
  Animated,
  ScrollView,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '../utils/colors';
import Button from './Button';

export default function Modal({
  // ===== الأساسيات =====
  visible,
  onClose,
  title,
  message,
  children,

  // ===== الأزرار =====
  confirmText = 'موافق',
  cancelText = 'إلغاء',
  onConfirm,
  onCancel,
  confirmVariant = 'primary',
  cancelVariant = 'secondary',
  confirmLoading = false,

  // ===== التخصيص =====
  type = 'default', // default, confirm, danger, success, info
  size = 'medium', // small, medium, large
  showClose = true,
  closeOnBackdrop = true,
  closeOnConfirm = true,

  // ===== التنسيق =====
  style,
  titleStyle,
  messageStyle,
  contentStyle,
}) {
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0.9)).current;

  // ===== أنيميشن الدخول =====
  useEffect(() => {
    if (visible) {
      Animated.parallel([
        Animated.spring(scaleAnim, {
          toValue: 1,
          friction: 6,
          tension: 50,
          useNativeDriver: true,
        }),
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 250,
          useNativeDriver: true,
        }),
      ]).start();
    } else {
      Animated.parallel([
        Animated.timing(scaleAnim, {
          toValue: 0.9,
          duration: 200,
          useNativeDriver: true,
        }),
        Animated.timing(fadeAnim, {
          toValue: 0,
          duration: 200,
          useNativeDriver: true,
        }),
      ]).start();
    }
  }, [visible]);

  // ===== أيقونة حسب النوع =====
  const getIcon = () => {
    switch (type) {
      case 'confirm':
        return { name: 'help-circle', color: Colors.navy };
      case 'danger':
        return { name: 'alert-circle', color: Colors.red };
      case 'success':
        return { name: 'checkmark-circle', color: Colors.green };
      case 'info':
        return { name: 'information-circle', color: Colors.gold };
      default:
        return null;
    }
  };

  // ===== حجم المودال =====
  const getSize = () => {
    switch (size) {
      case 'small':
        return { width: '80%', padding: 20 };
      case 'medium':
        return { width: '90%', padding: 24 };
      case 'large':
        return { width: '95%', padding: 28, maxHeight: '85%' };
      default:
        return { width: '90%', padding: 24 };
    }
  };

  const sizeConfig = getSize();
  const icon = getIcon();

  const handleClose = () => {
    if (onClose) onClose();
  };

  const handleBackdrop = () => {
    if (closeOnBackdrop) handleClose();
  };

  const handleConfirm = () => {
    if (onConfirm) onConfirm();
    if (closeOnConfirm) handleClose();
  };

  const handleCancel = () => {
    if (onCancel) onCancel();
    handleClose();
  };

  // ===== عرض المودال =====
  return (
    <RNModal
      visible={visible}
      transparent
      animationType="none"
      onRequestClose={handleClose}
    >
      <TouchableWithoutFeedback onPress={handleBackdrop}>
        <Animated.View style={[styles.overlay, { opacity: fadeAnim }]}>
          <TouchableWithoutFeedback>
            <Animated.View
              style={[
                styles.modal,
                {
                  width: sizeConfig.width,
                  padding: sizeConfig.padding,
                  maxHeight: size === 'large' ? '85%' : 'auto',
                },
                { transform: [{ scale: scaleAnim }] },
                style,
              ]}
            >
              {/* ===== تم حذف زر الإغلاق بناءً على طلب السيادة البصرية ===== */}

              {/* ===== الأيقونة ===== */}
              {icon && (
                <View style={[styles.iconWrapper, { backgroundColor: icon.color + '15' }]}>
                  <Ionicons name={icon.name} size={48} color={icon.color} />
                </View>
              )}

              {/* ===== العنوان ===== */}
              {title && (
                <Text style={[styles.title, icon && styles.titleWithIcon, { textAlign: 'right', width: '100%' }, titleStyle]}>
                  {title}
                </Text>
              )}

              {/* ===== الرسالة ===== */}
              {message && (
                <Text style={[styles.message, { textAlign: 'right', width: '100%' }, messageStyle]}>
                  {message}
                </Text>
              )}

              {/* ===== المحتوى المخصص ===== */}
              {children && (
                <ScrollView
                  showsVerticalScrollIndicator={false}
                  style={styles.contentScroll}
                  contentContainerStyle={[styles.contentContainer, contentStyle]}
                >
                  {children}
                </ScrollView>
              )}

              {/* ===== الأزرار ===== */}
              {(onConfirm || onCancel) && (
                <View style={styles.buttons}>
                  {onCancel && (
                    <Button
                      title={cancelText}
                      onPress={handleCancel}
                      variant={cancelVariant}
                      style={[styles.button, styles.buttonCancel]}
                      disabled={confirmLoading}
                    />
                  )}
                  {onConfirm && (
                    <Button
                      title={confirmText}
                      onPress={handleConfirm}
                      variant={confirmVariant}
                      loading={confirmLoading}
                      disabled={confirmLoading}
                      style={[styles.button, styles.buttonConfirm]}
                    />
                  )}
                </View>
              )}
            </Animated.View>
          </TouchableWithoutFeedback>
        </Animated.View>
      </TouchableWithoutFeedback>
    </RNModal>
  );
}

const styles = StyleSheet.create({
  // ===== الخلفية =====
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },

  // ===== المودال =====
  modal: {
    backgroundColor: Colors.white,
    borderRadius: 24,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.2,
    shadowRadius: 24,
    elevation: 12,
  },

  // ===== زر الإغلاق =====
  closeBtn: {
    position: 'absolute',
    top: 12,
    right: 12,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#F5F6FA',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 10,
  },

  // ===== الأيقونة =====
  iconWrapper: {
    width: 80,
    height: 80,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    marginTop: 8,
  },

  // ===== العنوان =====
  title: {
    fontSize: 20,
    fontFamily: 'Tajawal-Bold',
    color: Colors.dark,
    textAlign: 'center',
    marginBottom: 8,
  },
  titleWithIcon: {
    marginTop: 0,
  },

  // ===== الرسالة =====
  message: {
    fontSize: 14,
    fontFamily: 'Tajawal-Regular',
    color: Colors.gray,
    textAlign: 'center',
    lineHeight: 22,
    marginBottom: 16,
    paddingHorizontal: 8,
  },

  // ===== المحتوى =====
  contentScroll: {
    width: '100%',
    maxHeight: 400,
  },
  contentContainer: {
    paddingVertical: 4,
    width: '100%',
  },

  // ===== الأزرار =====
  buttons: {
    flexDirection: 'row-reverse',
    gap: 10,
    marginTop: 8,
    width: '100%',
  },
  button: {
    flex: 1,
  },
  buttonCancel: {
    backgroundColor: Colors.lightGray,
  },
  buttonConfirm: {
    flex: 1,
  },
});