// src/shared/services/api.js
// =============================================
// خدمة الاتصال بالخادم (API Service)
// المسؤولة عن جميع طلبات HTTP إلى Supabase
// =============================================

import { Platform } from 'react-native';
import { SecureStorage } from './storageService';
import { Logger } from '../utils/logger';
import * as SecureStore from 'expo-secure-store';

// =============================================
// 1. الثوابت
// =============================================

const API_BASE_URL =
  process.env.EXPO_PUBLIC_SUPABASE_URL ||
  process.env.NEXT_PUBLIC_SUPABASE_URL ||
  process.env.SUPABASE_URL ||
  'https://your-project.supabase.co';

const API_KEY =
  process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ||
  process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY ||
  process.env.SUPABASE_ANON_KEY ||
  process.env.SUPABASE_PUBLISHABLE_KEY ||
  'your-anon-key';

const DEFAULT_HEADERS = {
  'Content-Type': 'application/json',
  'apikey': API_KEY,
};

const TIMEOUT = 30000; // 30 ثانية

// =============================================
// 2. دوال المساعدة
// =============================================

/**
 * الحصول على التوكن من التخزين الآمن
 * @returns {Promise<string|null>}
 */
const getToken = async () => {
  try {
    return await SecureStore.getItemAsync('userToken');
  } catch (error) {
    Logger.error('Failed to get token:', error);
    return null;
  }
};

/**
 * الحصول على التوكن مع البادئة
 * @returns {Promise<string|null>}
 */
const getAuthHeader = async () => {
  const token = await getToken();
  if (!token) return null;
  return `Bearer ${token}`;
};

/**
 * إنشاء رؤوس الطلب
 * @param {Object} extraHeaders - رؤوس إضافية
 * @returns {Promise<Object>}
 */
const getHeaders = async (extraHeaders = {}) => {
  const authHeader = await getAuthHeader();
  const headers = { ...DEFAULT_HEADERS, ...extraHeaders };

  if (authHeader) {
    headers['Authorization'] = authHeader;
  }

  return headers;
};

/**
 * معالجة استجابة الخادم
 * @param {Response} response - كائن الاستجابة
 * @returns {Promise<any>}
 */
const handleResponse = async (response) => {
  const contentType = response.headers.get('content-type');
  const isJson = contentType?.includes('application/json');

  let data;
  try {
    data = isJson ? await response.json() : await response.text();
  } catch (error) {
    throw new Error('فشل في قراءة استجابة الخادم');
  }

  if (!response.ok) {
    const errorMessage = data?.message || data?.error || data?.error_description || 'حدث خطأ غير متوقع';
    const error = new Error(errorMessage);
    error.status = response.status;
    error.data = data;
    throw error;
  }

  return data;
};

/**
 * إنشاء AbortController مع timeout
 * @param {number} timeout - مدة الانتظار
 * @returns {Object}
 */
const createTimeoutController = (timeout = TIMEOUT) => {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  return { controller, timer };
};

// =============================================
// 3. دوال الطلبات الأساسية
// =============================================

/**
 * إرسال طلب GET
 * @param {string} endpoint - نقطة النهاية
 * @param {Object} options - خيارات إضافية
 * @returns {Promise<any>}
 */
export const get = async (endpoint, options = {}) => {
  const { headers = {}, params = {}, timeout = TIMEOUT, signal = null } = options;

  const queryString = new URLSearchParams(params).toString();
  const url = `${API_BASE_URL}${endpoint}${queryString ? `?${queryString}` : ''}`;
  const finalHeaders = await getHeaders(headers);
  const { controller, timer } = createTimeoutController(timeout);

  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: finalHeaders,
      signal: signal || controller.signal,
    });
    clearTimeout(timer);
    return await handleResponse(response);
  } catch (error) {
    clearTimeout(timer);
    if (error.name === 'AbortError') {
      throw new Error('انتهت مدة الطلب');
    }
    throw error;
  }
};

/**
 * إرسال طلب POST
 * @param {string} endpoint - نقطة النهاية
 * @param {any} data - البيانات المرسلة
 * @param {Object} options - خيارات إضافية
 * @returns {Promise<any>}
 */
export const post = async (endpoint, data, options = {}) => {
  const { headers = {}, timeout = TIMEOUT, signal = null } = options;

  const url = `${API_BASE_URL}${endpoint}`;
  const finalHeaders = await getHeaders(headers);
  const { controller, timer } = createTimeoutController(timeout);

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: finalHeaders,
      body: JSON.stringify(data),
      signal: signal || controller.signal,
    });
    clearTimeout(timer);
    return await handleResponse(response);
  } catch (error) {
    clearTimeout(timer);
    if (error.name === 'AbortError') {
      throw new Error('انتهت مدة الطلب');
    }
    throw error;
  }
};

/**
 * إرسال طلب PUT
 * @param {string} endpoint - نقطة النهاية
 * @param {any} data - البيانات المرسلة
 * @param {Object} options - خيارات إضافية
 * @returns {Promise<any>}
 */
export const put = async (endpoint, data, options = {}) => {
  const { headers = {}, timeout = TIMEOUT, signal = null } = options;

  const url = `${API_BASE_URL}${endpoint}`;
  const finalHeaders = await getHeaders(headers);
  const { controller, timer } = createTimeoutController(timeout);

  try {
    const response = await fetch(url, {
      method: 'PUT',
      headers: finalHeaders,
      body: JSON.stringify(data),
      signal: signal || controller.signal,
    });
    clearTimeout(timer);
    return await handleResponse(response);
  } catch (error) {
    clearTimeout(timer);
    if (error.name === 'AbortError') {
      throw new Error('انتهت مدة الطلب');
    }
    throw error;
  }
};

/**
 * إرسال طلب PATCH
 * @param {string} endpoint - نقطة النهاية
 * @param {any} data - البيانات المرسلة
 * @param {Object} options - خيارات إضافية
 * @returns {Promise<any>}
 */
export const patch = async (endpoint, data, options = {}) => {
  const { headers = {}, timeout = TIMEOUT, signal = null } = options;

  const url = `${API_BASE_URL}${endpoint}`;
  const finalHeaders = await getHeaders(headers);
  const { controller, timer } = createTimeoutController(timeout);

  try {
    const response = await fetch(url, {
      method: 'PATCH',
      headers: finalHeaders,
      body: JSON.stringify(data),
      signal: signal || controller.signal,
    });
    clearTimeout(timer);
    return await handleResponse(response);
  } catch (error) {
    clearTimeout(timer);
    if (error.name === 'AbortError') {
      throw new Error('انتهت مدة الطلب');
    }
    throw error;
  }
};

/**
 * إرسال طلب DELETE
 * @param {string} endpoint - نقطة النهاية
 * @param {Object} options - خيارات إضافية
 * @returns {Promise<any>}
 */
export const del = async (endpoint, options = {}) => {
  const { headers = {}, timeout = TIMEOUT, signal = null } = options;

  const url = `${API_BASE_URL}${endpoint}`;
  const finalHeaders = await getHeaders(headers);
  const { controller, timer } = createTimeoutController(timeout);

  try {
    const response = await fetch(url, {
      method: 'DELETE',
      headers: finalHeaders,
      signal: signal || controller.signal,
    });
    clearTimeout(timer);
    return await handleResponse(response);
  } catch (error) {
    clearTimeout(timer);
    if (error.name === 'AbortError') {
      throw new Error('انتهت مدة الطلب');
    }
    throw error;
  }
};

// =============================================
// 4. دوال رفع الملفات
// =============================================

/**
 * رفع ملف إلى الخادم
 * @param {string} endpoint - نقطة النهاية
 * @param {FormData} formData - بيانات الملف
 * @param {Object} options - خيارات إضافية
 * @returns {Promise<any>}
 */
export const uploadFile = async (endpoint, formData, options = {}) => {
  const { headers = {}, timeout = 60000, signal = null, onProgress } = options;

  const url = `${API_BASE_URL}${endpoint}`;
  const authHeader = await getAuthHeader();

  const finalHeaders = {
    ...headers,
    'Content-Type': 'multipart/form-data',
  };

  if (authHeader) {
    finalHeaders['Authorization'] = authHeader;
  }

  const { controller, timer } = createTimeoutController(timeout);

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: finalHeaders,
      body: formData,
      signal: signal || controller.signal,
    });
    clearTimeout(timer);
    return await handleResponse(response);
  } catch (error) {
    clearTimeout(timer);
    if (error.name === 'AbortError') {
      throw new Error('انتهت مدة رفع الملف');
    }
    throw error;
  }
};

// =============================================
// 5. دوال Supabase المباشرة
// =============================================

/**
 * استعلام Supabase (محاكاة)
 * @param {string} table - اسم الجدول
 * @param {Object} query - استعلام
 * @param {Object} options - خيارات إضافية
 * @returns {Promise<any>}
 */
export const supabaseQuery = async (table, query = {}, options = {}) => {
  const { select = '*', filters = {}, order = null, limit = null, offset = null } = query;

  let endpoint = `/rest/v1/${table}?select=${select}`;

  // إضافة الفلاتر
  for (const [key, value] of Object.entries(filters)) {
    endpoint += `&${key}=eq.${value}`;
  }

  if (order) {
    endpoint += `&order=${order.column}.${order.direction || 'asc'}`;
  }

  if (limit) {
    endpoint += `&limit=${limit}`;
  }

  if (offset) {
    endpoint += `&offset=${offset}`;
  }

  return await get(endpoint, options);
};

/**
 * إدراج في Supabase
 * @param {string} table - اسم الجدول
 * @param {Object} data - البيانات
 * @param {Object} options - خيارات إضافية
 * @returns {Promise<any>}
 */
export const supabaseInsert = async (table, data, options = {}) => {
  const endpoint = `/rest/v1/${table}`;
  return await post(endpoint, data, options);
};

/**
 * تحديث في Supabase
 * @param {string} table - اسم الجدول
 * @param {Object} data - البيانات
 * @param {Object} filters - فلترة
 * @param {Object} options - خيارات إضافية
 * @returns {Promise<any>}
 */
export const supabaseUpdate = async (table, data, filters = {}, options = {}) => {
  const endpoint = `/rest/v1/${table}`;
  const queryParams = new URLSearchParams();
  for (const [key, value] of Object.entries(filters)) {
    queryParams.append(key, `eq.${value}`);
  }
  const url = `${endpoint}?${queryParams.toString()}`;
  return await patch(url, data, options);
};

/**
 * حذف من Supabase
 * @param {string} table - اسم الجدول
 * @param {Object} filters - فلترة
 * @param {Object} options - خيارات إضافية
 * @returns {Promise<any>}
 */
export const supabaseDelete = async (table, filters = {}, options = {}) => {
  const endpoint = `/rest/v1/${table}`;
  const queryParams = new URLSearchParams();
  for (const [key, value] of Object.entries(filters)) {
    queryParams.append(key, `eq.${value}`);
  }
  const url = `${endpoint}?${queryParams.toString()}`;
  return await del(url, options);
};

// =============================================
// 6. كائن API الرئيسي
// =============================================
export const api = {
  // الطلبات الأساسية
  get,
  post,
  put,
  patch,
  delete: del,
  upload: uploadFile,

  // Supabase
  query: supabaseQuery,
  insert: supabaseInsert,
  update: supabaseUpdate,
  delete: supabaseDelete,
  // مساعدة
  getToken,
  getAuthHeader,
};
export default api;