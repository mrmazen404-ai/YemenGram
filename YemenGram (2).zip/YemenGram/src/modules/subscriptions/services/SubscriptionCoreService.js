/** خدمة الاشتراك المركزية: LocalDB هو مصدر الحقيقة المحلي الحالي. */
import { transition, STATES, EVENTS } from './SubscriptionEngine';
import { LocalDB } from '../../database/localDB';
import TimeService from '../../../services/timeService';

const DAY = 24 * 60 * 60 * 1000;
const id = (prefix) => `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 12)}`;

class SubscriptionCoreService {
  async _get(subscriptionId, userId) {
    if (subscriptionId) {
      const byId = await LocalDB.queryOne('SELECT * FROM subscriptions WHERE id = ?', [subscriptionId]);
      if (byId) return byId;
    }
    if (userId) return LocalDB.queryOne('SELECT * FROM subscriptions WHERE user_id = ? ORDER BY created_at DESC LIMIT 1', [userId]);
    return null;
  }

  async _claimKey(subscriptionId, key, userId) {
    if (!key) return { claimed: true };
    try {
      await LocalDB.execute(
        'INSERT INTO subscription_event_keys (idempotency_key, subscription_id, user_id, created_at) VALUES (?, ?, ?, ?)',
        [key, subscriptionId, userId || null, Date.now()],
        { system: true }
      );
      return { claimed: true };
    } catch (error) {
      if (/unique|constraint/i.test(error?.message || '')) return { claimed: false, duplicate: true };
      throw error;
    }
  }

  async processEvent(subscriptionId, event, ctx = {}) {
    if (!event || !Object.values(EVENTS).includes(event)) throw new Error('UNKNOWN_SUBSCRIPTION_EVENT');
    if (!ctx.userId && !subscriptionId) throw new Error('SUBSCRIPTION_USER_REQUIRED');
    const now = TimeService?.getSovereignTime?.() || Date.now();
    let record = await this._get(subscriptionId, ctx.userId);

    if (!record && [EVENTS.REQUEST_SUBSCRIPTION, EVENTS.START_FREE_TRIAL].includes(event)) {
      const newId = subscriptionId || id('sub');
      const initialStatus = event === EVENTS.START_FREE_TRIAL ? STATES.TRIAL_ACTIVE : STATES.UNSUBSCRIBED;
      const plan = ctx.plan || (event === EVENTS.START_FREE_TRIAL ? 'trial' : 'free');
      const start = now;
      const end = event === EVENTS.START_FREE_TRIAL ? now + 30 * DAY : null;
      await LocalDB.execute(
        `INSERT INTO subscriptions (id, user_id, status, plan, start_date, end_date, trial_end_date, grace_period_end, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [newId, ctx.userId, initialStatus, plan, start, end, end, null, now, now],
        { system: true }
      );
      record = await this._get(newId, ctx.userId);
      subscriptionId = newId;
      if (event === EVENTS.START_FREE_TRIAL) {
        await LocalDB.addAuditLog('trial_activated', 'subscriptions', subscriptionId, { prevState: STATES.UNSUBSCRIBED, nextState: STATES.TRIAL_ACTIVE, event, timestamp: now }, ctx.userId, { system: true });
        return { result: { prevState: STATES.UNSUBSCRIBED, event, nextState: STATES.TRIAL_ACTIVE, valid: true }, subscriptionId };
      }
    }

    if (!record) throw new Error('SUBSCRIPTION_NOT_FOUND');
    if (ctx.userId && record.user_id && record.user_id !== ctx.userId) throw new Error('SUBSCRIPTION_OWNER_MISMATCH');

    const keyResult = await this._claimKey(record.id, ctx.idempotencyKey, ctx.userId || record.user_id);
    if (keyResult.duplicate) return { duplicate: true, subscriptionId: record.id, result: { prevState: record.status, nextState: record.status, event, valid: true, duplicate: true } };

    const result = transition(record.status || STATES.UNSUBSCRIBED, event, {
      ...ctx,
      previousState: record.previous_status || null,
    });
    if (!result.valid) {
      await LocalDB.addAuditLog('subscription_transition_rejected', 'subscriptions', record.id, { prevState: result.prevState, nextState: result.nextState, event, errorCode: result.errorCode, timestamp: now }, ctx.userId || record.user_id, { system: true });
      throw new Error(result.errorCode || 'INVALID_TRANSITION');
    }

    const updates = ['status = ?', 'updated_at = ?'];
    const params = [result.nextState, now];
    if (result.nextState === STATES.SECURITY_SUSPENDED) { updates.push('previous_status = ?', 'suspended_at = ?', 'suspension_reason = ?'); params.push(result.restoreState || record.status, now, ctx.reason || 'security_policy'); }
    if (result.nextState === STATES.ACTIVE_FULL && record.status === STATES.VERIFICATION_PENDING) updates.push('verification_approved_at = ?'), params.push(now);
    if (event === EVENTS.RECEIPT_SUBMITTED) updates.push('verification_requested_at = ?', 'payment_proof = ?'), params.push(now, ctx.data?.receiptUrl || null);
    if (event === EVENTS.CANCEL) updates.push('cancelled_at = ?', 'cancellation_reason = ?'), params.push(now, ctx.reason || 'user_requested');
    if (event === EVENTS.REFUND_REQUESTED) updates.push('refund_requested_at = ?', 'refund_status = ?'), params.push(now, 'pending');
    if (event === EVENTS.REFUND_APPROVED) updates.push('refund_status = ?', 'archived_at = ?'), params.push('approved', now);
    params.push(record.id);
    await LocalDB.execute(`UPDATE subscriptions SET ${updates.join(', ')} WHERE id = ? AND user_id = ?`, [...params, record.user_id], { system: true });

    await LocalDB.addAuditLog(result.sideEffects.find(s => s.type === 'audit')?.message || event, 'subscriptions', record.id, {
      prevState: result.prevState, nextState: result.nextState, event, timestamp: now, idempotencyKey: ctx.idempotencyKey || null,
    }, ctx.userId || record.user_id, { system: true });
    return { result, subscriptionId: record.id };
  }

  async startTrial(userId) {
    if (!userId) throw new Error('USER_REQUIRED');
    const existing = await LocalDB.queryOne('SELECT id FROM subscriptions WHERE user_id = ? AND plan = ? LIMIT 1', [userId, 'trial']);
    if (existing) throw new Error('TRIAL_ALREADY_USED');
    return this.processEvent(id('trial'), EVENTS.START_FREE_TRIAL, { userId, plan: 'trial', idempotencyKey: `trial:${userId}` });
  }
}

export default SubscriptionCoreService;
