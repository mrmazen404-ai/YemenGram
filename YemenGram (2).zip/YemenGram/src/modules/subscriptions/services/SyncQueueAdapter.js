/**
 * محول طابور المزامنة (Sovereign Sync Queue Adapter)
 */

class SyncQueueAdapter {
  constructor(localQueue) {
    this.localQueue = localQueue || [];
  }

  enqueue(item) {
    this.localQueue.push({
      ...item,
      id: `q_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`,
      status: 'pending',
      created_at: Date.now()
    });
    return this.localQueue[this.localQueue.length - 1];
  }

  getPending() {
    return this.localQueue.filter(i => i.status === 'pending');
  }
}

export default SyncQueueAdapter;
