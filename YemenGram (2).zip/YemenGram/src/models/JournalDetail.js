// src/models/JournalDetail.js
// =============================================
// نموذج تفاصيل القيد اليومي (Journal Detail Model)
// المسؤول عن تسجيل كل صف (حركة) داخل القيد
// =============================================

import { Model } from '@nozbe/watermelondb';
import { field } from '@nozbe/watermelondb/decorators';

export default class JournalDetail extends Model {
  // ===== 1. اسم الجدول =====
  static table = 'journal_details';

  // ===== 2. الحقول الأساسية =====

  // معرف القيد اليومي الذي ينتمي إليه هذا التفصيل
  @field('journal_entry_id') journalEntryId;

  // معرف الحساب المتأثر
  @field('account_id') accountId;

  // المبلغ المدين لهذا الحساب
  @field('debit') debit;

  // المبلغ الدائن لهذا الحساب
  @field('credit') credit;

  // وصف إضافي لهذا البند (اختياري)
  @field('description') description;

  // ===== 3. العلاقات =====

  static associations = {
    // كل تفصيل ينتمي إلى قيد واحد
    journalEntry: { type: 'belongs_to', key: 'journal_entry_id' },
    // كل تفصيل ينتمي إلى حساب واحد
    account: { type: 'belongs_to', key: 'account_id' },
  };

  // ===== 4. دوال مساعدة =====

  /**
   * التحقق من أن هذا البند مدين
   * @returns {boolean}
   */
  isDebit() {
    return (this.debit || 0) > 0;
  }

  /**
   * التحقق من أن هذا البند دائن
   * @returns {boolean}
   */
  isCredit() {
    return (this.credit || 0) > 0;
  }

  /**
   * الحصول على قيمة المبلغ (القيمة المطلقة)
   * @returns {number}
   */
  getAmount() {
    return Math.abs((this.debit || 0) - (this.credit || 0));
  }

  /**
   * الحصول على نوع البند (مدين/دائن)
   * @returns {string}
   */
  getType() {
    if (this.isDebit()) return 'مدين';
    if (this.isCredit()) return 'دائن';
    return 'صفر';
  }

  /**
   * الحصول على اسم الحساب
   * @returns {Promise<string>}
   */
  async getAccountName() {
    const account = await this.getAccount();
    return account ? account.name : 'حساب غير معروف';
  }

  /**
   * الحصول على رقم الحساب
   * @returns {Promise<string>}
   */
  async getAccountCode() {
    const account = await this.getAccount();
    return account ? account.code : '???';
  }

  /**
   * جلب الحساب المرتبط
   * @returns {Promise<Account>}
   */
  async getAccount() {
    return this.collections.get('accounts').find(this.accountId);
  }

  /**
   * جلب القيد المرتبط
   * @returns {Promise<JournalEntry>}
   */
  async getJournalEntry() {
    return this.collections.get('journal_entries').find(this.journalEntryId);
  }

  /**
   * الحصول على اسم الحساب مع الرقم
   * @returns {Promise<string>}
   */
  async getAccountDisplayName() {
    const account = await this.getAccount();
    return account ? `${account.code} - ${account.name}` : '??? - غير معروف';
  }

  /**
   * الحصول على اسم القيد المرتبط
   * @returns {Promise<string>}
   */
  async getJournalEntryDisplayName() {
    const entry = await this.getJournalEntry();
    return entry ? `قيد رقم ${entry.number}` : 'قيد غير معروف';
  }

  // ===== 5. دوال ثابتة (Static Methods) =====

  /**
   * حساب إجمالي المدين لمجموعة من التفاصيل
   * @param {JournalDetail[]} details
   * @returns {number}
   */
  static sumDebit(details) {
    return details.reduce((sum, d) => sum + (d.debit || 0), 0);
  }

  /**
   * حساب إجمالي الدائن لمجموعة من التفاصيل
   * @param {JournalDetail[]} details
   * @returns {number}
   */
  static sumCredit(details) {
    return details.reduce((sum, d) => sum + (d.credit || 0), 0);
  }

  /**
   * التحقق من توازن مجموعة من التفاصيل (المدين = الدائن)
   * @param {JournalDetail[]} details
   * @returns {boolean}
   */
  static isBalanced(details) {
    return this.sumDebit(details) === this.sumCredit(details);
  }

  /**
   * الحصول على الفرق بين المدين والدائن لمجموعة من التفاصيل
   * @param {JournalDetail[]} details
   * @returns {number}
   */
  static getDifference(details) {
    return this.sumDebit(details) - this.sumCredit(details);
  }

  /**
   * الحصول على عدد التفاصيل
   * @param {JournalDetail[]} details
   * @returns {number}
   */
  static count(details) {
    return details.length;
  }

  /**
   * تجميع التفاصيل حسب الحساب
   * @param {JournalDetail[]} details
   * @returns {Object}
   */
  static groupByAccount(details) {
    const groups = {};
    for (const detail of details) {
      const key = detail.accountId;
      if (!groups[key]) {
        groups[key] = [];
      }
      groups[key].push(detail);
    }
    return groups;
  }

  /**
   * الحصول على الحسابات الفريدة في مجموعة من التفاصيل
   * @param {JournalDetail[]} details
   * @returns {string[]}
   */
  static getUniqueAccountIds(details) {
    const ids = new Set();
    for (const detail of details) {
      ids.add(detail.accountId);
    }
    return Array.from(ids);
  }

  /**
   * التحقق من أن جميع التفاصيل تنتمي إلى نفس القيد
   * @param {JournalDetail[]} details
   * @returns {boolean}
   */
  static belongToSameEntry(details) {
    if (details.length === 0) return true;
    const firstEntryId = details[0].journalEntryId;
    return details.every(d => d.journalEntryId === firstEntryId);
  }
}