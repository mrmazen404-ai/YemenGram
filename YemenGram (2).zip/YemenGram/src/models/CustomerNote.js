// src/models/CustomerNote.js
// =============================================
// نموذج ملاحظات العميل (Customer Note Model)
// المسؤول عن إدارة الملاحظات الداخلية للعميل
// =============================================

import { Model } from '@nozbe/watermelondb';
import { field, date, readonly } from '@nozbe/watermelondb/decorators';

export default class CustomerNote extends Model {
  // ===== 1. اسم الجدول =====
  static table = 'customer_notes';

  // ===== 2. الحقول الأساسية =====

  // معرف العميل المرتبط بهذه الملاحظة
  @field('customer_id') customerId;

  // نص الملاحظة
  @field('note') note;

  // من قام بإنشاء الملاحظة
  @field('created_by') createdBy;

  // ===== 3. التواريخ التلقائية =====

  @readonly @date('created_at') createdAt;

  // ===== 4. العلاقات =====

  static associations = {
    // كل ملاحظة تنتمي إلى عميل واحد
    customer: { type: 'belongs_to', key: 'customer_id' },
  };

  // ===== 5. دوال مساعدة =====

  /**
   * جلب العميل المرتبط
   * @returns {Promise<Customer>}
   */
  async getCustomer() {
    return this.collections.get('customers').find(this.customerId);
  }

  /**
   * الحصول على اسم العميل
   * @returns {Promise<string>}
   */
  async getCustomerName() {
    const customer = await this.getCustomer();
    return customer ? customer.name : 'عميل غير معروف';
  }

  /**
   * الحصول على نص الملاحظة المختصر
   * @param {number} maxLength
   * @returns {string}
   */
  getShortNote(maxLength = 50) {
    if (!this.note) return '';
    if (this.note.length <= maxLength) return this.note;
    return this.note.slice(0, maxLength) + '...';
  }

  /**
   * الحصول على تاريخ الملاحظة بتنسيق مقروء
   * @returns {string}
   */
  getFormattedDate() {
    if (!this.createdAt) return '';
    const date = new Date(this.createdAt);
    return date.toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  /**
   * الحصول على الملاحظة كاملة مع التاريخ
   * @returns {string}
   */
  getFullNote() {
    const dateStr = this.getFormattedDate();
    return `[${dateStr}] ${this.note}`;
  }

  /**
   * التحقق من وجود نص في الملاحظة
   * @returns {boolean}
   */
  hasContent() {
    return !!(this.note && this.note.trim().length > 0);
  }
}