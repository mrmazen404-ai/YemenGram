// src/modules/auth/AppLockScreen.js
// =============================================
// شاشة قفل التطبيق (App Lock Screen)
// تظهر عند العودة للتطبيق بعد فترة خمول
// =============================================

import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Vibration,
  StatusBar,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as LocalAuthentication from 'expo-local-authentication';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors } from '../../shared/utils/colors';
import { useAuth } from '../../shared/contexts/AuthContext';
import { LocalDB } from '../../shared/services/storageService';


// =============================================
// 1. الثوابت
// =============================================

const MAX_ATTEMPTS = 5;
const LOCK_TIME = 60; // 60 ثانية

// =============================================
// 2. المكون الرئيسي
// =============================================

export default function AppLockScreen({ navigation, route }) {
  const { verifyPIN, isBiometricEnabled, disableBiometric, logout } = useAuth();
  const onSuccess = route?.params?.onSuccess;

  // ===== State =====
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [attempts, setAttempts] = useState(0);
  const [locked, setLocked] = useState(false);
  const [lockTimer, setLockTimer] = useState(0);
  const [hasBio, setHasBio] = useState(false);
  const [bioEnabled, setBioEnabled] = useState(false);
  const [loading, setLoading] = useState(false);

  // ===== Animated =====
  const shakeAnim = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0.9)).current;

  // ===== التحقق من البصمة =====
  useEffect(() => {
    const checkBiometric = async () => {
      try {
        const hw = await LocalAuthentication.hasHardwareAsync();
        const en = await LocalAuthentication.isEnrolledAsync();
        const bio = await isBiometricEnabled();

        setHasBio(hw && en);
        setBioEnabled(bio && hw && en);

        if (bio && !(hw && en)) {
          await disableBiometric();
          setBioEnabled(false);
        }

        // إذا كان الجهاز يدعم البصمة ومفعلة، حاول تلقائياً
        if (bio && hw && en) {
          setTimeout(() => {
            handleBiometric();
          }, 500);
        }
      } catch (error) {
        console.log('⚠️ فشل التحقق من البصمة:', error.message);
      }
    };
    checkBiometric();
  }, []);

  // ===== أنيميشن الدخول =====
  useEffect(() => {
    Animated.parallel([
      Animated.spring(scaleAnim, {
        toValue: 1,
        friction: 6,
        tension: 50,
        useNativeDriver: true,
      }),
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 400,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  // ===== مؤقت القفل =====
  useEffect(() => {
    if (lockTimer > 0) {
      const timer = setTimeout(() => setLockTimer(lockTimer - 1), 1000);
      return () => clearTimeout(timer);
    }
    if (lockTimer === 0 && locked) {
      setLocked(false);
      setAttempts(0);
      setError(false);
    }
  }, [lockTimer, locked]);

  // ===== هز الشاشة =====
  const doShake = () => {
    Vibration.vibrate(80);
    Animated.sequence([
      Animated.timing(shakeAnim, { toValue: 12, duration: 40, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -12, duration: 40, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 8, duration: 40, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 0, duration: 40, useNativeDriver: true }),
    ]).start();
  };

  // ===== معالجة الضغط =====
  const handlePress = (num) => {
    if (locked || loading) return;
    if (error) {
      setError(false);
      setErrorMessage('');
    }

    if (num === 'delete') {
      setPin(p => p.slice(0, -1));
      return;
    }

    if (num === 'logout') {
      handleLogout();
      return;
    }

    const newPin = pin + num;
    setPin(newPin);
    if (newPin.length === 6) {
      verifyNow(newPin);
    }
  };

  // ===== التحقق من PIN =====
  const verifyNow = async (p) => {
    setLoading(true);
    try {
      const isValid = await verifyPIN(p);

      if (isValid) {
        // نجاح
        setPin('');
        setError(false);
        setAttempts(0);
        await LocalDB.addAuditLog('app_unlock_success', 'auth', null, {
          timestamp: new Date().toISOString(),
        });
        if (onSuccess) {
          onSuccess();
        }
        navigation.goBack();
      } else {
        // فشل
        const newAttempts = attempts + 1;
        setAttempts(newAttempts);
        setPin('');
        setError(true);

        const remaining = MAX_ATTEMPTS - newAttempts;
        setErrorMessage(
          remaining > 0
            ? `PIN غير صحيح (${remaining} محاولات متبقية)`
            : 'تم تجاوز عدد المحاولات المسموح به'
        );

        doShake();
        await LocalDB.addAuditLog('app_unlock_failed', 'auth', null, {
          attempts: newAttempts,
          timestamp: new Date().toISOString(),
        });

        if (newAttempts >= MAX_ATTEMPTS) {
          setLocked(true);
          setLockTimer(LOCK_TIME);
          setErrorMessage(`تم القفل لمدة ${LOCK_TIME} ثانية`);
        }
      }
    } catch (error) {
      setError(true);
      setErrorMessage(error.message || 'حدث خطأ في التحقق');
      doShake();
    } finally {
      setLoading(false);
    }
  };

  // ===== البصمة =====
  const handleBiometric = async () => {
    try {
      const result = await LocalAuthentication.authenticateAsync({
        promptMessage: 'فتح التطبيق',
        fallbackLabel: 'استخدام PIN',
      });

      if (result.success) {
        await LocalDB.addAuditLog('app_unlock_biometric', 'auth', null, {
          timestamp: new Date().toISOString(),
        });
        if (onSuccess) {
          onSuccess();
        }
        navigation.goBack();
      }
    } catch (error) {
      console.log('⚠️ فشل البصمة:', error.message);
    }
  };

  // ===== تسجيل الخروج =====
  const handleLogout = async () => {
    try {
      // ✅ بمجرد تنفيذ logout، سيقوم AppNavigator بتحويل المستخدم تلقائياً لشاشة Login
      await logout();
    } catch (error) {
      console.log('❌ فشل تسجيل الخروج:', error.message);
    }
  };

  // ===== المفاتيح =====
  const keys = [
    ['1', '2', '3'],
    ['4', '5', '6'],
    ['7', '8', '9'],
    ['', '0', 'delete'],
  ];

  // ===== عرض الشاشة =====
  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.navy} />

      {/* خلفية متدرجة */}
      <LinearGradient
        colors={[Colors.navy, '#0D2137']}
        style={styles.gradient}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
      />

      {/* المحتوى */}
      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
            transform: [{ scale: scaleAnim }, { translateX: shakeAnim }],
          },
        ]}
      >
        {/* الأيقونة */}
        <View style={styles.iconWrapper}>
          <LinearGradient
            colors={['rgba(255,255,255,0.1)', 'rgba(255,255,255,0.05)']}
            style={styles.iconGradient}
          >
            <Ionicons
              name={locked ? 'timer' : 'lock-closed'}
              size={48}
              color={locked ? Colors.orange : Colors.white}
            />
          </LinearGradient>
        </View>

        {/* العنوان */}
        <Text style={styles.title}>
          {locked
            ? `مقفل ${Math.floor(lockTimer / 60)}:${(lockTimer % 60).toString().padStart(2, '0')}`
            : 'أدخل رمز PIN'}
        </Text>

        <Text style={styles.subtitle}>
          {locked
            ? 'الرجاء الانتظار قبل المحاولة مرة أخرى'
            : 'أدخل رمز PIN لتأكيد هويتك'}
        </Text>

        {/* النقاط */}
        <View style={styles.dotsRow}>
          {[0, 1, 2, 3, 4, 5].map(i => (
            <View
              key={i}
              style={[
                styles.dot,
                pin.length > i && styles.dotFilled,
                error && styles.dotError,
                locked && styles.dotLocked,
              ]}
            />
          ))}
        </View>

        {/* رسالة الخطأ */}
        {error && (
          <Text style={[styles.errorText, locked && styles.lockedText]}>
            {errorMessage}
          </Text>
        )}

        {/* لوحة الأرقام */}
        <View style={[styles.keypad, locked && styles.keypadLocked]}>
          {keys.map((row, ri) => (
            <View key={ri} style={styles.keyRow}>
              {row.map(k => {
                const isEmpty = k === '';
                const isDelete = k === 'delete';
                const isLogout = k === 'logout';

                return (
                  <TouchableOpacity
                    key={k || 'empty'}
                    style={[
                      styles.key,
                      isEmpty && styles.keyEmpty,
                      locked && styles.keyLocked,
                      isLogout && styles.keyLogout,
                    ]}
                    onPress={() => k && handlePress(k)}
                    disabled={isEmpty || locked || loading}
                    activeOpacity={0.5}
                  >
                    {isDelete ? (
                      <Ionicons name="backspace" size={24} color={Colors.white} />
                    ) : isLogout ? (
                      <Ionicons name="log-out" size={20} color={Colors.red} />
                    ) : k ? (
                      <Text style={styles.keyText}>{k}</Text>
                    ) : null}
                  </TouchableOpacity>
                );
              })}
            </View>
          ))}
        </View>

        {/* زر البصمة */}
        {hasBio && bioEnabled && !locked && (
          <TouchableOpacity
            style={styles.bioBtn}
            onPress={handleBiometric}
            activeOpacity={0.5}
          >
            <Ionicons name="finger-print" size={24} color={Colors.gold} />
            <Text style={styles.bioText}>فتح بالبصمة</Text>
          </TouchableOpacity>
        )}

        {/* زر تسجيل الخروج */}
        <TouchableOpacity
          style={styles.logoutBtn}
          onPress={handleLogout}
          activeOpacity={0.5}
        >
          <Text style={styles.logoutText}>تسجيل الخروج</Text>
        </TouchableOpacity>

        {/* الإصدار */}
        <Text style={styles.version}>يمن جرام v1.0.0</Text>
      </Animated.View>
    </View>
  );
}

// =============================================
// الأنماط (Styles)
// =============================================
const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: Colors.navy,
  },

  gradient: {
    flex: 1,
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },

  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 24,
  },

  iconWrapper: {
    marginBottom: 20,
  },

  iconGradient: {
    width: 88,
    height: 88,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },

  title: {
    fontSize: 22,
    fontFamily: 'Tajawal-Bold',
    color: Colors.white,
    marginBottom: 4,
  },

  subtitle: {
    fontSize: 14,
    fontFamily: 'Tajawal-Regular',
    color: 'rgba(255,255,255,0.5)',
    marginBottom: 28,
    textAlign: 'center',
  },

  dotsRow: {
    flexDirection: 'row',
    gap: 14,
    marginBottom: 24,
  },

  dot: {
    width: 14,
    height: 14,
    borderRadius: 7,
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.2)',
    backgroundColor: 'transparent',
  },

  dotFilled: {
    backgroundColor: Colors.gold,
    borderColor: Colors.gold,
  },

  dotError: {
    backgroundColor: Colors.red,
    borderColor: Colors.red,
  },

  dotLocked: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderColor: 'rgba(255,255,255,0.1)',
  },

  errorText: {
    fontSize: 13,
    fontFamily: 'Tajawal-Medium',
    color: Colors.red,
    marginBottom: 16,
    textAlign: 'center',
  },

  lockedText: {
    color: Colors.orange,
  },

  keypad: {
    width: '100%',
    maxWidth: 280,
    marginBottom: 16,
  },

  keypadLocked: {
    opacity: 0.5,
  },

  keyRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },

  key: {
    width: 64,
    height: 56,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.06)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.04)',
  },

  keyEmpty: {
    opacity: 0,
  },

  keyLocked: {
    backgroundColor: 'rgba(255,255,255,0.02)',
    borderColor: 'rgba(255,255,255,0.02)',
  },

  keyLogout: {
    backgroundColor: 'rgba(231,76,60,0.15)',
    borderColor: 'rgba(231,76,60,0.2)',
  },

  keyText: {
    fontSize: 28,
    fontFamily: 'Tajawal-Medium',
    color: Colors.white,
  },

  bioBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 10,
    paddingHorizontal: 20,
    marginBottom: 8,
  },

  bioText: {
    fontSize: 14,
    fontFamily: 'Tajawal-Medium',
    color: Colors.gold,
  },

  logoutBtn: {
    paddingVertical: 8,
    paddingHorizontal: 16,
  },

  logoutText: {
    fontSize: 13,
    fontFamily: 'Tajawal-Regular',
    color: 'rgba(255,255,255,0.3)',
  },

  version: {
    position: 'absolute',
    bottom: 30,
    fontSize: 10,
    fontFamily: 'Tajawal-Regular',
    color: 'rgba(255,255,255,0.15)',
    letterSpacing: 2,
  },
});