// src/modules/auth/recovery/RecoveryService.js
// خدمة إدارة عمليات الاستعادة (Recovery Management Service) - v1.2 Cleaned

import { LocalDB } from '../../database/localDB';

export const RecoveryService = {
  /**
   * فحص هل يمكن إرسال كود جديد (Rate Limiting محلي)
   */
  async canResendCode() {
    try {
      const lastResend = await LocalDB.getSetting('last_recovery_resend');
      if (!lastResend) return { allowed: true };

      const diff = Date.now() - parseInt(lastResend);
      const waitTime = 60000; // دقيقة واحدة

      if (diff < waitTime) {
        return {
          allowed: false,
          remaining: Math.ceil((waitTime - diff) / 1000)
        };
      }
      return { allowed: true };
    } catch {
      return { allowed: true };
    }
  },

  /**
   * تحديث وقت آخر إرسال
   */
  async updateResendTime() {
    await LocalDB.saveSetting('last_recovery_resend', Date.now().toString());
  }
};
