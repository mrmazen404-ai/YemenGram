// src/models/AccountMovement.js
// =============================================
// نموذج حركة الحساب (Account Movement Model)
// المسؤول عن تسجيل كل حركة تؤثر على رصيد الحساب
// =============================================

import { Model } from '@nozbe/watermelondb';
import { field, date, readonly } from '@nozbe/watermelondb/decorators';
import { Q } from '@nozbe/watermelondb';

export default class AccountMovement extends Model {
  // ===== 1. اسم الجدول =====
  static table = 'account_movements';

  // ===== 2. الحقول الأساسية =====

  // معرف الحساب المتأثر بالحركة
  @field('account_id') accountId;

  // تاريخ الحركة (timestamp)
  @field('date') date;

  // معرف القيد اليومي المرتبط (إن وجد)
  @field('journal_entry_id') journalEntryId;

  // معرف الفاتورة المرتبطة (إن وجد)
  @field('invoice_id') invoiceId;

  // مرجع اختياري (رقم الفاتورة، رقم السند...)
  @field('reference') reference;

  // وصف الحركة
  @field('description') description;

  // المبلغ المدين
  @field('debit') debit;

  // المبلغ الدائن
  @field('credit') credit;

  // الرصيد التراكمي بعد هذه الحركة
  @field('balance') balance;

  // ===== 3. التواريخ التلقائية =====

  @readonly @date('created_at') createdAt;

  // ===== 4. العلاقات =====

  static associations = {
    // كل حركة تنتمي إلى حساب واحد
    account: { type: 'belongs_to', key: 'account_id' },
    // كل حركة قد تنتمي إلى قيد يومي (اختياري)
    journalEntry: { type: 'belongs_to', key: 'journal_entry_id' },
    // كل حركة قد تنتمي إلى فاتورة (اختياري)
    invoice: { type: 'belongs_to', key: 'invoice_id' },
  };

  // ===== 5. دوال مساعدة =====

  /**
   * التحقق من أن الحركة مدين (Debit)
   * @returns {boolean}
   */
  isDebit() {
    return (this.debit || 0) > 0;
  }

  /**
   * التحقق من أن الحركة دائن (Credit)
   * @returns {boolean}
   */
  isCredit() {
    return (this.credit || 0) > 0;
  }

  /**
   * الحصول على قيمة الحركة (القيمة المطلقة للمبلغ)
   * @returns {number}
   */
  getAmount() {
    return Math.abs((this.debit || 0) - (this.credit || 0));
  }

  /**
   * الحصول على نوع الحركة (مدين/دائن)
   * @returns {string}
   */
  getType() {
    if (this.isDebit()) return 'مدين';
    if (this.isCredit()) return 'دائن';
    return 'صفر';
  }

  /**
   * الحصول على اتجاه الحركة (+/-)
   * @returns {string}
   */
  getDirection() {
    if (this.isDebit()) return '+';
    if (this.isCredit()) return '-';
    return '0';
  }

  /**
   * الحصول على لون الحركة
   * @returns {string}
   */
  getColor() {
    if (this.isDebit()) return '#27AE60';
    if (this.isCredit()) return '#E74C3C';
    return '#6B7280';
  }

  /**
   * جلب الحساب المرتبط بالحركة
   * @returns {Promise<Account>}
   */
  async getAccount() {
    return this.collections.get('accounts').find(this.accountId);
  }

  /**
   * جلب القيد اليومي المرتبط (إن وجد)
   * @returns {Promise<JournalEntry|null>}
   */
  async getJournalEntry() {
    if (!this.journalEntryId) return null;
    return this.collections.get('journal_entries').find(this.journalEntryId);
  }

  /**
   * جلب الفاتورة المرتبطة (إن وجدت)
   * @returns {Promise<Invoice|null>}
   */
  async getInvoice() {
    if (!this.invoiceId) return null;
    return this.collections.get('invoices').find(this.invoiceId);
  }

  /**
   * الحصول على اسم الحساب
   * @returns {Promise<string>}
   */
  async getAccountName() {
    const account = await this.getAccount();
    return account ? account.name : 'حساب غير معروف';
  }

  /**
   * الحصول على رقم الحساب
   * @returns {Promise<string>}
   */
  async getAccountCode() {
    const account = await this.getAccount();
    return account ? account.code : '???';
  }

  /**
   * الحصول على اسم الحساب مع الرقم
   * @returns {Promise<string>}
   */
  async getAccountDisplayName() {
    const account = await this.getAccount();
    return account ? `${account.code} - ${account.name}` : '??? - غير معروف';
  }

  // ===== 6. تجميع الحركات =====

  /**
   * حساب إجمالي المدين لجميع الحركات في مجموعة
   * @param {AccountMovement[]} movements
   * @returns {number}
   */
  static sumDebit(movements) {
    return movements.reduce((sum, m) => sum + (m.debit || 0), 0);
  }

  /**
   * حساب إجمالي الدائن لجميع الحركات في مجموعة
   * @param {AccountMovement[]} movements
   * @returns {number}
   */
  static sumCredit(movements) {
    return movements.reduce((sum, m) => sum + (m.credit || 0), 0);
  }

  /**
   * حساب صافي الرصيد لجميع الحركات في مجموعة
   * @param {AccountMovement[]} movements
   * @returns {number}
   */
  static sumBalance(movements) {
    return movements.reduce((sum, m) => sum + ((m.debit || 0) - (m.credit || 0)), 0);
  }

  /**
   * حساب عدد الحركات في مجموعة
   * @param {AccountMovement[]} movements
   * @returns {number}
   */
  static countMovements(movements) {
    return movements.length;
  }

  /**
   * الحصول على أول حركة في مجموعة (الأقدم)
   * @param {AccountMovement[]} movements
   * @returns {AccountMovement|null}
   */
  static getFirst(movements) {
    if (movements.length === 0) return null;
    return movements.reduce((a, b) => (a.date < b.date ? a : b));
  }

  /**
   * الحصول على آخر حركة في مجموعة (الأحدث)
   * @param {AccountMovement[]} movements
   * @returns {AccountMovement|null}
   */
  static getLast(movements) {
    if (movements.length === 0) return null;
    return movements.reduce((a, b) => (a.date > b.date ? a : b));
  }

  /**
   * الحصول على تاريخ أول حركة
   * @param {AccountMovement[]} movements
   * @returns {number|null}
   */
  static getFirstDate(movements) {
    const first = this.getFirst(movements);
    return first ? first.date : null;
  }

  /**
   * الحصول على تاريخ آخر حركة
   * @param {AccountMovement[]} movements
   * @returns {number|null}
   */
  static getLastDate(movements) {
    const last = this.getLast(movements);
    return last ? last.date : null;
  }

  /**
   * تجميع الحركات حسب الشهر
   * @param {AccountMovement[]} movements
   * @returns {Object}
   */
  static groupByMonth(movements) {
    const groups = {};
    for (const movement of movements) {
      const date = new Date(movement.date);
      const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      if (!groups[key]) {
        groups[key] = [];
      }
      groups[key].push(movement);
    }
    return groups;
  }

  /**
   * تجميع الحركات حسب السنة
   * @param {AccountMovement[]} movements
   * @returns {Object}
   */
  static groupByYear(movements) {
    const groups = {};
    for (const movement of movements) {
      const year = new Date(movement.date).getFullYear();
      if (!groups[year]) {
        groups[year] = [];
      }
      groups[year].push(movement);
    }
    return groups;
  }
}