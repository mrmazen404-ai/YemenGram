import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';

export default function SubscriptionStatusCard({
  status = 'نشط',
  plan = 'Starter',
  statusColor = '#0f766e',
  onManagePress,
  onExtendPress,
  onRenewPress,
  onCancelPress,
}) {
  return (
    <View style={styles.card}>
      <Text style={styles.label}>حالة الاشتراك</Text>
      <Text style={[styles.status, { color: statusColor }]}>{status}</Text>
      <Text style={styles.plan}>{plan}</Text>

      <View style={styles.actionRow}>
        <TouchableOpacity style={styles.secondaryButton} onPress={onExtendPress}>
          <Text style={styles.secondaryText}>تمديد</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.secondaryButton} onPress={onRenewPress}>
          <Text style={styles.secondaryText}>تجديد</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.dangerButton} onPress={onCancelPress}>
          <Text style={styles.dangerText}>إلغاء</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.button} onPress={onManagePress}>
        <Text style={styles.buttonText}>إدارة الاشتراك</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 18,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  label: {
    color: '#6b7280',
    fontSize: 12,
    marginBottom: 8,
  },
  status: {
    fontSize: 28,
    fontWeight: '800',
    marginBottom: 6,
  },
  plan: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 14,
  },
  actionRow: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 12,
  },
  secondaryButton: {
    flex: 1,
    backgroundColor: '#f3f4f6',
    borderRadius: 10,
    paddingVertical: 10,
    alignItems: 'center',
  },
  secondaryText: {
    color: '#111827',
    fontWeight: '700',
  },
  dangerButton: {
    flex: 1,
    backgroundColor: '#fff1f2',
    borderRadius: 10,
    paddingVertical: 10,
    alignItems: 'center',
  },
  dangerText: {
    color: '#be123c',
    fontWeight: '700',
  },
  button: {
    backgroundColor: '#111827',
    borderRadius: 10,
    paddingVertical: 10,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontWeight: '700',
  },
});
