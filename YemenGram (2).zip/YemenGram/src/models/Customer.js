// src/models/Customer.js
// =============================================
// نموذج العميل (Customer Model)
// المسؤول عن إدارة بيانات العملاء وعلاقاتهم المالية
// =============================================

import { Model } from '@nozbe/watermelondb';
import { field, date, readonly, relation } from '@nozbe/watermelondb/decorators';
import { Q } from '@nozbe/watermelondb';

export default class Customer extends Model {
  // ===== 1. اسم الجدول =====
  static table = 'customers';

  // ===== 2. الحقول الأساسية =====

  // معرف المستخدم (لفصل البيانات)
  @field('user_id') userId;

  // رمز العميل الفريد (CUST-0001)
  @field('code') code;

  // اسم العميل
  @field('name') name;

  // نوع العميل (individual, company)
  @field('type') type;

  // ===== 3. معلومات الاتصال =====

  @field('phone') phone;
  @field('email') email;
  @field('address') address;
  @field('tax_number') taxNumber;

  // ===== 4. المعلومات المالية =====

  @field('credit_limit') creditLimit;      // السقف الائتماني
  @field('balance') balance;              // الرصيد الحالي
  @field('opening_balance') openingBalance; // الرصيد الافتتاحي
  @field('currency') currency;            // العملة
  @field('default_discount') defaultDiscount; // الخصم الافتراضي
  @field('payment_terms') paymentTerms;   // مدة السداد (أيام)

  // ===== 5. المفاتيح الخارجية =====

  @field('account_id') accountId;         // الحساب المحاسبي
  @field('tier_id') tierId;               // مستوى العميل

  // ===== 6. معلومات إضافية =====

  @field('category') category;            // retail, wholesale
  @field('preferred_payment_method') preferredPaymentMethod; // cash, bank, check
  @field('contact_person') contactPerson;
  @field('contact_phone') contactPhone;
  @field('assigned_to') assignedTo;      // المسؤول عن العميل
  @field('source') source;               // مصدر العميل
  @field('tags') tags;                   // علامات (VIP, جديد...)
  @field('last_contact_date') lastContactDate;
  @field('notes') notes;

  // ===== 7. حالة العميل =====

  @field('is_active') isActive;

  // ===== 8. التواريخ التلقائية =====

  @readonly @date('created_at') createdAt;
  @readonly @date('updated_at') updatedAt;

  // ===== 9. العلاقات =====

  static associations = {
    user: { type: 'belongs_to', key: 'user_id' },
    tier: { type: 'belongs_to', key: 'tier_id' },
    account: { type: 'belongs_to', key: 'account_id' },
    invoices: { type: 'has_many', foreignKey: 'customer_id' },
    payments: { type: 'has_many', foreignKey: 'customer_id' },
    contacts: { type: 'has_many', foreignKey: 'customer_id' },
    notes: { type: 'has_many', foreignKey: 'customer_id' },
    activities: { type: 'has_many', foreignKey: 'customer_id' },
  };

  // ===== 10. دوال مساعدة =====

  /**
   * الحصول على اسم العميل مع الرمز
   * @returns {string}
   */
  getDisplayName() {
    return `${this.code} - ${this.name}`;
  }

  /**
   * التحقق من نشاط العميل
   * @returns {boolean}
   */
  isActiveCustomer() {
    return this.isActive === 1 || this.isActive === true;
  }

  /**
   * التحقق من تجاوز السقف الائتماني
   * @returns {boolean}
   */
  isOverCreditLimit() {
    return this.creditLimit > 0 && this.balance > this.creditLimit;
  }

  /**
   * حساب نسبة استخدام السقف الائتماني
   * @returns {number}
   */
  getCreditUtilization() {
    if (this.creditLimit <= 0) return 0;
    return Math.min((this.balance / this.creditLimit) * 100, 100);
  }

  /**
   * الحصول على حالة العميل المالية
   * @returns {string} normal, warning, overdue
   */
  getFinancialStatus() {
    if (this.creditLimit <= 0) return 'normal';
    if (this.balance > this.creditLimit) return 'overdue';
    if (this.balance > this.creditLimit * 0.8) return 'warning';
    return 'normal';
  }

  /**
   * الحصول على لون الحالة المالية
   * @returns {string}
   */
  getFinancialStatusColor() {
    const colors = {
      normal: '#27AE60',
      warning: '#F39C12',
      overdue: '#E74C3C',
    };
    return colors[this.getFinancialStatus()] || '#6B7280';
  }

  /**
   * الحصول على تسمية الحالة المالية
   * @returns {string}
   */
  getFinancialStatusLabel() {
    const labels = {
      normal: 'طبيعي',
      warning: 'تحذير',
      overdue: 'متأخر',
    };
    return labels[this.getFinancialStatus()] || this.getFinancialStatus();
  }

  // ===== 11. جلب البيانات المرتبطة =====

  /**
   * جلب حساب العميل المحاسبي
   * @returns {Promise<Account>}
   */
  async getAccount() {
    if (!this.accountId) return null;
    return this.collections.get('accounts').find(this.accountId);
  }

  /**
   * جلب مستوى العميل
   * @returns {Promise<CustomerTier>}
   */
  async getTier() {
    if (!this.tierId) return null;
    return this.collections.get('customer_tiers').find(this.tierId);
  }

  /**
   * جلب فواتير العميل
   * @returns {Promise<Invoice[]>}
   */
  async getInvoices() {
    return this.collections.get('invoices').query(
      Q.where('customer_id', this.id)
    ).fetch();
  }

  /**
   * جلب مدفوعات العميل
   * @returns {Promise<Payment[]>}
   */
  async getPayments() {
    return this.collections.get('payments').query(
      Q.where('customer_id', this.id)
    ).fetch();
  }

  /**
   * جلب جهات اتصال العميل
   * @returns {Promise<CustomerContact[]>}
   */
  async getContacts() {
    return this.collections.get('customer_contacts').query(
      Q.where('customer_id', this.id)
    ).fetch();
  }

  /**
   * جلب ملاحظات العميل
   * @returns {Promise<CustomerNote[]>}
   */
  async getNotes() {
    return this.collections.get('customer_notes').query(
      Q.where('customer_id', this.id)
    ).fetch();
  }

  /**
   * جلب أنشطة العميل
   * @returns {Promise<CustomerActivity[]>}
   */
  async getActivities() {
    return this.collections.get('customer_activities').query(
      Q.where('customer_id', this.id)
    ).fetch();
  }

  // ===== 12. تحديث الرصيد =====

  /**
   * تحديث رصيد العميل
   * @param {number} newBalance
   */
  async updateBalance(newBalance) {
    await this.write(() => {
      this.balance = newBalance;
    });
  }

  /**
   * إضافة مبلغ إلى رصيد العميل
   * @param {number} amount
   */
  async addBalance(amount) {
    await this.write(() => {
      this.balance = (this.balance || 0) + amount;
    });
  }
}