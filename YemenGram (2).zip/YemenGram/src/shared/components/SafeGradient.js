// src/shared/components/SafeGradient.js
// مكوّن التدرج اللوني الآمن (The Sovereign Safe Gradient)
// يضمن عدم انهيار التطبيق على الأندرويد في ظل المعمارية الجديدة

import React from 'react';
import { View, Platform } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors } from '../utils/colors';

const SafeGradient = ({
  colors,
  style,
  start = { x: 0, y: 0 },
  end = { x: 1, y: 1 },
  children,
  ...props
}) => {
  // ✅ حل تقني: في الأندرويد، نستخدم لوناً صلباً (أول لون في المصفوفة)
  // لتجنب خطأ "Received 2 arguments" المزعج في SDK 52
  if (Platform.OS === 'android') {
    const fallbackColor = colors && colors.length > 0 ? colors[0] : Colors.navy;
    return (
      <View style={[{ backgroundColor: fallbackColor }, style]} {...props}>
        {children}
      </View>
    );
  }

  // ✅ في iOS و Web، نستمتع بالتدرجات اللونية الفاخرة
  return (
    <LinearGradient
      colors={colors}
      style={style}
      start={start}
      end={end}
      {...props}
    >
      {children}
    </LinearGradient>
  );
};

export default SafeGradient;
