// src/shared/utils/security.js
// طبقة الأمان المركزية: تشفير مصادق + عشوائية آمنة + تخزين آمن

import * as SecureStore from 'expo-secure-store';
import * as Crypto from 'expo-crypto';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as LocalAuthentication from 'expo-local-authentication';
import { gcm } from '@noble/ciphers/aes';
import { Logger } from './logger';

const STORAGE_KEY_NAME = 'yg_local_encryption_key_v1';
const FORMAT_VERSION = 'v1';
const NONCE_BYTES = 12;
const AES_KEY_BYTES = 32;

const bytesToBase64 = (bytes) => {
  let binary = '';
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary);
};

const base64ToBytes = (value) => {
  const binary = atob(value);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return bytes;
};

const utf8 = (value) => new TextEncoder().encode(String(value));
const text = (bytes) => new TextDecoder().decode(bytes);

export const generateRandomBytes = async (length = 32) => {
  if (!Number.isInteger(length) || length <= 0) throw new Error('Invalid random byte length');
  return Crypto.getRandomBytesAsync(length);
};

export const generateSecureId = async (length = 16) => bytesToBase64(await generateRandomBytes(length))
  .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

export const generateOTP = async () => {
  const bytes = await generateRandomBytes(4);
  const value = ((bytes[0] << 24) | (bytes[1] << 16) | (bytes[2] << 8) | bytes[3]) >>> 0;
  return String(100000 + (value % 900000));
};

export const generateToken = async (length = 32) => generateSecureId(length);

const getOrCreateLocalKey = async () => {
  let encoded = await SecureStore.getItemAsync(STORAGE_KEY_NAME);
  if (!encoded) {
    encoded = bytesToBase64(await generateRandomBytes(AES_KEY_BYTES));
    await SecureStore.setItemAsync(STORAGE_KEY_NAME, encoded, {
      keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY,
    });
  }
  const key = base64ToBytes(encoded);
  if (key.length !== AES_KEY_BYTES) throw new Error('Invalid local encryption key');
  return key;
};

const resolveKey = async (key) => {
  if (!key) return getOrCreateLocalKey();
  if (key instanceof Uint8Array) {
    if (key.length !== AES_KEY_BYTES) throw new Error('AES-256 requires a 32-byte key');
    return key;
  }
  const digest = await Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256, String(key));
  const bytes = new Uint8Array(digest.match(/.{2}/g).map((pair) => parseInt(pair, 16)));
  return bytes;
};

/** AES-256-GCM. The output contains version, nonce, and authenticated ciphertext. */
export const encryptData = async (value, key = null, associatedData = 'yemengram') => {
  if (value === null || value === undefined) return '';
  const aesKey = await resolveKey(key);
  const nonce = await generateRandomBytes(NONCE_BYTES);
  const cipher = gcm(aesKey, nonce, utf8(associatedData));
  const ciphertext = cipher.encrypt(utf8(value));
  return [FORMAT_VERSION, bytesToBase64(nonce), bytesToBase64(ciphertext)].join('.');
};

export const decryptData = async (payload, key = null, associatedData = 'yemengram') => {
  if (!payload) return '';
  const [version, noncePart, ciphertextPart] = String(payload).split('.');
  if (version !== FORMAT_VERSION || !noncePart || !ciphertextPart) {
    throw new Error('Unsupported or malformed encrypted payload');
  }
  const aesKey = await resolveKey(key);
  const cipher = gcm(aesKey, base64ToBytes(noncePart), utf8(associatedData));
  return text(cipher.decrypt(base64ToBytes(ciphertextPart)));
};

export const secureStorage = {
  setItem: async (key, value) => {
    try {
      await SecureStore.setItemAsync(key, await encryptData(value), {
        keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY,
      });
      return true;
    } catch (error) {
      Logger.error('SecureStorage setItem failed');
      return false;
    }
  },
  getItem: async (key) => {
    try {
      const payload = await SecureStore.getItemAsync(key);
      return payload ? await decryptData(payload) : null;
    } catch (error) {
      Logger.error('SecureStorage getItem failed');
      return null;
    }
  },
  deleteItem: async (key) => {
    try { await SecureStore.deleteItemAsync(key); return true; }
    catch { return false; }
  },
};

export const cacheStorage = {
  setItem: async (key, value, ttl = 3600000) => {
    await AsyncStorage.setItem(key, JSON.stringify({ value, expiresAt: Date.now() + ttl }));
    return true;
  },
  getItem: async (key) => {
    const raw = await AsyncStorage.getItem(key);
    if (!raw) return null;
    const data = JSON.parse(raw);
    if (Date.now() > data.expiresAt) { await AsyncStorage.removeItem(key); return null; }
    return data.value;
  },
  removeItem: (key) => AsyncStorage.removeItem(key),
  clear: () => AsyncStorage.clear(),
};

export const SecurityManager = {
  getSecurityLevel: async () => {
    try {
      const { AuthenticationType } = LocalAuthentication;
      const types = await LocalAuthentication.supportedAuthenticationTypesAsync();
      if (types.includes(AuthenticationType.FACIAL_RECOGNITION) || types.includes(AuthenticationType.FINGERPRINT)) return 'high';
      if (types.length > 0) return 'medium';
      return 'low';
    } catch { return 'low'; }
  },
  logSecurityEvent: async (event) => Logger.info(`Security event: ${event}`),
};

export default {
  generateRandomBytes, generateSecureId, generateOTP, generateToken,
  encryptData, decryptData, secureStorage, cacheStorage, SecurityManager,
};
