// src/models/CustomerTier.js
// =============================================
// نموذج مستوى العميل (Customer Tier Model)
// المسؤول عن تعريف مستويات العملاء وتصنيفهم
// =============================================

import { Model } from '@nozbe/watermelondb';
import { field, date, readonly } from '@nozbe/watermelondb/decorators';

export default class CustomerTier extends Model {
  // ===== 1. اسم الجدول في قاعدة البيانات =====
  static table = 'customer_tiers';

  // ===== 2. تعريف الحقول (Columns) =====

  // اسم المستوى (مثال: أساسي، فضي، ذهبي، مؤسسة)
  @field('name') name;

  // رقم المستوى (1, 2, 3, 4) للترتيب
  @field('level') level;

  // وصف المستوى (اختياري)
  @field('description') description;

  // حالة التفعيل (0 = غير مفعل، 1 = مفعل)
  @field('is_active') isActive;

  // ===== 3. التواريخ التلقائية =====

  @readonly @date('created_at') createdAt;
  @readonly @date('updated_at') updatedAt;

  // ===== 4. العلاقات =====

  static associations = {
    // مستوى واحد → لديه عدة عملاء
    customers: { type: 'has_many', foreignKey: 'tier_id' },
  };

  // ===== 5. دوال مساعدة (Helper Methods) =====

  /**
   * الحصول على اللون المرتبط بالمستوى
   * @returns {string} - كود اللون
   */
  getColor() {
    const colors = {
      'tier_basic': '#27AE60',
      'tier_standard': '#607D8B',
      'tier_advanced': '#D4A853',
      'tier_enterprise': '#1B365D',
    };
    return colors[this.id] || '#6B7280';
  }

  /**
   * الحصول على اسم المستوى باللغة العربية
   * @returns {string}
   */
  getArabicName() {
    const names = {
      'tier_basic': 'أساسي',
      'tier_standard': 'فضي',
      'tier_advanced': 'ذهبي',
      'tier_enterprise': 'مؤسسة',
    };
    return names[this.id] || this.name;
  }

  /**
   * التحقق من نشاط المستوى
   * @returns {boolean}
   */
  isActive() {
    return this.isActive === 1 || this.isActive === true;
  }

  /**
   * جلب جميع العملاء الذين ينتمون لهذا المستوى
   * @returns {Promise<Customer[]>}
   */
  async getCustomers() {
    return this.collections.get('customers').query(
      Q.where('tier_id', this.id)
    ).fetch();
  }

  /**
   * الحصول على عدد العملاء في هذا المستوى
   * @returns {Promise<number>}
   */
  async getCustomerCount() {
    const customers = await this.getCustomers();
    return customers.length;
  }
}