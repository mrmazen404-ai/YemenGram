// src/models/CashAccount.js
// =============================================
// نموذج الحساب النقدي والبنكي (Cash Account Model)
// المسؤول عن إدارة الصناديق والحسابات البنكية
// =============================================

import { Model } from '@nozbe/watermelondb';
import { field, date, readonly } from '@nozbe/watermelondb/decorators';
import { Q } from '@nozbe/watermelondb';

export default class CashAccount extends Model {
  // ===== 1. اسم الجدول =====
  static table = 'cash_accounts';

  // ===== 2. الحقول الأساسية =====

  // معرف المستخدم (لفصل البيانات)
  @field('user_id') userId;

  // رمز الحساب (مثل: CASH-001, BANK-001)
  @field('code') code;

  // اسم الحساب (مثل: صندوق النقدية، البنك الأهلي)
  @field('name') name;

  // نوع الحساب (cash, bank)
  @field('type') type;

  // ===== 3. المفاتيح الخارجية =====

  // الحساب المحاسبي المرتبط (الأصول النقدية)
  @field('account_id') accountId;

  // ===== 4. معلومات البنك (للحسابات البنكية) =====

  @field('bank_name') bankName;
  @field('account_number') accountNumber;

  // ===== 5. المعلومات المالية =====

  // الرصيد الحالي
  @field('balance') balance;

  // العملة
  @field('currency') currency;

  // ===== 6. الحالة =====

  @field('is_active') isActive;

  // ===== 7. التواريخ التلقائية =====

  @readonly @date('created_at') createdAt;
  @readonly @date('updated_at') updatedAt;

  // ===== 8. العلاقات =====

  static associations = {
    // كل حساب نقدي ينتمي إلى مستخدم واحد
    user: { type: 'belongs_to', key: 'user_id' },
    // كل حساب نقدي له حساب محاسبي واحد
    account: { type: 'belongs_to', key: 'account_id' },
    // حساب نقدي واحد → لديه عدة مدفوعات
    payments: { type: 'has_many', foreignKey: 'cash_account_id' },
    // حساب نقدي واحد → لديه عدة تحويلات كمرسل
    outgoingTransfers: { type: 'has_many', foreignKey: 'from_account_id' },
    // حساب نقدي واحد → لديه عدة تحويلات كمرسل إليه
    incomingTransfers: { type: 'has_many', foreignKey: 'to_account_id' },
    // حساب نقدي واحد → لديه عدة شيكات
    checks: { type: 'has_many', foreignKey: 'cash_account_id' },
  };

  // ===== 9. دوال مساعدة =====

  /**
   * الحصول على نوع الحساب باللغة العربية
   * @returns {string}
   */
  getTypeArabic() {
    const types = {
      cash: 'صندوق نقدي',
      bank: 'حساب بنكي',
    };
    return types[this.type] || this.type;
  }

  /**
   * الحصول على أيقونة الحساب
   * @returns {string}
   */
  getTypeIcon() {
    const icons = {
      cash: 'cash',
      bank: 'business',
    };
    return icons[this.type] || 'wallet';
  }

  /**
   * الحصول على لون الحساب
   * @returns {string}
   */
  getTypeColor() {
    const colors = {
      cash: '#27AE60',
      bank: '#2196F3',
    };
    return colors[this.type] || '#6B7280';
  }

  /**
   * التحقق من نشاط الحساب
   * @returns {boolean}
   */
  isActiveAccount() {
    return this.isActive === 1 || this.isActive === true;
  }

  /**
   * التحقق من أن الحساب صندوق نقدي
   * @returns {boolean}
   */
  isCash() {
    return this.type === 'cash';
  }

  /**
   * التحقق من أن الحساب بنكي
   * @returns {boolean}
   */
  isBank() {
    return this.type === 'bank';
  }

  /**
   * الحصول على اسم الحساب المعروض
   * @returns {string}
   */
  getDisplayName() {
    return `${this.code} - ${this.name}`;
  }

  /**
   * الحصول على اسم الحساب مع النوع
   * @returns {string}
   */
  getFullName() {
    return `${this.getTypeArabic()} - ${this.name}`;
  }

  /**
   * جلب الحساب المحاسبي
   * @returns {Promise<Account>}
   */
  async getAccount() {
    if (!this.accountId) return null;
    return this.collections.get('accounts').find(this.accountId);
  }

  /**
   * جلب المدفوعات المرتبطة
   * @returns {Promise<Payment[]>}
   */
  async getPayments() {
    return this.collections.get('payments').query(
      Q.where('cash_account_id', this.id)
    ).fetch();
  }

  /**
   * جلب الشيكات المرتبطة
   * @returns {Promise<Check[]>}
   */
  async getChecks() {
    return this.collections.get('checks').query(
      Q.where('cash_account_id', this.id)
    ).fetch();
  }

  /**
   * جلب التحويلات الصادرة
   * @returns {Promise<Transfer[]>}
   */
  async getOutgoingTransfers() {
    return this.collections.get('transfers').query(
      Q.where('from_account_id', this.id)
    ).fetch();
  }

  /**
   * جلب التحويلات الواردة
   * @returns {Promise<Transfer[]>}
   */
  async getIncomingTransfers() {
    return this.collections.get('transfers').query(
      Q.where('to_account_id', this.id)
    ).fetch();
  }

  /**
   * حساب إجمالي المدفوعات المرتبطة
   * @returns {Promise<number>}
   */
  async getTotalPayments() {
    const payments = await this.getPayments();
    return payments.reduce((sum, p) => sum + (p.amount || 0), 0);
  }

  /**
   * حساب إجمالي التحويلات الصادرة
   * @returns {Promise<number>}
   */
  async getTotalOutgoingTransfers() {
    const transfers = await this.getOutgoingTransfers();
    return transfers.reduce((sum, t) => sum + (t.amount || 0), 0);
  }

  /**
   * حساب إجمالي التحويلات الواردة
   * @returns {Promise<number>}
   */
  async getTotalIncomingTransfers() {
    const transfers = await this.getIncomingTransfers();
    return transfers.reduce((sum, t) => sum + (t.amount || 0), 0);
  }

  /**
   * حساب الرصيد الفعلي (من الحركات)
   * @returns {Promise<number>}
   */
  async calculateActualBalance() {
    const payments = await this.getPayments();
    const outgoing = await this.getOutgoingTransfers();
    const incoming = await this.getIncomingTransfers();

    // بدءاً من الرصيد الافتتاحي (يمكن تخزينه في مكان آخر)
    let balance = this.balance || 0;

    // حساب المدفوعات
    for (const payment of payments) {
      // المدفوعات تقلل الرصيد
      balance -= payment.amount || 0;
    }

    // حساب التحويلات
    for (const transfer of outgoing) {
      balance -= transfer.amount || 0;
    }
    for (const transfer of incoming) {
      balance += transfer.amount || 0;
    }

    return balance;
  }

  /**
   * تحديث رصيد الحساب
   * @param {number} newBalance
   */
  async updateBalance(newBalance) {
    await this.write(() => {
      this.balance = newBalance;
    });
  }

  /**
   * إضافة مبلغ إلى الرصيد
   * @param {number} amount
   */
  async addBalance(amount) {
    await this.write(() => {
      this.balance = (this.balance || 0) + amount;
    });
  }

  /**
   * خصم مبلغ من الرصيد
   * @param {number} amount
   */
  async deductBalance(amount) {
    await this.write(() => {
      this.balance = (this.balance || 0) - amount;
    });
  }

  // ===== 10. دوال ثابتة =====

  /**
   * حساب إجمالي أرصدة مجموعة حسابات
   * @param {CashAccount[]} accounts
   * @returns {number}
   */
  static sumBalance(accounts) {
    return accounts.reduce((sum, a) => sum + (a.balance || 0), 0);
  }

  /**
   * حساب إجمالي أرصدة الحسابات النقدية
   * @param {CashAccount[]} accounts
   * @returns {number}
   */
  static sumCashBalance(accounts) {
    return accounts
      .filter(a => a.type === 'cash')
      .reduce((sum, a) => sum + (a.balance || 0), 0);
  }

  /**
   * حساب إجمالي أرصدة الحسابات البنكية
   * @param {CashAccount[]} accounts
   * @returns {number}
   */
  static sumBankBalance(accounts) {
    return accounts
      .filter(a => a.type === 'bank')
      .reduce((sum, a) => sum + (a.balance || 0), 0);
  }

  /**
   * تجميع الحسابات حسب النوع
   * @param {CashAccount[]} accounts
   * @returns {Object}
   */
  static groupByType(accounts) {
    const groups = {};
    for (const account of accounts) {
      if (!groups[account.type]) {
        groups[account.type] = [];
      }
      groups[account.type].push(account);
    }
    return groups;
  }

  /**
   * الحصول على الحسابات النشطة فقط
   * @param {CashAccount[]} accounts
   * @returns {CashAccount[]}
   */
  static getActiveAccounts(accounts) {
    return accounts.filter(a => a.isActiveAccount());
  }
}