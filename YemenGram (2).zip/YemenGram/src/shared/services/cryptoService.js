// src/shared/services/cryptoService.js
// خدمة التشفير المركزية: تشفير مصادق وverifier بطيء لكلمات المرور المحلية

import * as Crypto from 'expo-crypto';
import { pbkdf2 } from '@noble/hashes/pbkdf2';
import { sha256 } from '@noble/hashes/sha2';
import { encryptData, decryptData, generateRandomBytes } from '../utils/security';

const encoder = new TextEncoder();
const bytesToHex = (bytes) => Array.from(bytes).map((b) => b.toString(16).padStart(2, '0')).join('');
const hexToBytes = (hex) => new Uint8Array(hex.match(/.{2}/g).map((pair) => parseInt(pair, 16)));

export const CryptoService = {
  async derivePasswordVerifier(password, saltHex = null) {
    const salt = saltHex ? hexToBytes(saltHex) : await generateRandomBytes(16);
    const derived = pbkdf2(sha256, encoder.encode(password), salt, { c: 210000, dkLen: 32 });
    return `pbkdf2-sha256$210000$${bytesToHex(salt)}$${bytesToHex(derived)}`;
  },

  async verifyPassword(password, storedVerifier) {
    if (!storedVerifier || !storedVerifier.startsWith('pbkdf2-sha256$')) return false;
    const [, iterations, saltHex, expectedHex] = storedVerifier.split('$');
    if (!iterations || !saltHex || !expectedHex) return false;
    const actual = pbkdf2(sha256, encoder.encode(password), hexToBytes(saltHex), {
      c: Number(iterations), dkLen: expectedHex.length / 2,
    });
    return bytesToHex(actual) === expectedHex;
  },

  async hashIdentifier(value) {
    return Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256, String(value));
  },

  async generateKey() {
    return bytesToHex(await generateRandomBytes(32));
  },

  encryptData,
  decryptData,
};

export default CryptoService;
