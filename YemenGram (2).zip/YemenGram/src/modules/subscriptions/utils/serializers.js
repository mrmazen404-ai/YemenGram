/**
 * محول البيانات المالي (Subscription Serializers)
 * تحويل سجلات قاعدة البيانات إلى كائنات جاهزة للـ UI والفواتير
 */

export const serializeSubscription = (record) => {
  if (!record) return null;

  return {
    id: record.id,
    userId: record.userId,
    status: record.status,
    plan: record.plan,
    startDate: record.startDate,
    endDate: record.endDate,
    amount: record.total || record.price || 0,
    currency: record.currency || 'YER',
    maxDevices: record.maxDevices,
    maxCustomers: record.maxCustomers,
    maxInvoices: record.maxInvoices,
    // بيانات إضافية محسوبة
    isExpired: record.endDate < Date.now(),
    isTrial: record.plan === 'trial',
    isActive: ['ACTIVE_FULL', 'TRIAL_ACTIVE'].includes(record.status),
  };
};

/**
 * تحويل السجل لبيانات فاتورة PDF
 */
export const toInvoiceData = (sub, user) => {
  return {
    invoiceNumber: `YG-SUB-${sub.id.slice(-6).toUpperCase()}`,
    date: new Date(sub.startDate).toLocaleDateString('ar-EG'),
    customerName: user.name,
    company: user.company_name,
    planLabel: sub.plan.toUpperCase(),
    totalAmount: sub.amount,
  };
};

export default { serializeSubscription, toInvoiceData };
