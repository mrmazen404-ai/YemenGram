// src/models/Session.js
// =============================================
// نموذج الجلسة (Session Model)
// المسؤول عن إدارة جلسات المستخدم وتخزين التوكنات
// =============================================

import { Model } from '@nozbe/watermelondb';
import { field, date, readonly } from '@nozbe/watermelondb/decorators';

export default class Session extends Model {
  // ===== 1. اسم الجدول في قاعدة البيانات =====
  static table = 'sessions';

  // ===== 2. تعريف الحقول (Columns) =====

  // معرف المستخدم المرتبط بهذه الجلسة
  @field('user_id') userId;

  // توكن المصادقة الرئيسي (Access Token)
  @field('token') token;

  // توكن التحديث (Refresh Token) لتجديد الجلسة
  @field('refresh_token') refreshToken;

  // تاريخ انتهاء صلاحية التوكن (timestamp)
  @field('expires_at') expiresAt;

  // ===== 3. التواريخ التلقائية =====

  // تاريخ إنشاء الجلسة
  @readonly @date('created_at') createdAt;

  // ===== 4. العلاقات =====

  static associations = {
    // كل جلسة تنتمي إلى مستخدم واحد
    user: { type: 'belongs_to', key: 'user_id' },
  };

  // ===== 5. دوال مساعدة (Helper Methods) =====

  /**
   * التحقق من صلاحية الجلسة (لم تنتهي بعد)
   * @returns {boolean}
   */
  isValid() {
    if (!this.expiresAt) return false;
    return Date.now() < this.expiresAt;
  }

  /**
   * التحقق من أن الجلسة منتهية الصلاحية
   * @returns {boolean}
   */
  isExpired() {
    return !this.isValid();
  }

  /**
   * الحصول على الوقت المتبقي للجلسة بالثواني
   * @returns {number}
   */
  getRemainingSeconds() {
    if (!this.expiresAt) return 0;
    const remaining = Math.floor((this.expiresAt - Date.now()) / 1000);
    return Math.max(0, remaining);
  }

  /**
   * الحصول على الوقت المتبقي للجلسة بتنسيق مقروء
   * @returns {string}
   */
  getRemainingTime() {
    const seconds = this.getRemainingSeconds();
    if (seconds === 0) return 'منتهية';

    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;

    if (hours > 0) {
      return `${hours} ساعة و ${minutes} دقيقة`;
    }
    if (minutes > 0) {
      return `${minutes} دقيقة و ${secs} ثانية`;
    }
    return `${secs} ثانية`;
  }

  /**
   * جلب المستخدم المرتبط بهذه الجلسة
   * @returns {Promise<User>}
   */
  async getUser() {
    return this.collections.get('users').find(this.userId);
  }
}