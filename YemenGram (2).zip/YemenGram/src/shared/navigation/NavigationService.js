// src/shared/navigation/NavigationService.js
// =============================================
// خدمة التنقل (Navigation Service)
// للتنقل من أي مكان في التطبيق دون الحاجة إلى useNavigation
// =============================================

import { createNavigationContainerRef, CommonActions, StackActions } from '@react-navigation/native';

// =============================================
// 1. إنشاء المرجع
// =============================================

export const navigationRef = createNavigationContainerRef();

// =============================================
// 2. دوال التنقل الأساسية
// =============================================

/**
 * التنقل إلى شاشة معينة
 * @param {string} name - اسم الشاشة
 * @param {Object} params - المعاملات
 */
export const navigate = (name, params) => {
  if (navigationRef.isReady()) {
    navigationRef.navigate(name, params);
  } else {
    console.warn('⚠️ [NavigationService] التنقل غير جاهز بعد');
  }
};

/**
 * العودة إلى الشاشة السابقة
 */
export const goBack = () => {
  if (navigationRef.isReady()) {
    navigationRef.goBack();
  } else {
    console.warn('⚠️ [NavigationService] التنقل غير جاهز بعد');
  }
};

/**
 * إعادة تعيين التنقل (حذف المكدس)
 * @param {Array} routes - قائمة الشاشات الجديدة
 * @param {number} index - الفهرس الافتراضي
 */
export const reset = (routes, index = 0) => {
  if (navigationRef.isReady()) {
    navigationRef.dispatch(
      CommonActions.reset({
        index,
        routes,
      })
    );
  } else {
    console.warn('⚠️ [NavigationService] التنقل غير جاهز بعد');
  }
};

/**
 * استبدال الشاشة الحالية بأخرى
 * @param {string} name - اسم الشاشة
 * @param {Object} params - المعاملات
 */
export const replace = (name, params) => {
  if (navigationRef.isReady()) {
    navigationRef.dispatch(StackActions.replace(name, params));
  } else {
    console.warn('⚠️ [NavigationService] التنقل غير جاهز بعد');
  }
};

/**
 * إضافة شاشة إلى المكدس (Push)
 * @param {string} name - اسم الشاشة
 * @param {Object} params - المعاملات
 */
export const push = (name, params) => {
  if (navigationRef.isReady()) {
    navigationRef.dispatch(StackActions.push(name, params));
  } else {
    console.warn('⚠️ [NavigationService] التنقل غير جاهز بعد');
  }
};

/**
 * العودة إلى الشاشة الأولى في المكدس (Pop to top)
 */
export const popToTop = () => {
  if (navigationRef.isReady()) {
    navigationRef.dispatch(StackActions.popToTop());
  } else {
    console.warn('⚠️ [NavigationService] التنقل غير جاهز بعد');
  }
};

// =============================================
// 3. دوال الحصول على معلومات التنقل
// =============================================

/**
 * الحصول على اسم الشاشة الحالية
 * @returns {string|null}
 */
export const getCurrentRoute = () => {
  if (navigationRef.isReady()) {
    return navigationRef.getCurrentRoute()?.name || null;
  }
  return null;
};

/**
 * الحصول على معاملات الشاشة الحالية
 * @returns {Object|null}
 */
export const getCurrentParams = () => {
  if (navigationRef.isReady()) {
    return navigationRef.getCurrentRoute()?.params || null;
  }
  return null;
};

/**
 * الحصول على اسم الشاشة الحالية مع المعاملات
 * @returns {Object|null}
 */
export const getCurrentRouteName = () => {
  return getCurrentRoute();
};

/**
 * التحقق من جاهزية التنقل
 * @returns {boolean}
 */
export const isReady = () => {
  return navigationRef.isReady();
};

// =============================================
// 4. دوال التنقل السريع (للاستخدام المتكرر)
// =============================================

/**
 * التنقل إلى Dashboard
 */
export const goToDashboard = () => {
  navigate('Dashboard');
};

/**
 * التنقل إلى Login
 */
export const goToLogin = () => {
  reset([
    { name: 'Auth', params: { screen: 'Login' } },
  ]);
};

/**
 * التنقل إلى Register
 */
export const goToRegister = () => {
  navigate('Register');
};

/**
 * التنقل إلى Home بعد تسجيل الدخول
 */
export const goToHome = () => {
  reset([
    { name: 'Dashboard' },
  ], 0);
};

// =============================================
// 5. كائن الخدمة الرئيسي
// =============================================

export const NavigationService = {
  // الأساسية
  navigate,
  goBack,
  reset,
  replace,
  push,
  popToTop,

  // المعلومات
  getCurrentRoute,
  getCurrentParams,
  getCurrentRouteName,
  isReady,

  // السريعة
  goToDashboard,
  goToLogin,
  goToRegister,
  goToHome,
};

export default NavigationService;