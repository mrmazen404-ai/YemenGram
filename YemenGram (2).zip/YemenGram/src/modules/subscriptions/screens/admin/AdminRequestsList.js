import React from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  ActivityIndicator,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import LocalDB from '../../../database/localDB';
import SupabaseService from '../../../../services/supabaseClient';

const STATUS_LABELS = {
  VERIFICATION_PENDING: 'مراجعة الإيصال',
  REFUND_PENDING: 'طلب استرداد',
  EXTENSION_PENDING: 'طلب تمديد',
  ACTIVE: 'نشط',
};

export default function AdminRequestsList() {
  const navigation = useNavigation();
  const [requests, setRequests] = React.useState([]);
  const [loading, setLoading] = React.useState(true);

  const loadRequests = React.useCallback(async () => {
    try {
      setLoading(true);

      const rows = await LocalDB.query(
        `SELECT s.id, s.user_id, s.status, s.plan, s.total, s.price, s.payment_proof,
                s.verification_requested_at, s.created_at,
                u.name AS user_name, u.email AS user_email, u.phone AS user_phone
         FROM subscriptions s
         LEFT JOIN user u ON u.id = s.user_id
         WHERE s.status = 'VERIFICATION_PENDING'
         ORDER BY s.created_at DESC
         LIMIT 50`
      );

      const mapped = (rows || []).map((row) => ({
        id: row.id,
        userId: row.user_id,
        userName: row.user_name || 'مستخدم',
        email: row.user_email || '',
        phone: row.user_phone || '',
        plan: row.plan || 'starter',
        status: row.status || 'VERIFICATION_PENDING',
        amount: row.total || row.price || 0,
        submittedAt: new Date(row.verification_requested_at || row.created_at || Date.now()).toLocaleString('ar-EG'),
        receiptUrl: row.payment_proof || null,
      }));

      if (mapped.length > 0) {
        setRequests(mapped);
        return;
      }

      const { data, error } = await SupabaseService.supabase
        .from('subscriptions')
        .select('*')
        .eq('status', 'VERIFICATION_PENDING')
        .order('created_at', { ascending: false })
        .limit(50);

      if (!error && data) {
        const supaMapped = data.map((row) => ({
          id: row.id,
          userId: row.user_id,
          userName: row.user_id || 'مستخدم',
          email: '',
          phone: '',
          plan: row.plan || 'starter',
          status: row.status || 'VERIFICATION_PENDING',
          amount: row.total || row.price || 0,
          submittedAt: new Date(row.created_at || Date.now()).toLocaleString('ar-EG'),
          receiptUrl: row.payment_proof || null,
        }));
        setRequests(supaMapped);
      } else {
        setRequests([]);
      }
    } catch (error) {
      console.log('❌ [AdminRequestsList] failed to load subscription requests:', error?.message || error);
      setRequests([]);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    loadRequests();
  }, [loadRequests]);

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={styles.card}
      activeOpacity={0.8}
      onPress={() => navigation.navigate('AdminSubscriptionRequestDetail', { request: item })}
    >
      <View style={styles.headerRow}>
        <Text style={styles.userName}>{item.userName}</Text>
        <Text style={styles.status}>{STATUS_LABELS[item.status] || item.status}</Text>
      </View>

      <Text style={styles.plan}>الخطة: {item.plan}</Text>
      <Text style={styles.amount}>المبلغ: {Number(item.amount || 0).toFixed(0)} ر.س</Text>
      <Text style={styles.meta}>تاريخ التقديم: {item.submittedAt}</Text>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>مراجعة طلبات الاشتراك</Text>
      </View>

      {loading ? (
        <View style={styles.loadingWrap}>
          <ActivityIndicator size="small" color="#111827" />
          <Text style={styles.loadingText}>جاري تحميل الطلبات...</Text>
        </View>
      ) : (
        <FlatList
          data={requests}
          keyExtractor={(item) => String(item.id)}
          contentContainerStyle={styles.list}
          renderItem={renderItem}
          ListEmptyComponent={
            <View style={styles.emptyState}>
              <Text style={styles.emptyText}>لا توجد طلبات بانتظار المراجعة</Text>
            </View>
          }
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f3f4f6',
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 18,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
  },
  title: {
    fontSize: 24,
    fontWeight: '800',
    color: '#111827',
  },
  list: {
    padding: 16,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 2,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  userName: {
    fontSize: 18,
    fontWeight: '700',
    color: '#111827',
  },
  status: {
    fontSize: 12,
    fontWeight: '700',
    color: '#b45309',
    backgroundColor: '#fef3c7',
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  plan: {
    fontSize: 14,
    color: '#374151',
    marginBottom: 4,
  },
  amount: {
    fontSize: 14,
    color: '#0f766e',
    marginBottom: 4,
    fontWeight: '600',
  },
  meta: {
    fontSize: 12,
    color: '#6b7280',
  },
});
