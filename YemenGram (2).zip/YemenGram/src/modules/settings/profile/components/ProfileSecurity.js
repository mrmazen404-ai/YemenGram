// src/modules/settings/profile/components/ProfileSecurity.js
// وحدة إدارة ترسانة الأمان (Security Suite Unit)

import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { styles } from '../ProfileStyles';
import { Colors } from '../../../../shared/utils/colors';

export const ProfileSecurity = ({ onAction }) => {
  return (
    <View style={styles.section}>
      <View style={styles.sectionHeader}>
        <Ionicons name="shield-checkmark-outline" size={20} color={Colors.navy} />
        <Text style={styles.sectionTitle}>ترسانة الأمان</Text>
      </View>

      <View style={styles.card}>
        {/* تغيير كلمة المرور */}
        <TouchableOpacity
          style={[styles.infoItem, { borderBottomWidth: 0 }]}
          onPress={() => onAction?.('change_password')}
        >
          <Text style={styles.infoLabel}>تغيير كلمة المرور</Text>
          <Ionicons name="chevron-back" size={18} color={Colors.border} />
        </TouchableOpacity>
      </View>
    </View>
  );
};
