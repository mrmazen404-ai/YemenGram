// src/modules/settings/screens/PinSettingsScreen.js
// شاشة إعدادات الأمان المتقدمة (نسخة فائقة الاستقرار ومحمية بـ SafeGradient)

import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Alert,
  StatusBar,
  Platform
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as LocalAuthentication from 'expo-local-authentication';
import * as Haptics from 'expo-haptics';
import { Colors } from '../../../shared/utils/colors';
import { useAuth } from '../../../shared/contexts/AuthContext';
import Toast from '../../../shared/components/Toast';
import SafeGradient from '../../../shared/components/SafeGradient';
import PinSetupDialog from '../../auth/screens/PIN/PinSetupDialog';
import PinChangeDialog from '../../auth/screens/PIN/PinChangeDialog';
import PinLoginDialog from '../../auth/screens/PIN/PinLoginDialog';
import { LocalDB } from '../../../shared/services/storageService';

export default function PinSettingsScreen({ navigation }) {
  const { isPINSet, enableBiometric, disableBiometric, disablePIN } = useAuth();

  const [pinOn, setPinOn] = useState(false);
  const [bioOn, setBioOn] = useState(false);
  const [lockTime, setLockTime] = useState('5');
  const [showSetup, setShowSetup] = useState(false);
  const [showChange, setShowChange] = useState(false);
  const [hasBio, setHasBio] = useState(false);
  const [biometricType, setBiometricType] = useState('البصمة');
  const [toast, setToast] = useState({ visible: false, message: '', type: 'error' });
  const [showReAuth, setShowReAuth] = useState(false);
  const [reAuthCallback, setReAuthCallback] = useState(null);

  useEffect(() => {
    refreshAllStates();
  }, []);

  const refreshAllStates = async () => {
    try {
      const pinActive = await isPINSet();
      setPinOn(pinActive);
      const hw = await LocalAuthentication.hasHardwareAsync();
      const en = await LocalAuthentication.isEnrolledAsync();
      const types = await LocalAuthentication.supportedAuthenticationTypesAsync();
      if (types.includes(LocalAuthentication.AuthenticationType.FACIAL_RECOGNITION)) setBiometricType('Face ID');
      setHasBio(hw && en);
      const bioStatus = await LocalDB.getSetting('biometric_enabled');
      setBioOn(bioStatus === 'true');
      const savedLockTime = await LocalDB.getSetting('pin_lock_time');
      if (savedLockTime) setLockTime(savedLockTime);
    } catch (e) {}
  };

  const triggerHaptic = () => {
    if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  };

  const requestReAuth = async () => {
    return new Promise((resolve) => {
      const tryBiometric = async () => {
        if (bioOn && hasBio) {
          const result = await LocalAuthentication.authenticateAsync({ promptMessage: 'تأكيد الهوية' });
          if (result.success) return resolve(true);
        }
        setShowReAuth(true);
        setReAuthCallback(() => resolve);
      };
      tryBiometric();
    });
  };

  const handlePinToggle = async (value) => {
    triggerHaptic();
    if (value) setShowSetup(true);
    else {
      const authenticated = await requestReAuth();
      if (!authenticated) return;
      Alert.alert('تعطيل الحماية؟', 'هل أنت متأكد؟', [
        { text: 'إلغاء', style: 'cancel' },
        { text: 'تعطيل', style: 'destructive', onPress: async () => {
          await disablePIN();
          setPinOn(false);
          setBioOn(false);
          setToast({ visible: true, message: 'تم تعطيل الحماية', type: 'info' });
        }}
      ]);
    }
  };

  const handleBioToggle = async (value) => {
    triggerHaptic();
    const authenticated = await requestReAuth();
    if (!authenticated) return;
    if (value) {
      if (!pinOn) return setToast({ visible: true, message: 'فعل الـ PIN أولاً', type: 'error' });
      const result = await LocalAuthentication.authenticateAsync({ promptMessage: `تفعيل ${biometricType}` });
      if (result.success) {
        await enableBiometric();
        setBioOn(true);
        setToast({ visible: true, message: 'تم التفعيل بنجاح', type: 'success' });
      }
    } else {
      await disableBiometric();
      setBioOn(false);
    }
  };

  const SecurityCard = ({ icon, label, description, children, color = Colors.navy }) => (
    <View style={styles.card}>
      <View style={styles.cardHeader}>
        <View style={[styles.iconBox, { backgroundColor: color + '15' }]}>
          <Ionicons name={icon} size={22} color={color} />
        </View>
        <View style={styles.headerInfo}>
          <Text style={styles.cardLabel}>{label}</Text>
          <Text style={styles.cardDesc}>{description}</Text>
        </View>
        {children}
      </View>
    </View>
  );

  const handleBack = () => {
    triggerHaptic();
    if (navigation.canGoBack()) {
      navigation.goBack();
    } else {
      navigation.navigate('Settings');
    }
  };

  return (
    <View style={styles.root}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      <Toast visible={toast.visible} message={toast.message} type={toast.type} onHide={() => setToast(p => ({ ...p, visible: false }))} />

      <SafeGradient colors={['#FFFFFF', '#F8FAFC']} style={styles.header}>
        <TouchableOpacity onPress={handleBack} style={styles.backBtn}>
          <Ionicons name="chevron-forward" size={24} color={Colors.dark} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>الأمان والخصوصية</Text>
        <View style={{ width: 45 }} />
      </SafeGradient>

      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View style={styles.sectionHeader}><Text style={styles.sectionTitle}>إعدادات الوصول</Text></View>
        <SecurityCard icon="lock-closed" label="رمز PIN" description="حماية بـ 6 أرقام">
          <Switch value={pinOn} onValueChange={handlePinToggle} trackColor={{ false: '#E2E8F0', true: Colors.navy }} thumbColor="#FFF" />
        </SecurityCard>

        {pinOn && (
          <TouchableOpacity style={styles.subAction} onPress={() => setShowChange(true)}>
            <Ionicons name="create-outline" size={20} color={Colors.navy} />
            <Text style={styles.subActionText}>تغيير رمز PIN</Text>
            <Ionicons name="chevron-back" size={18} color={Colors.placeholder} />
          </TouchableOpacity>
        )}

        {hasBio && (
          <SecurityCard icon={biometricType === 'Face ID' ? "scan" : "finger-print"} label={`تفعيل ${biometricType}`} description={`استخدام ${biometricType} للوصول`} color={Colors.green}>
            <Switch value={bioOn} onValueChange={handleBioToggle} trackColor={{ false: '#E2E8F0', true: Colors.green }} thumbColor="#FFF" />
          </SecurityCard>
        )}

        {pinOn && (
          <>
            <View style={styles.sectionHeader}><Text style={styles.sectionTitle}>القفل التلقائي</Text></View>
            <View style={styles.lockOptionsCard}>
              {[{l:'فوري', v:'0'}, {l:'دقيقة', v:'1'}, {l:'5 دقائق', v:'5'}].map((opt, i) => (
                <TouchableOpacity key={i} style={[styles.lockOption, lockTime === opt.v && styles.lockOptionActive]} onPress={() => { triggerHaptic(); setLockTime(opt.v); LocalDB.saveSetting('pin_lock_time', opt.v); }}>
                  <Text style={[styles.lockOptionLabel, lockTime === opt.v && styles.lockOptionLabelActive]}>{opt.l}</Text>
                  {lockTime === opt.v && <Ionicons name="checkmark-circle" size={20} color={Colors.navy} />}
                </TouchableOpacity>
              ))}
            </View>
          </>
        )}
      </ScrollView>

      <PinSetupDialog visible={showSetup} onComplete={() => { setShowSetup(false); refreshAllStates(); }} onSkip={() => setShowSetup(false)} />
      <PinChangeDialog visible={showChange} onClose={() => setShowChange(false)} onDone={() => { setShowChange(false); setToast({ visible: true, message: 'تم التغيير', type: 'success' }); refreshAllStates(); }} />
      {showReAuth && <PinLoginDialog visible={true} onSuccess={() => { setShowReAuth(false); if (reAuthCallback) reAuthCallback(true); }} onWipe={() => setShowReAuth(false)} />}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#F8FAFC' },
  header: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingTop: Platform.OS === 'ios' ? 50 : 40, paddingBottom: 20, borderBottomWidth: 1, borderBottomColor: '#F1F5F9' },
  backBtn: { width: 45, height: 45, borderRadius: 15, backgroundColor: '#F1F5F9', justifyContent: 'center', alignItems: 'center' },
  headerTitle: { fontSize: 16, fontFamily: 'Tajawal-Bold', color: Colors.navy },
  scrollContent: { padding: 20, paddingBottom: 40 },
  sectionHeader: { marginTop: 10, marginBottom: 12 },
  sectionTitle: { fontSize: 13, fontFamily: 'Tajawal-Bold', color: Colors.gray, textAlign: 'right' },
  card: { backgroundColor: '#FFFFFF', borderRadius: 24, padding: 16, marginBottom: 12, borderWidth: 1, borderColor: '#F1F5F9' },
  cardHeader: { flexDirection: 'row-reverse', alignItems: 'center', gap: 12 },
  iconBox: { width: 45, height: 45, borderRadius: 14, justifyContent: 'center', alignItems: 'center' },
  headerInfo: { flex: 1 },
  cardLabel: { fontSize: 14, fontFamily: 'Tajawal-Bold', color: Colors.dark, textAlign: 'right' },
  cardDesc: { fontSize: 11, fontFamily: 'Tajawal-Regular', color: Colors.gray, textAlign: 'right', marginTop: 2 },
  subAction: { flexDirection: 'row-reverse', alignItems: 'center', gap: 10, padding: 15, backgroundColor: '#F1F5F9', borderRadius: 18, marginBottom: 20 },
  subActionText: { flex: 1, fontSize: 13, fontFamily: 'Tajawal-Medium', color: Colors.navy, textAlign: 'right' },
  lockOptionsCard: { backgroundColor: '#FFFFFF', borderRadius: 24, overflow: 'hidden', borderWidth: 1, borderColor: '#F1F5F9' },
  lockOption: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', padding: 15, borderBottomWidth: 1, borderBottomColor: '#F8FAFC' },
  lockOptionActive: { backgroundColor: Colors.navy + '05' },
  lockOptionLabel: { fontSize: 13, fontFamily: 'Tajawal-Regular', color: Colors.dark },
  lockOptionLabelActive: { fontFamily: 'Tajawal-Bold', color: Colors.navy },
});
