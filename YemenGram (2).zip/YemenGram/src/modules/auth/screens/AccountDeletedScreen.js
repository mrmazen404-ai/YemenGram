// src/modules/auth/screens/AccountDeletedScreen.js
// شاشة وداع السيادة (The Final Farewell - v1.1 Refined)
// واجهة احترافية تظهر بعد التطهير الكامل للحساب

import React, { useEffect } from 'react';
import { View, Text, StyleSheet, Image, BackHandler, TouchableOpacity, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '../../../shared/utils/colors';
import Button from '../../../shared/components/Button';
import { useAuth } from '../../../shared/contexts/AuthContext';

const LOGO = require('../../../shared/assets/images/full-logo.png');

export default function AccountDeletedScreen({ navigation }) {
  const { setPurgeSuccess } = useAuth();

  // منع زر الرجوع في الأندرويد لضمان حتمية المسار
  useEffect(() => {
    const backHandler = BackHandler.addEventListener('hardwareBackPress', () => true);
    return () => backHandler.remove();
  }, []);

  const handleExit = () => {
    if (Platform.OS === 'ios') {
      setPurgeSuccess(false);
      navigation.replace('Login');
    } else {
      BackHandler.exitApp();
    }
  };
  const handleRegister = () => {
    console.log('🔄 [AccountDeleted] بدء رحلة هوية جديدة. إعادة ضبط الكون...');
    // ✅ تصفير حالة الفناء لفتح البوابات الأخرى
    setPurgeSuccess(false);

    // ✅ إجبار النظام على الانتقال لشاشة التسجيل (وليس تسجيل الدخول)
    setTimeout(() => {
      navigation.navigate('Register');
    }, 100);
  };
  return (
    <View style={styles.root}>
      <View style={styles.container}>
        {/* وسام التطهير الناجح */}
        <View style={styles.badgeContainer}>
           <View style={styles.badgeCircle}>
              <Ionicons name="shield-checkmark" size={70} color={Colors.green} />
           </View>
           <View style={styles.glowEffect} />
        </View>

        <View style={styles.textSection}>
           <Text style={styles.title}>تم حذف الحساب بنجاح</Text>
           <Text style={styles.message}>
             لقد قمت بإتمام بروتوكول التطهير النهائي. تم مسح كافة سجلاتك المالية، صورك الشخصية،
             ونجاح إتلاف النسخ الاحتياطية. هويتك الرقمية لم تعد موجودة في هذا الجهاز.
           </Text>
        </View>

        <View style={styles.actionSection}>
           <Button
             title="إنشاء حساب جديد"
             onPress={handleRegister}
             variant="primary"
             style={styles.btn}
           />
           <TouchableOpacity style={styles.exitBtn} onPress={handleExit}>
              <Text style={styles.exitText}>إغلاق  الآن</Text>
           </TouchableOpacity>
        </View>

        <View style={styles.footer}>
           <Image source={LOGO} style={styles.miniLogo} resizeMode="contain" />
           <Text style={styles.footerText}>يمن جرام - YemenGram </Text>
        </View>

      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  container: {
    flex: 1,
    paddingHorizontal: 30,
    justifyContent: 'center',
    alignItems: 'center',
  },
  badgeContainer: {
    marginBottom: 40,
    position: 'relative',
    justifyContent: 'center',
    alignItems: 'center',
  },
  badgeCircle: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#F0FFF4',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#C6F6D5',
    zIndex: 2,
  },
  glowEffect: {
    position: 'absolute',
    width: 160,
    height: 160,
    borderRadius: 80,
    backgroundColor: 'rgba(72, 187, 120, 0.1)',
    zIndex: 1,
  },
  textSection: {
    alignItems: 'center',
    marginBottom: 50,
  },
  title: {
    fontSize: 24,
    fontFamily: 'Tajawal-Bold',
    color: Colors.dark,
    marginBottom: 15,
  },
  message: {
    fontSize: 14,
    fontFamily: 'Tajawal-Regular',
    color: Colors.gray,
    textAlign: 'center',
    lineHeight: 24,
    paddingHorizontal: 10,
  },
  actionSection: {
    width: '100%',
    gap: 20,
  },
  btn: {
    height: 56,
    borderRadius: 16,
  },
  exitBtn: {
    alignItems: 'center',
    paddingVertical: 10,
  },
  exitText: {
    fontSize: 14,
    fontFamily: 'Tajawal-Bold',
    color: Colors.navy,
    textDecorationLine: 'underline',
  },
  footer: {
    position: 'absolute',
    bottom: 40,
    alignItems: 'center',
  },
  miniLogo: {
    width: 100,
    height: 40,
    opacity: 0.5,
    marginBottom: 5,
  },
  footerText: {
    fontSize: 10,
    fontFamily: 'Tajawal-Medium',
    color: Colors.border,
    letterSpacing: 1,
  }
});