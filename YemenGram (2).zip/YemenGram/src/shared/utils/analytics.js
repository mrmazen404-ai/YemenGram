// src/shared/utils/analytics.js

import { Platform } from 'react-native';
import { Logger } from './logger';

class AnalyticsService {
  constructor() {
    this.sessionId = this.generateSessionId();
    this.events = [];
    this.isEnabled = true;
  }

  static getInstance() {
    if (!AnalyticsService.instance) {
      AnalyticsService.instance = new AnalyticsService();
    }
    return AnalyticsService.instance;
  }

  generateSessionId() {
    return `session_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  }

  trackEvent(name, properties) {
    if (!this.isEnabled) return;

    const event = {
      name,
      properties,
      timestamp: Date.now(),
      sessionId: this.sessionId,
    };

    this.events.push(event);
    this.saveEvents();
    Logger.security(`Analytics: ${name}`, { properties });
    this.sendToAnalyticsService(event);
  }

  async saveEvents() {
    try {
      // حفظ الأحداث محلياً
    } catch (error) {
      Logger.error('Failed to save analytics events:', error);
    }
  }

  sendToAnalyticsService(event) {
    if (__DEV__) {
      console.log('📊 Analytics Event:', event);
    }
  }

  setUser(userId, properties) {
    this.trackEvent('user_identified', { userId, ...properties });
  }

  setEnabled(enabled) {
    this.isEnabled = enabled;
  }

  getEvents() {
    return this.events;
  }

  clearEvents() {
    this.events = [];
  }

  async syncEvents() {
    if (this.events.length === 0) return;

    try {
      this.clearEvents();
    } catch (error) {
      Logger.error('Failed to sync analytics events:', error);
    }
  }
}

export const Analytics = AnalyticsService.getInstance();