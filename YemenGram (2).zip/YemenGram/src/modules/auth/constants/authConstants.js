// src/modules/auth/constants/authConstants.js
// ثوابت المصادقة (Authentication Constants) - v1.1 Cleaned

export const AUTH_EVENTS = {
  LOGIN_SUCCESS: 'login_success',
  LOGIN_FAILED: 'login_failed',
  LOGOUT: 'logout',
  REGISTER_ATTEMPT: 'register_attempt',
  REGISTER_SUCCESS: 'register_success',
  OTP_SENT: 'otp_sent',
  OTP_VERIFY_SUCCESS: 'otp_verify_success',
  OTP_VERIFY_FAILED: 'otp_verify_failed',
  PASSWORD_RESET_REQUEST: 'password_reset_request',
  PASSWORD_RESET_SUCCESS: 'password_reset_success',
};

export const AUTH_MESSAGES = {
  INVALID_CREDENTIALS: 'بيانات الدخول غير صحيحة',
  ACCOUNT_BLOCKED: 'الحساب محظور، يرجى التواصل مع الدعم',
  EMAIL_REQUIRED: 'البريد الإلكتروني مطلوب',
  PASSWORD_REQUIRED: 'كلمة المرور مطلوبة',
  WEAK_PASSWORD: 'كلمة المرور ضعيفة جداً',
  OTP_EXPIRED: 'انتهت صلاحية الكود، اطلب كود جديد',
  REGISTRATION_SUCCESS: 'تم إنشاء الحساب بنجاح',
};
