/**
 * شاشة طلب تمديد السيادة (Sovereign Extension Request Screen)
 * تتيح للمستخدم طلب مهلة إضافية أو تمديد تجريبي قبل القفل النهائي
 */

import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, SafeAreaView, Alert, ActivityIndicator } from 'react-native';
import { MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';
import { Colors } from '../../../shared/utils/colors';
import SubscriptionCoreService from '../services/SubscriptionCoreService';
import { useSubscriptionState } from '../hooks/useSubscriptionState';

export default function ExtensionScreen({ navigation }) {
  const { subscription, refresh } = useSubscriptionState();
  const [loading, setLoading] = React.useState(false);

  const handleRequestExtension = async () => {
    if (!subscription?.id) return;

    Alert.alert(
      'تأكيد طلب التمديد',
      'هل تود طلب تمديد استثنائي لمدة 7 أيام؟ (يسمح بذلك مرة واحدة لكل دورة اشتراك)',
      [
        { text: 'تراجع', style: 'cancel' },
        {
          text: 'تأكيد الطلب',
          onPress: async () => {
            try {
              setLoading(true);
              const service = new SubscriptionCoreService();

              // تنفيذ حدث التمديد السيادي (EXTEND_REQUEST)
              await service.processEvent(subscription.id, 'EXTEND_REQUEST', {
                userId: subscription.user_id || subscription.userId,
                idempotencyKey: `${subscription.id}:extension:${subscription.user_id || subscription.userId}`,
                plan: subscription.plan,
                data: {
                  reason: 'grace_period_extension',
                  requestedAt: Date.now(),
                }
              });

              Alert.alert(
                'تم تسجيل الطلب',
                'سيتم مراجعة طلب التمديد من قبل الإدارة الفنية والرد عليك خلال ساعة.',
                [{ text: 'حسناً', onPress: () => navigation.goBack() }]
              );
              refresh();
            } catch (error) {
              Alert.alert('خطأ', error.message || 'فشل تسجيل طلب التمديد');
            } finally {
              setLoading(false);
            }
          },
        },
      ]
    );
  };

  return (
    <SafeAreaView style={styles.root}>
      <ScrollView style={styles.container} contentContainerStyle={styles.content}>

        {/* 🛡️ الهيدر */}
        <View style={styles.header}>
          <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
            <Ionicons name="chevron-forward" size={24} color={Colors.navy} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>طلب تمديد السيادة</Text>
          <View style={{ width: 40 }} />
        </View>

        <View style={styles.heroSection}>
          <View style={styles.iconCircle}>
             <MaterialCommunityIcons name="clock-plus-outline" size={50} color={Colors.gold} />
          </View>
          <Text style={styles.title}>تحتاج لمزيد من الوقت؟</Text>
          <Text style={styles.subtitle}>
            نحن نتفهم ظروف العمل. يمكنك طلب تمديد مؤقت لضمان عدم توقف عملياتك المحاسبية أثناء تجهيز السداد.
          </Text>
        </View>

        <View style={styles.infoCard}>
           <Text style={styles.infoTitle}>تفاصيل التمديد المتاح:</Text>
           <View style={styles.infoRow}>
              <Ionicons name="calendar-outline" size={18} color={Colors.navy} />
              <Text style={styles.infoText}>المدة الإضافية: 7 أيام عمل</Text>
           </View>
           <View style={styles.infoRow}>
              <Ionicons name="shield-outline" size={18} color={Colors.navy} />
              <Text style={styles.infoText}>حالة الوصول: سيادة كاملة</Text>
           </View>
           <View style={styles.infoRow}>
              <Ionicons name="alert-circle-outline" size={18} color="#EF4444" />
              <Text style={styles.infoText}>التوفر: متاح مرة واحدة فقط</Text>
           </View>
        </View>

        <View style={styles.noticeBox}>
           <Text style={styles.noticeText}>
             * ملاحظة: التمديد يهدف لمساعدتك على إكمال فواتيرك العالقة ولا يعتبر بديلاً عن تجديد الاشتراك الرسمي.
           </Text>
        </View>

        <TouchableOpacity
          style={styles.requestBtn}
          onPress={handleRequestExtension}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color="#FFF" />
          ) : (
            <>
              <Text style={styles.requestBtnText}>إرسال طلب التمديد الآن</Text>
              <Ionicons name="paper-plane-outline" size={20} color="#FFF" />
            </>
          )}
        </TouchableOpacity>

      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#F8FAFC' },
  container: { flex: 1 },
  content: { padding: 25, paddingBottom: 40 },
  header: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', marginBottom: 30 },
  backBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: '#FFF', justifyContent: 'center', alignItems: 'center', elevation: 2 },
  headerTitle: { fontSize: 18, fontFamily: 'Tajawal-Bold', color: Colors.navy },
  heroSection: { alignItems: 'center', marginBottom: 40 },
  iconCircle: { width: 100, height: 100, borderRadius: 50, backgroundColor: Colors.navy, justifyContent: 'center', alignItems: 'center', marginBottom: 20, elevation: 5 },
  title: { fontSize: 22, fontFamily: 'Tajawal-Bold', color: '#0F172A', textAlign: 'center' },
  subtitle: { fontSize: 14, fontFamily: 'Tajawal-Medium', color: '#64748B', textAlign: 'center', marginTop: 12, lineHeight: 22 },
  infoCard: { backgroundColor: '#FFF', borderRadius: 24, padding: 25, marginBottom: 30, borderWidth: 1, borderColor: '#F1F5F9', elevation: 3 },
  infoTitle: { fontSize: 15, fontFamily: 'Tajawal-Bold', color: Colors.navy, marginBottom: 20, textAlign: 'right' },
  infoRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 15, marginBottom: 15 },
  infoText: { fontSize: 14, fontFamily: 'Tajawal-Medium', color: '#334155' },
  noticeBox: { backgroundColor: '#F1F5F9', borderRadius: 15, padding: 15, marginBottom: 40 },
  noticeText: { fontSize: 11, fontFamily: 'Tajawal-Medium', color: '#94A3B8', textAlign: 'center', lineHeight: 18 },
  requestBtn: {
    backgroundColor: Colors.navy,
    borderRadius: 20,
    paddingVertical: 18,
    flexDirection: 'row-reverse',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 15,
    elevation: 5,
  },
  requestBtnText: { color: '#FFF', fontFamily: 'Tajawal-Bold', fontSize: 16 },
});
