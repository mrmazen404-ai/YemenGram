// src/shared/utils/logger.js

import { Platform } from 'react-native';

const LogLevel = {
  DEBUG: 'debug',
  INFO: 'info',
  WARN: 'warn',
  ERROR: 'error',
  SECURITY: 'security',
};

class LoggerService {
  constructor() {
    this.logBuffer = [];
    this.isProduction = __DEV__ === false;
    this.maxBufferSize = 100;
  }

  static getInstance() {
    if (!LoggerService.instance) {
      LoggerService.instance = new LoggerService();
    }
    return LoggerService.instance;
  }

  log(level, message, context) {
    const entry = {
      timestamp: Date.now(),
      level,
      message,
      context,
      platform: Platform.OS,
      version: '1.0.0',
    };

    if (context?.error instanceof Error) {
      entry.stack = context.error.stack;
      entry.message += `: ${context.error.message}`;
    }

    this.logBuffer.push(entry);
    if (this.logBuffer.length > this.maxBufferSize) {
      this.logBuffer.shift();
    }

    if (!this.isProduction) {
      this.logToConsole(entry);
    }

    if (this.isProduction) {
      this.sendToRemoteServer(entry);
    }
  }

  logToConsole(entry) {
    const prefix = `[${entry.level.toUpperCase()}]`;
    const timestamp = new Date(entry.timestamp).toISOString();

    switch (entry.level) {
      case LogLevel.DEBUG:
        console.debug(`${prefix} ${timestamp} - ${entry.message}`, entry.context || '');
        break;
      case LogLevel.INFO:
        console.info(`${prefix} ${timestamp} - ${entry.message}`, entry.context || '');
        break;
      case LogLevel.WARN:
        console.warn(`${prefix} ${timestamp} - ${entry.message}`, entry.context || '');
        break;
      case LogLevel.ERROR:
        console.error(`${prefix} ${timestamp} - ${entry.message}`, entry.context || '');
        if (entry.stack) {
          console.error(entry.stack);
        }
        break;
      case LogLevel.SECURITY:
        console.log(`🔒 ${prefix} ${timestamp} - ${entry.message}`, entry.context || '');
        break;
    }
  }

  async sendToRemoteServer(_entry) {
    // يمكن إرسال إلى خادم مركزي
  }

  // Instance methods
  debug(message, context) { this.log(LogLevel.DEBUG, message, context); }
  info(message, context) { this.log(LogLevel.INFO, message, context); }
  warn(message, context) { this.log(LogLevel.WARN, message, context); }
  error(message, context) { this.log(LogLevel.ERROR, message, { error: context }); }
  security(message, context) { this.log(LogLevel.SECURITY, message, context); }

  // Static methods
  static debug(message, context) { this.getInstance().debug(message, context); }
  static info(message, context) { this.getInstance().info(message, context); }
  static warn(message, context) { this.getInstance().warn(message, context); }
  static error(message, context) { this.getInstance().error(message, context); }
  static security(message, context) { this.getInstance().security(message, context); }

  static getBuffer() {
    return this.getInstance().logBuffer;
  }

  static clearBuffer() {
    this.getInstance().logBuffer = [];
  }

  static async getLogs(level) {
    const buffer = this.getInstance().logBuffer;
    if (level) {
      return buffer.filter(entry => entry.level === level);
    }
    return buffer;
  }
}

export const Logger = LoggerService.getInstance();
