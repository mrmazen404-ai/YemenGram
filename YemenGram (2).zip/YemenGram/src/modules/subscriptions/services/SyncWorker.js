/** عامل مزامنة الاشتراك: يقرأ LocalDB فقط ويعالج كل عملية مرة واحدة. */
import RemoteAdapter from './RemoteAdapter';
import { LocalDB } from '../../database/localDB';
import TimeService from '../../../services/timeService';

class SyncWorker {
  constructor({ adapter } = {}) { this.adapter = adapter || new RemoteAdapter(); this.running = false; }

  async runOnce(userId) {
    if (!userId) return { success: false, error: 'user_required' };
    if (this.running) return { success: false, error: 'already_running' };
    this.running = true;
    try {
      const pending = await LocalDB.query(
        `SELECT * FROM sync_queue WHERE user_id = ? AND status = 'pending' AND attempts < 5 ORDER BY created_at ASC LIMIT 50`,
        [userId]
      );
      let processed = 0;
      for (const op of pending) {
        try {
          const data = typeof op.data === 'string' ? JSON.parse(op.data) : op.data;
          const response = await this.adapter.send({
            idempotencyKey: `sync:${op.id}`,
            payload: { action: op.action, tableName: op.table_name, recordId: op.record_id, data },
          });
          if (!response?.success) throw new Error(response?.error || 'remote_sync_failed');
          await LocalDB.execute('UPDATE sync_queue SET status = ?, synced_at = ? WHERE id = ? AND user_id = ?', ['synced', Date.now(), op.id, userId], { system: true });
          processed += 1;
        } catch (_) {
          await LocalDB.execute('UPDATE sync_queue SET attempts = attempts + 1, status = CASE WHEN attempts + 1 >= 5 THEN \'failed\' ELSE \'pending\' END WHERE id = ? AND user_id = ?', [op.id, userId], { system: true });
        }
      }
      if (processed || pending.length === 0) await TimeService.updateLastSyncTimestamp();
      return { success: true, processed, pending: pending.length };
    } finally { this.running = false; }
  }
}
export default SyncWorker;
