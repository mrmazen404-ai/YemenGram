// src/shared/i18n/en.js
// English Localization File - v1.2 Cleaned

export default {
  common: {
    save: 'Save',
    cancel: 'Cancel',
    confirm: 'Confirm',
    delete: 'Delete',
    edit: 'Edit',
    next: 'Next',
    back: 'Back',
    loading: 'Loading...',
    success: 'Success',
    error: 'Error',
  },
  auth: {
    login: 'Login',
    register: 'Register',
    logout: 'Logout',
    email: 'Email',
    password: 'Password',
    forgot_password: 'Forgot Password?',
  },
  profile: {
    title: 'Profile',
    security: 'Security',
    appearance: 'Appearance',
  },
  settings: {
    title: 'Settings',
    notifications: 'Notifications',
  }
};
