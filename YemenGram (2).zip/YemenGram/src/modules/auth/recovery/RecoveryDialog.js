// src/modules/auth/recovery/RecoveryDialog.js
// دايلوج استعادة كلمة المرور - يمن جرام

import React, { useState, useRef, useEffect } from 'react';
import { View, Text, Modal, TextInput, TouchableOpacity, Animated, Dimensions,  } from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { styles } from './RecoveryStyles';
import { RecoveryService } from './RecoveryService';
import { AuthService } from '../services/authService';
import { Colors } from '../../../shared/utils/colors';
import SecurityLoading from '../../../shared/components/SecurityLoading';

import Input from '../../../shared/components/Input';
import Button from '../../../shared/components/Button';

const { height } = Dimensions.get('window');

export default function RecoveryDialog({ visible, email, onClose, onSuccess }) {
  const [step, setStep] = useState('otp'); // otp, new_password, success
  const [code, setCode] = useState(['', '', '', '', '', '']);
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadingText, setLoadingStatus] = useState('جاري المعالجة...');
  const [error, setError] = useState('');
  const [recoveryToken, setRecoveryToken] = useState(null); // ✅ تعريف التوكن في المكان الصحيح

  const [resendTimer, setResendTimer] = useState(0);
  const [canResend, setCanResend] = useState(false);
  const [focusedIndex, setFocusedIndex] = useState(0); // ✅ إضافة حالة التركيز

  // أنيميشن الانتقال بين الخطوات
  const contentFade = useRef(new Animated.Value(1)).current;
  const slideAnim = useRef(new Animated.Value(height)).current;
  const inputRefs = useRef([]);

  useEffect(() => {
    if (visible) {
      Animated.spring(slideAnim, { toValue: 0, tension: 50, friction: 12, useNativeDriver: true }).start();
      setTimeout(() => inputRefs.current[0]?.focus(), 600);
      checkCooldown();
    } else {
      resetState();
    }
  }, [visible]);

  useEffect(() => {
    let interval;
    if (resendTimer > 0) {
      interval = setInterval(() => setResendTimer(p => p - 1), 1000);
    } else {
      setCanResend(true);
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [resendTimer]);

  const checkCooldown = async () => {
    const status = await RecoveryService.canResendCode();
    if (!status.allowed) {
      setResendTimer(status.remaining);
      setCanResend(false);
    } else {
      setResendTimer(0);
      setCanResend(true);
    }
  };

  const resetState = () => {
    setStep('otp');
    setCode(['', '', '', '', '', '']);
    setError('');
    contentFade.setValue(1);
  };

  const triggerHaptic = (type = 'light') => {
    if (type === 'success') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    else if (type === 'error') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    else Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  // ✅ أنيميشن الانتقال السلس لتعيين كلمة المرور
  const transitionToPassword = () => {
    Animated.timing(contentFade, { toValue: 0, duration: 200, useNativeDriver: true }).start(() => {
      setStep('new_password');
      setCode(['', '', '', '', '', '']); // مسح كود الـ OTP من الذاكرة
      Animated.timing(contentFade, { toValue: 1, duration: 300, useNativeDriver: true }).start();
    });
  };

  const handleOTPChange = (value, index) => {
    const cleaned = value.replace(/[^0-9]/g, '');
    if (!cleaned) return;
    const newCode = [...code];
    newCode[index] = cleaned.slice(-1);
    setCode(newCode);
    if (index < 5) inputRefs.current[index + 1]?.focus();
    if (newCode.every(c => c !== '')) setTimeout(() => verifyOTP(newCode.join('')), 50);
  };

  const handleKeyPress = (e, index) => {
    if (e.nativeEvent.key === 'Backspace') {
      if (code[index] === '' && index > 0) {
        const newCode = [...code];
        newCode[index - 1] = '';
        setCode(newCode);
        inputRefs.current[index - 1]?.focus();
      } else {
        const newCode = [...code];
        newCode[index] = '';
        setCode(newCode);
      }
    }
  };



  const handleResend = async () => {
    if (!canResend) return;
    setLoading(true);
    try {
      await AuthService.sendOTP(email);
      await RecoveryService.updateResendTime();
      setResendTimer(60);
      setCanResend(false);
      triggerHaptic('success');
      setError('تم إرسال كود جديد بنجاح');
    } catch (e) {
      setError('فشل إعادة الإرسال');
    } finally {
      setLoading(false);
    }
  };



   const verifyOTP = async (enteredCode) => {
      if (__DEV__) console.log('🛡️ [UI] محاولة التحقق من كود الـ OTP المدخل.');
      setLoading(true);
      setLoadingStatus('جاري المراجعة...');
      setError('');
      try {
        // ✅ استخدام خدمة التحقق للحصول على توكن الاستعادة
        const result = await AuthService.verifyRecoveryOTP(email, enteredCode.trim());
        if (result.success) {
          if (__DEV__) console.log('🛡️ [UI] نجاح التحقق من الكود. الانتقال لتعيين كلمة المرور.');
          // تأخير بسيط لتحسين تجربة المستخدم
          await new Promise(r => setTimeout(r, 800));
          setRecoveryToken(result.recoveryToken);
          triggerHaptic('success');
          transitionToPassword();
        }
      } catch (e) {
        if (__DEV__) console.log(`🛡️ [UI] فشل التحقق من الـ OTP: ${e.message}`);
        triggerHaptic('error');
        setError(e.message || 'الرمز غير صحيح');
        setCode(['', '', '', '', '', '']);
        inputRefs.current[0]?.focus();
      } finally {
        setLoading(false);
      }
    };

  const handleFinalSubmit = async () => {
    if (__DEV__) console.log('🛡️ [UI] محاولة التنفيذ النهائي لتغيير كلمة المرور.');

    if (password !== confirmPassword) {
      if (__DEV__) console.log('🛡️ [UI] فشل التحقق: الكلمتان غير متطابقتين.');
      triggerHaptic('error'); setError('الكلمتان غير متطابقتين'); return;
    }
    if (password.length < 10) {
      if (__DEV__) console.log('🛡️ [UI] فشل التحقق: كلمة المرور ضعيفة.');
      triggerHaptic('error'); setError('الكلمة ضعيفة (أدخل 10 رموز)'); return;
    }

    setLoading(true);
    setLoadingStatus('جاري تحديث البيانات...');

    try {
      // ✅ التنفيذ النهائي للتغيير باستخدام التوكن المؤقت ومسح الجلسات
      await AuthService.finalizePasswordReset(email, recoveryToken, password);

      if (__DEV__) console.log('🛡️ [UI] تم تحديث كلمة المرور بنجاح. عرض واجهة النجاح.');
      triggerHaptic('success');
      setLoading(false);
      setStep('success');
    } catch (e) {
      if (__DEV__) console.log(`🛡️ [UI] خطأ حرج في الخطوة النهائية: ${e.message}`);
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  // ✅ حساب قوة كلمة المرور
  const getPasswordStrength = () => {
    if (password.length === 0) return { label: '', color: Colors.gray, width: '0%' };
    if (password.length < 6) return { label: 'ضعيفة جداً', color: Colors.red, width: '20%' };
    if (password.length < 8) return { label: 'ضعيفة', color: Colors.orange, width: '40%' };
    const hasNumbers = /\d/.test(password);
    const hasSymbols = /[!@#$%^&*]/.test(password);
    if (hasNumbers && hasSymbols) return { label: 'قوية جداً', color: Colors.green, width: '100%' };
    if (hasNumbers || hasSymbols) return { label: 'متوسطة', color: Colors.gold, width: '70%' };
    return { label: 'ضعيفة', color: Colors.orange, width: '40%' };
  };

  const strength = getPasswordStrength();

  if (!visible) return null;

  return (
    <Modal visible={visible} transparent animationType="none" statusBarTranslucent>
      <View style={styles.overlay}>
        <Animated.View style={[styles.sheet, { transform: [{ translateY: slideAnim }] }]}>
          <View style={styles.handle} />

          <Animated.View style={[styles.sheetContent, { opacity: contentFade }]}>
             <View style={styles.sheetControlRow}>
                <TouchableOpacity onPress={onClose} style={styles.miniTextBtn}>
                   <Text style={[styles.miniBtnText, { color: Colors.blue }]}>تغيير الإيميل؟</Text>
                </TouchableOpacity>
             </View>

             <View style={styles.iconCircle}>
                <Ionicons
                  name={step === 'otp' ? "mail-open-outline" : "shield-checkmark-outline"}
                  size={36} color={Colors.navy}
                />
             </View>

             <Text style={styles.sheetTitle}>
                {step === 'otp' ? 'التحقق من الرمز' : 'تعيين كلمة المرور'}
             </Text>

             {step === 'otp' ? (
               <View style={styles.otpContainer}>
                 <View style={styles.otpRowRTL}>
                    {code.map((digit, i) => (
                      <TextInput
                        key={i}
                        ref={r => inputRefs.current[i] = r}
                        style={[
                          styles.otpBox,
                          digit !== '' && styles.otpBoxFilled,
                          focusedIndex === i && styles.otpBoxFocused
                        ]}
                        value={digit}
                        onChangeText={v => handleOTPChange(v, i)}
                        onKeyPress={e => handleKeyPress(e, i)}
                        onFocus={() => setFocusedIndex(i)}
                        keyboardType="number-pad"
                        maxLength={1}
                        contextMenuHidden={true}
                        textAlign="center"
                      />
                    ))}
                 </View>

                 <TouchableOpacity
                   style={[styles.resendBtn, !canResend && { opacity: 0.5 }]}
                   onPress={handleResend}
                   disabled={!canResend}
                 >
                    <Text style={styles.resendBtnText}>
                       {canResend ? 'طلب كود جديد' : `إعادة الإرسال خلال (${resendTimer}ث)`}
                    </Text>
                 </TouchableOpacity>
               </View>
             ) : step === 'new_password' ? (
               <View style={styles.passGroup}>
                  <Input
                    label="كلمة المرور الجديدة"
                    icon="lock-closed-outline"
                    secureTextEntry
                    value={password}
                    onChangeText={setPassword}
                  />

                  {/* مؤشر قوة كلمة المرور */}
                  <View style={styles.strengthContainer}>
                    <View style={styles.strengthBarBg}>
                      <Animated.View style={[styles.strengthBarFill, { width: strength.width, backgroundColor: strength.color }]} />
                    </View>
                    <Text style={[styles.strengthLabel, { color: strength.color }]}>{strength.label}</Text>
                  </View>

                  <Input
                    label="تأكيد كلمة المرور"
                    icon="checkmark-circle-outline"
                    secureTextEntry
                    value={confirmPassword}
                    onChangeText={setConfirmPassword}
                  />

                  <Button
                    title="تغيير كلمة المرور"
                    onPress={handleFinalSubmit}
                    style={styles.mainBtn}
                  />
               </View>
             ) : (
               /* ✅ واجهة النجاح المطهيرة */
               <View style={styles.successContainer}>
                  <View style={styles.successBadge}>
                     <Ionicons name="checkmark-circle" size={60} color={Colors.green} />
                  </View>
                                      <Text style={styles.successTitle}>تم تغيير كلمة المرور بنجاح. يمكنك تسجيل الدخول الآن.</Text>
                  <Button
                    title="تسجيل الدخول"
                    onPress={onSuccess}
                    style={styles.mainBtn}
                  />
               </View>
             )}

             {error !== '' && <Text style={styles.errorFeedback}>{error}</Text>}
             <SecurityLoading visible={loading} status={loadingText} />

             <View style={styles.securitySeal}>
                <MaterialCommunityIcons name="shield-lock" size={14} color={Colors.gold} />
                <Text style={styles.sealText}>نظام الحماية  (SECURE INFRASTRUCTURE)</Text>
             </View>
          </Animated.View>
        </Animated.View>
      </View>
    </Modal>
  );
}
