// placeholder WatermelonDB model for Subscription
export default class Subscription {}
