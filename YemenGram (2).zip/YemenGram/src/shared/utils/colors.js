// src/shared/utils/colors.js
// الهوية اللونية الرسمية لنظام YemenGram ERP

export const Colors = {
  // الألوان الرئيسية (Corporate Identity)
  navy: '#1B365D',      // الكحلي الملكي - يمثل الثقة والاستقرار
  gold: '#D4A853',      // الذهبي المطفي - يمثل القيمة والفخامة
  dark: '#0D1B2A',      // الأسود العميق - للنصوص العريضة

  // الألوان الوظيفية (Functional)
  green: '#27AE60',     // النجاح، الإيرادات، والنشاط
  red: '#E74C3C',       // الخطر، المصروفات، والتحذير
  orange: '#F39C12',    // التنبيهات والانتظار
  blue: '#3498DB',      // المعلومات والروابط

  // الألوان المساعدة (Supportive)
  white: '#FFFFFF',     // الخلفيات النقية
  lightGray: '#F8FAFC', // خلفيات البطاقات
  border: '#E2E8F0',    // الحدود والفواصل
  placeholder: '#94A3B8', // النصوص الباهتة
  gray: '#64748B',      // النصوص الثانوية

  // تدرجات إضافية
  navyLight: '#2C4A73',
  navyDark: '#0D2137',
  successLight: '#E8F5E9',
  errorLight: '#FFEBEE',
  warningLight: '#FFF8E1',
};

export default Colors;
