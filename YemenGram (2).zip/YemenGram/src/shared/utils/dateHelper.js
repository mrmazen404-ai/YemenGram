// src/shared/utils/dateHelper.js
// =============================================
// دوال مساعدة للتواريخ (Date Helpers)
// مجموعة من الدوال للتعامل مع التواريخ بشكل احترافي
// =============================================

// =============================================
// 1. الثوابت
// =============================================

const DAYS_IN_MONTH = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
const MONTHS_AR = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
const DAYS_AR = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
const DAYS_SHORT_AR = ['أحد', 'إثن', 'ثلاث', 'أربع', 'خميس', 'جمع', 'سبت'];

// =============================================
// 2. دوال التحقق من التاريخ
// =============================================

/**
 * التحقق من صحة التاريخ
 * @param {Date|string|number} date - التاريخ
 * @returns {boolean}
 */
export const isValidDate = (date) => {
  if (!date) return false;
  const parsed = new Date(date);
  return !isNaN(parsed.getTime());
};

/**
 * التحقق من أن التاريخ هو اليوم
 * @param {Date|string} date - التاريخ
 * @returns {boolean}
 */
export const isToday = (date) => {
  if (!isValidDate(date)) return false;
  const d = new Date(date);
  const today = new Date();
  return d.getFullYear() === today.getFullYear() &&
         d.getMonth() === today.getMonth() &&
         d.getDate() === today.getDate();
};

/**
 * التحقق من أن التاريخ هو غداً
 * @param {Date|string} date - التاريخ
 * @returns {boolean}
 */
export const isTomorrow = (date) => {
  if (!isValidDate(date)) return false;
  const d = new Date(date);
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  return d.getFullYear() === tomorrow.getFullYear() &&
         d.getMonth() === tomorrow.getMonth() &&
         d.getDate() === tomorrow.getDate();
};

/**
 * التحقق من أن التاريخ هو أمس
 * @param {Date|string} date - التاريخ
 * @returns {boolean}
 */
export const isYesterday = (date) => {
  if (!isValidDate(date)) return false;
  const d = new Date(date);
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  return d.getFullYear() === yesterday.getFullYear() &&
         d.getMonth() === yesterday.getMonth() &&
         d.getDate() === yesterday.getDate();
};

/**
 * التحقق من أن التاريخ في نفس الأسبوع
 * @param {Date|string} date - التاريخ
 * @returns {boolean}
 */
export const isSameWeek = (date) => {
  if (!isValidDate(date)) return false;
  const d = new Date(date);
  const now = new Date();
  const startOfWeek = getStartOfWeek(now);
  const endOfWeek = getEndOfWeek(now);
  return d >= startOfWeek && d <= endOfWeek;
};

/**
 * التحقق من أن التاريخ في نفس الشهر
 * @param {Date|string} date - التاريخ
 * @returns {boolean}
 */
export const isSameMonth = (date) => {
  if (!isValidDate(date)) return false;
  const d = new Date(date);
  const now = new Date();
  return d.getFullYear() === now.getFullYear() &&
         d.getMonth() === now.getMonth();
};

/**
 * التحقق من أن التاريخ في نفس السنة
 * @param {Date|string} date - التاريخ
 * @returns {boolean}
 */
export const isSameYear = (date) => {
  if (!isValidDate(date)) return false;
  const d = new Date(date);
  const now = new Date();
  return d.getFullYear() === now.getFullYear();
};

// =============================================
// 3. دوال الحصول على بداية ونهاية الفترات
// =============================================

/**
 * الحصول على بداية اليوم
 * @param {Date} date - التاريخ
 * @returns {Date}
 */
export const getStartOfDay = (date = new Date()) => {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  return d;
};

/**
 * الحصول على نهاية اليوم
 * @param {Date} date - التاريخ
 * @returns {Date}
 */
export const getEndOfDay = (date = new Date()) => {
  const d = new Date(date);
  d.setHours(23, 59, 59, 999);
  return d;
};

/**
 * الحصول على بداية الأسبوع
 * @param {Date} date - التاريخ
 * @param {number} startDay - يوم البداية (0 = الأحد)
 * @returns {Date}
 */
export const getStartOfWeek = (date = new Date(), startDay = 0) => {
  const d = new Date(date);
  const day = d.getDay();
  const diff = (day - startDay + 7) % 7;
  d.setDate(d.getDate() - diff);
  d.setHours(0, 0, 0, 0);
  return d;
};

/**
 * الحصول على نهاية الأسبوع
 * @param {Date} date - التاريخ
 * @param {number} endDay - يوم النهاية (6 = السبت)
 * @returns {Date}
 */
export const getEndOfWeek = (date = new Date(), endDay = 6) => {
  const d = getStartOfWeek(date);
  d.setDate(d.getDate() + 6);
  d.setHours(23, 59, 59, 999);
  return d;
};

/**
 * الحصول على بداية الشهر
 * @param {Date} date - التاريخ
 * @returns {Date}
 */
export const getStartOfMonth = (date = new Date()) => {
  const d = new Date(date);
  d.setDate(1);
  d.setHours(0, 0, 0, 0);
  return d;
};

/**
 * الحصول على نهاية الشهر
 * @param {Date} date - التاريخ
 * @returns {Date}
 */
export const getEndOfMonth = (date = new Date()) => {
  const d = new Date(date);
  d.setMonth(d.getMonth() + 1);
  d.setDate(0);
  d.setHours(23, 59, 59, 999);
  return d;
};

/**
 * الحصول على بداية السنة
 * @param {Date} date - التاريخ
 * @returns {Date}
 */
export const getStartOfYear = (date = new Date()) => {
  const d = new Date(date);
  d.setMonth(0);
  d.setDate(1);
  d.setHours(0, 0, 0, 0);
  return d;
};

/**
 * الحصول على نهاية السنة
 * @param {Date} date - التاريخ
 * @returns {Date}
 */
export const getEndOfYear = (date = new Date()) => {
  const d = new Date(date);
  d.setMonth(11);
  d.setDate(31);
  d.setHours(23, 59, 59, 999);
  return d;
};

// =============================================
// 4. دوال إضافة وطرح التواريخ
// =============================================

/**
 * إضافة أيام إلى التاريخ
 * @param {Date} date - التاريخ
 * @param {number} days - عدد الأيام
 * @returns {Date}
 */
export const addDays = (date, days) => {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d;
};

/**
 * طرح أيام من التاريخ
 * @param {Date} date - التاريخ
 * @param {number} days - عدد الأيام
 * @returns {Date}
 */
export const subtractDays = (date, days) => {
  return addDays(date, -days);
};

/**
 * إضافة أشهر إلى التاريخ
 * @param {Date} date - التاريخ
 * @param {number} months - عدد الأشهر
 * @returns {Date}
 */
export const addMonths = (date, months) => {
  const d = new Date(date);
  d.setMonth(d.getMonth() + months);
  return d;
};

/**
 * طرح أشهر من التاريخ
 * @param {Date} date - التاريخ
 * @param {number} months - عدد الأشهر
 * @returns {Date}
 */
export const subtractMonths = (date, months) => {
  return addMonths(date, -months);
};

/**
 * إضافة سنوات إلى التاريخ
 * @param {Date} date - التاريخ
 * @param {number} years - عدد السنوات
 * @returns {Date}
 */
export const addYears = (date, years) => {
  const d = new Date(date);
  d.setFullYear(d.getFullYear() + years);
  return d;
};

/**
 * طرح سنوات من التاريخ
 * @param {Date} date - التاريخ
 * @param {number} years - عدد السنوات
 * @returns {Date}
 */
export const subtractYears = (date, years) => {
  return addYears(date, -years);
};

// =============================================
// 5. دوال حساب الفروق بين التواريخ
// =============================================

/**
 * حساب الفرق بين تاريخين بالأيام
 * @param {Date} date1 - التاريخ الأول
 * @param {Date} date2 - التاريخ الثاني
 * @returns {number}
 */
export const diffDays = (date1, date2) => {
  const d1 = new Date(date1);
  const d2 = new Date(date2);
  const diff = d2.getTime() - d1.getTime();
  return Math.floor(diff / (1000 * 60 * 60 * 24));
};

/**
 * حساب الفرق بين تاريخين بالأشهر
 * @param {Date} date1 - التاريخ الأول
 * @param {Date} date2 - التاريخ الثاني
 * @returns {number}
 */
export const diffMonths = (date1, date2) => {
  const d1 = new Date(date1);
  const d2 = new Date(date2);
  const months = (d2.getFullYear() - d1.getFullYear()) * 12;
  return months + (d2.getMonth() - d1.getMonth());
};

/**
 * حساب الفرق بين تاريخين بالسنوات
 * @param {Date} date1 - التاريخ الأول
 * @param {Date} date2 - التاريخ الثاني
 * @returns {number}
 */
export const diffYears = (date1, date2) => {
  const d1 = new Date(date1);
  const d2 = new Date(date2);
  return d2.getFullYear() - d1.getFullYear();
};

/**
 * حساب العمر بالسنوات
 * @param {Date|string} birthDate - تاريخ الميلاد
 * @returns {number}
 */
export const getAge = (birthDate) => {
  if (!isValidDate(birthDate)) return 0;
  const now = new Date();
  const diff = now.getTime() - new Date(birthDate).getTime();
  return Math.floor(diff / (1000 * 60 * 60 * 24 * 365.25));
};

// =============================================
// 6. دوال الحصول على معلومات التاريخ
// =============================================

/**
 * الحصول على رقم الأسبوع في السنة
 * @param {Date} date - التاريخ
 * @returns {number}
 */
export const getWeekNumber = (date) => {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() + 3 - (d.getDay() + 6) % 7);
  const week1 = new Date(d.getFullYear(), 0, 4);
  return 1 + Math.round(((d - week1) / 86400000 - 3 + (week1.getDay() + 6) % 7) / 7);
};

/**
 * الحصول على اسم اليوم بالعربية
 * @param {Date} date - التاريخ
 * @param {string} format - short, long
 * @returns {string}
 */
export const getDayName = (date, format = 'long') => {
  if (!isValidDate(date)) return '';
  const d = new Date(date);
  const dayIndex = d.getDay();
  return format === 'short' ? DAYS_SHORT_AR[dayIndex] : DAYS_AR[dayIndex];
};

/**
 * الحصول على اسم الشهر بالعربية
 * @param {Date} date - التاريخ
 * @returns {string}
 */
export const getMonthName = (date) => {
  if (!isValidDate(date)) return '';
  const d = new Date(date);
  return MONTHS_AR[d.getMonth()];
};

/**
 * الحصول على عدد أيام الشهر
 * @param {number} month - الشهر (0-11)
 * @param {number} year - السنة
 * @returns {number}
 */
export const getDaysInMonth = (month, year) => {
  if (month === 1) {
    const isLeap = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
    return isLeap ? 29 : 28;
  }
  return DAYS_IN_MONTH[month];
};

/**
 * الحصول على أول يوم في الشهر
 * @param {number} month - الشهر (0-11)
 * @param {number} year - السنة
 * @returns {number}
 */
export const getFirstDayOfMonth = (month, year) => {
  return new Date(year, month, 1).getDay();
};

// =============================================
// 7. دوال إنشاء التواريخ
// =============================================

/**
 * إنشاء تاريخ من سلسلة
 * @param {string} dateStr - سلسلة التاريخ (YYYY-MM-DD)
 * @returns {Date|null}
 */
export const parseDate = (dateStr) => {
  if (!dateStr) return null;
  const parts = dateStr.split('-');
  if (parts.length !== 3) return null;
  const year = parseInt(parts[0]);
  const month = parseInt(parts[1]) - 1;
  const day = parseInt(parts[2]);
  if (isNaN(year) || isNaN(month) || isNaN(day)) return null;
  return new Date(year, month, day);
};

/**
 * إنشاء سلسلة تاريخ (YYYY-MM-DD)
 * @param {Date} date - التاريخ
 * @returns {string}
 */
export const toDateString = (date) => {
  if (!isValidDate(date)) return '';
  const d = new Date(date);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

/**
 * إنشاء سلسلة تاريخ ووقت (YYYY-MM-DD HH:MM:SS)
 * @param {Date} date - التاريخ
 * @returns {string}
 */
export const toDateTimeString = (date) => {
  if (!isValidDate(date)) return '';
  const d = new Date(date);
  const dateStr = toDateString(d);
  const hours = String(d.getHours()).padStart(2, '0');
  const minutes = String(d.getMinutes()).padStart(2, '0');
  const seconds = String(d.getSeconds()).padStart(2, '0');
  return `${dateStr} ${hours}:${minutes}:${seconds}`;
};

// =============================================
// 8. دوال النطاقات الزمنية
// =============================================

/**
 * الحصول على نطاق زمني (الأيام القليلة الماضية)
 * @param {number} days - عدد الأيام
 * @param {Date} endDate - تاريخ النهاية
 * @returns {{start: Date, end: Date}}
 */
export const getDateRange = (days, endDate = new Date()) => {
  const end = new Date(endDate);
  const start = subtractDays(end, days);
  return { start, end };
};

/**
 * الحصول على نطاق الشهر الحالي
 * @param {Date} date - التاريخ
 * @returns {{start: Date, end: Date}}
 */
export const getMonthRange = (date = new Date()) => {
  const start = getStartOfMonth(date);
  const end = getEndOfMonth(date);
  return { start, end };
};

/**
 * الحصول على نطاق السنة الحالية
 * @param {Date} date - التاريخ
 * @returns {{start: Date, end: Date}}
 */
export const getYearRange = (date = new Date()) => {
  const start = getStartOfYear(date);
  const end = getEndOfYear(date);
  return { start, end };
};

// =============================================
// 9. دوال مساعدة إضافية
// =============================================

/**
 * مقارنة تاريخين (تجاهل الوقت)
 * @param {Date} date1 - التاريخ الأول
 * @param {Date} date2 - التاريخ الثاني
 * @returns {number} -1, 0, 1
 */
export const compareDates = (date1, date2) => {
  const d1 = new Date(date1);
  const d2 = new Date(date2);
  d1.setHours(0, 0, 0, 0);
  d2.setHours(0, 0, 0, 0);

  if (d1 < d2) return -1;
  if (d1 > d2) return 1;
  return 0;
};

/**
 * الحصول على أقرب تاريخ بين قائمتين
 * @param {Date[]} dates - قائمة التواريخ
 * @param {Date} target - التاريخ المستهدف
 * @returns {Date|null}
 */
export const getClosestDate = (dates, target = new Date()) => {
  if (!dates || dates.length === 0) return null;

  let closest = dates[0];
  let minDiff = Math.abs(new Date(closest).getTime() - new Date(target).getTime());

  for (const date of dates) {
    const diff = Math.abs(new Date(date).getTime() - new Date(target).getTime());
    if (diff < minDiff) {
      minDiff = diff;
      closest = date;
    }
  }

  return closest;
};

// =============================================
// 10. كائن المساعدة الرئيسي
// =============================================

export const dateHelpers = {
  // التحقق
  isValid: isValidDate,
  isToday,
  isTomorrow,
  isYesterday,
  isSameWeek,
  isSameMonth,
  isSameYear,

  // بداية ونهاية
  startOfDay: getStartOfDay,
  endOfDay: getEndOfDay,
  startOfWeek: getStartOfWeek,
  endOfWeek: getEndOfWeek,
  startOfMonth: getStartOfMonth,
  endOfMonth: getEndOfMonth,
  startOfYear: getStartOfYear,
  endOfYear: getEndOfYear,

  // إضافة وطرح
  addDays,
  subtractDays,
  addMonths,
  subtractMonths,
  addYears,
  subtractYears,

  // الفروق
  diffDays,
  diffMonths,
  diffYears,
  getAge,

  // المعلومات
  getWeekNumber,
  getDayName,
  getMonthName,
  getDaysInMonth,
  getFirstDayOfMonth,

  // الإنشاء
  parse: parseDate,
  toString: toDateString,
  toDateTime: toDateTimeString,

  // النطاقات
  getRange: getDateRange,
  getMonthRange,
  getYearRange,

  // إضافية
  compare: compareDates,
  getClosest: getClosestDate,
};

export default dateHelpers;