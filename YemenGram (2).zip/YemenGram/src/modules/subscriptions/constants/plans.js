/**
 * تعريف الباقات السيادية الرسمية (Official Sovereign Plans)
 * YemenGram ERP v1.0
 */

export const PLANS = {
  FREE: {
    id: 'free',
    label: 'المجانية',
    price: 0,
    features: ['جهاز واحد', '5 عملاء', '5 فواتير شهرياً'],
    color: '#64748B'
  },
  TRIAL: {
    id: 'trial',
    label: 'التجريبية',
    price: 0,
    duration: 30,
    features: ['جهاز واحد', '50 عميل', 'كافة الميزات لمدة 30 يوم'],
    color: '#D4A853'
  },
  MONTHLY: {
    id: 'monthly',
    label: 'الشهرية',
    price: 3000,
    currency: 'YER',
    features: ['3 أجهزة', '100 عميل', '500 فاتورة'],
    color: '#0F172A'
  },
  ANNUAL: {
    id: 'annual',
    label: 'السنوية',
    price: 30000,
    currency: 'YER',
    features: ['10 أجهزة', '500 عميل', 'ميزات غير محدودة'],
    color: '#1E293B'
  },
  ENTERPRISE: {
    id: 'enterprise',
    label: 'المؤسسات',
    price: 90000,
    currency: 'YER',
    features: ['أجهزة غير محدودة', 'عملاء غير محدودين', 'دعم فني مخصص'],
    color: '#000000'
  }
};

export default PLANS;
