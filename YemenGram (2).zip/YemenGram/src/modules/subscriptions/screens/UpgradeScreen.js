import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Alert,
  ActivityIndicator
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import LocalDB from '../../database/localDB';
import SubscriptionCoreService from '../services/SubscriptionCoreService';
import { Colors } from '../../../shared/utils/colors';

const UPGRADE_OPTIONS = [
  {
    key: 'monthly',
    label: 'الخطة الشهرية',
    price: 3000,
    note: 'مثالي للمؤسسات الناشئة',
    features: ['3 أجهزة', '100 عميل', '500 فاتورة'],
  },
  {
    key: 'annual',
    label: 'الخطة السنوية',
    price: 30000,
    note: 'أفضل قيمة مقابل السعر',
    features: ['10 أجهزة', '500 عميل', '5000 فاتورة'],
  },
  {
    key: 'enterprise',
    label: 'خطة المؤسسات',
    price: 90000,
    note: 'للسيادة المالية الكاملة',
    features: ['أجهزة غير محدودة', 'عملاء غير محدودين', 'دعم فني مخصص'],
  },
];

export default function UpgradeScreen() {
  const navigation = useNavigation();
  const [user, setUser] = React.useState(null);
  const [subscription, setSubscription] = React.useState(null);
  const [loading, setLoading] = React.useState(false);

  React.useEffect(() => {
    (async () => {
      try {
        const currentUser = await LocalDB.getUser();
        setUser(currentUser);

        if (!currentUser?.id) return;

        const row = await LocalDB.queryOne(
          'SELECT * FROM subscriptions WHERE user_id = ? ORDER BY created_at DESC LIMIT 1',
          [currentUser.id]
        );
        setSubscription(row || null);
      } catch (error) {
        console.error(error);
      }
    })();
  }, []);

  const handleUpgrade = async (plan) => {
    if (!user?.id) {
      Alert.alert('تنبيه', 'يجب تسجيل الدخول أولاً للترقية السيادية.');
      return;
    }

    Alert.alert(
      'تأكيد طلب الترقية',
      `هل أنت متأكد من الانتقال إلى ${plan.label} بسعر ${plan.price} ريال يمني؟`,
      [
        { text: 'تراجع', style: 'cancel' },
        {
          text: 'تأكيد الطلب',
          style: 'default',
          onPress: async () => {
            try {
              setLoading(true);
              const service = new SubscriptionCoreService();

              const subId = subscription?.id || `sub_${user.id}_${Date.now()}`;

              // تنفيذ حدث الترقية (ينقل الحالة لـ VERIFICATION_PENDING)
              const result = await service.processEvent(subId, 'UPGRADE_REQUEST', {
                userId: user.id,
                plan: plan.key,
                data: {
                  price: plan.price,
                  requestedAt: Date.now(),
                }
              });

              Alert.alert(
                'تم تسجيل الطلب',
                'يرجى رفع إيصال الدفع لتفعيل الترقية بعد مراجعة الإدارة.',
                [
                  {
                    text: 'رفع الإيصال الآن',
                    onPress: () => navigation.navigate('SubscriptionPayment', { subscriptionId: subId })
                  },
                  { text: 'لاحقاً', onPress: () => navigation.goBack() }
                ]
              );
            } catch (error) {
              Alert.alert('خطأ سيادي', error?.message || 'فشل تسجيل طلب الترقية');
            } finally {
              setLoading(false);
            }
          },
        },
      ]
    );
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.title}>ترقية السيادة المالية</Text>
      <Text style={styles.subtitle}>اختر المستوى الذي يناسب حجم أعمالك</Text>

      {UPGRADE_OPTIONS.map((plan) => (
        <View key={plan.key} style={styles.card}>
          <View style={styles.cardHeader}>
             <Text style={styles.planLabel}>{plan.label}</Text>
             <Text style={styles.priceText}>{plan.price} ر.ي</Text>
          </View>

          <Text style={styles.noteText}>{plan.note}</Text>

          <View style={styles.featureList}>
            {plan.features.map((f, i) => (
              <View key={i} style={styles.featureItem}>
                 <Text style={styles.featureText}>• {f}</Text>
              </View>
            ))}
          </View>

          <TouchableOpacity
            style={styles.upgradeBtn}
            onPress={() => handleUpgrade(plan)}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color="#FFF" size="small" />
            ) : (
              <Text style={styles.upgradeBtnText}>اختيار هذه الخطة</Text>
            )}
          </TouchableOpacity>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  content: {
    padding: 20,
    paddingBottom: 40,
  },
  title: {
    fontSize: 24,
    fontFamily: 'Tajawal-Bold',
    color: Colors.navy,
    textAlign: 'right',
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 14,
    fontFamily: 'Tajawal-Medium',
    color: '#64748B',
    textAlign: 'right',
    marginBottom: 25,
  },
  card: {
    backgroundColor: '#FFF',
    borderRadius: 20,
    padding: 20,
    marginBottom: 20,
    borderWidth: 1.5,
    borderColor: '#F1F5F9',
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 3,
  },
  cardHeader: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  planLabel: {
    fontSize: 18,
    fontFamily: 'Tajawal-Bold',
    color: Colors.navy,
  },
  priceText: {
    fontSize: 18,
    fontFamily: 'Tajawal-Bold',
    color: '#D4A853',
  },
  noteText: {
    fontSize: 13,
    fontFamily: 'Tajawal-Medium',
    color: '#64748B',
    textAlign: 'right',
    marginBottom: 15,
  },
  featureList: {
    marginBottom: 20,
  },
  featureItem: {
    marginBottom: 4,
  },
  featureText: {
    fontSize: 13,
    fontFamily: 'Tajawal-Medium',
    color: '#334155',
    textAlign: 'right',
  },
  upgradeBtn: {
    backgroundColor: Colors.navy,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  upgradeBtnText: {
    color: '#FFF',
    fontFamily: 'Tajawal-Bold',
    fontSize: 15,
  },
});
