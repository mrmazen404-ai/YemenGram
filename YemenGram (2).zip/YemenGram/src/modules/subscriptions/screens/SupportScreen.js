/**
 * شاشة دعم النخبة السيادية (Sovereign Elite Support Screen)
 * مركز التواصل الرسمي بين المشترك وإدارة YemenGram
 */

import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Linking,
  ScrollView,
  Platform,
  Dimensions
} from 'react-native';
import { Ionicons, FontAwesome, MaterialCommunityIcons } from '@expo/vector-icons';
import * as Clipboard from 'expo-clipboard';
import { Colors } from '../../../shared/utils/colors';
import { useAuth } from '../../../shared/contexts/AuthContext';

const { width } = Dimensions.get('window');

export default function SupportScreen() {
  const { user } = useAuth();
  const supportId = `YG-${user?.id?.slice(-6).toUpperCase() || 'OFFLINE'}`;

  const handleLink = (url) => {
    Linking.openURL(url).catch(err => console.error("Couldn't load page", err));
  };

  const copyId = async () => {
    await Clipboard.setStringAsync(supportId);
    alert('تم نسخ معرف الدعم الموحد');
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      {/* 🛡️ الهيدر السيادي */}
      <View style={styles.headerCard}>
        <View style={styles.iconCircle}>
           <MaterialCommunityIcons name="headset" size={40} color={Colors.gold} />
        </View>
        <Text style={styles.title}>مركز دعم النخبة</Text>
        <Text style={styles.subtitle}>نحن هنا لضمان استقرار سيادتك المالية وتسهيل عملياتك المحاسبية.</Text>

        <TouchableOpacity style={styles.supportIdBox} onPress={copyId}>
           <Text style={styles.supportIdLabel}>معرف الدعم الموحد:</Text>
           <Text style={styles.supportIdValue}>{supportId}</Text>
           <Ionicons name="copy-outline" size={14} color={Colors.gold} />
        </TouchableOpacity>
      </View>

      <Text style={styles.sectionTitle}>قنوات التواصل الرسمية</Text>

      {/* 🟢 واتساب الأعمال */}
      <TouchableOpacity
        style={styles.channelCard}
        onPress={() => handleLink('https://wa.me/967777881496')}
      >
        <View style={[styles.channelIcon, { backgroundColor: '#25D36620' }]}>
           <FontAwesome name="whatsapp" size={24} color="#25D366" />
        </View>
        <View style={styles.channelInfo}>
           <Text style={styles.channelLabel}>دعم واتساب الأعمال</Text>
           <Text style={styles.channelStatus}>متصل الآن • استجابة خلال دقائق</Text>
        </View>
        <Ionicons name="chevron-back" size={18} color="#CBD5E1" />
      </TouchableOpacity>

      {/* 📧 البريد الإلكتروني */}
      <TouchableOpacity
        style={styles.channelCard}
        onPress={() => handleLink('mailto:support@yemengram.com')}
      >
        <View style={[styles.channelIcon, { backgroundColor: '#3B82F620' }]}>
           <Ionicons name="mail-outline" size={24} color="#3B82F6" />
        </View>
        <View style={styles.channelInfo}>
           <Text style={styles.channelLabel}>المراسلة البريدية</Text>
           <Text style={styles.channelStatus}>للمعاملات الرسمية والعقود</Text>
        </View>
        <Ionicons name="chevron-back" size={18} color="#CBD5E1" />
      </TouchableOpacity>

      {/* 📞 الاتصال المباشر */}
      <TouchableOpacity
        style={styles.channelCard}
        onPress={() => handleLink('tel:+967777881496')}
      >
        <View style={[styles.channelIcon, { backgroundColor: Colors.navy + '20' }]}>
           <Ionicons name="call-outline" size={24} color={Colors.navy} />
        </View>
        <View style={styles.channelInfo}>
           <Text style={styles.channelLabel}>الخط الساخن</Text>
           <Text style={styles.channelStatus}>متاح 24/7 للحالات الحرجة</Text>
        </View>
        <Ionicons name="chevron-back" size={18} color="#CBD5E1" />
      </TouchableOpacity>

      <View style={styles.footer}>
         <Text style={styles.footerText}>YemenGram ERP - Excellence in Support</Text>
         <Text style={styles.versionText}>v1.0 Sovereign Edition</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC' },
  content: { padding: 20, paddingTop: 60 },
  headerCard: {
    backgroundColor: Colors.navy,
    borderRadius: 30,
    padding: 30,
    alignItems: 'center',
    marginBottom: 35,
    elevation: 10,
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 15,
  },
  iconCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: { fontSize: 24, fontFamily: 'Tajawal-Bold', color: '#FFF' },
  subtitle: { fontSize: 13, fontFamily: 'Tajawal-Medium', color: 'rgba(255,255,255,0.7)', textAlign: 'center', marginTop: 10, lineHeight: 20 },
  supportIdBox: {
    flexDirection: 'row-reverse',
    backgroundColor: 'rgba(0,0,0,0.2)',
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 12,
    marginTop: 25,
    alignItems: 'center',
    gap: 10,
    borderWidth: 1,
    borderColor: 'rgba(212, 168, 83, 0.3)',
  },
  supportIdLabel: { fontSize: 10, color: '#94A3B8', fontFamily: 'Tajawal-Medium' },
  supportIdValue: { fontSize: 14, color: Colors.gold, fontFamily: 'Tajawal-Bold' },
  sectionTitle: { fontSize: 14, fontFamily: 'Tajawal-Bold', color: '#64748B', textAlign: 'right', marginBottom: 15, marginRight: 5 },
  channelCard: {
    backgroundColor: '#FFF',
    borderRadius: 20,
    padding: 15,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#F1F5F9',
  },
  channelIcon: { width: 50, height: 50, borderRadius: 15, justifyContent: 'center', alignItems: 'center', marginLeft: 15 },
  channelInfo: { flex: 1, alignItems: 'flex-end' },
  channelLabel: { fontSize: 15, fontFamily: 'Tajawal-Bold', color: '#1E293B' },
  channelStatus: { fontSize: 11, fontFamily: 'Tajawal-Medium', color: '#94A3B8', marginTop: 2 },
  footer: { marginTop: 40, alignItems: 'center' },
  footerText: { fontSize: 11, color: '#CBD5E1', fontFamily: 'Tajawal-Medium' },
  versionText: { fontSize: 9, color: '#E2E8F0', marginTop: 5 }
});
