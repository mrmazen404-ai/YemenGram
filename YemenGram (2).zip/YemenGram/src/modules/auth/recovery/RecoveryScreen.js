// src/modules/auth/recovery/RecoveryScreen.js
// شاشة استعادة الهوية (The Entry Gate)

import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StatusBar } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { styles } from './RecoveryStyles';
import { Colors } from '../../../shared/utils/colors';
import Input from '../../../shared/components/Input';
import Button from '../../../shared/components/Button';
import RecoveryDialog from './RecoveryDialog';
import Toast from '../../../shared/components/Toast';
import SecurityLoading from '../../../shared/components/SecurityLoading';
import Modal from '../../../shared/components/Modal';
import { AuthService } from '../services/authService';
import { ImageBackground, ScrollView, KeyboardAvoidingView, Platform } from 'react-native';

const HEADER_BG = require('../../../shared/assets/images/hint.png');

export default function RecoveryScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [showDialog, setShowDialog] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState({ visible: false, message: '', type: 'error' });

  const triggerHaptic = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleStartRecovery = () => {
    if (__DEV__) console.log('🛡️ [UI] ضغط زر "بدء التحقق"');
    if (!email.includes('@') || email.length < 5) {
      if (__DEV__) console.log('🛡️ [UI] فشل التحقق الأولي من صيغة البريد');
      setToast({ visible: true, message: 'يرجى إدخال بريد إلكتروني صحيح', type: 'error' });
      return;
    }

    triggerHaptic();
    if (__DEV__) console.log(`🛡️ [UI] إظهار نافذة التأكيد لـ: ${email}`);
    setShowConfirmModal(true);
  };

  const initiateProcess = async () => {
    if (__DEV__) console.log(`🛡️ [UI] تأكيد البريد. بدء عملية التحقق.`);
    setLoading(true);
    try {
      // ✅ إرسال طلب التحقق (تحقق صامت وإرسال OTP)
      await AuthService.startPasswordRecovery(email.trim().toLowerCase());
      if (__DEV__) console.log('🛡️ [UI] نجاح بدء العملية. جاري فتح نافذة الـ OTP.');
      setShowDialog(true);
    } catch (e) {
      if (__DEV__) console.log(`🛡️ [UI] خطأ أثناء بدء العملية: ${e.message}`);
      setToast({ visible: true, message: e.message || 'فشل الاتصال بالخادم', type: 'error' });
    } finally {
      setLoading(false);
    }
  };

    return (
        <KeyboardAvoidingView
            style={styles.root}
            behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        >
            <StatusBar barStyle="dark-content" />
            <Toast visible={toast.visible} message={toast.message} type={toast.type} onHide={() => setToast(p => ({ ...p, visible: false }))} />
            <SecurityLoading visible={loading} status="جاري إرسال الرمز..." />

            <ImageBackground
                source={HEADER_BG}
                style={styles.fullBackground}
                imageStyle={styles.bgImage}
            >
                <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
                    <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
                        <Ionicons name="chevron-forward" size={24} color={Colors.navy} />
                    </TouchableOpacity>

                    <View style={styles.iconSection}>
                        <View style={styles.iconCircle}>
                            <Ionicons name="lock-open-outline" size={48} color={Colors.gold} />
                        </View>
                        <Text style={styles.title}>نسيت كلمة المرور</Text>
                        <Text style={styles.subtitle}>أدخل بريدك الإلكتروني لاستلام رمز التحقق وإعادة تعيين كلمة المرور.</Text>
                    </View>

                    <View style={styles.formCard}>
                        <Input
                            label="البريد الإلكتروني"
                            icon="mail-outline"
                            value={email}
                            onChangeText={setEmail}
                            keyboardType="email-address"
                            autoCapitalize="none"
                        />

                        <Button
                            title="إرسال الرمز"
                            onPress={handleStartRecovery}
                            style={styles.mainBtn}
                        />
                    </View>

                    <Text style={styles.bottomText}> يمن جرام ©  2026</Text>
                </ScrollView>
            </ImageBackground>

            {/* ✅ نافذة التأكيد */}
            <Modal
                visible={showConfirmModal}
                type="info"
                title="تأكيد البريد الإلكتروني"
                confirmText="متأكد"
                cancelText="تغيير"
                onConfirm={() => {
                    setShowConfirmModal(false);
                    initiateProcess();
                }}
                onCancel={() => setShowConfirmModal(false)}
            >
                <View style={styles.confirmContent}>
                    <Text style={styles.confirmText}>
                        لضمان اكتمال العملية بنجاح، يرجى التأكد من أن هذا هو البريد المرتبط بحسابك:
                    </Text>
                    <View style={styles.emailBadge}>
                        <Text style={styles.emailText}>{email}</Text>
                    </View>
                </View>
            </Modal>

            {/* نافذة استعادة كلمة المرور */}
            <RecoveryDialog
                visible={showDialog}
                email={email}
                onClose={() => setShowDialog(false)}
                onSuccess={() => {
                    setShowDialog(false);
                    navigation.reset({ index: 0, routes: [{ name: 'Login' }] });
                }}
            />
        </KeyboardAvoidingView>
  );
}
