// src/models/ProductCategory.js
// =============================================
// نموذج فئة المنتج (Product Category Model)
// المسؤول عن تصنيف المنتجات وتنظيمها
// =============================================

import { Model } from '@nozbe/watermelondb';
import { field, date, readonly } from '@nozbe/watermelondb/decorators';
import { Q } from '@nozbe/watermelondb';

export default class ProductCategory extends Model {
  // ===== 1. اسم الجدول =====
  static table = 'product_categories';

  // ===== 2. الحقول الأساسية =====

  // اسم الفئة (مثال: إلكترونيات، ملابس، مواد غذائية)
  @field('name') name;

  // وصف الفئة (اختياري)
  @field('description') description;

  // حالة التفعيل (0 = غير مفعل، 1 = مفعل)
  @field('is_active') isActive;

  // ===== 3. التواريخ التلقائية =====

  @readonly @date('created_at') createdAt;
  @readonly @date('updated_at') updatedAt;

  // ===== 4. العلاقات =====

  static associations = {
    // فئة واحدة → لديه عدة منتجات
    products: { type: 'has_many', foreignKey: 'category' },
  };

  // ===== 5. دوال مساعدة =====

  /**
   * التحقق من نشاط الفئة
   * @returns {boolean}
   */
  isActiveCategory() {
    return this.isActive === 1 || this.isActive === true;
  }

  /**
   * جلب جميع المنتجات في هذه الفئة
   * @returns {Promise<Product[]>}
   */
  async getProducts() {
    return this.collections.get('products').query(
      Q.where('category', this.id)
    ).fetch();
  }

  /**
   * الحصول على عدد المنتجات في الفئة
   * @returns {Promise<number>}
   */
  async getProductCount() {
    const products = await this.getProducts();
    return products.length;
  }

  /**
   * الحصول على إجمالي قيمة المخزون في الفئة
   * @returns {Promise<number>}
   */
  async getTotalStockValue() {
    const products = await this.getProducts();
    return products.reduce((sum, p) => sum + p.getStockValue(), 0);
  }

  /**
   * الحصول على إجمالي الكمية في الفئة
   * @returns {Promise<number>}
   */
  async getTotalQuantity() {
    const products = await this.getProducts();
    return products.reduce((sum, p) => sum + (p.quantity || 0), 0);
  }

  /**
   * الحصول على المنتجات منخفضة المخزون في الفئة
   * @returns {Promise<Product[]>}
   */
  async getLowStockProducts() {
    const products = await this.getProducts();
    return products.filter(p => p.isLowStock());
  }

  /**
   * الحصول على المنتجات النافذة في الفئة
   * @returns {Promise<Product[]>}
   */
  async getOutOfStockProducts() {
    const products = await this.getProducts();
    return products.filter(p => p.quantity <= 0);
  }

  /**
   * الحصول على اسم الفئة مع عدد المنتجات
   * @returns {Promise<string>}
   */
  async getDisplayName() {
    const count = await this.getProductCount();
    return `${this.name} (${count} منتج)`;
  }

  // ===== 6. دوال ثابتة =====

  /**
   * الحصول على الفئات النشطة فقط
   * @param {ProductCategory[]} categories
   * @returns {ProductCategory[]}
   */
  static getActiveCategories(categories) {
    return categories.filter(c => c.isActiveCategory());
  }

  /**
   * تجميع الفئات حسب الأحرف الأولى (للفهرسة)
   * @param {ProductCategory[]} categories
   * @returns {Object}
   */
  static groupByFirstLetter(categories) {
    const groups = {};
    for (const category of categories) {
      const firstLetter = category.name?.charAt(0) || '#';
      if (!groups[firstLetter]) {
        groups[firstLetter] = [];
      }
      groups[firstLetter].push(category);
    }
    return groups;
  }
}