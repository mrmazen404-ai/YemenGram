// src/shared/navigation/AuthNavigator.js
// =============================================
// تنقل شاشات المصادقة (Authentication Navigator)
// =============================================

import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

// ===== شاشات المصادقة =====
import SplashScreen from '../../modules/auth/screens/SplashScreen';
import LoginScreen from '../../modules/auth/screens/LoginScreen';
import RegisterScreen from '../../modules/auth/screens/RegisterScreen';
import OTPVerifyScreen from '../../modules/auth/screens/OTPVerifyScreen';
import OTPPhoneScreen from '../../modules/auth/screens/OTPPhoneScreen';
import ForgotPasswordScreen from '../../modules/auth/recovery/RecoveryScreen';

const Stack = createNativeStackNavigator();

export default function AuthNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false, animation: 'fade' }}>
      <Stack.Screen name="Splash" component={SplashScreen} />
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="Register" component={RegisterScreen} />
      <Stack.Screen name="OTPVerify" component={OTPVerifyScreen} />
      <Stack.Screen name="OTPPhone" component={OTPPhoneScreen} />
      <Stack.Screen name="ForgotPassword" component={ForgotPasswordScreen} />
    </Stack.Navigator>
  );
}