// src/modules/settings/profile/components/ChangePasswordModal.js
// بروتوكول تحديث الميثاق السري (Sovereign Password Change Modal)

import React, { useState, useRef, useEffect } from 'react';
import { View, Text, StyleSheet, Animated } from 'react-native';
import Modal from '../../../../shared/components/Modal';
import Input from '../../../../shared/components/Input';
import { useAuth } from '../../../../shared/contexts/AuthContext';
import { Colors } from '../../../../shared/utils/colors';

export default function ChangePasswordModal({ visible, onClose, onNotify }) {
  const { changePassword } = useAuth();

  const [step, setStep] = useState(1); // 1: Old Pass, 2: New Pass
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // إعادة ضبط الحالة عند الإغلاق
  useEffect(() => {
    if (!visible) {
      setStep(1);
      setOldPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setError('');
    }
  }, [visible]);

  // ✅ حساب قوة كلمة المرور
  const getPasswordStrength = () => {
    if (newPassword.length === 0) return { label: '', color: Colors.gray, width: '0%' };
    if (newPassword.length < 8) return { label: 'ضعيفة', color: Colors.red, width: '30%' };

    let score = 0;
    if (newPassword.length >= 12) score++;
    if (/[A-Z]/.test(newPassword)) score++;
    if (/[a-z]/.test(newPassword)) score++;
    if (/[0-9]/.test(newPassword)) score++;
    if (/[!@#$%^&*]/.test(newPassword)) score++;

    if (score >= 4) return { label: 'قوية جداً', color: Colors.green, width: '100%' };
    if (score >= 2) return { label: 'متوسطة', color: Colors.gold, width: '70%' };
    return { label: 'ضعيفة', color: Colors.red, width: '30%' };
  };

  const strength = getPasswordStrength();

  const handleNext = () => {
    if (!oldPassword) {
      setError('يرجى إدخال كلمة المرور الحالية');
      return;
    }
    setStep(2);
    setError('');
  };

  const handleSubmit = async () => {
    if (newPassword !== confirmPassword) {
      setError('كلمتا المرور غير متطابقتين');
      return;
    }
    if (strength.label === 'ضعيفة') {
      setError('كلمة المرور الجديدة ضعيفة جداً');
      return;
    }

    setLoading(true);
    try {
      await changePassword(oldPassword, newPassword);
      onNotify?.({ message: 'تم تحديث كلمة المرور بنجاح', type: 'success' });
      onClose();
    } catch (err) {
      setError(err.message || 'فشل تحديث كلمة المرور');
      if (err.message.includes('الحالية')) setStep(1);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      visible={visible}
      title={step === 1 ? "تأكيد الهوية" : "تغيير كلمة المرور"}
      message={step === 1 ? "يرجى إدخال كلمة المرور الحالية" : "أدخل كلمة المرور الجديدة وتأكد من قوتها"}
      confirmText={step === 1 ? "التالي" : "تحديث"}
      cancelText="إلغاء"
      onConfirm={step === 1 ? handleNext : handleSubmit}
      onCancel={onClose}
      confirmLoading={loading}
    >
      <View style={styles.content}>
        {step === 1 ? (
          <Input
            label="كلمة المرور الحالية"
            icon="lock-closed-outline"
            secureTextEntry
            value={oldPassword}
            onChangeText={(v) => { setOldPassword(v); setError(''); }}
            error={error}
          />
        ) : (
          <>
            <Input
              label="كلمة المرور الجديدة"
              icon="key-outline"
              secureTextEntry
              value={newPassword}
              onChangeText={(v) => { setNewPassword(v); setError(''); }}
            />

            {/* مقياس القوة */}
            <View style={styles.strengthContainer}>
              <View style={styles.strengthBarBg}>
                <View style={[styles.strengthBarFill, { width: strength.width, backgroundColor: strength.color }]} />
              </View>
              <Text style={[styles.strengthLabel, { color: strength.color }]}>{strength.label}</Text>
            </View>

            <Input
              label="تأكيد كلمة المرور"
              icon="checkmark-circle-outline"
              secureTextEntry
              value={confirmPassword}
              onChangeText={(v) => { setConfirmPassword(v); setError(''); }}
              error={error}
            />
          </>
        )}
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  content: {
    marginTop: 10,
    width: '100%',
  },
  strengthContainer: {
    width: '100%',
    marginTop: -5,
    marginBottom: 15,
    paddingHorizontal: 5,
  },
  strengthBarBg: {
    width: '100%',
    height: 4,
    backgroundColor: '#E2E8F0',
    borderRadius: 2,
    overflow: 'hidden',
  },
  strengthBarFill: {
    height: '100%',
    borderRadius: 2,
  },
  strengthLabel: {
    fontSize: 10,
    fontFamily: 'Tajawal-Bold',
    textAlign: 'right',
    marginTop: 4,
  },
});
