/**
 * شاشة انتهاء الفترة المجانية (Trial Expired Screen)
 */

import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Colors } from '../../../shared/utils/colors';

export default function TrialExpiredScreen({ navigation }) {
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.header}>
        <MaterialCommunityIcons name="timer-off-outline" size={80} color="#EF4444" />
        <Text style={styles.title}>انتهت فترتك المجانية</Text>
        <Text style={styles.subtitle}>
          لقد استفدت من 30 يوماً من السيادة المالية. نظامك الآن في وضع "القراءة فقط" حتى يتم الترقية.
        </Text>
      </View>

      <View style={styles.impactBox}>
        <Text style={styles.impactTitle}>ماذا فقدت الآن؟</Text>
        <Text style={styles.impactItem}>• إضافة فواتير أو قيود جديدة.</Text>
        <Text style={styles.impactItem}>• مزامنة البيانات بين الأجهزة.</Text>
        <Text style={styles.impactItem}>• الدعم الفني المباشر.</Text>
      </View>

      <TouchableOpacity
        style={styles.upgradeBtn}
        onPress={() => navigation.navigate('PlansCatalog')}
      >
        <Text style={styles.upgradeBtnText}>اختر باقتك المدفوعة الآن</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.laterBtn}
        onPress={() => navigation.navigate('Dashboard')}
      >
        <Text style={styles.laterText}>استكشاف البيانات السابقة فقط</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC' },
  content: { padding: 25, paddingTop: 80, alignItems: 'center' },
  header: { alignItems: 'center', marginBottom: 40 },
  title: { fontSize: 24, fontFamily: 'Tajawal-Bold', color: '#0F172A', marginTop: 20 },
  subtitle: { fontSize: 14, fontFamily: 'Tajawal-Medium', color: '#64748B', textAlign: 'center', marginTop: 10, lineHeight: 22 },
  impactBox: { backgroundColor: '#FFF', borderRadius: 20, padding: 20, width: '100%', marginBottom: 40, borderLeftWidth: 4, borderLeftColor: '#EF4444' },
  impactTitle: { fontSize: 15, fontFamily: 'Tajawal-Bold', color: '#334155', marginBottom: 10, textAlign: 'right' },
  impactItem: { fontSize: 13, fontFamily: 'Tajawal-Medium', color: '#64748B', textAlign: 'right', marginBottom: 5 },
  upgradeBtn: { backgroundColor: Colors.navy, width: '100%', borderRadius: 16, paddingVertical: 18, alignItems: 'center', elevation: 5 },
  upgradeBtnText: { color: '#FFF', fontFamily: 'Tajawal-Bold', fontSize: 16 },
  laterBtn: { marginTop: 20 },
  laterText: { color: '#94A3B8', fontFamily: 'Tajawal-Bold', fontSize: 13 }
});
