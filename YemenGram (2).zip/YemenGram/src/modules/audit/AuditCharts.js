// src/modules/audit/AuditCharts.js
// مكوّن "المصفوفة السيادية الثلاثية" (The Sovereign Triple Matrix)
// رسم بياني بـ 3 مسارات متداخلة: أخضر (آمن)، أصفر (تنبيه)، أحمر (خطر)

import React from 'react';
import { View, Text, StyleSheet, Dimensions } from 'react-native';
import Svg, { Path, Defs, LinearGradient, Stop, Line } from 'react-native-svg';

const { width } = Dimensions.get('window');

const SingleLayer = ({ data, color, id, chartWidth, chartHeight, maxVal }) => {
  if (!data || data.length < 2) return null;
  const step = chartWidth / (data.length - 1);

  const generateLinePath = () => {
    let path = `M 0 ${chartHeight - (data[0] / maxVal) * chartHeight}`;
    data.forEach((val, i) => {
      const x = i * step;
      const y = chartHeight - (val / maxVal) * chartHeight;
      path += ` L ${x} ${y}`;
    });
    return path;
  };

  const generateAreaPath = () => {
    const line = generateLinePath();
    return `${line} L ${chartWidth} ${chartHeight} L 0 ${chartHeight} Z`;
  };

  return (
    <>
      <Defs>
        <LinearGradient id={`grad-${id}`} x1="0" y1="0" x2="0" y2="1">
          <Stop offset="0" stopColor={color} stopOpacity="0.12" />
          <Stop offset="1" stopColor={color} stopOpacity="0" />
        </LinearGradient>
      </Defs>
      <Path d={generateAreaPath()} fill={`url(#grad-${id})`} />
      <Path d={generateLinePath()} fill="none" stroke={color} strokeWidth="2.2" strokeLinejoin="round" strokeLinecap="round" />
    </>
  );
};

export const TriplePulseChart = ({ greenData, yellowData, redData, labels }) => {
  const chartWidth = width - 80;
  const chartHeight = 150;

  const allValues = [...greenData, ...yellowData, ...redData];
  const maxVal = Math.max(...allValues, 10);

  return (
    <View style={styles.outerContainer}>
      <View style={styles.yAxis}>
         <Text style={styles.axisText}>{maxVal}</Text>
         <Text style={styles.axisText}>{Math.round(maxVal / 2)}</Text>
         <Text style={styles.axisText}>0</Text>
      </View>

      <View style={styles.chartWrapper}>
        <Svg width={chartWidth} height={chartHeight}>
          {/* شبكة المراقبة الجنائية */}
          {[0, 0.25, 0.5, 0.75, 1].map((p, i) => (
            <Line key={i} x1="0" y1={p * chartHeight} x2={chartWidth} y2={p * chartHeight} stroke="#E2E8F0" strokeWidth="0.5" />
          ))}

          {/* المسارات الثلاثة المتداخلة */}
          <SingleLayer id="green" data={greenData} color="#2ECC71" chartWidth={chartWidth} chartHeight={chartHeight} maxVal={maxVal} />
          <SingleLayer id="yellow" data={yellowData} color="#F1C40F" chartWidth={chartWidth} chartHeight={chartHeight} maxVal={maxVal} />
          <SingleLayer id="red" data={redData} color="#E74C3C" chartWidth={chartWidth} chartHeight={chartHeight} maxVal={maxVal} />
        </Svg>

        <View style={styles.xAxis}>
           {labels.map((l, i) => (
             <Text key={i} style={styles.axisText}>{l}</Text>
           ))}
        </View>

        {/* دليل السيادة (The Legend) */}
        <View style={styles.legend}>
           <View style={styles.legendItem}><View style={[styles.dot, {backgroundColor:'#2ECC71'}]} /><Text style={styles.legendText}>آمن</Text></View>
           <View style={styles.legendItem}><View style={[styles.dot, {backgroundColor:'#F1C40F'}]} /><Text style={styles.legendText}>تنبيه</Text></View>
           <View style={styles.legendItem}><View style={[styles.dot, {backgroundColor:'#E74C3C'}]} /><Text style={styles.legendText}>خطر</Text></View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  outerContainer: { flexDirection: 'row-reverse', paddingHorizontal: 10, paddingVertical: 20, backgroundColor: '#FFFFFF', borderRadius: 28 },
  yAxis: { justifyContent: 'space-between', paddingLeft: 10, height: 150, alignItems: 'flex-start' },
  chartWrapper: { flex: 1 },
  xAxis: { flexDirection: 'row-reverse', justifyContent: 'space-between', marginTop: 10 },
  axisText: { fontSize: 8, fontFamily: 'Tajawal-Medium', color: '#94A3B8' },
  legend: { flexDirection: 'row-reverse', justifyContent: 'center', gap: 18, marginTop: 20 },
  legendItem: { flexDirection: 'row-reverse', alignItems: 'center', gap: 6 },
  dot: { width: 10, height: 10, borderRadius: 3 },
  legendText: { fontSize: 10, fontFamily: 'Tajawal-Bold', color: '#64748B' }
});
