// src/models/CustomerContact.js
// =============================================
// نموذج جهة اتصال العميل (Customer Contact Model)
// المسؤول عن إدارة جهات الاتصال المتعددة للعميل
// =============================================

import { Model } from '@nozbe/watermelondb';
import { field, date, readonly } from '@nozbe/watermelondb/decorators';
import { Q } from '@nozbe/watermelondb';

export default class CustomerContact extends Model {
  // ===== 1. اسم الجدول =====
  static table = 'customer_contacts';

  // ===== 2. الحقول الأساسية =====

  // معرف العميل المرتبط بهذه الجهة
  @field('customer_id') customerId;

  // اسم جهة الاتصال
  @field('name') name;

  // رقم الهاتف
  @field('phone') phone;

  // البريد الإلكتروني
  @field('email') email;

  // المنصب/الوظيفة
  @field('position') position;

  // هل هي جهة اتصال رئيسية؟ (1 = رئيسية، 0 = فرعية)
  @field('is_primary') isPrimary;

  // ===== 3. التواريخ التلقائية =====

  @readonly @date('created_at') createdAt;
  @readonly @date('updated_at') updatedAt;

  // ===== 4. العلاقات =====

  static associations = {
    // كل جهة اتصال تنتمي إلى عميل واحد
    customer: { type: 'belongs_to', key: 'customer_id' },
  };

  // ===== 5. دوال مساعدة =====

  /**
   * التحقق من أن جهة الاتصال رئيسية
   * @returns {boolean}
   */
  isPrimaryContact() {
    return this.isPrimary === 1 || this.isPrimary === true;
  }

  /**
   * الحصول على اسم جهة الاتصال مع المنصب
   * @returns {string}
   */
  getDisplayName() {
    return this.position ? `${this.name} (${this.position})` : this.name;
  }

  /**
   * الحصول على معلومات الاتصال الكاملة
   * @returns {string}
   */
  getFullContact() {
    const parts = [this.name];
    if (this.phone) parts.push(`📞 ${this.phone}`);
    if (this.email) parts.push(`✉️ ${this.email}`);
    if (this.position) parts.push(`(${this.position})`);
    if (this.isPrimaryContact()) parts.push('⭐ رئيسي');
    return parts.join(' ');
  }

  /**
   * جلب العميل المرتبط
   * @returns {Promise<Customer>}
   */
  async getCustomer() {
    return this.collections.get('customers').find(this.customerId);
  }

  /**
   * الحصول على اسم العميل
   * @returns {Promise<string>}
   */
  async getCustomerName() {
    const customer = await this.getCustomer();
    return customer ? customer.name : 'عميل غير معروف';
  }

  /**
   * جعل جهة الاتصال رئيسية (وتحديث الجهات الأخرى)
   * @param {Database} database
   * @returns {Promise<void>}
   */
  async setAsPrimary(database) {
    await database.write(async () => {
      // 1. إزالة الرئيسية من جميع جهات الاتصال الأخرى للعميل
      const existingPrimary = await this.collections.get('customer_contacts').query(
        Q.where('customer_id', this.customerId),
        Q.where('is_primary', true)
      ).fetch();

      for (const contact of existingPrimary) {
        if (contact.id !== this.id) {
          await contact.update(() => {
            contact.isPrimary = false;
          });
        }
      }

      // 2. جعل هذه الجهة رئيسية
      await this.update(() => {
        this.isPrimary = true;
      });
    });
  }
}