// src/shared/utils/typography.js
// =============================================
// نظام الطباعة الموحد (Typography System)
// مجموعة من الثوابت والدوال لإدارة الخطوط والأحجام
// =============================================

import { Colors } from './colors';
import { spacing } from './spacing';

// =============================================
// 1. الثوابت الأساسية
// =============================================

/**
 * أنواع الخطوط المتاحة
 */
export const FONT_FAMILIES = {
  BOLD: 'Tajawal-Bold',
  MEDIUM: 'Tajawal-Medium',
  REGULAR: 'Tajawal-Regular',
  LIGHT: 'Tajawal-Light',
  EXTRA_BOLD: 'Tajawal-ExtraBold',
  EXTRA_LIGHT: 'Tajawal-ExtraLight',
  BLACK: 'Tajawal-Black',
};

/**
 * أحجام الخطوط
 */
export const FONT_SIZES = {
  /** 8px */
  XS: 8,
  /** 10px */
  SM: 10,
  /** 12px */
  MD: 12,
  /** 14px */
  BASE: 14,
  /** 16px */
  LG: 16,
  /** 18px */
  XL: 18,
  /** 20px */
  XXL: 20,
  /** 24px */
  XXXL: 24,
  /** 28px */
  HUGE: 28,
  /** 32px */
  GIANT: 32,
  /** 36px */
  MEGA: 36,
  /** 40px */
  ULTRA: 40,
};

/**
 * أوزان الخطوط
 */
export const FONT_WEIGHTS = {
  THIN: '100',
  EXTRA_LIGHT: '200',
  LIGHT: '300',
  REGULAR: '400',
  MEDIUM: '500',
  SEMI_BOLD: '600',
  BOLD: '700',
  EXTRA_BOLD: '800',
  BLACK: '900',
};

// =============================================
// 2. تعريفات الأنماط الأساسية
// =============================================

export const typography = {
  // ===== العناوين =====
  h1: {
    fontFamily: FONT_FAMILIES.BOLD,
    fontSize: FONT_SIZES.MEGA,
    color: Colors.dark,
    letterSpacing: 1,
  },
  h2: {
    fontFamily: FONT_FAMILIES.BOLD,
    fontSize: FONT_SIZES.ULTRA,
    color: Colors.dark,
    letterSpacing: 0.5,
  },
  h3: {
    fontFamily: FONT_FAMILIES.BOLD,
    fontSize: FONT_SIZES.GIANT,
    color: Colors.dark,
  },
  h4: {
    fontFamily: FONT_FAMILIES.BOLD,
    fontSize: FONT_SIZES.HUGE,
    color: Colors.dark,
  },
  h5: {
    fontFamily: FONT_FAMILIES.BOLD,
    fontSize: FONT_SIZES.XXL,
    color: Colors.dark,
  },
  h6: {
    fontFamily: FONT_FAMILIES.BOLD,
    fontSize: FONT_SIZES.XL,
    color: Colors.dark,
  },

  // ===== النصوص الأساسية =====
  body: {
    fontFamily: FONT_FAMILIES.REGULAR,
    fontSize: FONT_SIZES.BASE,
    color: Colors.dark,
    lineHeight: FONT_SIZES.BASE * 1.6,
  },
  bodyMedium: {
    fontFamily: FONT_FAMILIES.MEDIUM,
    fontSize: FONT_SIZES.BASE,
    color: Colors.dark,
    lineHeight: FONT_SIZES.BASE * 1.6,
  },
  bodySmall: {
    fontFamily: FONT_FAMILIES.REGULAR,
    fontSize: FONT_SIZES.SM,
    color: Colors.gray,
    lineHeight: FONT_SIZES.SM * 1.5,
  },
  bodyLarge: {
    fontFamily: FONT_FAMILIES.REGULAR,
    fontSize: FONT_SIZES.LG,
    color: Colors.dark,
    lineHeight: FONT_SIZES.LG * 1.6,
  },

  // ===== النصوص المميزة =====
  caption: {
    fontFamily: FONT_FAMILIES.REGULAR,
    fontSize: FONT_SIZES.SM,
    color: Colors.gray,
    lineHeight: FONT_SIZES.SM * 1.4,
  },
  overline: {
    fontFamily: FONT_FAMILIES.MEDIUM,
    fontSize: FONT_SIZES.XS,
    color: Colors.gray,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  subtitle: {
    fontFamily: FONT_FAMILIES.MEDIUM,
    fontSize: FONT_SIZES.MD,
    color: Colors.gray,
    lineHeight: FONT_SIZES.MD * 1.5,
  },

  // ===== الأزرار =====
  button: {
    fontFamily: FONT_FAMILIES.MEDIUM,
    fontSize: FONT_SIZES.BASE,
    color: Colors.white,
  },
  buttonSmall: {
    fontFamily: FONT_FAMILIES.MEDIUM,
    fontSize: FONT_SIZES.SM,
    color: Colors.white,
  },
  buttonLarge: {
    fontFamily: FONT_FAMILIES.MEDIUM,
    fontSize: FONT_SIZES.LG,
    color: Colors.white,
  },

  // ===== الحقول =====
  input: {
    fontFamily: FONT_FAMILIES.REGULAR,
    fontSize: FONT_SIZES.BASE,
    color: Colors.dark,
  },
  inputLabel: {
    fontFamily: FONT_FAMILIES.MEDIUM,
    fontSize: FONT_SIZES.SM,
    color: Colors.gray,
  },
  inputError: {
    fontFamily: FONT_FAMILIES.REGULAR,
    fontSize: FONT_SIZES.SM,
    color: Colors.red,
  },

  // ===== الحالات =====
  success: {
    color: Colors.green,
  },
  error: {
    color: Colors.red,
  },
  warning: {
    color: Colors.orange,
  },
  info: {
    color: Colors.blue,
  },
  muted: {
    color: Colors.gray,
  },
  gold: {
    color: Colors.gold,
  },
  navy: {
    color: Colors.navy,
  },

  // ===== التنسيق =====
  center: {
    textAlign: 'center',
  },
  right: {
    textAlign: 'right',
  },
  left: {
    textAlign: 'left',
  },
  justify: {
    textAlign: 'justify',
  },

  // ===== الديكور =====
  underline: {
    textDecorationLine: 'underline',
  },
  lineThrough: {
    textDecorationLine: 'line-through',
  },
  uppercase: {
    textTransform: 'uppercase',
  },
  lowercase: {
    textTransform: 'lowercase',
  },
  capitalize: {
    textTransform: 'capitalize',
  },
};

// =============================================
// 3. دوال إنشاء الأنماط
// =============================================

/**
 * إنشاء نمط نصي
 * @param {Object} options - خيارات النص
 * @param {string} options.family - نوع الخط
 * @param {number} options.size - حجم الخط
 * @param {string} options.color - لون النص
 * @param {number} options.lineHeight - ارتفاع السطر
 * @param {number} options.letterSpacing - تباعد الأحرف
 * @param {string} options.align - محاذاة النص
 * @param {string} options.transform - تحويل النص
 * @param {string} options.decoration - زخرفة النص
 * @returns {Object}
 */
export const createTextStyle = (options = {}) => {
  const {
    family = FONT_FAMILIES.REGULAR,
    size = FONT_SIZES.BASE,
    color = Colors.dark,
    lineHeight = size * 1.6,
    letterSpacing = 0,
    align = 'right',
    transform = 'none',
    decoration = 'none',
  } = options;

  const style = {
    fontFamily: family,
    fontSize: size,
    color,
  };

  if (lineHeight) style.lineHeight = lineHeight;
  if (letterSpacing) style.letterSpacing = letterSpacing;
  if (align) style.textAlign = align;
  if (transform !== 'none') style.textTransform = transform;
  if (decoration !== 'none') style.textDecorationLine = decoration;

  return style;
};

/**
 * إنشاء نمط عنوان
 * @param {number} level - مستوى العنوان (1-6)
 * @param {Object} options - خيارات إضافية
 * @returns {Object}
 */
export const createHeading = (level, options = {}) => {
  const sizes = {
    1: FONT_SIZES.MEGA,
    2: FONT_SIZES.ULTRA,
    3: FONT_SIZES.GIANT,
    4: FONT_SIZES.HUGE,
    5: FONT_SIZES.XXL,
    6: FONT_SIZES.XL,
  };

  const size = sizes[level] || FONT_SIZES.XL;

  return createTextStyle({
    family: FONT_FAMILIES.BOLD,
    size,
    color: Colors.dark,
    lineHeight: size * 1.3,
    ...options,
  });
};

/**
 * إنشاء نمط زر
 * @param {string} size - حجم الزر (small, medium, large)
 * @param {Object} options - خيارات إضافية
 * @returns {Object}
 */
export const createButtonText = (size = 'medium', options = {}) => {
  const sizes = {
    small: FONT_SIZES.SM,
    medium: FONT_SIZES.BASE,
    large: FONT_SIZES.LG,
  };

  const fontSize = sizes[size] || FONT_SIZES.BASE;

  return createTextStyle({
    family: FONT_FAMILIES.MEDIUM,
    size: fontSize,
    color: Colors.white,
    lineHeight: fontSize * 1.4,
    ...options,
  });
};

/**
 * إنشاء نمط نص جسم
 * @param {string} size - حجم النص (small, medium, large)
 * @param {Object} options - خيارات إضافية
 * @returns {Object}
 */
export const createBodyText = (size = 'medium', options = {}) => {
  const sizes = {
    small: FONT_SIZES.SM,
    medium: FONT_SIZES.BASE,
    large: FONT_SIZES.LG,
  };

  const fontSize = sizes[size] || FONT_SIZES.BASE;

  return createTextStyle({
    family: FONT_FAMILIES.REGULAR,
    size: fontSize,
    color: Colors.dark,
    lineHeight: fontSize * 1.6,
    ...options,
  });
};

// =============================================
// 4. دوال مساعدة
// =============================================

/**
 * الحصول على حجم خط محدد
 * @param {string|number} size - حجم الخط
 * @returns {number}
 */
export const getFontSize = (size) => {
  if (typeof size === 'number') return size;
  return FONT_SIZES[size] || FONT_SIZES.BASE;
};

/**
 * الحصول على عائلة خط محدد
 * @param {string} family - عائلة الخط
 * @returns {string}
 */
export const getFontFamily = (family) => {
  return FONT_FAMILIES[family] || FONT_FAMILIES.REGULAR;
};

/**
 * دمج أنماط النصوص
 * @param {...Object} styles - أنماط النصوص
 * @returns {Object}
 */
export const mergeTextStyles = (...styles) => {
  return Object.assign({}, ...styles);
};

// =============================================
// 5. كائن الطباعة الرئيسي
// =============================================

export const typographySystem = {
  // الثوابت
  families: FONT_FAMILIES,
  sizes: FONT_SIZES,
  weights: FONT_WEIGHTS,

  // الأنماط الأساسية
  ...typography,

  // دوال الإنشاء
  create: createTextStyle,
  heading: createHeading,
  button: createButtonText,
  body: createBodyText,

  // دوال مساعدة
  getSize: getFontSize,
  getFamily: getFontFamily,
  merge: mergeTextStyles,
};

export default typographySystem;