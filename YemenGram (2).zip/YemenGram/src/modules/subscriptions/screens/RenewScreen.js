import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import LocalDB from '../../database/localDB';
import SubscriptionCoreService from '../services/SubscriptionCoreService';
import { Colors } from '../../../shared/utils/colors';

export default function RenewScreen() {
  const navigation = useNavigation();
  const [subscription, setSubscription] = React.useState(null);
  const [loading, setLoading] = React.useState(false);

  React.useEffect(() => {
    (async () => {
      try {
        const user = await LocalDB.getUser();
        if (!user?.id) return;

        const row = await LocalDB.queryOne(
          'SELECT * FROM subscriptions WHERE user_id = ? ORDER BY created_at DESC LIMIT 1',
          [user.id]
        );
        setSubscription(row || null);
      } catch (error) {
        console.error(error);
      }
    })();
  }, []);

  const handleRenew = async (planKey) => {
    if (!subscription) {
      Alert.alert('تنبيه', 'لا يوجد اشتراك سابق لتجديده. يرجى اختيار باقة جديدة.');
      return;
    }

    const price = planKey === 'monthly' ? 3000 : 30000;
    const label = planKey === 'monthly' ? 'شهري' : 'سنوي';

    Alert.alert(
      'تأكيد طلب التجديد',
      `هل تريد تجديد اشتراكك بنظام ${label} بسعر ${price} ر.ي؟`,
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'تأكيد التجديد',
          onPress: async () => {
            try {
              setLoading(true);
              const service = new SubscriptionCoreService();

              // حدث الترقية/التجديد السيادي
              await service.processEvent(subscription.id, 'UPGRADE_REQUEST', {
                userId: subscription.user_id,
                plan: planKey,
                data: {
                  price: price,
                  requestedAt: Date.now(),
                }
              });

              Alert.alert(
                'تم تسجيل الطلب',
                'يرجى رفع إيصال الدفع لتأكيد عملية التجديد.',
                [
                  {
                    text: 'رفع الإيصال',
                    onPress: () => navigation.navigate('SubscriptionPayment', { subscriptionId: subscription.id })
                  },
                  { text: 'العودة', onPress: () => navigation.goBack() }
                ]
              );
            } catch (error) {
              Alert.alert('خطأ', error?.message || 'فشل عملية التجديد');
            } finally {
              setLoading(false);
            }
          }
        }
      ]
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.card}>
        <Ionicons name="refresh-circle" size={80} color={Colors.gold} />
        <Text style={styles.title}>تجديد السيادة المالية</Text>
        <Text style={styles.subtitle}>
          الخطة الحالية: <Text style={styles.planText}>{subscription?.plan || 'Starter'}</Text>
        </Text>

        <TouchableOpacity
          style={styles.actionButton}
          onPress={() => handleRenew('monthly')}
          disabled={loading}
        >
          {loading ? <ActivityIndicator color="#FFF" /> : <Text style={styles.actionText}>تجديد شهري (3,000 ر.ي)</Text>}
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.actionButtonSecondary}
          onPress={() => handleRenew('annual')}
          disabled={loading}
        >
          <Text style={styles.actionTextSecondary}>تجديد سنوي (30,000 ر.ي)</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <Text style={styles.backText}>إلغاء والعودة</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
    padding: 20,
    justifyContent: 'center',
  },
  card: {
    backgroundColor: '#FFF',
    borderRadius: 24,
    padding: 30,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 20,
    elevation: 10,
    borderWidth: 1,
    borderColor: '#F1F5F9',
  },
  title: {
    fontSize: 22,
    fontFamily: 'Tajawal-Bold',
    marginTop: 20,
    color: Colors.navy,
  },
  subtitle: {
    fontSize: 14,
    fontFamily: 'Tajawal-Medium',
    color: '#64748B',
    marginTop: 8,
    marginBottom: 30,
  },
  planText: {
    color: Colors.navy,
    fontFamily: 'Tajawal-Bold',
  },
  actionButton: {
    backgroundColor: Colors.navy,
    borderRadius: 14,
    paddingVertical: 16,
    width: '100%',
    alignItems: 'center',
    marginBottom: 12,
  },
  actionButtonSecondary: {
    backgroundColor: '#FFF',
    borderRadius: 14,
    paddingVertical: 16,
    width: '100%',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: Colors.navy,
    marginBottom: 20,
  },
  actionText: {
    color: '#FFF',
    fontFamily: 'Tajawal-Bold',
    fontSize: 16,
  },
  actionTextSecondary: {
    color: Colors.navy,
    fontFamily: 'Tajawal-Bold',
    fontSize: 16,
  },
  backButton: {
    paddingVertical: 10,
  },
  backText: {
    color: '#94A3B8',
    fontFamily: 'Tajawal-Medium',
    fontSize: 14,
  },
});
