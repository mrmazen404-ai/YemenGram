// src/modules/settings/profile/components/ChangeEmailModal.js
// بروتوكول نقل الملكية البريدية (Sovereign Email Change Modal)

import React, { useState, useRef, useEffect } from 'react';
import { View, Text, StyleSheet, TextInput, Keyboard } from 'react-native';
import Modal from '../../../../shared/components/Modal';
import Input from '../../../../shared/components/Input';
import Button from '../../../../shared/components/Button';
import { useAuth } from '../../../../shared/contexts/AuthContext';
import { Colors } from '../../../../shared/utils/colors';
import { ProfileService } from '../ProfileService';
import AuthService from '../../../auth/services/authService';
import * as Haptics from 'expo-haptics';

export default function ChangeEmailModal({ visible, onClose, onNotify }) {
  const { user, sendOTP, verifyOTP, updateUserData } = useAuth();
  const [step, setStep] = useState(1); // 1: Password, 2: New Email, 3: OTP
  const [password, setPassword] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [otpCode, setOtpCode] = useState(['', '', '', '', '', '']);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [focusedIndex, setFocusedIndex] = useState(0);
  const inputRefs = useRef([]);

  const triggerHaptic = (style = Haptics.ImpactFeedbackStyle.Light) => {
    Haptics.impactAsync(style);
  };

  // تصفير الحالة عند الإغلاق
  useEffect(() => {
    if (!visible) {
      setStep(1);
      setPassword('');
      setNewEmail('');
      setOtpCode(['', '', '', '', '', '']);
      setError('');
      Keyboard.dismiss();
    }
  }, [visible]);

  const handleVerifyPassword = async () => {
    if (!password) {
      setError('يرجى إدخال كلمة المرور');
      return;
    }
    setLoading(true);
    setError('');
    try {
      const result = await AuthService.login(user.email, password);
      if (result.success) {
        triggerHaptic(Haptics.ImpactFeedbackStyle.Medium);
        setStep(2);
      }
    } catch (err) {
      setError('كلمة المرور غير صحيحة');
    } finally {
      setLoading(false);
    }
  };

  const handleRequestOTP = async () => {
    if (!newEmail.includes('@') || newEmail.length < 5) {
      setError('يرجى إدخال بريد إلكتروني صحيح');
      return;
    }
    setLoading(true);
    setError('');
    try {
      await ProfileService.validateNewEmail(newEmail);
      await sendOTP(newEmail);
      triggerHaptic(Haptics.ImpactFeedbackStyle.Medium);
      setStep(3);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOTP = async () => {
    const code = otpCode.join('').trim();
    if (code.length < 6) return;

    Keyboard.dismiss();
    setLoading(true);
    setError('');
    try {
      // ✅ التحقق الصارم باستخدام بيانات نظيفة
      const cleanEmail = newEmail.trim().toLowerCase();
      console.log('🛡️ [ChangeEmailModal] محاولة التحقق للبريد:', cleanEmail);

      const result = await verifyOTP(cleanEmail, code);

      if (result.success) {
        await ProfileService.finalizeEmailUpdate(user.id, cleanEmail);
        updateUserData({ email: cleanEmail });
        triggerHaptic(Haptics.ImpactFeedbackStyle.Heavy);
        onNotify?.({ message: 'تم تحديث البريد الإلكتروني بنجاح', type: 'success' });
        onClose();
      }
    } catch (err) {
      console.log('❌ [ChangeEmailModal] فشل التحقق:', err.message);
      setError('رمز التحقق غير صحيح');
      triggerHaptic(Haptics.ImpactFeedbackStyle.Medium);
    } finally {
      setLoading(false);
    }
  };

  const handleOTPChange = (v, i) => {
    const cleaned = v.replace(/[^0-9]/g, '');
    if (!cleaned && v !== '') return;

    const newCode = [...otpCode];
    newCode[i] = cleaned.slice(-1);
    setOtpCode(newCode);

    // ✅ الانتقال للأمام (LTR Logic 0 -> 5)
    if (cleaned && i < 5) {
      inputRefs.current[i+1]?.focus();
    }

    if (newCode.every(c => c !== '')) setError('');
  };

  const handleKeyPress = (e, i) => {
    // ✅ الحذف الذكي (الرجوع للخلف 5 -> 0)
    if (e.nativeEvent.key === 'Backspace') {
      if (otpCode[i] === '' && i > 0) {
        const newCode = [...otpCode];
        newCode[i-1] = '';
        setOtpCode(newCode);
        inputRefs.current[i-1]?.focus();
      }
    }
  };

  return (
    <Modal
      visible={visible}
      title={step === 1 ? "تأكيد الهوية" : step === 2 ? "تغيير البريد" : "التحقق من الملكية"}
      message={step === 1 ? "أدخل كلمة المرور للمتابعة" : step === 2 ? "أدخل البريد الإلكتروني الجديد" : `أدخل الرمز المرسل إلى: ${newEmail}`}
      confirmText={step === 3 ? "تأكيد التغيير" : "التالي"}
      cancelText="إلغاء"
      onConfirm={step === 1 ? handleVerifyPassword : step === 2 ? handleRequestOTP : handleVerifyOTP}
      onCancel={onClose}
      confirmLoading={loading}
    >
      <View style={styles.content}>
        {step === 1 ? (
          <Input
            label="كلمة المرور الحالية"
            icon="lock-closed-outline"
            secureTextEntry
            value={password}
            onChangeText={setPassword}
            error={error}
          />
        ) : step === 2 ? (
          <Input
            label="البريد الإلكتروني الجديد"
            icon="mail-outline"
            value={newEmail}
            onChangeText={setNewEmail}
            keyboardType="email-address"
            autoCapitalize="none"
            error={error}
          />
        ) : (
          <View style={styles.otpSection}>
            <View style={styles.otpRow}>
              {otpCode.map((d, i) => (
                <TextInput
                  key={i}
                  ref={r => inputRefs.current[i] = r}
                  style={[
                    styles.otpBox,
                    d !== '' && styles.otpBoxFilled,
                    focusedIndex === i && styles.otpBoxFocused
                  ]}
                  value={d}
                  onChangeText={v => handleOTPChange(v, i)}
                  onKeyPress={e => handleKeyPress(e, i)}
                  onFocus={() => setFocusedIndex(i)}
                  keyboardType="number-pad"
                  maxLength={1}
                  textAlign="center"
                  selectTextOnFocus
                />
              ))}
            </View>
            {error !== '' && <Text style={styles.errorText}>{error}</Text>}
          </View>
        )}
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  content: { marginTop: 10, width: '100%' },
  otpSection: { alignItems: 'center', paddingVertical: 15, width: '100%' },
  otpRow: { flexDirection: 'row', gap: 8, justifyContent: 'center', width: '100%' }, // ✅ LTR Row for Numbers
  otpBox: {
    width: 32,
    height: 44,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: Colors.border,
    fontSize: 15,
    fontFamily: 'Tajawal-Bold',
    backgroundColor: '#F9FAFB',
    color: Colors.dark
  },
  otpBoxFilled: { borderColor: Colors.navy, backgroundColor: Colors.white },
  otpBoxFocused: { borderColor: Colors.gold, shadowColor: Colors.gold, shadowOpacity: 0.1, shadowRadius: 5, elevation: 2 },
  errorText: { color: Colors.red, fontSize: 12, marginTop: 15, fontFamily: 'Tajawal-Bold', textAlign: 'center' }
});
