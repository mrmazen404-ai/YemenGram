// src/modules/database/syncManager.js
// =============================================
// إدارة المزامنة مع الخادم السحابي (Sync Manager)
// =============================================

import { LocalDB } from './localDB';
import { Logger } from '../../shared/utils/logger';
import { api } from '../../shared/services/api';

// =============================================
// 1. الثوابت
// =============================================

const STATUS = {
  PENDING: 'pending',
  SYNCED: 'synced',
  FAILED: 'failed',
};

const ACTIONS = {
  INSERT: 'insert',
  UPDATE: 'update',
  DELETE: 'delete',
};

const MAX_ATTEMPTS = 5;
const BATCH_SIZE = 50;
const RETRY_DELAY = 5000;

// =============================================
// 2. دوال قائمة المزامنة
// =============================================

/**
 * إضافة عملية إلى قائمة المزامنة
 * @param {string} userId - معرف المستخدم
 * @param {string} action - نوع العملية
 * @param {string} tableName - اسم الجدول
 * @param {string} recordId - معرف السجل
 * @param {Object} data - البيانات
 * @returns {Promise<number>}
 */
export const addToSyncQueue = async (userId, action, tableName, recordId, data) => {
  try {
    const result = await LocalDB.execute(
      `INSERT INTO sync_queue
       (user_id, action, table_name, record_id, data, status, attempts, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        userId,
        action,
        tableName,
        recordId || null,
        JSON.stringify(data),
        STATUS.PENDING,
        0,
        Date.now(),
      ]
    );

    Logger.debug(`✅ [Sync] تمت إضافة عملية ${action} إلى قائمة المزامنة`);
    return result.lastInsertRowId;
  } catch (error) {
    Logger.error('❌ [Sync] فشل إضافة عملية إلى قائمة المزامنة:', error);
    throw error;
  }
};

/**
 * الحصول على العمليات المعلقة
 * @param {string} userId - معرف المستخدم
 * @param {number} limit - الحد الأقصى
 * @returns {Promise<Array>}
 */
export const getPendingOperations = async (userId, limit = BATCH_SIZE) => {
  try {
    return await LocalDB.query(
      `SELECT * FROM sync_queue
       WHERE user_id = ? AND status = ?
       ORDER BY created_at ASC
       LIMIT ?`,
      [userId, STATUS.PENDING, limit]
    );
  } catch (error) {
    Logger.error('❌ [Sync] فشل جلب العمليات المعلقة:', error);
    return [];
  }
};

/**
 * الحصول على عدد العمليات المعلقة
 * @param {string} userId - معرف المستخدم
 * @returns {Promise<number>}
 */
export const getPendingCount = async (userId) => {
  try {
    const result = await LocalDB.queryOne(
      'SELECT COUNT(*) as count FROM sync_queue WHERE user_id = ? AND status = ?',
      [userId, STATUS.PENDING]
    );
    return result?.count || 0;
  } catch (error) {
    Logger.error('❌ [Sync] فشل جلب عدد العمليات المعلقة:', error);
    return 0;
  }
};

/**
 * تحديث حالة عملية المزامنة
 * @param {number} syncId - معرف العملية
 * @param {string} status - الحالة الجديدة
 * @param {number} attempts - عدد المحاولات
 * @returns {Promise<void>}
 */
export const updateSyncStatus = async (syncId, status, attempts = null) => {
  try {
    const updates = [];
    const params = [];

    updates.push('status = ?');
    params.push(status);

    if (status === STATUS.SYNCED) {
      updates.push('synced_at = ?');
      params.push(Date.now());
    }

    if (attempts !== null) {
      updates.push('attempts = ?');
      params.push(attempts);
    }

    params.push(syncId);

    await LocalDB.execute(
      `UPDATE sync_queue SET ${updates.join(', ')} WHERE id = ?`,
      params
    );
  } catch (error) {
    Logger.error('❌ [Sync] فشل تحديث حالة العملية:', error);
  }
};

// =============================================
// 3. دوال المزامنة الأساسية
// =============================================

/**
 * مزامنة عملية واحدة
 * @param {Object} operation - عملية المزامنة
 * @param {string} userId - معرف المستخدم
 * @returns {Promise<boolean>}
 */
export const syncOperation = async (operation, userId) => {
  const { id, action, table_name, record_id, data, attempts } = operation;

  try {
    const parsedData = JSON.parse(data);
    const endpoint = `/rest/v1/${table_name}`;

    let result;
    switch (action) {
      case ACTIONS.INSERT:
        result = await api.post(endpoint, parsedData);
        break;
      case ACTIONS.UPDATE:
        result = await api.patch(`${endpoint}?id=eq.${record_id}`, parsedData);
        break;
      case ACTIONS.DELETE:
        result = await api.delete(`${endpoint}?id=eq.${record_id}`);
        break;
      default:
        throw new Error(`إجراء غير معروف: ${action}`);
    }

    await updateSyncStatus(id, STATUS.SYNCED);
    Logger.debug(`✅ [Sync] تمت مزامنة العملية ${id}`);
    return true;
  } catch (error) {
    const newAttempts = (attempts || 0) + 1;
    Logger.error(`❌ [Sync] فشلت مزامنة العملية ${id}:`, error.message);

    if (newAttempts >= MAX_ATTEMPTS) {
      await updateSyncStatus(id, STATUS.FAILED, newAttempts);
      Logger.warn(`⚠️ [Sync] تجاوزت العملية ${id} الحد الأقصى للمحاولات`);
    } else {
      await updateSyncStatus(id, STATUS.PENDING, newAttempts);
    }
    return false;
  }
};

/**
 * مزامنة جميع العمليات المعلقة
 * @param {string} userId - معرف المستخدم
 * @param {Object} options - خيارات إضافية
 * @returns {Promise<Object>}
 */
export const syncAllPending = async (userId, options = {}) => {
  const { batchSize = BATCH_SIZE, onProgress = null } = options;

  let success = 0;
  let failed = 0;

  try {
    let hasMore = true;
    while (hasMore) {
      const operations = await getPendingOperations(userId, batchSize);

      if (operations.length === 0) {
        hasMore = false;
        break;
      }

      for (const operation of operations) {
        const result = await syncOperation(operation, userId);
        if (result) {
          success++;
        } else {
          failed++;
        }

        if (onProgress) {
          onProgress({ success, failed, total: success + failed });
        }
      }

      const remaining = await getPendingCount(userId);
      if (remaining === 0) {
        hasMore = false;
      }
    }

    Logger.info(`✅ [Sync] اكتملت المزامنة: ${success} نجاح، ${failed} فشل`);
    return { success, failed };
  } catch (error) {
    Logger.error('❌ [Sync] فشل في مزامنة العمليات:', error);
    return { success, failed };
  }
};

// =============================================
// 4. دوال المزامنة العكسية
// =============================================

/**
 * مزامنة البيانات من السحابة إلى المحلي
 * @param {string} tableName - اسم الجدول
 * @param {string} userId - معرف المستخدم
 * @param {Object} options - خيارات إضافية
 * @returns {Promise<number>}
 */
export const syncFromCloud = async (tableName, userId, options = {}) => {
  const { lastSync = null, limit = 1000 } = options;

  try {
    const remoteData = await api.get(`/rest/v1/${tableName}`, {
      params: { select: '*', user_id: `eq.${userId}` },
    });

    let count = 0;
    for (const record of remoteData) {
      // التحقق من وجود السجل محلياً
      const local = await LocalDB.queryOne(
        `SELECT * FROM ${tableName} WHERE id = ? AND user_id = ?`,
        [record.id, userId]
      );

      if (local) {
        // تحديث السجل الموجود
        await LocalDB.execute(
          `UPDATE ${tableName} SET ? WHERE id = ? AND user_id = ?`,
          [record, record.id, userId]
        );
      } else {
        // إضافة سجل جديد
        const columns = Object.keys(record);
        const placeholders = columns.map(() => '?').join(', ');
        const values = columns.map(col => record[col]);
        await LocalDB.execute(
          `INSERT INTO ${tableName} (${columns.join(', ')}) VALUES (${placeholders})`,
          values
        );
      }
      count++;
    }

    Logger.info(`✅ [Sync] تم مزامنة ${count} سجل من ${tableName}`);
    return count;
  } catch (error) {
    Logger.error(`❌ [Sync] فشل مزامنة ${tableName} من السحابة:`, error);
    return 0;
  }
};

// =============================================
// 5. دوال المزامنة الكاملة
// =============================================

/**
 * مزامنة كاملة (ذهاباً وإياباً)
 * @param {string} userId - معرف المستخدم
 * @param {Object} options - خيارات إضافية
 * @returns {Promise<Object>}
 */
export const fullSync = async (userId, options = {}) => {
  const { tables = [], onProgress = null } = options;

  Logger.info('🔄 [Sync] بدء المزامنة الكاملة');

  const result = {
    localToCloud: { success: 0, failed: 0 },
    cloudToLocal: {},
    total: 0,
  };

  // 1. مزامنة المحلي → السحابة
  const syncResult = await syncAllPending(userId, { onProgress });
  result.localToCloud = syncResult;
  result.total += syncResult.success + syncResult.failed;

  // 2. مزامنة السحابة → المحلي
  const tablesToSync = tables.length > 0 ? tables : ['customers', 'invoices', 'payments', 'products'];

  for (const table of tablesToSync) {
    const count = await syncFromCloud(table, userId, options);
    result.cloudToLocal[table] = count;
    result.total += count;
  }

  Logger.info(`✅ [Sync] اكتملت المزامنة الكاملة: ${result.total} عملية`);
  return result;
};

// =============================================
// 6. دوال مساعدة
// =============================================

/**
 * إعادة محاولة العمليات الفاشلة
 * @param {string} userId - معرف المستخدم
 * @returns {Promise<number>}
 */
export const retryFailedOperations = async (userId) => {
  try {
    const failedOps = await LocalDB.query(
      `SELECT * FROM sync_queue
       WHERE user_id = ? AND status = ? AND attempts < ?
       ORDER BY created_at ASC`,
      [userId, STATUS.FAILED, MAX_ATTEMPTS]
    );

    let count = 0;
    for (const op of failedOps) {
      await updateSyncStatus(op.id, STATUS.PENDING, op.attempts);
      count++;
    }

    Logger.info(`🔄 [Sync] تم إعادة محاولة ${count} عملية فاشلة`);
    return count;
  } catch (error) {
    Logger.error('❌ [Sync] فشل إعادة محاولة العمليات الفاشلة:', error);
    return 0;
  }
};

/**
 * تنظيف العمليات المتزامنة القديمة
 * @param {string} userId - معرف المستخدم
 * @param {number} days - عدد الأيام
 * @returns {Promise<number>}
 */
export const cleanSyncedOperations = async (userId, days = 7) => {
  try {
    const cutoff = Date.now() - (days * 24 * 60 * 60 * 1000);
    const result = await LocalDB.execute(
      `DELETE FROM sync_queue
       WHERE user_id = ? AND status = ? AND synced_at < ?`,
      [userId, STATUS.SYNCED, cutoff]
    );
    Logger.info(`🧹 [Sync] تم تنظيف ${result.changes || 0} عملية قديمة`);
    return result.changes || 0;
  } catch (error) {
    Logger.error('❌ [Sync] فشل تنظيف العمليات القديمة:', error);
    return 0;
  }
};

/**
 * حذف جميع عمليات المستخدم
 * @param {string} userId - معرف المستخدم
 * @returns {Promise<number>}
 */
export const deleteAllUserOperations = async (userId) => {
  try {
    const result = await LocalDB.execute(
      'DELETE FROM sync_queue WHERE user_id = ?',
      [userId]
    );
    return result.changes || 0;
  } catch (error) {
    Logger.error('❌ [Sync] فشل حذف عمليات المستخدم:', error);
    return 0;
  }
};

// =============================================
// 7. كائن الخدمة الرئيسي
// =============================================

export const SyncManager = {
  // قائمة المزامنة
  addToQueue: addToSyncQueue,
  getPending: getPendingOperations,
  getPendingCount,
  updateStatus: updateSyncStatus,

  // المزامنة
  syncOperation,
  syncAll: syncAllPending,
  syncFromCloud,
  fullSync,

  // مساعدة
  retryFailed: retryFailedOperations,
  cleanOld: cleanSyncedOperations,
  deleteAll: deleteAllUserOperations,

  // الثوابت
  STATUS,
  ACTIONS,
  MAX_ATTEMPTS,
};

export default SyncManager;