import { gcm } from '@noble/ciphers/aes';
import { randomBytes } from 'node:crypto';

const key = new Uint8Array(randomBytes(32));
const nonce = new Uint8Array(randomBytes(12));
const associatedData = new TextEncoder().encode('yemengram');
const plaintext = new TextEncoder().encode('اختبار تشفير بيانات مالية');
const cipher = gcm(key, nonce, associatedData);
const ciphertext = cipher.encrypt(plaintext);
const roundTrip = new TextDecoder().decode(cipher.decrypt(ciphertext));
if (roundTrip !== 'اختبار تشفير بيانات مالية') throw new Error('AES-GCM round-trip failed');

ciphertext[0] ^= 1;
let tamperRejected = false;
try { cipher.decrypt(ciphertext); } catch { tamperRejected = true; }
if (!tamperRejected) throw new Error('AES-GCM accepted tampered ciphertext');

console.log('Security smoke test: PASS (AES-GCM round-trip + tamper rejection)');
