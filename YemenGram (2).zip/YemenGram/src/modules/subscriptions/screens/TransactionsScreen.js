/**
 * سجل العمليات السيادي (Sovereign Transaction Log)
 * يعرض سجل المدفوعات والاشتراكات والترقيات من سجل التدقيق وقاعدة البيانات
 */

import React from 'react';
import { View, Text, ScrollView, StyleSheet, ActivityIndicator, RefreshControl, TouchableOpacity, Alert, SafeAreaView } from 'react-native';
import { MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import LocalDB from '../../database/localDB';
import InvoiceService from '../services/InvoiceService';
import { Colors } from '../../../shared/utils/colors';

export default function TransactionsScreen() {
    const navigation = useNavigation();
    const [logs, setLogs] = React.useState([]);
    const [loading, setLoading] = React.useState(true);
    const [refreshing, setRefreshing] = React.useState(false);
    const [currentUser, setCurrentUser] = React.useState(null);

    const loadData = async () => {
        try {
            const user = await LocalDB.getUser();
            setCurrentUser(user);
            if (!user?.id) return;

            // جلب سجلات التدقيق المتعلقة بالاشتراكات
            const rows = await LocalDB.query(
                `SELECT * FROM audit_log
                 WHERE table_name = 'subscriptions' OR action LIKE 'subscription_%'
                 ORDER BY created_at DESC LIMIT 50`,
                []
            );

            const formattedLogs = rows.map(row => {
                let details = {};
                try {
                    details = JSON.parse(row.details || '{}');
                } catch (e) {
                    details = {};
                }

                return {
                    id: row.id,
                    action: row.action,
                    tableName: row.table_name,
                    date: row.created_at,
                    recordId: row.record_id,
                    details: details,
                };
            });

            setLogs(formattedLogs);
        } catch (error) {
            console.error('Audit Log Load Failure:', error);
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    };

    const handleDownloadInvoice = async (log) => {
        try {
            Alert.alert('جاري التوليد', 'يتم الآن تحضير فاتورتك السيادية...');

            const subRow = await LocalDB.queryOne('SELECT * FROM subscriptions WHERE id = ?', [log.recordId]);

            if (!subRow) {
                throw new Error('لم يتم العثور على بيانات الاشتراك التفصيلية.');
            }

            await InvoiceService.shareInvoice({
                user: currentUser,
                subscription: subRow,
                invoiceNumber: `YG-${log.id}`,
                date: new Date(log.date).toLocaleDateString('ar-EG')
            });
        } catch (error) {
            Alert.alert('فشل الفاتورة', error.message);
        }
    };

    React.useEffect(() => {
        loadData();
    }, []);

    const getStatusStyle = (action) => {
        if (action.includes('success') || action.includes('approved')) return { color: '#10B981', label: 'مقبول' };
        if (action.includes('failed') || action.includes('rejected')) return { color: '#EF4444', label: 'مرفوض' };
        return { color: '#3B82F6', label: 'قيد المعالجة' };
    };

    const handleBack = () => {
        if (navigation.canGoBack()) {
            navigation.goBack();
        } else {
            navigation.navigate('SubscriptionOverview');
        }
    };

    if (loading) {
        return <View style={styles.center}><ActivityIndicator size="large" color={Colors.navy} /></View>;
    }

    return (
        <SafeAreaView style={styles.container}>
            {/* 🛡️ الهيدر */}
            <View style={styles.header}>
                <TouchableOpacity style={styles.backBtn} onPress={handleBack}>
                    <Ionicons name="chevron-forward" size={24} color={Colors.navy} />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>سجل العمليات السيادي</Text>
                <View style={{ width: 40 }} />
            </View>

            <ScrollView
                contentContainerStyle={styles.content}
                refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); loadData(); }} />}
            >
                <Text style={styles.subtitle}>تتبع نزاهة كافة التحركات المالية والاشتراكات</Text>

                {logs.length === 0 ? (
                    <View style={styles.emptyBox}>
                        <MaterialCommunityIcons name="clipboard-text-off-outline" size={60} color="#CBD5E1" />
                        <Text style={styles.emptyText}>لا توجد سجلات مسجلة حالياً</Text>
                    </View>
                ) : (
                    logs.map((log) => {
                        const status = getStatusStyle(log.action);
                        return (
                            <View key={log.id} style={styles.card}>
                                <View style={styles.cardHeader}>
                                    <View style={styles.actionBox}>
                                        <Text style={styles.actionName}>{log.action.replace(/_/g, ' ').toUpperCase()}</Text>
                                        <Text style={styles.dateText}>{new Date(log.date).toLocaleString('ar-EG')}</Text>
                                    </View>
                                    <View style={[styles.statusBadge, { backgroundColor: status.color + '20' }]}>
                                        <Text style={[styles.statusText, { color: status.color }]}>{status.label}</Text>
                                    </View>
                                </View>

                                <View style={styles.detailsRow}>
                                    <Text style={styles.detailLabel}>معرف المرجع:</Text>
                                    <Text style={styles.detailValue}>{log.details.subscriptionId || 'YG-GLOBAL'}</Text>
                                </View>

                                {log.details.ctx?.plan && (
                                    <View style={styles.detailsRow}>
                                        <Text style={styles.detailLabel}>الباقة المستهدفة:</Text>
                                        <Text style={styles.detailValue}>{log.details.ctx.plan.toUpperCase()}</Text>
                                    </View>
                                )}

                                {log.details.signature && (
                                    <View style={styles.signatureRow}>
                                        <MaterialCommunityIcons name="fingerprint" size={12} color="#94A3B8" />
                                        <Text style={styles.signatureText} numberOfLines={1}>Signed: {log.details.signature}</Text>
                                    </View>
                                )}

                                {/* 📄 زر تحميل الفاتورة للعمليات المكتملة */}
                                {status.label === 'مقبول' && (
                                    <TouchableOpacity
                                        style={styles.invoiceBtn}
                                        onPress={() => handleDownloadInvoice(log)}
                                    >
                                        <Ionicons name="cloud-download-outline" size={16} color={Colors.gold} />
                                        <Text style={styles.invoiceBtnText}>تحميل الفاتورة السيادية</Text>
                                    </TouchableOpacity>
                                )}
                            </View>
                        );
                    })
                )}
            </ScrollView>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#F8FAFC' },
    header: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingVertical: 15, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#F1F5F9' },
    backBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: '#F8FAFC', justifyContent: 'center', alignItems: 'center' },
    headerTitle: { fontSize: 18, fontFamily: 'Tajawal-Bold', color: Colors.navy },
    content: { padding: 20, paddingBottom: 40 },
    center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
    title: { fontSize: 24, fontFamily: 'Tajawal-Bold', color: '#0F172A', textAlign: 'right' },
    subtitle: { fontSize: 13, fontFamily: 'Tajawal-Medium', color: '#64748B', textAlign: 'right', marginBottom: 25 },
    emptyBox: { alignItems: 'center', marginTop: 100 },
    emptyText: { marginTop: 15, fontSize: 14, fontFamily: 'Tajawal-Medium', color: '#94A3B8' },
    card: {
        backgroundColor: '#FFF',
        borderRadius: 18,
        padding: 15,
        marginBottom: 15,
        borderWidth: 1,
        borderColor: '#F1F5F9',
        elevation: 2,
    },
    cardHeader: {
        flexDirection: 'row-reverse',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        marginBottom: 15,
        borderBottomWidth: 1,
        borderBottomColor: '#F1F5F9',
        paddingBottom: 12,
    },
    actionBox: { alignItems: 'flex-end' },
    actionName: { fontSize: 14, fontFamily: 'Tajawal-Bold', color: '#334155' },
    dateText: { fontSize: 10, fontFamily: 'Tajawal-Medium', color: '#94A3B8', marginTop: 4 },
    statusBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
    statusText: { fontSize: 11, fontFamily: 'Tajawal-Bold' },
    detailsRow: { flexDirection: 'row-reverse', justifyContent: 'space-between', marginBottom: 6 },
    detailLabel: { fontSize: 12, fontFamily: 'Tajawal-Medium', color: '#64748B' },
    detailValue: { fontSize: 12, fontFamily: 'Tajawal-Bold', color: '#0F172A' },
    signatureRow: {
        flexDirection: 'row-reverse',
        alignItems: 'center',
        gap: 5,
        marginTop: 10,
        paddingTop: 8,
        borderTopWidth: 1,
        borderTopColor: '#F8FAFC',
    },
    signatureText: { flex: 1, fontSize: 9, color: '#CBD5E1', fontFamily: 'monospace', textAlign: 'right' },
    invoiceBtn: {
        marginTop: 15,
        backgroundColor: Colors.navy,
        borderRadius: 10,
        paddingVertical: 10,
        flexDirection: 'row-reverse',
        justifyContent: 'center',
        alignItems: 'center',
        gap: 8,
        borderWidth: 1,
        borderColor: Colors.gold,
    },
    invoiceBtnText: {
        color: '#FFF',
        fontSize: 12,
        fontFamily: 'Tajawal-Bold',
    }
});
