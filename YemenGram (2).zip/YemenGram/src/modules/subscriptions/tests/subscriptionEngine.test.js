import assert from 'node:assert/strict';
import { STATES, EVENTS, transition } from '../services/SubscriptionEngine.js';

const expectTransition = (from, event, ctx, to) => {
  const result = transition(from, event, ctx);
  assert.equal(result.valid, true);
  assert.equal(result.nextState, to, `${from} + ${event}`);
};

expectTransition(STATES.UNSUBSCRIBED, EVENTS.START_FREE_TRIAL, { userId: 'u1' }, STATES.TRIAL_ACTIVE);
expectTransition(STATES.TRIAL_ACTIVE, EVENTS.EXPIRE, {}, STATES.TRIAL_EXPIRED);
expectTransition(STATES.ACTIVE_FULL, EVENTS.EXPIRE, {}, STATES.EXPIRED_GRACE);
expectTransition(STATES.ACTIVE_FULL, EVENTS.REFUND_REQUESTED, { userId: 'u1' }, STATES.REFUND_PENDING);
expectTransition(STATES.REFUND_PENDING, EVENTS.REFUND_APPROVED, { actorId: 'a1', actorRole: 'admin' }, STATES.CANCELLED);
expectTransition(STATES.ACTIVE_FULL, EVENTS.EXTEND_REQUEST, { userId: 'u1' }, STATES.EXTENSION_PENDING);
expectTransition(STATES.EXTENSION_PENDING, EVENTS.EXTEND_APPROVED, { actorId: 'a1', actorRole: 'owner' }, STATES.ACTIVE_FULL);
expectTransition(STATES.RESOURCES_EXCEEDED, EVENTS.RESOURCE_RECOVERY, {}, STATES.ACTIVE_FULL);

const invalid = transition(STATES.UNSUBSCRIBED, EVENTS.CANCEL);
assert.equal(invalid.valid, false);
assert.equal(invalid.errorCode, 'INVALID_TRANSITION');
assert.equal(invalid.nextState, STATES.UNSUBSCRIBED);

const forged = transition(STATES.VERIFICATION_PENDING, EVENTS.VERIFICATION_APPROVED, { admin: true });
assert.equal(forged.valid, false);
assert.equal(forged.errorCode, 'ADMIN_AUTH_REQUIRED');

console.log('subscriptionEngine: all tests passed');
