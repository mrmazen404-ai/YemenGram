// src/models/Account.js
// =============================================
// نموذج الحساب المحاسبي (Account Model)
// المسؤول عن إدارة دليل الحسابات والبنية الشجرية
// =============================================

import { Model } from '@nozbe/watermelondb';
import { field, date, readonly } from '@nozbe/watermelondb/decorators';
import { Q } from '@nozbe/watermelondb';

export default class Account extends Model {
  // ===== 1. اسم الجدول =====
  static table = 'accounts';

  // ===== 2. الحقول الأساسية =====

  // معرف المستخدم (لفصل البيانات)
  @field('user_id') userId;

  // رقم الحساب (مثال: 1000، 2000، 3000)
  @field('code') code;

  // اسم الحساب (مثال: النقدية، البنك، المبيعات)
  @field('name') name;

  // نوع الحساب (asset, liability, equity, revenue, expense)
  @field('type') type;

  // الحساب الأب (للحسابات الفرعية)
  @field('parent_id') parentId;

  // العملة الافتراضية للحساب
  @field('currency') currency;

  // الرصيد الحالي للحساب
  @field('balance') balance;

  // حالة التفعيل (0 = غير نشط، 1 = نشط)
  @field('is_active') isActive;

  // ملاحظات إضافية
  @field('notes') notes;

  // ===== 3. التواريخ التلقائية =====

  @readonly @date('created_at') createdAt;
  @readonly @date('updated_at') updatedAt;

  // ===== 4. العلاقات =====

  static associations = {
    // حساب واحد → لديه عدة حسابات فرعية
    children: { type: 'has_many', foreignKey: 'parent_id' },
    // حساب واحد → لديه عدة حركات
    movements: { type: 'has_many', foreignKey: 'account_id' },
    // حساب واحد → ينتمي إلى حساب أب واحد
    parent: { type: 'belongs_to', key: 'parent_id' },
    // حساب واحد → ينتمي إلى مستخدم واحد
    user: { type: 'belongs_to', key: 'user_id' },
  };

  // ===== 5. دوال مساعدة =====

  /**
   * الحصول على اسم النوع باللغة العربية
   * @returns {string}
   */
  getTypeArabic() {
    const types = {
      asset: 'أصول',
      liability: 'خصوم',
      equity: 'حقوق ملكية',
      revenue: 'إيرادات',
      expense: 'مصروفات',
    };
    return types[this.type] || this.type;
  }

  /**
   * الحصول على لون النوع
   * @returns {string}
   */
  getTypeColor() {
    const colors = {
      asset: '#27AE60',
      liability: '#E74C3C',
      equity: '#1B365D',
      revenue: '#D4A853',
      expense: '#F39C12',
    };
    return colors[this.type] || '#6B7280';
  }

  /**
   * الحصول على أيقونة النوع
   * @returns {string}
   */
  getTypeIcon() {
    const icons = {
      asset: 'wallet',
      liability: 'card',
      equity: 'shield',
      revenue: 'trending-up',
      expense: 'trending-down',
    };
    return icons[this.type] || 'folder';
  }

  /**
   * التحقق من نشاط الحساب
   * @returns {boolean}
   */
  isActiveAccount() {
    return this.isActive === 1 || this.isActive === true;
  }

  /**
   * التحقق من أن الحساب رئيسي (ليس له أب)
   * @returns {boolean}
   */
  isRoot() {
    return !this.parentId;
  }

  /**
   * الحصول على الاسم الكامل مع الرقم
   * @returns {string}
   */
  getDisplayName() {
    return `${this.code} - ${this.name}`;
  }

  /**
   * الحصول على مستوى الحساب في الشجرة
   * @returns {Promise<number>}
   */
  async getLevel() {
    let level = 0;
    let current = this;
    while (current.parentId) {
      const parent = await this.collections.get('accounts').find(current.parentId);
      if (!parent) break;
      current = parent;
      level++;
    }
    return level;
  }

  /**
   * جلب جميع الحسابات الفرعية (المباشرة)
   * @returns {Promise<Account[]>}
   */
  async getChildren() {
    return this.collections.get('accounts').query(
      Q.where('parent_id', this.id),
      Q.where('is_active', true),
      Q.sortBy('code')
    ).fetch();
  }

  /**
   * جلب جميع الحسابات الفرعية (المباشرة وغير المباشرة)
   * @returns {Promise<Account[]>}
   */
  async getAllDescendants() {
    const descendants = [];
    const stack = [this];

    while (stack.length > 0) {
      const current = stack.pop();
      const children = await current.getChildren();
      descendants.push(...children);
      stack.push(...children);
    }

    return descendants;
  }

  /**
   * جلب الحساب الأب
   * @returns {Promise<Account|null>}
   */
  async getParent() {
    if (!this.parentId) return null;
    return this.collections.get('accounts').find(this.parentId);
  }

  /**
   * جلب المسار الكامل للحساب (من الجذر إلى الحساب الحالي)
   * @returns {Promise<Account[]>}
   */
  async getPath() {
    const path = [];
    let current = this;
    while (current) {
      path.unshift(current);
      current = await current.getParent();
    }
    return path;
  }

  /**
   * جلب المسار كأسماء
   * @returns {Promise<string>}
   */
  async getPathNames(separator = ' › ') {
    const path = await this.getPath();
    return path.map(a => a.name).join(separator);
  }

  /**
   * جلب حركات الحساب
   * @param {number} limit
   * @returns {Promise<AccountMovement[]>}
   */
  async getMovements(limit = 100) {
    return this.collections.get('account_movements').query(
      Q.where('account_id', this.id),
      Q.sortBy('date', Q.desc),
      Q.take(limit)
    ).fetch();
  }

  /**
   * حساب رصيد الحساب من الحركات
   * @returns {Promise<number>}
   */
  async calculateBalanceFromMovements() {
    const movements = await this.collections.get('account_movements').query(
      Q.where('account_id', this.id)
    ).fetch();

    let total = 0;
    for (const movement of movements) {
      total += (movement.debit || 0) - (movement.credit || 0);
    }
    return total;
  }

  /**
   * تحديث رصيد الحساب (يُستخدم بعد إضافة حركة)
   * @param {number} newBalance
   */
  async updateBalance(newBalance) {
    await this.write(() => {
      this.balance = newBalance;
    });
  }

  /**
   * إضافة مبلغ إلى رصيد الحساب (مدين)
   * @param {number} amount
   */
  async addDebit(amount) {
    await this.write(() => {
      this.balance = (this.balance || 0) + amount;
    });
  }

  /**
   * خصم مبلغ من رصيد الحساب (دائن)
   * @param {number} amount
   */
  async addCredit(amount) {
    await this.write(() => {
      this.balance = (this.balance || 0) - amount;
    });
  }

  /**
   * التحقق من أن الحساب له حركات
   * @returns {Promise<boolean>}
   */
  async hasMovements() {
    const count = await this.collections.get('account_movements').query(
      Q.where('account_id', this.id)
    ).fetchCount();
    return count > 0;
  }

  /**
   * الحصول على إجمالي المدين للفترة
   * @param {number} fromDate
   * @param {number} toDate
   * @returns {Promise<number>}
   */
  async getTotalDebit(fromDate, toDate) {
    const movements = await this.collections.get('account_movements').query(
      Q.where('account_id', this.id),
      Q.where('date', Q.gte(fromDate)),
      Q.where('date', Q.lte(toDate))
    ).fetch();

    return movements.reduce((sum, m) => sum + (m.debit || 0), 0);
  }

  /**
   * الحصول على إجمالي الدائن للفترة
   * @param {number} fromDate
   * @param {number} toDate
   * @returns {Promise<number>}
   */
  async getTotalCredit(fromDate, toDate) {
    const movements = await this.collections.get('account_movements').query(
      Q.where('account_id', this.id),
      Q.where('date', Q.gte(fromDate)),
      Q.where('date', Q.lte(toDate))
    ).fetch();

    return movements.reduce((sum, m) => sum + (m.credit || 0), 0);
  }
}