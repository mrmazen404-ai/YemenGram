// src/modules/subscriptions/utils/storageEncryptor.js
// Compatibility facade: all storage encryption uses the central AES-GCM service.
import { encryptData, decryptData } from '../../../shared/utils/security';

export const encrypt = async (text, key = null) => {
  if (!text) return '';
  return encryptData(text, key, 'yemengram.subscriptions');
};

export const decrypt = async (encryptedText, key = null) => {
  if (!encryptedText) return '';
  return decryptData(encryptedText, key, 'yemengram.subscriptions');
};

export default { encrypt, decrypt };
