// src/models/database.js
// =============================================
// تهيئة قاعدة البيانات (Database Initialization)
// إعداد WatermelonDB مع الموديلات - نسخة متوافقة مع Expo
// =============================================

import { Database } from '@nozbe/watermelondb';
import SQLiteAdapter from '@nozbe/watermelondb/adapters/sqlite';
import { Platform } from 'react-native';
import schema from './schema';

// ===== 1. استيراد الموديلات مباشرة (لتجنب Require Cycle) =====
import User from './User';
import Session from './Session';
import Account from './Account';
import AccountMovement from './AccountMovement';
import JournalEntry from './JournalEntry';
import JournalDetail from './JournalDetail';
import Customer from './Customer';
import CustomerContact from './CustomerContact';
import CustomerNote from './CustomerNote';
import CustomerActivity from './CustomerActivity';
import CustomerTier from './CustomerTier';
import Supplier from './Supplier';
import Product from './Product';
import ProductCategory from './ProductCategory';
import Invoice from './Invoice';
import InvoiceItem from './InvoiceItem';
import Payment from './Payment';
import Expense from './Expense';
import Revenue from './Revenue';
import Transfer from './Transfer';
import CashAccount from './CashAccount';
import Check from './Check';
import Employee from './Employee';
import Payroll from './Payroll';
import FixedAsset from './FixedAsset';
import AssetDepreciation from './AssetDepreciation';
import Setting from './Setting';
import Notification from './Notification';
import Subscription from './Subscription';
import AuditLog from './AuditLog';
import BackupHistory from './BackupHistory';
import SyncQueue from './SyncQueue';
import Receipt from './Receipt';

// ===== 2. إعداد محول SQLite المخصص لـ Expo =====
let databaseInstance = null;

export const getDatabase = () => {
  if (databaseInstance) return databaseInstance;

  try {
    const adapter = new SQLiteAdapter({
      schema,
      dbName: 'yemengram_watermelon',
      jsI: Platform.OS === 'ios',
      onSetUpError: (error) => {
        console.error('❌ [Database] setup error:', error);
      },
    });

    databaseInstance = new Database({
      adapter,
      modelClasses: [
        User, Session, Account, AccountMovement, JournalEntry, JournalDetail,
        Customer, CustomerContact, CustomerNote, CustomerActivity, CustomerTier,
        Supplier, Product, ProductCategory, Invoice, InvoiceItem, Payment,
        Expense, Revenue, Transfer, CashAccount, Check, Employee, Payroll,
        FixedAsset, AssetDepreciation, Setting, Notification, Subscription,
        AuditLog, BackupHistory, SyncQueue, Receipt,
      ],
    });

    return databaseInstance;
  } catch (error) {
    console.warn('⚠️ [Database] WatermelonDB native bridge not available (Expo Go environment). App will run using LocalDB (SQLite).');
    return null;
  }
};

// للحفاظ على التوافق مع الكود القديم الذي يستورد database مباشرة
export const database = getDatabase();

export default getDatabase;
