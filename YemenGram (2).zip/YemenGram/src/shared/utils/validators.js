// src/shared/utils/validators.js
// =============================================
// دوال التحقق من صحة البيانات (Validators)
// مجموعة من الدوال للتحقق من صحة المدخلات
// =============================================

import { Logger } from './logger';

// =============================================
// 1. التحقق من البريد الإلكتروني
// =============================================

/**
 * التحقق من صحة البريد الإلكتروني
 * @param {string} email - البريد الإلكتروني
 * @returns {boolean}
 */
export const isValidEmail = (email) => {
  if (!email) return false;
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  return emailRegex.test(email.trim());
};

/**
 * التحقق من صحة البريد الإلكتروني مع رسالة خطأ
 * @param {string} email - البريد الإلكتروني
 * @param {string} message - رسالة الخطأ المخصصة
 * @returns {string|null}
 */
export const validateEmail = (email, message = 'بريد إلكتروني غير صحيح') => {
  if (!email || !email.trim()) return 'البريد الإلكتروني مطلوب';
  if (email.length > 254) return 'البريد الإلكتروني طويل جداً';
  if (!isValidEmail(email)) return message;
  return null;
};

// =============================================
// 2. التحقق من رقم الهاتف
// =============================================

/**
 * التحقق من صحة رقم الهاتف اليمني
 * @param {string} phone - رقم الهاتف
 * @returns {boolean}
 */
export const isValidYemeniPhone = (phone) => {
  if (!phone) return false;
  const clean = phone.replace(/[\s\-\(\)\+]/g, '').replace(/[^0-9]/g, '');
  if (clean.length !== 9) return false;
  return /^(77|71|78|70|73)\d{7}$/.test(clean);
};

/**
 * التحقق من صحة رقم الهاتف (عام)
 * @param {string} phone - رقم الهاتف
 * @returns {boolean}
 */
export const isValidPhone = (phone) => {
  if (!phone) return false;
  const clean = phone.replace(/[\s\-\(\)\+]/g, '').replace(/[^0-9]/g, '');
  return clean.length >= 8 && clean.length <= 15;
};

/**
 * التحقق من صحة رقم الهاتف مع رسالة خطأ
 * @param {string} phone - رقم الهاتف
 * @param {string} message - رسالة الخطأ المخصصة
 * @returns {string|null}
 */
export const validatePhone = (phone, message = 'رقم هاتف غير صحيح') => {
  if (!phone || !phone.trim()) return 'رقم الهاتف مطلوب';
  const clean = phone.replace(/[\s\-\(\)\+]/g, '').replace(/[^0-9]/g, '');
  if (clean.length < 8 || clean.length > 15) return 'رقم الهاتف غير صحيح (8-15 أرقام)';
  if (!isValidPhone(phone)) return message;
  return null;
};

/**
 * التحقق من صحة رقم هاتف يمني مع رسالة خطأ
 * @param {string} phone - رقم الهاتف
 * @param {string} message - رسالة الخطأ المخصصة
 * @returns {string|null}
 */
export const validateYemeniPhone = (phone, message = 'رقم يمني غير صحيح (يبدأ بـ 70,71,73,77,78)') => {
  if (!phone || !phone.trim()) return 'رقم الهاتف مطلوب';
  if (!isValidYemeniPhone(phone)) return message;
  return null;
};

// =============================================
// 3. التحقق من كلمة المرور
// =============================================

/**
 * التحقق من قوة كلمة المرور
 * @param {string} password - كلمة المرور
 * @returns {Object} { score, label, color, isValid, errors }
 */
export const getPasswordStrength = (password) => {
  if (!password) {
    return {
      score: 0,
      label: '',
      color: '#E5E7EB',
      isValid: false,
      errors: ['كلمة المرور مطلوبة'],
    };
  }

  let score = 0;
  const errors = [];

  if (password.length >= 8) score++;
  else errors.push('8 أحرف على الأقل');

  if (password.length >= 12) score++;

  if (/[A-Z]/.test(password)) score++;
  else errors.push('حرف كبير (A-Z)');

  if (/[a-z]/.test(password)) score++;
  else errors.push('حرف صغير (a-z)');

  if (/[0-9]/.test(password)) score++;
  else errors.push('رقم (0-9)');

  if (/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) score++;
  else errors.push('رمز خاص (!@#$%^&*)');

  // منع الكلمات الضعيفة
  const weakPasswords = ['12345678', 'password', 'qwerty', '11111111', '00000000', 'abcdefgh'];
  if (weakPasswords.includes(password.toLowerCase())) {
    score = Math.min(score, 2);
    errors.push('كلمة مرور ضعيفة جداً');
  }

  // منع الأحرف المكررة
  if (/^(.)\1+$/.test(password)) {
    score = Math.min(score, 1);
    errors.push('لا يمكن استخدام أحرف مكررة');
  }

  // منع الأرقام المتسلسلة
  if (/(012|123|234|345|456|567|678|789|890)/.test(password)) {
    score = Math.min(score, 2);
    errors.push('لا يمكن استخدام أرقام متسلسلة');
  }

  const levels = [
    { label: 'ضعيفة جداً', color: '#E74C3C' },
    { label: 'ضعيفة', color: '#F39C12' },
    { label: 'متوسطة', color: '#F1C40F' },
    { label: 'قوية', color: '#2ECC71' },
    { label: 'قوية جداً', color: '#27AE60' },
  ];

  const level = levels[Math.min(Math.max(score - 1, 0), 4)];

  return {
    score: Math.min(score, 5),
    label: level.label,
    color: level.color,
    isValid: score >= 4,
    errors,
  };
};

/**
 * التحقق من صحة كلمة المرور
 * @param {string} password - كلمة المرور
 * @param {Object} options - خيارات التحقق
 * @returns {string|null}
 */
export const validatePassword = (password, options = {}) => {
  const { minLength = 8, requireUppercase = true, requireLowercase = true, requireNumber = true, requireSpecial = true } = options;

  if (!password) return 'كلمة المرور مطلوبة';
  if (password.length < minLength) return `كلمة المرور ${minLength} أحرف على الأقل`;
  if (password.length > 64) return 'كلمة المرور طويلة جداً (حد أقصى 64 حرف)';

  if (requireUppercase && !/[A-Z]/.test(password)) {
    return 'كلمة المرور تحتوي على حرف كبير (A-Z)';
  }
  if (requireLowercase && !/[a-z]/.test(password)) {
    return 'كلمة المرور تحتوي على حرف صغير (a-z)';
  }
  if (requireNumber && !/[0-9]/.test(password)) {
    return 'كلمة المرور تحتوي على رقم (0-9)';
  }
  if (requireSpecial && !/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
    return 'كلمة المرور تحتوي على رمز خاص (!@#$%^&*)';
  }

  const strength = getPasswordStrength(password);
  if (strength.score < 3) {
    return `كلمة المرور ضعيفة: ${strength.errors.join('، ')}`;
  }

  return null;
};

// =============================================
// 4. التحقق من الاسم
// =============================================

/**
 * التحقق من صحة الاسم
 * @param {string} name - الاسم
 * @param {Object} options - خيارات التحقق
 * @returns {string|null}
 */
export const validateName = (name, options = {}) => {
  const { minLength = 2, maxLength = 100, allowNumbers = false } = options;

  if (!name || !name.trim()) return 'الاسم مطلوب';
  const clean = name.trim();
  if (clean.length < minLength) return `الاسم ${minLength} أحرف على الأقل`;
  if (clean.length > maxLength) return `الاسم طويل جداً (حد أقصى ${maxLength} حرف)`;
  if (!allowNumbers && /\d/.test(clean)) return 'الاسم لا يمكن أن يحتوي على أرقام';
  if (/[<>{}()'"]/.test(clean)) return 'الاسم يحتوي على أحرف غير مسموحة';
  return null;
};

// =============================================
// 5. التحقق من المبلغ
// =============================================

/**
 * التحقق من صحة المبلغ
 * @param {number|string} amount - المبلغ
 * @param {Object} options - خيارات التحقق
 * @returns {string|null}
 */
export const validateAmount = (amount, options = {}) => {
  const { min = 0, max = Infinity, allowZero = false } = options;

  if (amount === undefined || amount === null || amount === '') {
    return 'المبلغ مطلوب';
  }

  const num = parseFloat(amount);
  if (isNaN(num)) return 'المبلغ يجب أن يكون رقماً';
  if (!allowZero && num === 0) return 'المبلغ يجب أن يكون أكبر من صفر';
  if (num < min) return `المبلغ يجب أن يكون ${min} على الأقل`;
  if (num > max) return `المبلغ كبير جداً (حد أقصى ${max})`;
  if (num < 0) return 'المبلغ لا يمكن أن يكون سالباً';
  return null;
};

// =============================================
// 6. التحقق من التاريخ
// =============================================

/**
 * التحقق من صحة التاريخ
 * @param {string|Date} date - التاريخ
 * @param {Object} options - خيارات التحقق
 * @returns {string|null}
 */
export const validateDate = (date, options = {}) => {
  const { allowPast = true, allowFuture = true, minDate = null, maxDate = null } = options;

  if (!date) return 'التاريخ مطلوب';

  const parsedDate = typeof date === 'string' ? new Date(date) : date;
  if (isNaN(parsedDate.getTime())) return 'تاريخ غير صحيح';

  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  if (!allowPast && parsedDate < today) return 'لا يمكن استخدام تاريخ سابق';
  if (!allowFuture && parsedDate > today) return 'لا يمكن استخدام تاريخ مستقبلي';
  if (minDate && parsedDate < new Date(minDate)) return `التاريخ يجب أن يكون بعد ${minDate}`;
  if (maxDate && parsedDate > new Date(maxDate)) return `التاريخ يجب أن يكون قبل ${maxDate}`;

  return null;
};

// =============================================
// 7. التحقق من النص
// =============================================

/**
 * التحقق من صحة النص
 * @param {string} text - النص
 * @param {Object} options - خيارات التحقق
 * @returns {string|null}
 */
export const validateText = (text, options = {}) => {
  const { minLength = 0, maxLength = Infinity, required = false, pattern = null } = options;

  if (required && (!text || !text.trim())) return 'هذا الحقل مطلوب';
  if (!text) return null;

  const clean = text.trim();
  if (minLength > 0 && clean.length < minLength) {
    return `الحد الأدنى ${minLength} أحرف`;
  }
  if (maxLength < Infinity && clean.length > maxLength) {
    return `الحد الأقصى ${maxLength} أحرف`;
  }
  if (pattern && !pattern.test(clean)) {
    return 'قيمة غير صحيحة';
  }
  if (/[<>{}()'"]/.test(clean)) {
    return 'يحتوي على أحرف غير مسموحة';
  }

  return null;
};

// =============================================
// 8. التحقق من الكود
// =============================================

/**
 * التحقق من صحة الكود
 * @param {string} code - الكود
 * @param {Object} options - خيارات التحقق
 * @returns {string|null}
 */
export const validateCode = (code, options = {}) => {
  const { length = 6, pattern = /^[A-Z0-9]+$/, required = true } = options;

  if (required && (!code || !code.trim())) return 'الكود مطلوب';
  if (!code) return null;

  const clean = code.trim();
  if (length && clean.length !== length) return `الكود يجب أن يكون ${length} أحرف`;
  if (pattern && !pattern.test(clean)) return 'كود غير صحيح';

  return null;
};

// =============================================
// 9. التحقق من الرقم
// =============================================

/**
 * التحقق من صحة الرقم
 * @param {number|string} value - القيمة
 * @param {Object} options - خيارات التحقق
 * @returns {string|null}
 */
export const validateNumber = (value, options = {}) => {
  const { min = null, max = null, integer = false, positive = false, required = true } = options;

  if (required && (value === undefined || value === null || value === '')) {
    return 'هذا الحقل مطلوب';
  }
  if (!required && (value === undefined || value === null || value === '')) {
    return null;
  }

  const num = parseFloat(value);
  if (isNaN(num)) return 'يجب أن يكون رقماً';
  if (integer && !Number.isInteger(num)) return 'يجب أن يكون عدداً صحيحاً';
  if (positive && num < 0) return 'يجب أن يكون موجباً';
  if (min !== null && num < min) return `الحد الأدنى ${min}`;
  if (max !== null && num > max) return `الحد الأقصى ${max}`;

  return null;
};

// =============================================
// 10. التحقق من URL
// =============================================

/**
 * التحقق من صحة URL
 * @param {string} url - الرابط
 * @returns {boolean}
 */
export const isValidURL = (url) => {
  if (!url) return false;
  try {
    const parsed = new URL(url);
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
};

/**
 * التحقق من صحة URL مع رسالة خطأ
 * @param {string} url - الرابط
 * @param {string} message - رسالة الخطأ المخصصة
 * @returns {string|null}
 */
export const validateURL = (url, message = 'رابط غير صحيح') => {
  if (!url || !url.trim()) return null;
  if (!isValidURL(url)) return message;
  return null;
};

// =============================================
// 11. دوال مساعدة إضافية
// =============================================

/**
 * التحقق من تطابق قيمتين
 * @param {string} value - القيمة الأولى
 * @param {string} compare - القيمة الثانية
 * @param {string} message - رسالة الخطأ
 * @returns {string|null}
 */
export const validateMatch = (value, compare, message = 'القيم غير متطابقة') => {
  if (value !== compare) return message;
  return null;
};

/**
 * التحقق من أن القيمة ليست فارغة
 * @param {any} value - القيمة
 * @param {string} message - رسالة الخطأ
 * @returns {string|null}
 */
export const validateRequired = (value, message = 'هذا الحقل مطلوب') => {
  if (value === undefined || value === null || value === '') return message;
  if (typeof value === 'string' && !value.trim()) return message;
  if (Array.isArray(value) && value.length === 0) return message;
  return null;
};

/**
 * التحقق من أن القيمة ضمن قائمة
 * @param {any} value - القيمة
 * @param {Array} allowed - القيم المسموحة
 * @param {string} message - رسالة الخطأ
 * @returns {string|null}
 */
export const validateInArray = (value, allowed, message = 'قيمة غير مسموحة') => {
  if (!allowed.includes(value)) return message;
  return null;
};

/**
 * تجميع عدة تحقيقات
 * @param {Array} validators - مصفوفة من دوال التحقق
 * @param {any} value - القيمة
 * @returns {string|null}
 */
export const composeValidators = (validators) => (value) => {
  for (const validator of validators) {
    const error = validator(value);
    if (error) return error;
  }
  return null;
};

// =============================================
// 12. كائن التحقق الرئيسي
// =============================================

export const validators = {
  email: validateEmail,
  phone: validatePhone,
  yemeniPhone: validateYemeniPhone,
  password: validatePassword,
  passwordStrength: getPasswordStrength,
  name: validateName,
  amount: validateAmount,
  date: validateDate,
  text: validateText,
  code: validateCode,
  number: validateNumber,
  url: validateURL,
  match: validateMatch,
  required: validateRequired,
  inArray: validateInArray,
  compose: composeValidators,


  isEmail: isValidEmail,
  isPhone: isValidPhone,
  isYemeniPhone: isValidYemeniPhone,
  isURL: isValidURL,
};

export default validators;