// src/modules/auth/screens/RegisterScreen.js
import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '../../../shared/utils/colors';
import Button from '../../../shared/components/Button';
import Toast from '../../../shared/components/Toast';
import Input from '../../../shared/components/Input'; // ✅ استيراد المكون السيادي
import SecurityLoading from '../../../shared/components/SecurityLoading';
import Modal from '../../../shared/components/Modal';
import { useAuth } from '../../../shared/contexts/AuthContext';
import AuthService from '../services/authService'; // ✅ استيراد رسمي مباشر
import { ImageBackground } from 'react-native';
const LOGO = require('../../../shared/assets/images/full-logo.png');
const HEADER_BG = require('../../../shared/assets/images/hint.png');

// =============================================
// 1. دوال التعقيم والتحقق (Sanitization & Validation)
// =============================================

// ----- تعقيم المدخلات -----
const sanitizeName = (name) => {
  return name.trim()
    .replace(/[<>{}()'"]/g, '')
    .replace(/\s{2,}/g, ' ');
};

const sanitizeCompany = (company) => {
  return company.trim()
    .replace(/[<>{}()'"]/g, '')
    .replace(/\s{2,}/g, ' ');
};

const sanitizeEmail = (email) => {
  return email.trim()
    .toLowerCase()
    .replace(/\s/g, '')
    .replace(/[<>{}()]/g, '');
};

const sanitizePhone = (phone) => {
  let clean = phone.trim()
    .replace(/[\s\-\(\)\+]/g, '')
    .replace(/[^0-9]/g, '');

  // تطبيع الرقم اليمني: إزالة المفتاح الدولي إذا وجد
  if (clean.startsWith('967')) clean = clean.substring(3);
  if (clean.startsWith('00967')) clean = clean.substring(5);

  return clean;
};

// ----- التحقق من صحة البريد الإلكتروني -----
const validateEmail = (email) => {
  if (!email) return 'البريد الإلكتروني مطلوب';
  
  const clean = sanitizeEmail(email);
  if (!clean) return 'يُرجى إدخال بريد إلكتروني صحيح';
  if (clean.length > 254) return 'البريد الإلكتروني طويل جداً';
  if (/[<>{}()'"]/.test(clean)) return 'البريد الإلكتروني يحتوي على أحرف غير مسموحة';
  
  const tempDomains = [
    'tempmail', '10minutemail', 'guerrillamail', 'mailinator', 
    'yopmail', 'throwaway', 'spamgourmet', 'trashmail'
  ];
  const domain = clean.split('@')[1];
  if (domain && tempDomains.some(d => domain.includes(d))) {
    return 'يُرجى استخدام بريد إلكتروني دائم';
  }
  
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(clean)) {
    return 'بريد إلكتروني غير صحيح';
  }
  
  return null;
};

// ----- التحقق من صحة رقم الهاتف -----
const validatePhone = (phone) => {
  if (!phone) return 'رقم الهاتف مطلوب';
  
  const clean = sanitizePhone(phone);
  if (!clean) return 'يُرجى إدخال رقم هاتف صحيح';

  // التحقق الحصري من الشبكات اليمنية الجوالة (9 أرقام)
  const isYemeniMobile = /^(77|71|78|70|73)\d{7}$/.test(clean);

  if (!isYemeniMobile) {
    return 'رقم يمني غير مدعوم. يجب أن يبدأ بـ (77, 73, 71, 78, 70)';
  }
  
  if (/^(.)\1{8,}$/.test(clean)) {
    return 'رقم الهاتف لا يمكن أن يكون أرقاماً مكررة';
  }

  return null;
};

// ----- التحقق من قوة كلمة المرور -----
const validatePassword = (password) => {
  if (!password) return 'كلمة المرور مطلوبة';
  if (password.length < 10) return 'كلمة المرور 10 أحرف على الأقل';
  if (password.length > 64) return 'كلمة المرور طويلة جداً (حد أقصى 64 حرف)';
  
  let score = 0;
  const errors = [];
  
  if (password.length >= 14) score++;
  else errors.push('14 حرفاً أو أكثر');
  
  if (/[A-Z]/.test(password)) score++;
  else errors.push('حرف كبير (A-Z)');
  
  if (/[a-z]/.test(password)) score++;
  else errors.push('حرف صغير (a-z)');
  
  if (/[0-9]/.test(password)) score++;
  else errors.push('رقم (0-9)');
  
  if (/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) score++;
  else errors.push('رمز خاص (!@#$%^&*)');
  
  if (score < 4) {
    return `كلمة المرور ضعيفة: أضف ${errors.join('، ')}`;
  }
  
  if (/^(.)\1+$/.test(password)) {
    return 'كلمة المرور لا يمكن أن تكون أحرفاً مكررة';
  }
  
  if (/(012|123|234|345|456|567|678|789|890)/.test(password)) {
    return 'كلمة المرور لا يمكن أن تكون أرقاماً متسلسلة';
  }
  
  return null;
};

const validateName = (name) => {
  if (!name) return 'الاسم الكامل مطلوب';
  const clean = sanitizeName(name);
  if (clean.length < 2) return 'الاسم 2 أحرف على الأقل';
  if (clean.length > 100) return 'الاسم طويل جداً (حد أقصى 100 حرف)';
  if (/[<>{}()'"]/.test(clean)) return 'الاسم يحتوي على أحرف غير مسموحة';
  if (/\d/.test(clean)) return 'الاسم لا يمكن أن يحتوي على أرقام';
  return null;
};

const validateCompany = (company) => {
  if (!company) return 'اسم الشركة مطلوب';
  const clean = sanitizeCompany(company);
  if (clean.length < 2) return 'اسم الشركة 2 أحرف على الأقل';
  if (clean.length > 100) return 'اسم الشركة طويل جداً (حد أقصى 100 حرف)';
  if (/[<>{}()'"]/.test(clean)) return 'اسم الشركة يحتوي على أحرف غير مسموحة';
  return null;
};

// =============================================
// 2. المكون الرئيسي
// =============================================

export default function RegisterScreen({ navigation }) {
  const { register, isOnline } = useAuth();

  // ===== State =====
  const [form, setForm] = useState({
    name: '',
    company: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
    currency: 'YER',
  });

  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState({ visible: false, message: '', type: 'error' });
  const [duplicateModal, setDuplicateModal] = useState({ visible: false, type: '' });
  const [showTerms, setShowTerms] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);

  // ===== تحديث الحقل =====
  const updateField = (key, value) => {
    setForm(prev => ({ ...prev, [key]: value }));
    if (errors[key]) {
      setErrors(prev => ({ ...prev, [key]: null }));
    }
  };
// ✅ نسخة مطورة من validateForm للتحقق من كافة الشروط السيادية قبل فتح بوابة التأكيد
const validateForm = () => {
  if (__DEV__) console.log('🛡️ [Forensic] [UI] بدء التحقق الشامل من النموذج...');
  const newErrors = {};

  // 1. التحقق من الاسم
  const nameError = validateName(form.name);
  if (nameError) newErrors.name = nameError;

  // 2. التحقق من الشركة
  const companyError = validateCompany(form.company);
  if (companyError) newErrors.company = companyError;

  // 3. التحقق من البريد الإلكتروني
  const emailError = validateEmail(form.email);
  if (emailError) newErrors.email = emailError;

  // 4. التحقق من رقم الهاتف (التأكد من الشبكات اليمنية: 77, 71, 78, 70, 73)
  const phoneError = validatePhone(form.phone);
  if (phoneError) {
    if (__DEV__) console.log(`🛡️ [Forensic] [UI] فشل تحقق الهاتف: ${phoneError}`);
    newErrors.phone = phoneError;
  }

  // 5. التحقق من كلمة المرور
  const passwordError = validatePassword(form.password);
  if (passwordError) newErrors.password = passwordError;

  // 6. تطابق كلمات المرور
  if (form.password !== form.confirmPassword) {
    newErrors.confirmPassword = 'كلمتا المرور غير متطابقتين';
  }

  if (__DEV__) console.log('🛡️ [Forensic] [UI] حصاد الأخطاء:', newErrors);
  setErrors(newErrors);
  return Object.keys(newErrors).length === 0;
};

 // ===== معالجة إنشاء الحساب =====
 const handleRegister = async () => {
   if (__DEV__) console.log('🛡️ [UI] بدء إنشاء حساب جديد');

   const isValid = validateForm();
   if (!isValid) {
     const firstError = Object.values(errors).find(e => e);
     if (firstError) setToast({ visible: true, message: firstError, type: 'error' });
     return;
   }

   setLoading(true);
   try {
     // ✅ فحص تكرار البيانات (فحص رسمي)
     const uniqueness = await AuthService.checkUniqueness(form.email, form.phone, form.name, form.company);

     if (!uniqueness.success) {
       if (uniqueness.field === 'device') {
         // إظهار دايلوج التنبيه الرسمي
         setDuplicateModal({ visible: true, type: 'DEVICE_LINKED' });
       } else {
         setErrors(prev => ({ ...prev, [uniqueness.field]: uniqueness.message }));
         setToast({ visible: true, message: uniqueness.message, type: 'error' });
       }
       return;
     }

     setShowConfirmModal(true);
   } catch (error) {
     setToast({ visible: true, message: 'خطأ في النظام: ' + error.message, type: 'error' });
   } finally {
     setLoading(false);
   }
 };

 const initiateSovereignRegistration = async () => {
   setShowConfirmModal(false);
   setLoading(true);
   if (__DEV__) console.log('🛡️ [UI] تم التأكيد. جاري إنشاء الحساب.');

   try {
     // 1. تنظيف البيانات
     const cleanData = {
       name: form.name.trim(),
       company: form.company.trim(),
       email: form.email.trim().toLowerCase(),
       phone: form.phone.trim(),
       password: form.password,
       currency: form.currency || 'YER',
     };

     // 2. إرسال الطلب
     await register(cleanData);

     setToast({ visible: true, message: 'تم إرسال رمز التحقق بنجاح', type: 'success' });

     // 3. الانتقال إلى خطوة الـ OTP
     setTimeout(() => {
       console.log('🛡️ [Forensic] [UI] الانتقال إلى بوتقة التحقق (OTP).');
       navigation.navigate('OTPVerify', { email: cleanData.email });
     }, 1000);

   } catch (error) {
     console.log(`🛡️ [Forensic] [UI] خطأ أثناء التخليق: ${error.message}`);

     // معالجة التعارضات الصريحة لرحلة المستخدم
     if (error.message === 'DUPLICATE_BOTH' || error.message === 'DUPLICATE_EMAIL' || error.message === 'DUPLICATE_PHONE') {
       setDuplicateModal({ visible: true, type: error.message });
     } else {
       setToast({ visible: true, message: error.message || 'حدث خطأ غير متوقع', type: 'error' });
     }
   } finally {
     setLoading(false);
   }
 };

  // ===== حساب قوة كلمة المرور فوريّاً =====
  const getPasswordStrength = (password) => {
    if (!password) return { score: 0, label: '', color: Colors.border };
    
    let score = 0;
    if (password.length >= 14) score++;
    if (/[A-Z]/.test(password)) score++;
    if (/[a-z]/.test(password)) score++;
    if (/[0-9]/.test(password)) score++;
    if (/[!@#$%^&*]/.test(password)) score++;
    
    const levels = [
      { label: 'ضعيفة جداً', color: '#E74C3C' },
      { label: 'ضعيفة', color: '#F39C12' },
      { label: 'متوسطة', color: '#F1C40F' },
      { label: 'قوية', color: '#2ECC71' },
      { label: 'قوية جداً', color: '#27AE60' },
    ];
    
    return {
      score,
      label: score > 0 ? levels[score - 1].label : '',
      color: score > 0 ? levels[score - 1].color : Colors.border,
    };
  };

  const strength = getPasswordStrength(form.password);

  const modalMessages = {
    DUPLICATE_BOTH: 'لديك حساب بالفعل بهذا البريد الإلكتروني ورقم الهاتف. يرجى تسجيل الدخول أو تغيير البيانات.',
    DUPLICATE_EMAIL: 'هذا البريد الإلكتروني مسجل مسبقاً في النظام.',
    DUPLICATE_PHONE: 'رقم الهاتف هذا مرتبط بحساب آخر مسجل.',
    DEVICE_LINKED: 'تنبيه أمني: هذا الجهاز مرتبط بحساب نشط بالفعل. لا يسمح النظام بإنشاء أكثر من حساب واحد على نفس الجهاز حمايةً لنزاهة البيانات.',
  };

  const modalTitles = {
    DUPLICATE_BOTH: 'الحساب موجود بالفعل',
    DUPLICATE_EMAIL: 'البريد مسجل مسبقاً',
    DUPLICATE_PHONE: 'رقم الهاتف مسجل مسبقاً',
    DEVICE_LINKED: 'تعدد حسابات',
  };

 return (
  <KeyboardAvoidingView style={styles.root} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <Toast visible={toast.visible} message={toast.message} type={toast.type} onHide={() => setToast((prev) => ({ ...prev, visible: false }))} />

       {/* ✅ التحميل السحري السيادي الموحد */}
       <SecurityLoading visible={loading} status="جاري تأمين ميثاقك..." />

        <ImageBackground
          source={HEADER_BG}
          style={styles.headerSection}
          imageStyle={styles.headerImage}
        >
          <View style={styles.logoWrapper}>
            <Image source={LOGO} style={styles.logo} resizeMode="contain" />
          </View>
          <Text style={styles.welcomeTitle}>أنشئ حسابك</Text>
          <Text style={styles.welcomeSub}>أدخل بياناتك وابدأ رحلتك المالية</Text>
        </ImageBackground>
      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>

        <View style={styles.formCard}>
          {/* ✅ تنبيه السيادة الشبكية */}
          {!isOnline && (
            <View style={styles.networkAlert}>
              <Ionicons name="cloud-offline-outline" size={18} color={Colors.red} />
              <Text style={styles.networkAlertText}>
                النظام في وضع الأمان: لا يوجد اتصال بالإنترنت
              </Text>
            </View>
          )}

          {/* الصف الأول: الهوية المؤسسية */}
          <View style={styles.inputRow}>
            <View style={{ flex: 1 }}>
              <Input
                label="الاسم الكامل"
                icon="person-outline"
                value={form.name}
                onChangeText={(v) => updateField('name', v)}
                error={errors.name}
              />
            </View>
            <View style={{ flex: 1 }}>
              <Input
                label="اسم الشركة"
                icon="business-outline"
                value={form.company}
                onChangeText={(v) => updateField('company', v)}
                error={errors.company}
              />
            </View>
          </View>

          {/* الصف الثاني: البريد الإلكتروني (كامل العرض) */}
          <Input
            label="البريد الإلكتروني"
            icon="mail-outline"
            value={form.email}
            onChangeText={(v) => updateField('email', v)}
            keyboardType="email-address"
            autoCapitalize="none"
            error={errors.email}
          />

          {/* الصف الثالث: رقم الهاتف (كامل العرض) */}
          <Input
            label="رقم الهاتف"
            icon="call-outline"
            value={form.phone}
            onChangeText={(v) => updateField('phone', v)}
            keyboardType="phone-pad"
            maxLength={15}
            error={errors.phone}
          />

          {/* الصف الرابع: ميثاق الأمان */}
          <View style={styles.inputRow}>
            <View style={{ flex: 1 }}>
              <Input
                label="كلمة المرور"
                icon="lock-closed-outline"
                value={form.password}
                onChangeText={(v) => updateField('password', v)}
                secureTextEntry
                error={errors.password}
              />
            </View>
            <View style={{ flex: 1 }}>
              <Input
                label="تأكيد الكلمة"
                icon="shield-checkmark-outline"
                value={form.confirmPassword}
                onChangeText={(v) => updateField('confirmPassword', v)}
                secureTextEntry
                error={errors.confirmPassword}
              />
            </View>
          </View>

          {/* مؤشر قوة كلمة المرور */}
          {form.password.length > 0 && !errors.password && (
            <View style={styles.strengthContainer}>
              <View style={styles.strengthBars}>
                {[1, 2, 3, 4, 5].map((i) => (
                  <View
                    key={i}
                    style={[
                      styles.strengthBar,
                      {
                        backgroundColor: i <= strength.score
                          ? strength.color
                          : '#E5E7EB',
                      },
                    ]}
                  />
                ))}
              </View>
              <Text style={[styles.strengthLabel, { color: strength.color }]}>
                {strength.label}
              </Text>
            </View>
          )}

        <Button
          title={!isOnline ? 'في انتظار الشبكة...' : (loading ? 'جاري إنشاء الحساب...' : 'إنشاء حساب')}
          onPress={handleRegister}
          loading={loading}
          disabled={loading || !isOnline}
          style={[styles.registerBtn, !isOnline && { backgroundColor: Colors.gray }]}
        />

          <Text style={styles.termsText}>
            بالتسجيل أنت توافق على {' '}
            <TouchableOpacity onPress={() => setShowTerms(true)}>
              <Text style={styles.termsLink}>شروط الاستخدام</Text>
            </TouchableOpacity>
            {' '} و       {' '}
            <TouchableOpacity onPress={() => setShowTerms(true)}>
              <Text style={styles.termsLink}>سياسة الخصوصية</Text>
            </TouchableOpacity>
          </Text>
        </View>

        {/* ===== فوتر الانتقال لتسجيل الدخول ===== */}
        <View style={styles.footer}>
          <Text style={styles.footerText}>لديك حساب؟</Text>
          <TouchableOpacity
            onPress={() => navigation.goBack()}
            activeOpacity={0.6}
          >
            <Text style={styles.linkText}>تسجيل الدخول</Text>
          </TouchableOpacity>
        </View>

        <Text style={styles.bottomText}>YemenGram © 2026</Text>
      </ScrollView>

      {/* ===== مودال شروط الاستخدام السيادية ===== */}
      <Modal
        visible={showTerms}
        title="ميثاق الاستخدام والخصوصية"
        message="أنت الآن بصدد استخدام نظام يمن جرام للقيادة الرقمية. كافة بياناتك مشفرة ومحمية ببصمة الجهاز. يرجى الالتزام بمعايير الأمان المؤسسي."
        confirmText="أوافق"
        onConfirm={() => setShowTerms(false)}
        hideCancel
      />

      {/* ✅ نافذة التأكيد */}
      <Modal
        visible={showConfirmModal}
        type="confirm"
        title="تأكيد البيانات"
        confirmText="تأكيد"
        cancelText="تعديل"
        onConfirm={initiateSovereignRegistration}
        onCancel={() => setShowConfirmModal(false)}
      >
        <View style={styles.confirmModalContent}>
          <View style={styles.policyNotice}>
             <Ionicons name="alert-circle" size={22} color={Colors.gold} />
             <View style={{flex: 1}}>
                <Text style={styles.policyNoticeTitle}>تنبيه هام:</Text>
                <Text style={styles.policyNoticeText}>
                  سيتم ربط هذا الحساب بجهازك الحالي، ولا يمكن تغيير اسم الشركة أو الاسم الكامل لاحقاً لضمان رسمية السجلات.
                </Text>
             </View>
          </View>

          <Text style={styles.confirmModalDesc}>يرجى التأكد من صحة البيانات لاستلام رمز التحقق:</Text>
          <View style={styles.dataBadge}>
             <Ionicons name="mail" size={14} color={Colors.navy} />
             <Text style={styles.dataText}>{form.email}</Text>
          </View>
          <View style={styles.dataBadge}>
             <Ionicons name="call" size={14} color={Colors.navy} />
             <Text style={styles.dataText}>{form.phone}</Text>
          </View>
        </View>
      </Modal>

      {/* ✅ مودال معالجة التعارضات الصريح */}
      <Modal
        visible={duplicateModal.visible}
        type="warning"
        title={modalTitles[duplicateModal.type]}
        message={modalMessages[duplicateModal.type]}
        confirmText="تسجيل الدخول"
        onConfirm={() => {
          setDuplicateModal({ visible: false, type: '' });
          navigation.navigate('Login');
        }}
        onCancel={() => {
          setDuplicateModal({ visible: false, type: '' });
        }}
      />
 </KeyboardAvoidingView>
  );
}

// =============================================
// 4. الأنماط وتنسيقات التصميم (Styles)
// =============================================

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: Colors.lightGray,
  },

  container: {
    flexGrow: 1,
    justifyContent: 'center',
    paddingHorizontal: 10,
    paddingTop: Platform.OS === 'ios' ? 40 : 3,
    paddingBottom: 30,
  },

  headerSection: {
    alignItems: 'center',
    marginBottom: 10,
    paddingVertical: 20,
    width: '112%',
    alignSelf: 'center',
    overflow: 'hidden',
    borderBottomLeftRadius: 50,
    borderBottomRightRadius: 50,
  },

  headerImage: {
      opacity: 0.9, // تعتيم خفيف للهيبة والوضوح
           resizeMode: 'cover',

       resizeMode: 'center',
       borderRadius:1
  },

  logoWrapper: {
     width: 330,
     height: 120,
     backgroundColor: Colors.white,
     justifyContent: 'center',
     borderRadius: 16,
     shadowColor: '#000',
     shadowOffset: { width: 0, height: 4 },
     shadowOpacity: 0.06,
     shadowRadius: 12,
     elevation: 4,
     marginBottom: 4,
     marginTop:10

  },

  logo: {
    width: 320,
    height: 130,
    borderRadius: 12,
  },

  welcomeTitle: {
    fontSize: 24,
    fontFamily: 'Tajawal-Bold',
    color: Colors.dark,
    textAlign: 'right',
  },

  welcomeSub: {
    fontSize: 13,
    fontFamily: 'Tajawal-Regular',
    color: Colors.gray,
    textAlign: 'right',
    marginTop: 4,
  },

  networkAlert: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    backgroundColor: '#FFF5F5',
    padding: 10,
    borderRadius: 12,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: '#FED7D7',
    gap: 8,
  },

  networkAlertText: {
    fontSize: 12,
    fontFamily: 'Tajawal-Bold',
    color: Colors.red,
    flex: 1,
    textAlign: 'center',
  },

  formCard: {
    width: '100%',
    backgroundColor: Colors.white,
    borderRadius: 20,
    padding: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.09,
    shadowRadius: 78,
    elevation: 9,
  },

  inputRow: {
    flexDirection: 'row-reverse',
    gap: 10,
    width: '100%',
  },

  field: {
    marginBottom: 14,
  },

  label: {
    fontSize: 13,
    fontFamily: 'Tajawal-Medium',
    color: Colors.dark,
    marginBottom: 4,
    textAlign: 'right',
  },

  required: {
    color: Colors.red,
  },

  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F5F6FA',
    borderRadius: 10,
    borderWidth: 1.5,
    borderColor: Colors.border,
    paddingHorizontal: 10,
    height: 46,
  },

  inputError: {
    borderColor: Colors.red,
    backgroundColor: '#FFF5F5',
  },

  input: {
    flex: 1,
    fontSize: 13,
    fontFamily: 'Tajawal-Regular',
    color: Colors.dark,
    height: '100%',
    textAlign:"right"

  },

  errorText: {
    fontSize: 11,
    fontFamily: 'Tajawal-Regular',
    color: Colors.red,
    marginTop: 4,
    textAlign: 'right',
  },

  strengthContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginTop: 6,
  },

  strengthBars: {
    flexDirection: 'row',
    gap: 4,
    flex: 1,
  },

  strengthBar: {
    flex: 0,
    height: 3,
    borderRadius: 2,
    backgroundColor: '#E5E7EB',
  },

  strengthLabel: {
    fontSize: 11,
    fontFamily: 'Tajawal-Medium',
    minWidth: 50,
    textAlign: 'right',
  },

  authRow: {
    flexDirection: 'row',
    gap: 8,
  },

  authOption: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 8,
    borderRadius: 10,
    borderWidth: 1.5,
    borderColor: Colors.border,
    backgroundColor: Colors.white,
  },

  authOptionActive: {
    borderColor: Colors.gold,
    backgroundColor: '#FEFDF9',
  },

  authLabel: {
    fontSize: 12,
    fontFamily: 'Tajawal-Regular',
    color: Colors.gray,
  },

  authLabelActive: {
    color: Colors.dark,
    fontFamily: 'Tajawal-Medium',
  },
  registerBtn: {
    width: '100%',
    marginTop: 4,
  },
  termsText: {
    fontSize: 11,
    fontFamily: 'Tajawal-Regular',
    color: Colors.gray,
    textAlign: 'right',
    marginTop: 1,
    lineHeight: 20,
    width: '100%',
  },

  termsLink: {
    marginLeft:10,

      fontSize: 10,

    color: Colors.navy,
    fontFamily: 'Tajawal-Medium',
  },
  footer: {
    flexDirection: 'row-reverse',
    marginTop: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  footerText: {
    fontSize: 13,
    fontFamily: 'Tajawal-Regular',
    color: Colors.gray,
  },
  linkText: {
    fontSize: 13,
    fontFamily: 'Tajawal-Bold',
    color: Colors.navy,
    marginStart: 6,
  },
  bottomText: {
    marginTop: 20,
    fontSize: 10,
    fontFamily: 'Tajawal-Regular',
    color: Colors.placeholder,
    textAlign: 'center',
  },
  confirmModalContent: {
    paddingVertical: 10,
    alignItems: 'center',
  },
  confirmModalDesc: {
    fontSize: 13,
    fontFamily: 'Tajawal-Regular',
    color: Colors.gray,
    textAlign: 'center',
    marginBottom: 15,
  },
  policyNotice: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    backgroundColor: '#FFFBEB',
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#FEF3C7',
    marginBottom: 20,
    gap: 12,
  },
  policyNoticeTitle: {
    fontSize: 13,
    fontFamily: 'Tajawal-Bold',
    color: '#92400E',
    textAlign: 'right',
  },
  policyNoticeText: {
    fontSize: 11,
    fontFamily: 'Tajawal-Medium',
    color: '#B45309',
    textAlign: 'right',
    marginTop: 2,
  },
  dataBadge: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    backgroundColor: '#F1F5F9',
    paddingVertical: 8,
    paddingHorizontal: 15,
    borderRadius: 20,
    marginBottom: 8,
    width: '100%',
    gap: 10,
  },
  dataText: {
    fontSize: 14,
    fontFamily: 'Tajawal-Medium',
    color: Colors.navy,
    flex: 1,
    textAlign: 'right',
  },
});