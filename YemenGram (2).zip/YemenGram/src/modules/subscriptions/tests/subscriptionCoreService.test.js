const SubscriptionCoreService = require('../services/SubscriptionCoreService');
const { EVENTS, STATES } = require('../services/SubscriptionEngine');

(function run() {
  const svc = new SubscriptionCoreService();
  const id = 'test-sub-1';

  svc.processEvent(id, EVENTS.REQUEST_SUBSCRIPTION).then(({ result, auditEntry, queueItem }) => {
    if (result.nextState !== STATES.PENDING_PAYMENT) throw new Error('expected PENDING_PAYMENT');
    if (!auditEntry || auditEntry.subscriptionId !== id) throw new Error('audit missing');
    if (!queueItem) throw new Error('queueItem missing');
    console.log('subscriptionCoreService: basic integration test passed');
  }).catch(err => {
    console.error('subscriptionCoreService: test failed', err);
    process.exitCode = 1;
  });
})();
