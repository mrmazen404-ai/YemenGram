// src/shared/utils/formatters.js
// =============================================
// دوال تنسيق البيانات (Formatters)
// مجموعة من الدوال لتنسيق الأرقام، التواريخ، العملات، والنصوص
// =============================================

// =============================================
// 1. تنسيق الأرقام
// =============================================

/**
 * تنسيق رقم مع فاصلة الآلاف
 * @param {number} num - الرقم
 * @param {Object} options - خيارات التنسيق
 * @returns {string}
 */
export const formatNumber = (num, options = {}) => {
  const { decimals = 0, useGrouping = true, fallback = '0' } = options;

  if (num === undefined || num === null || isNaN(num)) {
    return fallback;
  }

  const formatted = Number(num).toFixed(decimals);
  if (useGrouping) {
    return Number(formatted).toLocaleString();
  }
  return formatted;
};

/**
 * تنسيق المبلغ بالريال
 * @param {number} amount - المبلغ
 * @param {string} currency - العملة (YER, SAR, USD)
 * @param {Object} options - خيارات التنسيق
 * @returns {string}
 */
export const formatAmount = (amount, currency = 'YER', options = {}) => {
  const { decimals = 2, showSymbol = true, useGrouping = true, fallback = '0' } = options;

  if (amount === undefined || amount === null || isNaN(amount)) {
    return fallback;
  }

  const symbols = {
    YER: 'ريال',
    SAR: 'ر.س',
    USD: '$',
  };

  const symbol = showSymbol ? symbols[currency] || currency : '';
  const formatted = formatNumber(amount, { decimals, useGrouping });

  return `${formatted} ${symbol}`.trim();
};

/**
 * تنسيق المبلغ كنسبة مئوية
 * @param {number} value - القيمة
 * @param {Object} options - خيارات التنسيق
 * @returns {string}
 */
export const formatPercent = (value, options = {}) => {
  const { decimals = 1, showSymbol = true, fallback = '0%' } = options;

  if (value === undefined || value === null || isNaN(value)) {
    return fallback;
  }

  const formatted = Number(value).toFixed(decimals);
  return showSymbol ? `${formatted}%` : formatted;
};

// =============================================
// 2. تنسيق التواريخ
// =============================================

/**
 * تنسيق التاريخ
 * @param {string|Date} date - التاريخ
 * @param {Object} options - خيارات التنسيق
 * @returns {string}
 */
export const formatDate = (date, options = {}) => {
  const {
    format = 'short', // short, medium, long, full
    locale = 'ar-SA',
    fallback = '',
  } = options;

  if (!date) return fallback;

  const parsedDate = typeof date === 'string' ? new Date(date) : date;
  if (isNaN(parsedDate.getTime())) return fallback;

  const formats = {
    short: { year: 'numeric', month: 'numeric', day: 'numeric' },
    medium: { year: 'numeric', month: 'short', day: 'numeric' },
    long: { year: 'numeric', month: 'long', day: 'numeric' },
    full: { year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' },
  };

  return parsedDate.toLocaleDateString(locale, formats[format] || formats.short);
};

/**
 * تنسيق التاريخ مع الوقت
 * @param {string|Date} date - التاريخ
 * @param {Object} options - خيارات التنسيق
 * @returns {string}
 */
export const formatDateTime = (date, options = {}) => {
  const {
    dateFormat = 'medium',
    timeFormat = 'short',
    locale = 'ar-SA',
    fallback = '',
  } = options;

  if (!date) return fallback;

  const parsedDate = typeof date === 'string' ? new Date(date) : date;
  if (isNaN(parsedDate.getTime())) return fallback;

  const dateFormats = {
    short: { year: 'numeric', month: 'numeric', day: 'numeric' },
    medium: { year: 'numeric', month: 'short', day: 'numeric' },
    long: { year: 'numeric', month: 'long', day: 'numeric' },
  };

  const timeFormats = {
    short: { hour: '2-digit', minute: '2-digit' },
    medium: { hour: '2-digit', minute: '2-digit', second: '2-digit' },
  };

  const dateStr = parsedDate.toLocaleDateString(locale, dateFormats[dateFormat] || dateFormats.medium);
  const timeStr = parsedDate.toLocaleTimeString(locale, timeFormats[timeFormat] || timeFormats.short);

  return `${dateStr} - ${timeStr}`;
};

/**
 * تنسيق الوقت فقط
 * @param {string|Date} date - التاريخ
 * @param {Object} options - خيارات التنسيق
 * @returns {string}
 */
export const formatTime = (date, options = {}) => {
  const { format = 'short', locale = 'ar-SA', fallback = '' } = options;

  if (!date) return fallback;

  const parsedDate = typeof date === 'string' ? new Date(date) : date;
  if (isNaN(parsedDate.getTime())) return fallback;

  const formats = {
    short: { hour: '2-digit', minute: '2-digit' },
    medium: { hour: '2-digit', minute: '2-digit', second: '2-digit' },
  };

  return parsedDate.toLocaleTimeString(locale, formats[format] || formats.short);
};

/**
 * الحصول على الوقت المنقضي (منذ)
 * @param {string|Date} date - التاريخ
 * @param {Object} options - خيارات التنسيق
 * @returns {string}
 */
export const formatTimeAgo = (date, options = {}) => {
  const { locale = 'ar-SA', fallback = '' } = options;

  if (!date) return fallback;

  const parsedDate = typeof date === 'string' ? new Date(date) : date;
  if (isNaN(parsedDate.getTime())) return fallback;

  const now = Date.now();
  const diff = now - parsedDate.getTime();

  if (diff < 0) return 'في المستقبل';

  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  const weeks = Math.floor(days / 7);
  const months = Math.floor(days / 30);
  const years = Math.floor(days / 365);

  const rtf = new Intl.RelativeTimeFormatter(locale, { numeric: 'auto' });

  if (seconds < 60) return 'الآن';
  if (minutes < 60) return rtf.format(-minutes, 'minute');
  if (hours < 24) return rtf.format(-hours, 'hour');
  if (days < 7) return rtf.format(-days, 'day');
  if (weeks < 4) return rtf.format(-weeks, 'week');
  if (months < 12) return rtf.format(-months, 'month');
  return rtf.format(-years, 'year');
};

// =============================================
// 3. تنسيق النصوص
// =============================================

/**
 * اختصار النص الطويل
 * @param {string} text - النص
 * @param {number} maxLength - الحد الأقصى
 * @param {string} suffix - النهاية
 * @returns {string}
 */
export const truncateText = (text, maxLength = 30, suffix = '...') => {
  if (!text) return '';
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength) + suffix;
};

/**
 * تحويل النص إلى حالة الجمل (Capitalize)
 * @param {string} text - النص
 * @returns {string}
 */
export const capitalize = (text) => {
  if (!text) return '';
  return text.charAt(0).toUpperCase() + text.slice(1).toLowerCase();
};

/**
 * تحويل النص إلى حالة الجمل (كل كلمة)
 * @param {string} text - النص
 * @returns {string}
 */
export const capitalizeWords = (text) => {
  if (!text) return '';
  return text.split(' ').map(word => capitalize(word)).join(' ');
};

/**
 * إزالة المسافات الزائدة
 * @param {string} text - النص
 * @returns {string}
 */
export const normalizeSpaces = (text) => {
  if (!text) return '';
  return text.replace(/\s+/g, ' ').trim();
};

/**
 * إزالة التشكيل من النص العربي
 * @param {string} text - النص
 * @returns {string}
 */
export const removeDiacritics = (text) => {
  if (!text) return '';
  return text.replace(/[\u064B-\u0652]/g, '');
};

// =============================================
// 4. تنسيق العملات
// =============================================

/**
 * الحصول على رمز العملة
 * @param {string} currency - كود العملة
 * @returns {string}
 */
export const getCurrencySymbol = (currency) => {
  const symbols = {
    YER: 'ريال',
    SAR: 'ر.س',
    USD: '$',
    EUR: '€',
    GBP: '£',
    AED: 'د.إ',
    KWD: 'د.ك',
    QAR: 'ر.ق',
    BHD: 'د.ب',
    OMR: 'ر.ع',
  };
  return symbols[currency] || currency;
};

/**
 * الحصول على اسم العملة
 * @param {string} currency - كود العملة
 * @returns {string}
 */
export const getCurrencyName = (currency) => {
  const names = {
    YER: 'ريال يمني',
    SAR: 'ريال سعودي',
    USD: 'دولار أمريكي',
    EUR: 'يورو',
    GBP: 'جنيه إسترليني',
    AED: 'درهم إماراتي',
    KWD: 'دينار كويتي',
    QAR: 'ريال قطري',
    BHD: 'دينار بحريني',
    OMR: 'ريال عماني',
  };
  return names[currency] || currency;
};

/**
 * تنسيق المبلغ مع العملة
 * @param {number} amount - المبلغ
 * @param {string} currency - العملة
 * @param {Object} options - خيارات التنسيق
 * @returns {string}
 */
export const formatCurrency = (amount, currency = 'YER', options = {}) => {
  const {
    decimals = 2,
    showSymbol = true,
    showCode = false,
    useGrouping = true,
    fallback = '0',
  } = options;

  if (amount === undefined || amount === null || isNaN(amount)) {
    return fallback;
  }

  const symbol = showSymbol ? getCurrencySymbol(currency) : '';
  const formatted = formatNumber(amount, { decimals, useGrouping });
  const code = showCode ? ` ${currency}` : '';

  return `${formatted} ${symbol}${code}`.trim();
};

// =============================================
// 5. تنسيق الهوية والرقم
// =============================================

/**
 * تنسيق رقم الهاتف
 * @param {string} phone - رقم الهاتف
 * @param {string} format - نمط التنسيق
 * @returns {string}
 */
export const formatPhone = (phone, format = 'local') => {
  if (!phone) return '';

  const clean = phone.replace(/[\s\-\(\)\+]/g, '').replace(/[^0-9]/g, '');

  switch (format) {
    case 'international':
      if (clean.length === 9) return `+967 ${clean.slice(0, 3)} ${clean.slice(3, 6)} ${clean.slice(6)}`;
      if (clean.length === 10) return `+${clean.slice(0, 2)} ${clean.slice(2, 5)} ${clean.slice(5, 8)} ${clean.slice(8)}`;
      return clean;
    case 'local':
      if (clean.length === 9) return `${clean.slice(0, 3)} ${clean.slice(3, 6)} ${clean.slice(6)}`;
      return clean;
    default:
      return clean;
  }
};

/**
 * تنسيق البريد الإلكتروني (إخفاء جزئي)
 * @param {string} email - البريد الإلكتروني
 * @param {string} mask - رمز الإخفاء
 * @returns {string}
 */
export const maskEmail = (email, mask = '***') => {
  if (!email) return '';
  const [local, domain] = email.split('@');
  if (!domain) return email;
  if (local.length <= 2) return `${local}@${domain}`;
  return `${local.slice(0, 2)}${mask}@${domain}`;
};

/**
 * تنسيق رقم الحساب (إخفاء جزئي)
 * @param {string} number - الرقم
 * @param {number} visible - عدد الأرقام المرئية
 * @param {string} mask - رمز الإخفاء
 * @returns {string}
 */
export const maskNumber = (number, visible = 4, mask = '•') => {
  if (!number) return '';
  const str = String(number);
  if (str.length <= visible) return str;
  const masked = str.slice(0, -visible);
  const visiblePart = str.slice(-visible);
  return masked.replace(/./g, mask) + visiblePart;
};

// =============================================
// 6. تنسيق الملفات
// =============================================

/**
 * تنسيق حجم الملف
 * @param {number} bytes - الحجم بالبايت
 * @param {number} decimals - عدد الأرقام العشرية
 * @returns {string}
 */
export const formatFileSize = (bytes, decimals = 2) => {
  if (bytes === 0) return '0 B';
  if (!bytes || isNaN(bytes)) return '0 B';

  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));

  const size = (bytes / Math.pow(k, i)).toFixed(decimals);
  return `${size} ${sizes[i]}`;
};

/**
 * الحصول على نوع الملف
 * @param {string} filename - اسم الملف
 * @returns {string}
 */
export const getFileType = (filename) => {
  if (!filename) return 'unknown';
  const extension = filename.split('.').pop()?.toLowerCase() || '';

  const types = {
    pdf: 'pdf',
    doc: 'word',
    docx: 'word',
    xls: 'excel',
    xlsx: 'excel',
    ppt: 'powerpoint',
    pptx: 'powerpoint',
    jpg: 'image',
    jpeg: 'image',
    png: 'image',
    gif: 'image',
    svg: 'image',
    webp: 'image',
    mp4: 'video',
    avi: 'video',
    mov: 'video',
    wmv: 'video',
    mp3: 'audio',
    wav: 'audio',
    aac: 'audio',
    zip: 'archive',
    rar: 'archive',
    '7z': 'archive',
    tar: 'archive',
    gz: 'archive',
    txt: 'text',
    csv: 'text',
    json: 'text',
    xml: 'text',
    html: 'code',
    css: 'code',
    js: 'code',
    ts: 'code',
    py: 'code',
    java: 'code',
    cpp: 'code',
    c: 'code',
  };

  return types[extension] || 'unknown';
};

// =============================================
// 7. تنسيق النصوص العربية
// =============================================

/**
 * تحويل الأرقام إلى أرقام عربية
 * @param {string|number} text - النص
 * @returns {string}
 */
export const toArabicNumbers = (text) => {
  const arabicDigits = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  return String(text).replace(/\d/g, (d) => arabicDigits[parseInt(d)]);
};

/**
 * تحويل الأرقام العربية إلى أرقام إنجليزية
 * @param {string} text - النص
 * @returns {string}
 */
export const toEnglishNumbers = (text) => {
  const arabicDigits = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  return String(text).replace(/[٠-٩]/g, (d) => String(arabicDigits.indexOf(d)));
};

// =============================================
// 8. دوال مساعدة إضافية
// =============================================

/**
 * تنسيق الرقم كـ 0001
 * @param {number} num - الرقم
 * @param {number} length - الطول
 * @returns {string}
 */
export const padNumber = (num, length = 4) => {
  return String(num).padStart(length, '0');
};

/**
 * تنسيق الرقم مع علامة (+/-)
 * @param {number} num - الرقم
 * @param {Object} options - خيارات التنسيق
 * @returns {string}
 */
export const formatSigned = (num, options = {}) => {
  const { showPlus = true, fallback = '0' } = options;

  if (num === undefined || num === null || isNaN(num)) {
    return fallback;
  }

  if (num > 0 && showPlus) return `+${num}`;
  if (num < 0) return `${num}`;
  return '0';
};

// =============================================
// 9. كائن التنسيق الرئيسي
// =============================================

export const formatters = {
  // الأرقام
  number: formatNumber,
  amount: formatAmount,
  percent: formatPercent,

  // التواريخ
  date: formatDate,
  dateTime: formatDateTime,
  time: formatTime,
  timeAgo: formatTimeAgo,

  // النصوص
  truncate: truncateText,
  capitalize,
  capitalizeWords,
  normalizeSpaces,
  removeDiacritics,

  // العملات
  currency: formatCurrency,
  getSymbol: getCurrencySymbol,
  getName: getCurrencyName,

  // الهوية
  phone: formatPhone,
  maskEmail,
  maskNumber,

  // الملفات
  fileSize: formatFileSize,
  fileType: getFileType,

  // العربية
  toArabic: toArabicNumbers,
  toEnglish: toEnglishNumbers,

  // مساعدة
  pad: padNumber,
  signed: formatSigned,
};

export default formatters;