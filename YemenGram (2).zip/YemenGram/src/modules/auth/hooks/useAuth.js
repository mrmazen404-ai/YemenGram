// src/modules/auth/hooks/useAuth.js
// =============================================
// Hook المصادقة المخصص (Custom Auth Hook)
// يوفر دوال المصادقة للاستخدام في جميع أنحاء التطبيق
// =============================================

import { useContext } from 'react';
import AuthContext from '../../../shared/contexts/AuthContext';

// =============================================
// 1. Hook الرئيسي
// =============================================

/**
 * useAuth - Hook مخصص للمصادقة
 * @returns {Object} دوال وحالة المصادقة
 *
 * @example
 * const { user, login, logout } = useAuth();
 */
export const useAuth = () => {
  const context = useContext(AuthContext);

  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }

  return context;
};

// =============================================
// 2. Hooks مساعدة
// =============================================

/**
 * useUser - الحصول على بيانات المستخدم الحالي
 * @returns {Object|null} بيانات المستخدم
 */
export const useUser = () => {
  const { user } = useAuth();
  return user;
};

/**
 * useIsLoggedIn - التحقق من تسجيل الدخول
 * @returns {boolean}
 */
export const useIsLoggedIn = () => {
  const { isLoggedIn } = useAuth();
  return isLoggedIn;
};

/**
 * useIsAdmin - التحقق من صلاحية المدير
 * @returns {boolean}
 */
export const useIsAdmin = () => {
  const { user } = useAuth();
  return user?.role === 'admin';
};

/**
 * useIsAccountant - التحقق من صلاحية المحاسب
 * @returns {boolean}
 */
export const useIsAccountant = () => {
  const { user } = useAuth();
  return user?.role === 'admin' || user?.role === 'accountant';
};

/**
 * useIsSales - التحقق من صلاحية مندوب المبيعات
 * @returns {boolean}
 */
export const useIsSales = () => {
  const { user } = useAuth();
  return user?.role === 'admin' || user?.role === 'accountant' || user?.role === 'sales';
};

/**
 * useUserCode - الحصول على الرقم الفريد للمستخدم
 * @returns {string|null}
 */
export const useUserCode = () => {
  const { user } = useAuth();
  return user?.user_code || null;
};

/**
 * useCompanyName - الحصول على اسم الشركة
 * @returns {string|null}
 */
export const useCompanyName = () => {
  const { user } = useAuth();
  return user?.company_name || null;
};

/**
 * useAuthLoading - حالة تحميل المصادقة
 * @returns {boolean}
 */
export const useAuthLoading = () => {
  const { loading } = useAuth();
  return loading;
};

// =============================================
// 3. Hooks للإجراءات
// =============================================

/**
 * useLogin - دالة تسجيل الدخول
 * @returns {Function}
 */
export const useLogin = () => {
  const { login } = useAuth();
  return login;
};

/**
 * useLogout - دالة تسجيل الخروج
 * @returns {Function}
 */
export const useLogout = () => {
  const { logout } = useAuth();
  return logout;
};

/**
 * useRegister - دالة التسجيل
 * @returns {Function}
 */
export const useRegister = () => {
  const { register } = useAuth();
  return register;
};

/**
 * useVerifyOTP - دالة التحقق من OTP
 * @returns {Function}
 */
export const useVerifyOTP = () => {
  const { verifyOTP } = useAuth();
  return verifyOTP;
};

/**
 * useSendOTP - دالة إرسال OTP
 * @returns {Function}
 */
export const useSendOTP = () => {
  const { sendOTP } = useAuth();
  return sendOTP;
};

/**
 * useForgotPassword - دالة استعادة كلمة المرور
 * @returns {Function}
 */
export const useForgotPassword = () => {
  const { forgotPassword } = useAuth();
  return forgotPassword;
};

/**
 * useResetPassword - دالة إعادة تعيين كلمة المرور
 * @returns {Function}
 */
export const useResetPassword = () => {
  const { resetPassword } = useAuth();
  return resetPassword;
};

/**
 * useChangePassword - دالة تغيير كلمة المرور
 * @returns {Function}
 */
export const useChangePassword = () => {
  const { changePassword } = useAuth();
  return changePassword;
};

// =============================================
// 4. Hooks للـ PIN والأمان
// =============================================

/**
 * usePIN - دوال إدارة PIN
 * @returns {Object}
 */
export const usePIN = () => {
  const {
    setupPIN,
    verifyPIN,
    isPINSet,
    skipPIN,
    isPINSkipped,
    changePIN,
    disablePIN
  } = useAuth();

  return {
    setupPIN,
    verifyPIN,
    isPINSet,
    skipPIN,
    isPINSkipped,
    changePIN,
    disablePIN,
  };
};

/**
 * useBiometric - دوال إدارة البصمة
 * @returns {Object}
 */
export const useBiometric = () => {
  const {
    enableBiometric,
    disableBiometric,
    isBiometricEnabled
  } = useAuth();

  return {
    enableBiometric,
    disableBiometric,
    isBiometricEnabled,
  };
};

// =============================================
// 5. Hook للصلاحيات
// =============================================

/**
 * usePermissions - التحقق من صلاحيات المستخدم
 * @param {string|Array} required - الصلاحية المطلوبة
 * @returns {Object}
 */
export const usePermissions = (required) => {
  const { user } = useAuth();

  const hasRole = (role) => {
    if (!user) return false;
    const roles = {
      admin: ['admin'],
      accountant: ['admin', 'accountant'],
      sales: ['admin', 'accountant', 'sales'],
      customer: ['admin', 'accountant', 'sales', 'customer'],
    };
    const allowed = roles[role] || [];
    return allowed.includes(user.role);
  };

  const hasAnyRole = (roles) => {
    if (!user) return false;
    return roles.some(role => hasRole(role));
  };

  const hasAllRoles = (roles) => {
    if (!user) return false;
    return roles.every(role => hasRole(role));
  };

  let hasAccess = true;
  let requiredRoles = [];

  if (required) {
    if (Array.isArray(required)) {
      requiredRoles = required;
      hasAccess = hasAnyRole(required);
    } else {
      requiredRoles = [required];
      hasAccess = hasRole(required);
    }
  }

  return {
    user,
    isLoggedIn: !!user,
    hasAccess,
    requiredRoles,
    hasRole,
    hasAnyRole,
    hasAllRoles,
    isAdmin: hasRole('admin'),
    isAccountant: hasRole('accountant'),
    isSales: hasRole('sales'),
  };
};

// =============================================
// 6. Hook للتعامل مع المصادقة
// =============================================

/**
 * useAuthActions - جميع إجراءات المصادقة
 * @returns {Object}
 */
export const useAuthActions = () => {
  const {
    login,
    logout,
    register,
    verifyOTP,
    sendOTP,
    forgotPassword,
    resetPassword,
    changePassword,
    deleteAccount,
    updateAvatar,
    setupPIN,
    verifyPIN,
    isPINSet,
    skipPIN,
    isPINSkipped,
    changePIN,
    disablePIN,
    enableBiometric,
    disableBiometric,
    isBiometricEnabled,
  } = useAuth();

  return {
    login,
    logout,
    register,
    verifyOTP,
    sendOTP,
    forgotPassword,
    resetPassword,
    changePassword,
    deleteAccount,
    updateAvatar,
    setupPIN,
    verifyPIN,
    isPINSet,
    skipPIN,
    isPINSkipped,
    changePIN,
    disablePIN,
    enableBiometric,
    disableBiometric,
    isBiometricEnabled,
  };
};

// =============================================
// 7. تصدير الدوال كـ default
// =============================================

export default useAuth;