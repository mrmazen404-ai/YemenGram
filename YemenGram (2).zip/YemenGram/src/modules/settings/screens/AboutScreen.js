// src/modules/settings/screens/AboutScreen.js
// واجهة "عن المؤسسة ومركز الخدمات الشامل" (The Masterpiece Edition)
// نسخة فائقة الاستقرار: تم إزالة مسببات انهيار رندر الأندرويد

import React, { useRef, useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Linking,
  Platform,
  Animated,
  StatusBar,
  Dimensions,
  Share,
} from 'react-native';
import * as Clipboard from 'expo-clipboard';
import { Ionicons, FontAwesome, MaterialCommunityIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import * as Device from 'expo-device';
import Constants from 'expo-constants';
import { LocalDB } from '../../database/localDB';
import { Colors } from '../../../shared/utils/colors';
import Toast from '../../../shared/components/Toast';

const { width } = Dimensions.get('window');
const LOGO = require('../../../shared/assets/images/full-logo.png');

const AboutScreen = ({ navigation }) => {
  const appVersion = Constants.expoConfig?.version || '1.0.0';
  const deviceModel = Device.modelName || 'Unknown Device';
  const osVersion = `${Device.osName} ${Device.osVersion}`;

  const [supportId, setSupportId] = useState('YG-CHARGING...');
  const [isCheckingUpdate, setIsCheckingUpdate] = useState(false);
  const [toast, setToast] = useState({ visible: false, message: '', type: 'success' });
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(15)).current;

  useEffect(() => {
    loadPersistentId();
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.spring(slideAnim, { toValue: 0, tension: 50, friction: 10, useNativeDriver: true }),
    ]).start();
  }, []);

  const loadPersistentId = async () => {
    try {
      let savedId = await LocalDB.getSetting('permanent_support_id');
      if (!savedId) {
        const buildId = (Device.osBuildId || 'CORE').slice(-4).toUpperCase();
        const randomPart = Math.floor(1000 + Math.random() * 9000);
        savedId = `YG-${buildId}-${randomPart}`;
        await LocalDB.saveSetting('permanent_support_id', savedId);
      }
      setSupportId(savedId);
    } catch (e) {
      setSupportId('YG-CORE-OFF');
    }
  };

  const triggerHaptic = (type = 'light') => {
    if (Platform.OS !== 'web') {
      if (type === 'success') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      else Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  const showToast = (message, type = 'success') => {
    setToast({ visible: true, message, type });
  };

  const handleLink = (url) => {
    triggerHaptic();
    Linking.openURL(url).catch(() => showToast('فشل فتح الرابط', 'error'));
  };

  const openMap = () => {
    const latLng = '15.3235,44.2001';
    const label = 'YemenGram ERP HQ';
    const url = Platform.select({
      ios: `maps:0,0?q=${label}@${latLng}`,
      android: `geo:0,0?q=${latLng}(${label})`
    });
    handleLink(url);
  };

  const checkUpdates = () => {
    triggerHaptic();
    setIsCheckingUpdate(true);
    setTimeout(() => {
      setIsCheckingUpdate(false);
      showToast('أنت تستخدم أحدث نسخة أمنية مستقرة');
    }, 2000);
  };

  const handleBack = () => {
    triggerHaptic();
    if (navigation.canGoBack()) navigation.goBack();
    else navigation.navigate('Settings');
  };

  const ServiceRow = ({ icon, label, subLabel, color, onPress, lib = 'Ionicons', isLast = false }) => {
    const IconLib = lib === 'FontAwesome' ? FontAwesome : lib === 'Material' ? MaterialCommunityIcons : Ionicons;
    return (
      <TouchableOpacity style={[styles.serviceRow, isLast && { borderBottomWidth: 0 }]} onPress={onPress} activeOpacity={0.7}>
        <View style={[styles.miniIconBox, { backgroundColor: color + '12' }]}>
          <IconLib name={icon} size={16} color={color} />
        </View>
        <View style={styles.linkTextContainer}>
          <Text style={styles.linkLabel}>{label}</Text>
          <Text style={styles.linkSub}>{subLabel}</Text>
        </View>
        <Ionicons name="chevron-back" size={12} color={Colors.placeholder} />
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.root}>
      <StatusBar barStyle="dark-content" backgroundColor="#F8FAFC" />
      <Toast visible={toast.visible} message={toast.message} type={toast.type} onHide={() => setToast(p => ({ ...p, visible: false }))} />

      <View style={styles.header}>
        <TouchableOpacity style={styles.backBtn} onPress={handleBack}>
          <Ionicons name="chevron-forward" size={22} color={Colors.navy} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>بوابة المؤسسة الرقمية</Text>
        <View style={{ width: 45 }} />
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false} bounces={false}>
        <Animated.View style={{ opacity: fadeAnim, transform: [{ translateY: slideAnim }] }}>

          <View style={styles.brandSection}>
            <View style={styles.logoContainer}>
               <Image source={LOGO} style={styles.logo} resizeMode="contain" />
            </View>
            <Text style={styles.companyName}>YEMEN GRAM ERP</Text>
            <View style={styles.socialBar}>
              {[
                { i: 'telegram', c: '#0088cc', u: 'https://t.me/yemengram' },
                { i: 'youtube-play', c: '#FF0000', u: 'https://youtube.com/yemengram' },
                { i: 'facebook', c: '#1877F2', u: 'https://facebook.com/yemengram' },
                { i: 'whatsapp', c: '#25D366', u: 'https://wa.me/967777881496' }
              ].map((s, i) => (
                <TouchableOpacity key={i} style={styles.socialIcon} onPress={() => handleLink(s.u)}>
                  <FontAwesome name={s.i} size={14} color={s.c} />
                </TouchableOpacity>
              ))}
            </View>
          </View>

          <View style={styles.diagnosticCard}>
             <View style={styles.diagHeader}><Ionicons name="pulse" size={14} color={Colors.gold} /><Text style={styles.diagTitle}>الحالة الفنية للنظام</Text></View>
             <View style={styles.diagGrid}>
                <View style={styles.diagItem}><Text style={styles.diagLabel}>إصدار التطبيق</Text><Text style={styles.diagValue}>v{appVersion}</Text></View>
                <View style={styles.diagItem}><Text style={styles.diagLabel}>الجهاز</Text><Text style={styles.diagValue}>{deviceModel.slice(0,10)}</Text></View>
                <View style={styles.diagItem}><Text style={styles.diagLabel}>النظام</Text><Text style={styles.diagValue}>{osVersion}</Text></View>
             </View>
             <TouchableOpacity style={styles.supportIdBox} onPress={() => { triggerHaptic('success'); Clipboard.setStringAsync(supportId); showToast('تم نسخ معرف الدعم'); }}>
                <Text style={styles.supportIdLabel}>معرف الدعم الموحد:</Text>
                <Text style={styles.supportIdValue}>{supportId}</Text>
                <Ionicons name="copy-outline" size={12} color={Colors.gold} />
             </TouchableOpacity>
          </View>

          <View style={styles.card}>
            <Text style={styles.cardTitle}>الرؤية الاستراتيجية</Text>
            <Text style={styles.bioText}>نعمل على ريادة التحول الرقمي للمؤسسات ببيئة محاسبية فائقة الأمان وسهلة الاستخدام تضمن نمو أعمالكم.</Text>
          </View>

          <View style={styles.sectionHeader}><Text style={styles.sectionTitle}>مركز الدعم والاتصال الرسمي</Text></View>
          <View style={styles.linkCard}>
            <ServiceRow icon="logo-whatsapp" color="#25D366" label="دعم واتساب الأعمال" subLabel="استجابة فورية" onPress={() => handleLink('https://wa.me/967777881496')} />
            <ServiceRow icon="headset-outline" color={Colors.navy} label="الاتصال الهاتفي" subLabel="تحدث مع فريقنا" onPress={() => handleLink('tel:+967777881496')} />
            <ServiceRow icon="globe-outline" color="#3F51B5" label="الموقع الرسمي" subLabel="yemengram.com" onPress={() => handleLink('https://yemengram.com')} isLast />
          </View>

          <TouchableOpacity style={styles.addressCard} onPress={openMap} activeOpacity={0.8}>
             <View style={styles.addressIcon}><Ionicons name="map-outline" size={20} color={Colors.navy} /></View>
             <View style={styles.addressInfo}>
                <Text style={styles.addressLabel}>المقر الرئيسي للمؤسسة</Text>
                <Text style={styles.addressValue}>الجمهورية اليمنية - صنعاء - شارع حدة</Text>
             </View>
             <Ionicons name="chevron-back" size={14} color={Colors.placeholder} />
          </TouchableOpacity>

          {/* زر التحديث المستقر (تم إزالة التدرج اللوني المسبب للخطأ) */}
          <TouchableOpacity
             style={[styles.updateBtn, { backgroundColor: isCheckingUpdate ? '#9CA3AF' : Colors.navy }]}
             activeOpacity={0.8}
             onPress={checkUpdates}
             disabled={isCheckingUpdate}
          >
             <MaterialCommunityIcons name={isCheckingUpdate ? "sync" : "shield-check"} size={18} color={Colors.gold} />
             <Text style={styles.updateBtnText}>{isCheckingUpdate ? 'جاري فحص الأمان...' : 'التحقق من التحديثات الأمنية'}</Text>
          </TouchableOpacity>

          <View style={styles.footer}>
             <Text style={styles.copyright}>YEMEN GRAM © 2024-2026</Text>
             <Text style={styles.rights}>جميع الحقوق والوثائق موثقة ومحمية قانونياً</Text>
          </View>
        </Animated.View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#F8FAFC' },
  header: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingTop: Platform.OS === 'ios' ? 50 : 40, paddingBottom: 15, backgroundColor: '#FFFFFF', borderBottomWidth: 1, borderBottomColor: '#F1F5F9' },
  backBtn: { width: 38, height: 38, borderRadius: 12, backgroundColor: '#F1F5F9', justifyContent: 'center', alignItems: 'center' },
  headerTitle: { fontSize: 14, fontFamily: 'Tajawal-Bold', color: Colors.navy },
  scrollContent: { padding: 16, paddingBottom: 50 },
  brandSection: { alignItems: 'center', marginBottom: 15 },
  logoContainer: { width:  303, height: 150, backgroundColor: '#FFF', borderRadius: 15, justifyContent: 'center', alignItems: 'center', elevation: 2, marginBottom: 10 },
  logo: { width: 300, height: 200 },
  companyName: { fontSize: 18, fontFamily: 'Tajawal-Bold', color: Colors.navy },
  socialBar: { flexDirection: 'row', gap: 12, marginTop: 12 },
  socialIcon: { width: 32, height: 32, borderRadius: 8, backgroundColor: '#FFF', justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: '#F1F5F9' },
  diagCard: { backgroundColor: '#FFF', borderRadius: 20, padding: 12, marginBottom: 15, borderWidth: 1, borderColor: '#F1F5F9' },
  diagHeader: { flexDirection: 'row-reverse', alignItems: 'center', gap: 6, marginBottom: 10 },
  diagTitle: { fontSize: 10, fontFamily: 'Tajawal-Bold', color: Colors.gray },
  diagGrid: { flexDirection: 'row-reverse', justifyContent: 'space-between', marginBottom: 10 },
  diagItem: { alignItems: 'flex-end' },
  diagLabel: { fontSize: 8, fontFamily: 'Tajawal-Regular', color: Colors.placeholder },
  diagValue: { fontSize: 10, fontFamily: 'Tajawal-Bold', color: Colors.navy },
  supportIdBox: { flexDirection: 'row-reverse', backgroundColor: '#F8FAFC', padding: 8, borderRadius: 10, alignItems: 'center', gap: 8 },
  supportIdLabel: { fontSize: 8, fontFamily: 'Tajawal-Medium', color: Colors.gray },
  supportIdValue: { flex: 1, fontSize: 11, fontFamily: 'Tajawal-Bold', color: Colors.gold, textAlign: 'right' },
  card: { backgroundColor: '#FFF', borderRadius: 20, padding: 15, marginBottom: 15, borderWidth: 1, borderColor: '#F1F5F9' },
  cardTitle: { fontSize: 12, fontFamily: 'Tajawal-Bold', color: Colors.navy, textAlign: 'right', marginBottom: 6 },
  bioText: { fontSize: 11, fontFamily: 'Tajawal-Regular', color: Colors.gray, textAlign: 'right', lineHeight: 18 },
  sectionHeader: { marginBottom: 6, paddingHorizontal: 5 },
  sectionTitle: { fontSize: 11, fontFamily: 'Tajawal-Bold', color: Colors.placeholder, textAlign: 'right' },
  linkCard: { backgroundColor: '#FFF', borderRadius: 20, overflow: 'hidden', borderWidth: 1, borderColor: '#F1F5F9', marginBottom: 15 },
  serviceRow: { flexDirection: 'row-reverse', alignItems: 'center', padding: 12, borderBottomWidth: 1, borderBottomColor: '#F8FAFC' },
  miniIconBox: { width: 34, height: 34, borderRadius: 9, justifyContent: 'center', alignItems: 'center' },
  linkTextContainer: { flex: 1, marginRight: 10, alignItems: 'flex-end' },
  linkLabel: { fontSize: 12, fontFamily: 'Tajawal-Bold', color: Colors.dark },
  linkSub: { fontSize: 9, fontFamily: 'Tajawal-Regular', color: Colors.gray },
  addressCard: { flexDirection: 'row-reverse', backgroundColor: '#FFF', borderRadius: 20, padding: 15, alignItems: 'center', borderWidth: 1, borderColor: '#F1F5F9', marginBottom: 15 },
  addressIcon: { width: 40, height: 40, borderRadius: 10, backgroundColor: '#F1F5F9', justifyContent: 'center', alignItems: 'center' },
  addressInfo: { flex: 1, marginRight: 12 },
  addressLabel: { fontSize: 12, fontFamily: 'Tajawal-Bold', color: Colors.dark, textAlign: 'right' },
  addressValue: { fontSize: 10, fontFamily: 'Tajawal-Regular', color: Colors.gray, textAlign: 'right' },
  updateBtn: { height: 48, borderRadius: 12, flexDirection: 'row-reverse', justifyContent: 'center', alignItems: 'center', gap: 8, marginBottom: 30 },
  updateBtnText: { fontSize: 12, fontFamily: 'Tajawal-Bold', color: '#FFF' },
  footer: { alignItems: 'center', marginBottom: 10 },
  copyright: { fontSize: 10, fontFamily: 'Tajawal-Bold', color: Colors.navy },
  rights: { fontSize: 8, fontFamily: 'Tajawal-Regular', color: Colors.placeholder, marginTop: 4 },
});

export default AboutScreen;
