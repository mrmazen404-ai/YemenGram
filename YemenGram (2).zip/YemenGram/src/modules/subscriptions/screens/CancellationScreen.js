/**
 * شاشة إلغاء السيادة المالية (Sovereign Cancellation Screen)
 * تسمح للمستخدم بطلب إلغاء الاشتراك مع التحذير من العواقب المحاسبية
 */

import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import LocalDB from '../../database/localDB';
import SubscriptionCoreService from '../services/SubscriptionCoreService';
import { Colors } from '../../../shared/utils/colors';

export default function CancellationScreen() {
  const navigation = useNavigation();
  const [loading, setLoading] = React.useState(false);
  const [subscription, setSubscription] = React.useState(null);

  React.useEffect(() => {
    (async () => {
      const user = await LocalDB.getUser();
      if (user?.id) {
        const row = await LocalDB.queryOne(
          'SELECT * FROM subscriptions WHERE user_id = ? ORDER BY created_at DESC LIMIT 1',
          [user.id]
        );
        setSubscription(row);
      }
    })();
  }, []);

  const handleCancelRequest = async () => {
    if (!subscription) return;

    Alert.alert(
      'تحذير السيادة المالية',
      'بإلغاء الاشتراك، سيتحول النظام لوضع القراءة فقط ولن تتمكن من إضافة بيانات مالية جديدة. هل أنت متأكد؟',
      [
        { text: 'تراجع', style: 'cancel' },
        {
          text: 'تأكيد الإلغاء التام',
          style: 'destructive',
          onPress: async () => {
            try {
              setLoading(true);
              const service = new SubscriptionCoreService();

              // تنفيذ حدث الإلغاء السيادي
              await service.processEvent(subscription.id, 'CANCEL', {
                userId: subscription.user_id,
                reason: 'user_voluntary_exit',
              });

              Alert.alert('تم الإلغاء', 'تم إيقاف اشتراكك بنجاح. يمكنك استعادة بياناتك عبر التجديد في أي وقت خلال 90 يوماً.');
              navigation.navigate('Dashboard');
            } catch (error) {
              Alert.alert('خطأ', 'فشل تنفيذ طلب الإلغاء.');
            } finally {
              setLoading(false);
            }
          },
        },
      ]
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.warningBox}>
        <MaterialCommunityIcons name="alert-octagon" size={60} color="#EF4444" />
        <Text style={styles.title}>إلغاء السيادة المالية</Text>
        <Text style={styles.subtitle}>
          عذراً لرؤيتك ترحل. يرجى ملاحظة أن بياناتك المالية ستبقى محفوظة في "الأرشفة الباردة" لمدة عام، ولكن العمليات اليومية ستتوقف فوراً.
        </Text>
      </View>

      <View style={styles.impactList}>
        <Text style={styles.impactTitle}>ماذا سيحدث بعد الإلغاء؟</Text>
        <Text style={styles.impactItem}>• منع إضافة فواتير أو قيود محاسبية جديدة.</Text>
        <Text style={styles.impactItem}>• بقاء إمكانية تصدير التقارير السابقة (PDF/Excel).</Text>
        <Text style={styles.impactItem}>• فقدان ميزة المزامنة السحابية اللحظية.</Text>
      </View>

      <TouchableOpacity
        style={styles.cancelBtn}
        onPress={handleCancelRequest}
        disabled={loading || !subscription}
      >
        {loading ? <ActivityIndicator color="#FFF" /> : <Text style={styles.cancelBtnText}>تأكيد إيقاف النظام</Text>}
      </TouchableOpacity>

      <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
        <Text style={styles.backBtnText}>البقاء في "يمن جرام"</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC', padding: 25, justifyContent: 'center' },
  warningBox: { alignItems: 'center', marginBottom: 40 },
  title: { fontSize: 22, fontFamily: 'Tajawal-Bold', color: '#0F172A', marginTop: 20 },
  subtitle: { fontSize: 14, fontFamily: 'Tajawal-Medium', color: '#64748B', textAlign: 'center', marginTop: 10, lineHeight: 22 },
  impactList: { backgroundColor: '#FFF', borderRadius: 20, padding: 20, borderWidth: 1, borderColor: '#F1F5F9', marginBottom: 40 },
  impactTitle: { fontSize: 15, fontFamily: 'Tajawal-Bold', color: '#334155', marginBottom: 15, textAlign: 'right' },
  impactItem: { fontSize: 13, fontFamily: 'Tajawal-Medium', color: '#64748B', textAlign: 'right', marginBottom: 8 },
  cancelBtn: { backgroundColor: '#EF4444', borderRadius: 14, paddingVertical: 16, alignItems: 'center', marginBottom: 15 },
  cancelBtnText: { color: '#FFF', fontFamily: 'Tajawal-Bold', fontSize: 15 },
  backBtn: { backgroundColor: Colors.navy, borderRadius: 14, paddingVertical: 16, alignItems: 'center' },
  backBtnText: { color: '#FFF', fontFamily: 'Tajawal-Bold', fontSize: 15 },
});
