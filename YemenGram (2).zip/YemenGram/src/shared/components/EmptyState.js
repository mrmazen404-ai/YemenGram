// src/shared/components/EmptyState.js
// مكون الحالة الفارغة (Empty State) - يمن جرام (Sovereign Edition)

import React from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '../utils/colors';
import Button from './Button';

export default function EmptyState({
  title = 'لا توجد بيانات',
  description = 'لم يتم العثور على أي سجلات في هذا القسم حالياً.',
  icon = 'document-text-outline',
  image,
  actionTitle,
  onAction,
  style,
}) {
  return (
    <View style={[styles.container, style]}>
      <View style={styles.iconContainer}>
        {image ? (
          <Image source={image} style={styles.image} resizeMode="contain" />
        ) : (
          <Ionicons name={icon} size={80} color={Colors.navy + '20'} />
        )}
      </View>

      <Text style={styles.title}>{title}</Text>
      <Text style={styles.description}>{description}</Text>

      {actionTitle && onAction && (
        <Button
          title={actionTitle}
          onPress={onAction}
          style={styles.button}
          variant="gold"
          size="medium"
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
    backgroundColor: 'transparent',
  },
  iconContainer: {
    marginBottom: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  image: {
    width: 150,
    height: 150,
  },
  title: {
    fontSize: 20,
    fontFamily: 'Tajawal-Bold',
    color: Colors.navy,
    textAlign: 'center',
    marginBottom: 10,
  },
  description: {
    fontSize: 14,
    fontFamily: 'Tajawal-Medium',
    color: Colors.gray,
    textAlign: 'center',
    lineHeight: 22,
    marginBottom: 30,
  },
  button: {
    minWidth: 200,
  },
});