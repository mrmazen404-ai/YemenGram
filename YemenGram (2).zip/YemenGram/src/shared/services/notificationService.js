// src/shared/services/notificationService.js
// =============================================
// خدمة الإشعارات (Notification Service)
// المسؤولة عن إدارة الإشعارات داخل التطبيق و Push Notifications
// =============================================

import { Platform } from 'react-native';
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { LocalDB } from './storageService';
import { Logger } from '../utils/logger';
import { NOTIFICATION } from '../utils/constants';

// =============================================
// 1. الثوابت
// =============================================

const TYPES = NOTIFICATION.TYPES || {
  INFO: 'info',
  SUCCESS: 'success',
  WARNING: 'warning',
  ERROR: 'error',
};

const TYPES_COLORS = NOTIFICATION.TYPES_COLORS || {
  info: '#2196F3',
  success: '#27AE60',
  warning: '#F39C12',
  error: '#E74C3C',
};

const TYPES_ICONS = NOTIFICATION.TYPES_ICONS || {
  info: 'information-circle',
  success: 'checkmark-circle',
  warning: 'alert-circle',
  error: 'close-circle',
};

// =============================================
// 2. تهيئة الإشعارات
// =============================================

/**
 * تهيئة الإشعارات
 * @returns {Promise<void>}
 */
export const initializeNotifications = async () => {
  try {
    // طلب صلاحية الإشعارات
    const { status } = await Notifications.getPermissionsAsync();
    if (status !== 'granted') {
      const { status: newStatus } = await Notifications.requestPermissionsAsync();
      if (newStatus !== 'granted') {
        Logger.warn('⚠️ [Notifications] لم يتم منح صلاحية الإشعارات');
        return;
      }
    }

    // إعداد قناة الإشعارات (Android)
    if (Platform.OS === 'android') {
      await Notifications.setNotificationChannelAsync('default', {
        name: 'عام',
        importance: Notifications.AndroidImportance.MAX,
        vibrationPattern: [0, 250, 250, 250],
        lightColor: '#FF231F7C',
        sound: 'default',
        enableVibrate: true,
        enableLight: true,
      });

      await Notifications.setNotificationChannelAsync('success', {
        name: 'نجاح',
        importance: Notifications.AndroidImportance.HIGH,
        sound: 'default',
      });

      await Notifications.setNotificationChannelAsync('warning', {
        name: 'تحذير',
        importance: Notifications.AndroidImportance.HIGH,
        sound: 'default',
      });

      await Notifications.setNotificationChannelAsync('error', {
        name: 'خطأ',
        importance: Notifications.AndroidImportance.HIGH,
        sound: 'default',
      });
    }

    // الحصول على Push Token
    const token = await getPushToken();
    if (token) {
      Logger.info(`📱 [Notifications] Push Token: ${token}`);
      // حفظ التوكن في قاعدة البيانات
      await LocalDB.saveSetting('push_token', token);
    }

    Logger.info('✅ [Notifications] تم تهيئة الإشعارات بنجاح');
  } catch (error) {
    Logger.error('❌ [Notifications] فشل تهيئة الإشعارات:', error);
  }
};

/**
 * الحصول على Push Token
 * @returns {Promise<string|null>}
 */
export const getPushToken = async () => {
  try {
    if (!Device.isDevice) {
      Logger.warn('⚠️ [Notifications] Push notifications غير متاحة في المحاكي');
      return null;
    }

    const token = await Notifications.getExpoPushTokenAsync({
      projectId: process.env.EXPO_PROJECT_ID,
    });
    return token.data;
  } catch (error) {
    Logger.error('❌ [Notifications] فشل الحصول على Push Token:', error);
    return null;
  }
};

// =============================================
// 3. دوال الإشعارات الداخلية
// =============================================

/**
 * إنشاء إشعار داخلي
 * @param {Object} data - بيانات الإشعار
 * @param {string} data.type - نوع الإشعار
 * @param {string} data.title - عنوان الإشعار
 * @param {string} data.message - نص الإشعار
 * @param {string} data.action - الإجراء المرتبط
 * @param {any} data.actionData - بيانات الإجراء
 * @param {string} data.userId - معرف المستخدم
 * @returns {Promise<Object>}
 */
export const createNotification = async (data) => {
  const { type = TYPES.INFO, title, message, action = null, actionData = null, userId = null } = data;

  if (!title || !message) {
    throw new Error('العنوان والرسالة مطلوبان');
  }

  try {
    const result = await LocalDB.execute(
      `INSERT INTO notifications
       (user_id, type, title, message, read, action, action_data, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        userId || null,
        type,
        title,
        message,
        0, // غير مقروء
        action || null,
        actionData ? JSON.stringify(actionData) : null,
        Date.now(),
      ]
    );

    Logger.info(`🔔 [Notifications] تم إنشاء إشعار: ${title}`);

    return {
      success: true,
      id: result.lastInsertRowId,
      type,
      title,
      message,
      read: false,
      action,
      actionData,
      created_at: Date.now(),
    };
  } catch (error) {
    Logger.error('❌ [Notifications] فشل إنشاء الإشعار:', error);
    throw error;
  }
};

/**
 * إرسال إشعار فوري
 * @param {Object} data - بيانات الإشعار
 * @param {string} data.title - عنوان الإشعار
 * @param {string} data.body - نص الإشعار
 * @param {Object} data.data - بيانات إضافية
 * @param {string} data.channelId - معرف القناة (Android)
 * @returns {Promise<void>}
 */
export const sendPushNotification = async (data) => {
  const { title, body, data: extraData = {}, channelId = 'default' } = data;

  try {
    await Notifications.scheduleNotificationAsync({
      content: {
        title,
        body,
        data: extraData,
        sound: 'default',
        priority: Notifications.AndroidNotificationPriority.HIGH,
        channelId,
        color: '#1B365D',
        sticky: false,
      },
      trigger: null, // فوري
    });

    Logger.info(`📨 [Notifications] تم إرسال إشعار فوري: ${title}`);
  } catch (error) {
    Logger.error('❌ [Notifications] فشل إرسال الإشعار الفوري:', error);
  }
};

/**
 * إرسال إشعار مؤجل
 * @param {Object} data - بيانات الإشعار
 * @param {string} data.title - عنوان الإشعار
 * @param {string} data.body - نص الإشعار
 * @param {number} data.delay - التأخير بالمللي ثانية
 * @param {Object} data.data - بيانات إضافية
 * @returns {Promise<void>}
 */
export const sendScheduledNotification = async (data) => {
  const { title, body, delay = 5000, data: extraData = {} } = data;

  try {
    await Notifications.scheduleNotificationAsync({
      content: {
        title,
        body,
        data: extraData,
        sound: 'default',
        priority: Notifications.AndroidNotificationPriority.HIGH,
      },
      trigger: {
        seconds: delay / 1000,
      },
    });

    Logger.info(`⏰ [Notifications] تم جدولة إشعار بعد ${delay}ms: ${title}`);
  } catch (error) {
    Logger.error('❌ [Notifications] فشل جدولة الإشعار:', error);
  }
};

// =============================================
// 4. دوال إدارة الإشعارات
// =============================================

/**
 * جلب إشعارات المستخدم
 * @param {string} userId - معرف المستخدم
 * @param {Object} options - خيارات إضافية
 * @returns {Promise<Array>}
 */
export const getUserNotifications = async (userId, options = {}) => {
  const { limit = 50, unreadOnly = false, type = null } = options;

  try {
    let sql = 'SELECT * FROM notifications WHERE user_id = ?';
    const params = [userId];

    if (unreadOnly) {
      sql += ' AND read = 0';
    }

    if (type) {
      sql += ' AND type = ?';
      params.push(type);
    }

    sql += ' ORDER BY created_at DESC LIMIT ?';
    params.push(limit);

    return await LocalDB.query(sql, params);
  } catch (error) {
    Logger.error('❌ [Notifications] فشل جلب الإشعارات:', error);
    return [];
  }
};

/**
 * جلب الإشعارات غير المقروءة
 * @param {string} userId - معرف المستخدم
 * @returns {Promise<Array>}
 */
export const getUnreadNotifications = async (userId) => {
  return await getUserNotifications(userId, { unreadOnly: true });
};

/**
 * جلب عدد الإشعارات غير المقروءة
 * @param {string} userId - معرف المستخدم
 * @returns {Promise<number>}
 */
export const getUnreadCount = async (userId) => {
  try {
    const result = await LocalDB.queryOne(
      'SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND read = 0',
      [userId]
    );
    return result?.count || 0;
  } catch (error) {
    Logger.error('❌ [Notifications] فشل جلب عدد الإشعارات غير المقروءة:', error);
    return 0;
  }
};

/**
 * تحديد إشعار كمقروء
 * @param {number} notificationId - معرف الإشعار
 * @returns {Promise<boolean>}
 */
export const markAsRead = async (notificationId) => {
  try {
    await LocalDB.execute(
      'UPDATE notifications SET read = 1 WHERE id = ?',
      [notificationId]
    );
    return true;
  } catch (error) {
    Logger.error('❌ [Notifications] فشل تحديد الإشعار كمقروء:', error);
    return false;
  }
};

/**
 * تحديد جميع الإشعارات كمقروءة
 * @param {string} userId - معرف المستخدم
 * @returns {Promise<number>}
 */
export const markAllAsRead = async (userId) => {
  try {
    const result = await LocalDB.execute(
      'UPDATE notifications SET read = 1 WHERE user_id = ? AND read = 0',
      [userId]
    );
    return result.changes || 0;
  } catch (error) {
    Logger.error('❌ [Notifications] فشل تحديد جميع الإشعارات كمقروءة:', error);
    return 0;
  }
};

/**
 * حذف إشعار
 * @param {number} notificationId - معرف الإشعار
 * @returns {Promise<boolean>}
 */
export const deleteNotification = async (notificationId) => {
  try {
    await LocalDB.execute('DELETE FROM notifications WHERE id = ?', [notificationId]);
    return true;
  } catch (error) {
    Logger.error('❌ [Notifications] فشل حذف الإشعار:', error);
    return false;
  }
};

/**
 * حذف جميع إشعارات المستخدم
 * @param {string} userId - معرف المستخدم
 * @returns {Promise<number>}
 */
export const deleteAllNotifications = async (userId) => {
  try {
    const result = await LocalDB.execute(
      'DELETE FROM notifications WHERE user_id = ?',
      [userId]
    );
    return result.changes || 0;
  } catch (error) {
    Logger.error('❌ [Notifications] فشل حذف جميع الإشعارات:', error);
    return 0;
  }
};

// =============================================
// 5. دوال الإشعارات حسب النوع
// =============================================

/**
 * إشعار معلومات
 */
export const notifyInfo = (userId, title, message, action = null, actionData = null) => {
  return createNotification({
    userId,
    type: TYPES.INFO,
    title,
    message,
    action,
    actionData,
  });
};

/**
 * إشعار نجاح
 */
export const notifySuccess = (userId, title, message, action = null, actionData = null) => {
  return createNotification({
    userId,
    type: TYPES.SUCCESS,
    title,
    message,
    action,
    actionData,
  });
};

/**
 * إشعار تحذير
 */
export const notifyWarning = (userId, title, message, action = null, actionData = null) => {
  return createNotification({
    userId,
    type: TYPES.WARNING,
    title,
    message,
    action,
    actionData,
  });
};

/**
 * إشعار خطأ
 */
export const notifyError = (userId, title, message, action = null, actionData = null) => {
  return createNotification({
    userId,
    type: TYPES.ERROR,
    title,
    message,
    action,
    actionData,
  });
};

// =============================================
// 6. دوال الإشعارات المسبقة
// =============================================

/**
 * إشعار نجاح تسجيل الدخول
 */
export const notifyLoginSuccess = (userId, userName) => {
  return notifySuccess(
    userId,
    'مرحباً بعودتك!',
    `تم تسجيل الدخول بنجاح، مرحباً ${userName}`,
    'profile',
    { screen: 'Profile' }
  );
};

/**
 * إشعار فاتورة جديدة
 */
export const notifyNewInvoice = (userId, invoiceNumber, customerName) => {
  return notifyInfo(
    userId,
    'فاتورة جديدة',
    `تم إنشاء فاتورة رقم ${invoiceNumber} للعميل ${customerName}`,
    'invoice',
    { screen: 'InvoiceDetail', invoiceNumber }
  );
};

/**
 * إشعار دفعة جديدة
 */
export const notifyNewPayment = (userId, paymentAmount, customerName) => {
  return notifySuccess(
    userId,
    'دفعة جديدة',
    `تم تسجيل دفعة بمبلغ ${paymentAmount} من العميل ${customerName}`,
    'payment',
    { screen: 'PaymentDetail' }
  );
};

/**
 * إشعار فاتورة متأخرة
 */
export const notifyOverdueInvoice = (userId, invoiceNumber, daysOverdue) => {
  return notifyWarning(
    userId,
    'فاتورة متأخرة',
    `الفاتورة رقم ${invoiceNumber} متأخرة ${daysOverdue} يوماً`,
    'invoice',
    { screen: 'InvoiceDetail', invoiceNumber }
  );
};

/**
 * إشعار مخزون منخفض
 */
export const notifyLowStock = (userId, productName, quantity) => {
  return notifyWarning(
    userId,
    'مخزون منخفض',
    `المنتج ${productName} وصل إلى الحد الأدنى (${quantity} قطعة متبقية)`,
    'inventory',
    { screen: 'ProductDetail', productName }
  );
};

// =============================================
// 7. كائن الخدمة الرئيسي
// =============================================

export const notificationService = {
  // التهيئة
  initialize: initializeNotifications,
  getPushToken,

  // إنشاء الإشعارات
  create: createNotification,
  sendPush: sendPushNotification,
  sendScheduled: sendScheduledNotification,

  // جلب الإشعارات
  getUser: getUserNotifications,
  getUnread: getUnreadNotifications,
  getUnreadCount,

  // إدارة الإشعارات
  markAsRead,
  markAllAsRead,
  delete: deleteNotification,
  deleteAll: deleteAllNotifications,

  // إشعارات حسب النوع
  info: notifyInfo,
  success: notifySuccess,
  warning: notifyWarning,
  error: notifyError,

  // إشعارات مسبقة
  loginSuccess: notifyLoginSuccess,
  newInvoice: notifyNewInvoice,
  newPayment: notifyNewPayment,
  overdueInvoice: notifyOverdueInvoice,
  lowStock: notifyLowStock,

  // الثوابت
  TYPES,
  TYPES_COLORS,
  TYPES_ICONS,
};

export default notificationService;