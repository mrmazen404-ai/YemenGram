// src/modules/auth/screens/SplashScreen.js
// شاشة البداية - يمن جرام
import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  Animated,
  StatusBar,
  Easing,
  TouchableOpacity,
  Alert,
  I18nManager, // ✅ إضافة السيادة المكانية
} from 'react-native';
import * as Device from 'expo-device';
import * as SecureStore from 'expo-secure-store';
import * as Haptics from 'expo-haptics'; // ✅ إضافة التفاعل الحسي
import Constants from 'expo-constants';
import { Colors } from '../../../shared/utils/colors';
import { useAuth } from '../../../shared/contexts/AuthContext';
import { LocalDB } from '../../database/localDB';
import { Logger } from '../../../shared/utils/logger';

const LOGO = require('../../../shared/assets/images/full-logo.png');

// مصفوفة المراحل لربط شريط التقدم الفعلي
const INITIALIZATION_STAGES = {
  START: 0,
  INTEGRITY: 0.15,
  VERSION_CHECK: 0.3,
  DATABASE: 0.45,
  TIME_SYNC: 0.65,
  AUTH: 0.85,
  READY: 1.0,
};

export default function SplashScreen({ navigation, onReady, fontsLoaded }) {
  const { checkAuth, isLoggedIn, reAuthRequired } = useAuth();
  const [status, setStatus] = useState('جاري التحميل...');
  const [error, setError] = useState(null);
  const [errorId, setErrorId] = useState(null);
  const mountedRef = useRef(true);

  // ===== تفعيل السيادة المكانية (RTL Enforcement) =====
  useEffect(() => {
    const enforceRTL = async () => {
      try {
        if (!I18nManager.isRTL) {
          I18nManager.allowRTL(true);
          I18nManager.forceRTL(true);
        }
      } catch (e) {
        if (Logger && typeof Logger.warn === 'function') {
          Logger.warn('Splash', `RTL Enforcement failed: ${e.message}`);
        }
      }
    };
    enforceRTL();
  }, []);

  // ===== Refs للأنيميشن =====
  const logoOpacity = useRef(new Animated.Value(0)).current;
  const logoScale = useRef(new Animated.Value(0.7)).current;
  const barWidth = useRef(new Animated.Value(0)).current;
  const contentY = useRef(new Animated.Value(20)).current;

  useEffect(() => {
    return () => { mountedRef.current = false; };
  }, []);

  // تحديث شريط التقدم بذكاء بناءً على المراحل
  const updateProgress = (stage, msg) => {
    if (!mountedRef.current) return;
    setStatus(msg);
    Animated.timing(barWidth, {
      toValue: stage,
      duration: 600,
      useNativeDriver: false,
      easing: Easing.out(Easing.quad),
    }).start();
  };

  // 1. كاشف النزاهة (Integrity Check)
  const checkIntegrity = async () => {
    const isRooted = await Device.isRootedExperimentalAsync();
    const isEmulator = !Device.isDevice;

    // في بيئة الإنتاج، نمنع الأجهزة المخترقة
    if (isRooted && !__DEV__) {
      throw new Error('SYSTEM_COMPROMISED');
    }
    return true;
  };

  // 1.5. فحص التحديث القسري (Sovereign Force Update)
  const checkAppVersion = async () => {
    try {
      // 1. الحصول على الإصدار الحالي من Expo
      const currentVersionCode = Constants.expoConfig?.extra?.versionCode || 1; // نفترض 1 كبداية

      // 2. محاولة جلب آخر متطلبات تحديث من قاعدة البيانات
      const latestUpdate = await LocalDB.queryOne('SELECT * FROM system_updates ORDER BY id DESC LIMIT 1');

      if (latestUpdate) {
        // سياسة صارمة: إذا كان الإصدار الحالي أقل من الحد الأدنى المطلوب
        if (currentVersionCode < latestUpdate.min_required_code) {
          throw new Error('UPDATE_REQUIRED');
        }
      }
    } catch (e) {
      if (e.message === 'UPDATE_REQUIRED') throw e;
      if (__DEV__) console.log('⚠️ [VersionCheck] لم يتم العثور على سجلات تحديث.');
    }
  };

  // 2. مزامنة الزمن السيادية (Strict Time Sync v3.0)
  const checkTimeSync = async () => {
    const timeSources = [
      'https://worldtimeapi.org/api/timezone/Etc/UTC',
      'https://www.google.com',
      'https://1.1.1.1' // Cloudflare DNS
    ];

    let verifiedTime = null;

    for (const source of timeSources) {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 3500);

        const response = await fetch(source, { method: 'HEAD', signal: controller.signal });
        clearTimeout(timeoutId);

        const dateStr = response.headers.get('date');
        if (dateStr) {
          verifiedTime = new Date(dateStr);
          break; // نجحنا في جلب وقت موثوق
        }
      } catch (e) {
        if (__DEV__) console.log(`⚠️ [TimeSync] فشل المصدر: ${source}`);
      }
    }

    if (verifiedTime) {
      const localDate = new Date();
      const diff = Math.abs(verifiedTime - localDate);

      // سياسة صارمة: إذا كان الانحراف > 5 دقائق، نعتبره تلاعباً
      if (diff > 300000) {
        await LocalDB.addAuditLog('SECURITY_ALERT', 'SYSTEM', '0', {
          reason: 'TIME_DRIFT_DETECTED',
          drift_seconds: Math.floor(diff / 1000),
          device_time: localDate.toISOString(),
          server_time: verifiedTime.toISOString()
        });

        if (!__DEV__) throw new Error('TIME_INACCURATE');
      }
    } else {
      // إذا فشلت كافة المصادر، نتحقق من وجود إنترنت أصلاً
      if (!__DEV__) {
        console.warn('⚠️ [Splash] تعذر تأمين السيادة الزمنية.');
      }
    }
  };

  const initializeApp = async () => {
    try {
      setError(null);
      setErrorId(null);

      updateProgress(INITIALIZATION_STAGES.INTEGRITY, 'فحص نزاهة النظام...');
      await checkIntegrity();

      updateProgress(INITIALIZATION_STAGES.VERSION_CHECK, 'التحقق من التحديثات...');
      await checkAppVersion();

      updateProgress(INITIALIZATION_STAGES.DATABASE, 'تهيئة قاعدة البيانات...');
      await LocalDB.ensureConnection();

      updateProgress(INITIALIZATION_STAGES.TIME_SYNC, 'مزامنة الوقت...');
      await checkTimeSync();

      updateProgress(INITIALIZATION_STAGES.AUTH, 'التحقق من الهوية...');
      await checkAuth();

      updateProgress(INITIALIZATION_STAGES.READY, 'جاهز');

      // تسجيل نجاح الإقلاع في السجل الجنائي
      await LocalDB.addAuditLog('SYSTEM_BOOT_SUCCESS', 'SYSTEM', '0', {
        device: Device.modelName,
        os: Device.osName,
        version: Constants.expoConfig?.version
      });

      if (mountedRef.current && fontsLoaded) {
        // نبضة نجاح حسية
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
    } catch (err) {
      handleError(err);
    }
  };

  const handleError = async (err) => {
    if (!mountedRef.current) return;

    // نبضة خطأ حسية قوية
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);

    const randomId = Math.random().toString(36).substring(2, 8).toUpperCase();
    setErrorId(randomId);

    // تسجيل الخطأ جنائياً
    await LocalDB.addAuditLog('BOOT_ERROR', 'SYSTEM', '0', {
      error_id: randomId,
      message: err.message,
      stage: status
    });

    if (Logger && typeof Logger.error === 'function') {
      Logger.error('Splash', `BootError [${randomId}]: ${err.message}`);
    }

    let friendlyMsg = 'حدث خطأ أثناء تشغيل التطبيق. يرجى المحاولة لاحقاً.';

    if (err.message === 'SYSTEM_COMPROMISED') {
      friendlyMsg = 'تم رصد بيئة تشغيل غير آمنة. لا يسمح بالعمليات المالية من هذا الجهاز.';
    } else if (err.message === 'UPDATE_REQUIRED') {
      friendlyMsg = 'إصدار التطبيق قديم. يرجى التحديث للمتابعة.';
    } else if (err.message === 'TIME_INACCURATE') {
      friendlyMsg = 'توقيت الجهاز غير دقيق. يرجى ضبط الوقت تلقائياً والمحاولة مجدداً.';
    } else if (err.message === 'BOOT_TIMEOUT') {
      friendlyMsg = 'فشل الاتصال بالخادم. يرجى التأكد من الإنترنت.';
    }

    setError(friendlyMsg);
  };

  // ===== الأنيميشن النخبوي =====
  useEffect(() => {
    Animated.parallel([
      Animated.timing(logoOpacity, { toValue: 1, duration: 1000, useNativeDriver: true }),
      Animated.spring(logoScale, { toValue: 1, friction: 8, useNativeDriver: true }),
      Animated.timing(contentY, { toValue: 0, duration: 800, useNativeDriver: true, easing: Easing.out(Easing.back()) }),
    ]).start();

    // تشغيل التهيئة مع حماية Timeout مركزي
    const bootTimeout = new Promise((_, reject) =>
      setTimeout(() => reject(new Error('BOOT_TIMEOUT')), 15000)
    );

    Promise.race([initializeApp(), bootTimeout]).catch(err => {
      if (err.message === 'BOOT_TIMEOUT') {
        handleError(new Error('العملية استغرقت وقتاً أطول من المتوقع.'));
      }
    });
  }, []);

  // ===== الانتقال النهائي الذري =====
  useEffect(() => {
    if (status === 'جاهز' && mountedRef.current) {
      if (__DEV__) console.log('🏁 [Splash] تم رصد حالة الجاهزية. تحليل مسار الانتقال...');

      const triggerTransition = () => {
        if (onReady && mountedRef.current) {
          onReady(); // سيقوم AppNavigator بالتوجيه بناءً على reAuthRequired و isLoggedIn
        }
      };

      // تأخير بسيط لإنهاء حركة شريط التقدم بوضوح
      const timer = setTimeout(triggerTransition, 800);
      return () => clearTimeout(timer);
    }
  }, [status]);

  // ===== وظائف الاختبار الجنائي (DEV ONLY) =====
  const runTest = async (type) => {
    try {
      if (type === 'EXPIRE') {
        const eightDaysAgo = Date.now() - (8 * 24 * 60 * 60 * 1000);
        await SecureStore.setItemAsync('last_full_auth_timestamp', eightDaysAgo.toString());
        Alert.alert('الاختبار', 'تم تقديم الزمن لـ 8 أيام. أعد التشغيل الآن.');
      } else if (type === 'MIGRATE') {
        await SecureStore.deleteItemAsync('last_full_auth_timestamp');
        Alert.alert('الاختبار', 'تم مسح تاريخ الدخول (محاكاة مستخدم قديم). أعد التشغيل.');
      }
    } catch (e) {
      Alert.alert('خطأ', e.message);
    }
  };

  if (error) {
    return (
      <View style={styles.root}>
        <View style={styles.content}>
          <Text style={styles.errorIcon}>⚠️</Text>
          <Text style={styles.errorTitle}>فشل </Text>
          <Text style={styles.errorMessage}>{error}</Text>
          <Text style={styles.errorId}>رمز المرجع: {errorId}</Text>

          <TouchableOpacity style={styles.retryBtn} onPress={() => initializeApp()}>
            <Text style={styles.retryBtnText}>إعادة المحاولة</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.root}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      <Animated.View style={[styles.content, { opacity: logoOpacity, transform: [{ translateY: contentY }] }]}>

        <Animated.View style={{ transform: [{ scale: logoScale }] }}>
          <Image source={LOGO} style={styles.logo} resizeMode="contain" />
        </Animated.View>

        <View style={styles.loadingContainer}>
          <View style={styles.barTrack}>
            <Animated.View
              style={[
                styles.barFill,
                {
                  width: barWidth.interpolate({
                    inputRange: [0, 1],
                    outputRange: ['0%', '100%'],
                  }),
                },
              ]}
            />
          </View>

          <Text style={styles.statusText}>{status}</Text>
        </View>

        <View style={styles.footer}>
          <Text style={styles.footerText}>نظام يمن جرام نظامك المحاسبي والاداري المتكامل </Text>
          <Text style={styles.copyright}>النسخة المعتمدة v1.0.5</Text>

          {/* ✅ بوابة الاختبار الجنائية (تظهر فقط للمطورين) */}
          {__DEV__ && (
            <View style={styles.testSuite}>
              <TouchableOpacity onPress={() => runTest('EXPIRE')} style={styles.testBtn}>
                <Text style={styles.testBtnText}>محاكاة 8 أيام</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => runTest('MIGRATE')} style={styles.testBtn}>
                <Text style={styles.testBtnText}>محاكاة ترحيل</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#FFFFFF' },
  content: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 40 },
  logo: { width: 280, height: 180, marginBottom: 40 },
  loadingContainer: { width: '100%', alignItems: 'center', marginTop: 20 },
  barTrack: { width: '60%', height: 3, backgroundColor: '#F3F4F6', borderRadius: 10, overflow: 'hidden' },
  barFill: { height: '100%', backgroundColor: '#1B365D', borderRadius: 10 },
  statusText: { marginTop: 15, fontSize: 12, fontFamily: 'Tajawal-Medium', color: '#6B7280', textAlign: 'right' },
  errorIcon: { fontSize: 60, marginBottom: 20, textAlign: 'right' },
  errorTitle: { fontSize: 22, fontFamily: 'Tajawal-Bold', color: '#1B365D', marginBottom: 10, textAlign: 'right' },
  errorMessage: { fontSize: 14, fontFamily: 'Tajawal-Regular', color: '#6B7280', textAlign: 'right', marginBottom: 5, paddingHorizontal: 20 },
  errorId: { fontSize: 11, color: '#9CA3AF', marginBottom: 30, textAlign: 'right' },
  retryBtn: { backgroundColor: '#1B365D', paddingHorizontal: 40, paddingVertical: 14, borderRadius: 12 },
  retryBtnText: { color: '#FFFFFF', fontSize: 16, fontFamily: 'Tajawal-Medium' },
  footer: { position: 'absolute', bottom: 40, alignItems: 'center' },
  footerText: { fontSize: 12, fontFamily: 'Tajawal-Bold', color: '#1B365D', opacity: 0.6 },
  copyright: { fontSize: 10, fontFamily: 'Tajawal-Regular', color: '#9CA3AF', marginTop: 4 },
  testSuite: { flexDirection: 'row', gap: 10, marginTop: 15 },
  testBtn: { backgroundColor: '#F3F4F6', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8, borderWidth: 1, borderColor: '#D1D5DB' },
  testBtnText: { fontSize: 10, color: '#6B7280', fontFamily: 'Tajawal-Medium' },
});