// src/shared/utils/syncTester.js
// =============================================
// محاكي المزامنة والاختبار (Sync Simulator & Tester)
// مخصص لاختبار سيناريوهات الأوفلاين والمزامنة السحابية
// =============================================

import { LocalDB } from '../../modules/database/localDB';
import { syncService } from '../../services/syncService';
import { addToSyncQueue, getPendingCount } from '../../modules/database/syncManager';

export const SyncTester = {
  /**
   * 1. محاكاة إضافة بيانات محلياً (كما لو كان المستخدم أوفلاين)
   */
  async simulateOfflineAction(userId) {
    try {
      console.log('🧪 [SyncTester] بدء محاكاة إضافة عميل محلياً...');

      let activeUserId = userId;
      if (!activeUserId) {
        const currentUser = await LocalDB.getUser();
        activeUserId = currentUser?.id || 'default_user_id';
      }

      const testCustomerId = `cust_test_${Date.now()}`;
      const testCode = `C${Math.floor(Math.random() * 10000)}`;
      const testName = `عميل تجريبي سيادي ${Math.floor(Math.random() * 1000)}`;

      // إدخال العميل في جدول العملاء المحلي
      await LocalDB.execute(
        `INSERT INTO customers (id, user_id, code, name, phone, currency, balance, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))`,
        [testCustomerId, activeUserId, testCode, testName, '777000000', 'YER', 0]
      );

      // إضافة العملية إلى طابور المزامنة
      await addToSyncQueue(
        activeUserId,
        'insert',
        'customers',
        testCustomerId,
        {
          id: testCustomerId,
          user_id: activeUserId,
          code: testCode,
          name: testName,
          phone: '777000000',
          currency: 'YER',
          balance: 0,
          updated_at: new Date().toISOString()
        }
      );

      console.log(`✅ [SyncTester] تم بنجاح إضافة العميل الوهمي وتعبئة طابور المزامنة للعميل: ${testName}`);

      const pending = await getPendingCount(activeUserId);
      console.log(`📊 [SyncTester] عدد العمليات المعلقة في طابور المزامنة: ${pending}`);

      return { success: true, customerId: testCustomerId };
    } catch (e) {
      console.error('❌ [SyncTester] فشل محاكاة العملية:', e.message);
      return { success: false, error: e.message };
    }
  },

  /**
   * 2. تنفيذ المزامنة يدوياً وفحص النتيجة
   */
  async runManualSync() {
    try {
      console.log('🔄 [SyncTester] تشغيل المزامنة اليدوية للاختبار...');
      const result = await syncService.sync();
      console.log('🏁 [SyncTester] نتيجة المزامنة:', result);
      return result;
    } catch (e) {
      console.error('❌ [SyncTester] خطأ أثناء المزامنة اليدوية:', e.message);
      return { success: false, error: e.message };
    }
  },

  /**
   * 3. جلب حالة طابور المزامنة الحالي
   */
  async checkQueueStatus(userId) {
    try {
      let activeUserId = userId;
      if (!activeUserId) {
        const currentUser = await LocalDB.getUser();
        activeUserId = currentUser?.id || 'default_user_id';
      }

      const count = await getPendingCount(activeUserId);
      const pendingOps = await LocalDB.query(
        'SELECT * FROM sync_queue WHERE user_id = ? AND status = ?',
        [activeUserId, 'pending']
      );
      console.log(`📊 [SyncTester] العمليات المعلقة (${count}):`, pendingOps);
      return { count, pendingOps };
    } catch (e) {
      console.error('❌ [SyncTester] فشل فحص الطابور:', e.message);
      return { count: 0, pendingOps: [] };
    }
  }
};

export default SyncTester;
