// src/modules/dashboard/styles/DashboardStyles.js
// تحفة السيادة البصرية - التصميم والتنسيق فقط (v6.0 Design-Only)

import { StyleSheet, Dimensions, Platform, PixelRatio } from 'react-native';
import { Colors } from '../../../shared/utils/colors';

const { width, height } = Dimensions.get('window');
// Sovereign Scaling Utility
const scale = (size) => (width / 375) * size;
const moderateScale = (size, factor = 0.5) => size + (scale(size) - size) * factor;
export const styles = StyleSheet.create({
  // ===== الجذر =====
  root: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  // ===== حاوية الاندماج العلوي (Perfect Blend Wrapper) =====
  topSectionWrapper: {
    backgroundColor: Colors.navy,
    // لا نحتاج لـ padding هنا لأننا سنستخدم StatusBar.currentHeight برمجياً
  },

  // ===== شريط الحالة الداخلي (Sovereign Info Bar) =====
  statusBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: scale(20),
    paddingVertical: scale(10),
    backgroundColor: Colors.navy, // إعادة اللون لضمان الظهور
  },
  statusLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: scale(6),
  },
  statusDot: {
    width: scale(6),
    height: scale(6),
    borderRadius: scale(3),
    shadowColor: '#4ADE80',
    shadowOpacity: 0.5,
    shadowRadius: 5,
  },
  statusText: {
    fontSize: scale(9),
    fontFamily: 'Tajawal-Medium',
    color: 'rgba(255, 255, 255, 0.8)',
  },
  statusTime: {
    fontSize: scale(9),
    fontFamily: 'Tajawal-Regular',
    color: 'rgba(255, 255, 255, 0.5)',
  },

  // ===== الهيدر السيادي المطور =====
  header: {
    paddingHorizontal: scale(20),
    paddingVertical: scale(16),
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: Colors.navy, // إعادة اللون لضمان الظهور
    borderBottomWidth: 1,
    borderColor: 'rgba(212, 168, 83, 0.1)',
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: scale(14),
  },
  avatarMini: {
    width: scale(46),
    height: scale(46),
    borderRadius: scale(16),
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: Colors.gold,
    shadowColor: Colors.gold,
    shadowOpacity: 0.2,
    shadowRadius: 10,
  },
  avatarImage: {
    width: '100%',
    height: '100%',
    borderRadius: scale(14),
  },
  avatarInitial: {
    fontSize: scale(20),
    fontFamily: 'Tajawal-Bold',
    color: Colors.white,
  },
  welcomeText: {
    alignItems: 'flex-start',
  },
  greeting: {
    fontSize: scale(10),
    fontFamily: 'Tajawal-Medium',
    color: 'rgba(255, 255, 255, 0.5)',
    marginBottom: scale(-2),
  },
  userName: {
    fontSize: scale(17),
    fontFamily: 'Tajawal-Bold',
    color: Colors.white,
    letterSpacing: 0.2,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: scale(12),
  },
  iconBtn: {
    width: scale(42),
    height: scale(42),
    borderRadius: scale(12),
    backgroundColor: 'rgba(255, 255, 255, 0.12)', // زيادة الكثافة قليلاً
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.2,
    borderColor: 'rgba(255, 255, 255, 0.15)',
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 2,
  },

  // ===== بطاقة الخزنة =====
  vaultContainer: {
    paddingHorizontal: 16,
    marginTop: 12,
  },
  balanceCard: {
    width: '100%',
    height: 160,
    borderRadius: 24,
    padding: 18,
    justifyContent: 'space-between',
    overflow: 'hidden',
    shadowColor: Colors.navy,
    shadowOpacity: 0.2,
    shadowRadius: 20,
    elevation: 10,
  },
  chartOverlay: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.06,
    tintColor: Colors.white,
  },

  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(255,255,255,0.08)',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
  },
  statusText: {
    fontSize: 9,
    fontFamily: 'Tajawal-Bold',
    color: '#4ADE80',
  },

  mainBalanceRow: {
    alignItems: 'flex-end',
  },
  mainBalanceValue: {
    fontSize: 24,
    fontFamily: 'Tajawal-Bold',
    color: Colors.white,
    letterSpacing: 0.3,
  },

  multiCurrencyRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderTopWidth: 0.5,
    borderTopColor: 'rgba(255,255,255,0.08)',
    paddingTop: 10,
  },
  currencyUnit: {
    alignItems: 'center',
  },
  unitValue: {
    fontSize: 12,
    fontFamily: 'Tajawal-Bold',
    color: Colors.white,
  },
  unitLabel: {
    fontSize: 8,
    fontFamily: 'Tajawal-Medium',
    color: 'rgba(255,255,255,0.5)',
  },

  insightRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 4,
  },
  insightItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  insightText: {
    fontSize: 9,
    fontFamily: 'Tajawal-Bold',
  },
  lakomColor: {
    color: '#4B7B5E',
  },
  alaykomColor: {
    color: '#B76E79',
  },

  // ===== المؤشرات =====
  statsSection: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    marginTop: 16,
    gap: 8,
  },
  statsCard: {
    flex: 1,
    backgroundColor: Colors.white,
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 6,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 6,
    elevation: 2,
    borderWidth: 1,
    borderColor: '#F1F5F9',
  },
  statsIconWrapper: {
    width: 36,
    height: 36,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 4,
  },
  statsValue: {
    fontSize: 18,
    fontFamily: 'Tajawal-Bold',
    color: Colors.navy,
    marginBottom: 1,
  },
  statsLabel: {
    fontSize: 9,
    fontFamily: 'Tajawal-Medium',
    color: '#94A3B8',
    marginBottom: 3,
  },
  statsChangeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
  },
  statsChangeText: {
    fontSize: 8,
    fontFamily: 'Tajawal-Bold',
  },

  // ===== التنبيهات =====
  alertSection: {
    paddingHorizontal: 16,
    marginTop: 12,
  },
  alertBanner: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#FEF9E7',
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: '#FDEBD0',
  },
  alertText: {
    flex: 1,
    fontSize: 11,
    fontFamily: 'Tajawal-Medium',
    color: '#92400E',
    marginHorizontal: 8,
  },
  alertAction: {
    fontSize: 10,
    fontFamily: 'Tajawal-Bold',
    color: Colors.gold,
  },

  // ===== الرسم البياني =====
  chartSection: {
    paddingHorizontal: 16,
    marginTop: 16,
  },
  chartCard: {
    backgroundColor: Colors.white,
    borderRadius: 16,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 6,
    elevation: 2,
    borderWidth: 1,
    borderColor: '#F1F5F9',
  },
  chartHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  chartTitle: {
    fontSize: 14,
    fontFamily: 'Tajawal-Bold',
    color: Colors.navy,
  },
  chartExport: {
    fontSize: 11,
    fontFamily: 'Tajawal-Medium',
    color: Colors.gold,
  },
  chartWrapper: {
    width: '100%',
    position: 'relative',
    backgroundColor: '#F8FAFC',
    borderRadius: 12,
    overflow: 'hidden',
  },
  chartGridLine: {
    position: 'absolute',
    left: 10,
    right: 10,
    backgroundColor: '#E2E8F0',
  },
  chartLine: {
    position: 'absolute',
    left: 20,
    right: 20,
    top: 15,
    bottom: 15,
    borderWidth: 2,
    borderColor: Colors.gold,
    borderRadius: 10,
    opacity: 0.3,
  },
  chartDot: {
    position: 'absolute',
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: Colors.gold,
  },
  chartLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8,
    paddingHorizontal: 12,
  },
  chartLabel: {
    fontSize: 9,
    fontFamily: 'Tajawal-Medium',
    color: '#94A3B8',
  },

  // ===== النشاط =====
  activitySection: {
    paddingHorizontal: 16,
    marginTop: 16,
  },
  recentCard: {
    backgroundColor: Colors.white,
    borderRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 6,
    elevation: 2,
    borderWidth: 1,
    borderColor: '#F1F5F9',
  },
  recentHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  recentTitle: {
    fontSize: 14,
    fontFamily: 'Tajawal-Bold',
    color: Colors.navy,
  },
  recentViewAll: {
    fontSize: 11,
    fontFamily: 'Tajawal-Medium',
    color: Colors.gold,
  },
  recentItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
  },
  recentSeparator: {
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  recentLeft: {
    alignItems: 'flex-start',
  },
  recentNumber: {
    fontSize: 12,
    fontFamily: 'Tajawal-Bold',
    color: Colors.navy,
  },
  recentCustomer: {
    fontSize: 11,
    fontFamily: 'Tajawal-Regular',
    color: '#94A3B8',
    marginTop: 2,
  },
  recentRight: {
    alignItems: 'flex-end',
  },
  recentAmount: {
    fontSize: 13,
    fontFamily: 'Tajawal-Bold',
    color: Colors.navy,
  },
  recentStatusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 2,
  },
  recentStatusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  recentStatusText: {
    fontSize: 9,
    fontFamily: 'Tajawal-Medium',
  },

  // ===== مركز العمليات السيادي (Operations Hub) =====
  gridSection: {
    paddingHorizontal: 16,
    marginTop: 20,
    marginBottom: 10,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 14,
  },
  sectionTitle: {
    fontSize: 16,
    fontFamily: 'Tajawal-Bold',
    color: Colors.navy,
  },
  seeAll: {
    fontSize: 11,
    fontFamily: 'Tajawal-Medium',
    color: Colors.gold,
  },
  actionGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    backgroundColor: Colors.white,
    padding: 16,
    borderRadius: 24,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 15,
    elevation: 3,
    borderWidth: 1,
    borderColor: '#F1F5F9',
  },
  actionCard: {
    width: '30%',
    alignItems: 'center',
    marginBottom: 18,
  },
  iconWrapper: {
    width: scale(50),
    height: scale(50),
    borderRadius: scale(16),
    backgroundColor: '#F8FAFC',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#EDF2F7',
    marginBottom: scale(8),
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  actionLabel: {
    fontSize: 10,
    fontFamily: 'Tajawal-Bold',
    color: Colors.dark,
    textAlign: 'center',
  },

  footerSpacer: {
    height: 80,
  },

  // ===== شريط التنقل السفلي الاحترافي (Sovereign Navigation Bar) =====
  bottomBar: {
    position: 'absolute',
    bottom: scale(20),
    left: scale(14),
    right: scale(14),
    height: scale(68),
    backgroundColor: Colors.navy, // العودة للكحلي الملكي الرسمي
    borderRadius: scale(34),
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    shadowColor: Colors.navy,
    shadowOpacity: 0.4,
    shadowRadius: 20,
    elevation: 20,
    borderWidth: 1.5,
    borderColor: 'rgba(212, 168, 83, 0.2)', // استخدام شفافية الذهب الرسمي
    paddingHorizontal: scale(5),
  },
  navItem: {
    width: scale(50),
    height: scale(50),
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: scale(25),
  },
  navItemActive: {
    backgroundColor: 'rgba(212, 168, 83, 0.15)', // وهج من الذهب الرسمي
  },
  bloomCenterBtn: {
    width: scale(62),
    height: scale(62),
    borderRadius: scale(31),
    backgroundColor: Colors.gold,
    marginTop: scale(-40),
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 5,
    borderColor: Colors.navy, // التوحيد مع لون الشريط الرسمي
    shadowColor: Colors.gold,
    shadowOpacity: 0.6,
    shadowRadius: 15,
    elevation: 12,
  },
  navLabel: {
    fontSize: scale(8),
    fontFamily: 'Tajawal-Bold',
    color: Colors.gold,
    marginTop: scale(2),
  },

  // ===== قائمة Bloom المطهرة =====
  menuOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(15, 23, 42, 0.75)', // دمج أعمق
    zIndex: 1000,
  },
  bloomNode: {
    position: 'absolute',
    width: scale(48), // ✅ تصغير الحجم للهيبة (48 بدلاً من 56)
    height: scale(48),
    borderRadius: scale(24),
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.15,
    shadowRadius: 10,
    elevation: 8,
    borderWidth: 1,
    borderColor: 'rgba(212, 168, 83, 0.3)', // ذهبي خفيف
    zIndex: 1001,
  },
  bloomNodeTouch: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  bloomNodeLabel: {
    position: 'absolute',
    top: 52,
    minWidth: 70,
    textAlign: 'center',
    fontSize: 8, // ✅ تصغير الخط للرسمية
    fontFamily: 'Tajawal-Bold',
    color: Colors.navy,
    backgroundColor: 'rgba(255,255,255,0.95)',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
    borderWidth: 0.5,
    borderColor: Colors.border,
  },
  scrollContent: {
    paddingBottom: 20,
  },
  // ===== أزرار التنقل السريع (الهيبة والسيادة) =====
  quickNavSection: {
    paddingHorizontal: 16,
    marginTop: 16,
    gap: 12,
  },
  quickNavRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
  },
  quickNavBtn: {
    flex: 1,
    height: scale(80),
    borderRadius: scale(20),
    overflow: 'hidden',
    elevation: 8,
    shadowColor: Colors.navy,
    shadowOpacity: 0.15,
    shadowRadius: 10,
  },
  quickNavGradient: {
    flex: 1,
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  quickNavIconBox: {
    width: scale(40),
    height: scale(40),
    borderRadius: scale(14),
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  quickNavInfo: {
    flex: 1,
    alignItems: 'flex-end',
  },
  quickNavLabel: {
    fontSize: 14,
    fontFamily: 'Tajawal-Bold',
    color: Colors.white,
  },
  quickNavSub: {
    fontSize: 8,
    fontFamily: 'Tajawal-Medium',
    color: 'rgba(255, 255, 255, 0.5)',
    marginTop: 1,
  },
});