// src/modules/accounts/services/accountsService.js
// خدمة الحسابات المستخدمة من القيود اليومية

import { LocalDB } from '../../database/localDB';

export const AccountsService = {
  async addMovement(data) {
    const result = await LocalDB.execute(
      `INSERT INTO account_movements
       (account_id, date, journal_entry_id, invoice_id, reference, description, debit, credit, balance)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
      , [
        data.account_id,
        data.date || new Date().toISOString(),
        data.journal_entry_id || null,
        data.invoice_id || null,
        data.reference || null,
        data.description || null,
        Number(data.debit) || 0,
        Number(data.credit) || 0,
        0,
      ]
    );
    return result;
  },

  async updateBalance(accountId) {
    const row = await LocalDB.queryOne(
      `SELECT COALESCE(SUM(debit), 0) AS debit,
              COALESCE(SUM(credit), 0) AS credit
       FROM account_movements WHERE account_id = ?`,
      [accountId]
    );
    const account = await LocalDB.queryOne('SELECT type FROM accounts WHERE id = ?', [accountId]);
    if (!account) throw new Error('الحساب غير موجود');
    const debitNature = ['asset', 'expense'].includes(account.type);
    const balance = debitNature
      ? Number(row?.debit || 0) - Number(row?.credit || 0)
      : Number(row?.credit || 0) - Number(row?.debit || 0);
    await LocalDB.execute('UPDATE accounts SET balance = ?, updated_at = datetime("now") WHERE id = ?', [balance, accountId]);
    return balance;
  },
};

export default AccountsService;
