// src/modules/settings/profile/ProfileScreen.js
// شاشة إدارة الهوية السيادية (Sovereign Profile Hub - v1.0)
// المنسق الرئيسي لكافة وحدات الملف الشخصي

import React, { useState } from 'react';
import { ScrollView, View, Text, TouchableOpacity, SafeAreaView, StatusBar } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { styles } from './ProfileStyles';
import { Colors } from '../../../shared/utils/colors';
import { useAuth } from '../../../shared/contexts/AuthContext';
import Toast from '../../../shared/components/Toast';
import * as Clipboard from 'expo-clipboard';
import * as Haptics from 'expo-haptics';

// استيراد الوحدات الذرية
import { AvatarModule } from './avatar/AvatarManager';
import { ProfileInfo } from './components/ProfileInfo';
import { ProfileSecurity } from './components/ProfileSecurity';
import { DeleteAccountFlow } from './components/DeleteAccountFlow';
import ChangePasswordModal from './components/ChangePasswordModal';
import ChangeEmailModal from './components/ChangeEmailModal'; // ✅ إضافة الاستيراد
import ChangePhoneModal from './components/ChangePhoneModal';

export default function ProfileScreen({ navigation }) {
  const { user, setUser } = useAuth();
  const [toast, setToast] = useState({ visible: false, message: '', type: 'success' });
  const [showDeleteFlow, setShowDeleteFlow] = useState(false);
  const [showChangePass, setShowChangePass] = useState(false);
  const [showChangeEmail, setShowChangeEmail] = useState(false); // ✅ حالة تغيير البريد
  const [showChangePhone, setShowChangePhone] = useState(false);

  const showNotify = (data) => {
    setToast({ visible: true, ...data });
  };

  const copyToClipboard = async (text) => {
    await Clipboard.setStringAsync(text);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    showNotify({ message: 'تم نسخ معرف الهوية بنجاح', type: 'success' });
  };

  const handleSecurityAction = (action) => {
    switch (action) {
      case 'change_password':
        setShowChangePass(true); // ✅ فتح المودال بدلاً من الانتقال
        break;
      default:
        break;
    }
  };

  return (
    <SafeAreaView style={styles.root}>
      <StatusBar barStyle="dark-content" />
      <Toast
        visible={toast.visible}
        message={toast.message}
        type={toast.type}
        onHide={() => setToast(p => ({ ...p, visible: false }))}
      />

      {/* الرأس (Header) */}
      <View style={{ flexDirection: 'row-reverse', alignItems: 'center', padding: 20, gap: 15 }}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-forward" size={24} color={Colors.navy} />
        </TouchableOpacity>
        <Text style={{ fontSize: 20, fontFamily: 'Tajawal-Bold', color: Colors.navy }}>الملف الشخصي</Text>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 40 }}>

        {/* 1. وحدة الأفاتار */}
        <AvatarModule
          user={user}
          onUpdate={(newAvatar) => setUser(prev => ({ ...prev, avatar: newAvatar }))}
          onNotify={showNotify}
        />

        {/* 1.5 وسام الهوية السيادية (The ID Card) */}
        <View style={styles.idCard}>
           <View style={styles.idInfo}>
              <Text style={styles.idLabel}>مُعرف الحساب </Text>
              <Text style={styles.idValue}>{user?.user_code || 'CODE-0000'}</Text>
           </View>

           <TouchableOpacity
             style={styles.copyBtn}
             onPress={() => copyToClipboard(user?.user_code)}
             activeOpacity={0.7}
           >
              <Ionicons name="copy-outline" size={20} color={Colors.gold} />
           </TouchableOpacity>
        </View>

        {/* 2. وحدة البيانات المؤسسية */}
        <ProfileInfo
          user={user}
          onEditEmail={() => setShowChangeEmail(true)}
          onEditPhone={() => setShowChangePhone(true)}
        />

        {/* 3. وحدة ترسانة الأمان */}
        <ProfileSecurity onAction={handleSecurityAction} />

        {/* 4. منطقة الخطر (إبطال الهوية) */}
        <View style={styles.section}>
           <TouchableOpacity
             style={styles.deleteBtn}
             onPress={() => setShowDeleteFlow(true)}
           >
             <Ionicons name="trash-outline" size={20} color={Colors.red} />
             <Text style={styles.deleteText}>حذف الحساب نهائياً</Text>
           </TouchableOpacity>
        </View>

        <DeleteAccountFlow
          visible={showDeleteFlow}
          onClose={() => setShowDeleteFlow(false)}
        />

        <ChangePasswordModal
          visible={showChangePass}
          onClose={() => setShowChangePass(false)}
          onNotify={showNotify}
        />

        <ChangeEmailModal
          visible={showChangeEmail}
          onClose={() => setShowChangeEmail(false)}
          onNotify={showNotify}
        />

        <ChangePhoneModal
          visible={showChangePhone}
          onClose={() => setShowChangePhone(false)}
          onNotify={showNotify}
        />
        <Text style={{ textAlign: 'center', color: Colors.border, fontSize: 10, marginTop: 20 }}>
          يمن جرام © 2026
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}
