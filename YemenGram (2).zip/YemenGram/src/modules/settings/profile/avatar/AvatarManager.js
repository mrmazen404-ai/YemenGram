// src/modules/settings/profile/avatar/AvatarManager.js
// واجهة إدارة الأفاتار (Sovereign Avatar Component - v1.1 Hardened)
// تم الإصلاح: تفعيل حالات التحميل، توحيد الهوية البصرية، وتأمين التزامن

import React, { useState } from 'react';
import { View, Text, TouchableOpacity, Image, Modal, Pressable, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import * as Haptics from 'expo-haptics';
import { styles } from '../ProfileStyles';
import { AvatarService } from './AvatarService';
import { Colors } from '../../../../shared/utils/colors';
import SecurityLoading from '../../../../shared/components/SecurityLoading';

const DEFAULT_AVATAR = require('../../../../shared/assets/images/pc.png');

export const AvatarModule = ({ user, onUpdate, onNotify }) => {
  const [localLoading, setLocalLoading] = useState(false);
  const [showOptions, setShowOptions] = useState(false);

  const triggerHaptic = (style = Haptics.ImpactFeedbackStyle.Medium) => {
    Haptics.impactAsync(style);
  };

  const handleAction = async (action) => {
    setShowOptions(false);
    triggerHaptic();

    if (action === 'delete') {
      try {
        setLocalLoading(true);
        // ✅ إعادة تعيين الصورة إلى الحالة الافتراضية السيادية بدلاً من null
        await AvatarService.updateUserAvatar(user.id, 'default_pc');
        onUpdate?.('default_pc');
        onNotify?.({ message: 'تم إعادة الصورة الافتراضية بنجاح', type: 'success' });
      } catch (error) {
        onNotify?.({ message: 'فشل إعادة ضبط الصورة', type: 'error' });
      } finally {
        setLocalLoading(false);
      }
      return;
    }

    // اختيار صورة
    const source = action === 'camera' ? 'camera' : 'library';
    pickImage(source);
  };

  const pickImage = async (source) => {
    try {
      const permission = source === 'camera'
        ? await ImagePicker.requestCameraPermissionsAsync()
        : await ImagePicker.requestMediaLibraryPermissionsAsync();

      if (!permission.granted) {
        onNotify?.({ message: 'الصلاحية مطلوبة للوصول للصور', type: 'error' });
        return;
      }

      const result = source === 'camera'
        ? await ImagePicker.launchCameraAsync({
            allowsEditing: true,
            aspect: [1, 1],
            quality: 0.5,
            base64: true,
          })
        : await ImagePicker.launchImageLibraryAsync({
            allowsEditing: true,
            aspect: [1, 1],
            quality: 0.5,
            base64: true,
          });

      if (!result.canceled && result.assets[0].base64) {
        setLocalLoading(true);
        const base64 = `data:image/jpeg;base64,${result.assets[0].base64}`;

        // التحديث عبر الخدمة
        const success = await AvatarService.updateUserAvatar(user.id, base64);

        if (success) {
          onUpdate?.(base64);
          onNotify?.({ message: 'تم تحديث الصورة الشخصية بنجاح', type: 'success' });
          triggerHaptic(Haptics.ImpactFeedbackStyle.Heavy);
        }
      }
    } catch (error) {
      console.log('❌ [AvatarModule] خطأ:', error.message);
      onNotify?.({ message: 'فشل في تحديث الصورة', type: 'error' });
    } finally {
      setLocalLoading(false);
    }
  };

  return (
    <View style={styles.heroSection}>
      <SecurityLoading visible={localLoading} status="جاري الحفظ..." />

      <TouchableOpacity
        style={styles.avatarContainer}
        onPress={() => setShowOptions(true)}
        activeOpacity={0.8}
      >
        {user?.avatar && user.avatar !== 'default_pc' ? (
          <Image
            source={{ uri: user.avatar }}
            style={styles.avatarImage}
          />
        ) : (
          <View style={[styles.avatarInitial, { backgroundColor: 'transparent' }]}>
             <Image
               source={DEFAULT_AVATAR}
               style={styles.avatarImage}
               resizeMode="cover"
             />
             <View style={[StyleSheet.absoluteFill, { justifyContent: 'center', alignItems: 'center' }]}>
                <Text style={[styles.initialText, { textShadowColor: 'rgba(0, 0, 0, 0.4)', textShadowOffset: {width: 1, height: 1}, textShadowRadius: 10 }]}>
                  {user?.name ? user.name.charAt(0).toUpperCase() : 'Y'}
                </Text>
             </View>
          </View>
        )}
      </TouchableOpacity>

      <Text style={styles.userName}>{user?.name || 'مستخدم يمن جرام'}</Text>
      <Text style={styles.userCode}>{user?.user_code || ''}</Text>

      {/* مودال خيارات الصورة الاحترافي */}
      <Modal
        visible={showOptions}
        transparent
        animationType="slide"
        onRequestClose={() => setShowOptions(false)}
      >
        <Pressable
          style={styles.modalOverlay}
          onPress={() => setShowOptions(false)}
        >
          <View style={styles.actionSheet}>
            <Text style={styles.sheetTitle}>تعديل الصورة الشخصية</Text>

            <TouchableOpacity style={styles.sheetItem} onPress={() => handleAction('camera')}>
              <Ionicons name="camera-outline" size={22} color={Colors.navy} />
              <Text style={styles.itemText}>التقاط صورة بالكاميرا</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.sheetItem} onPress={() => handleAction('library')}>
              <Ionicons name="images-outline" size={22} color={Colors.navy} />
              <Text style={styles.itemText}>اختيار من المعرض</Text>
            </TouchableOpacity>

            {user?.avatar && (
              <TouchableOpacity style={[styles.sheetItem, styles.deleteItem]} onPress={() => handleAction('delete')}>
                <Ionicons name="trash-outline" size={22} color={Colors.red} />
                <Text style={[styles.itemText, { color: Colors.red }]}>حذف الصورة الحالية</Text>
              </TouchableOpacity>
            )}

            <TouchableOpacity style={styles.cancelItem} onPress={() => setShowOptions(false)}>
              <Text style={styles.cancelText}>إلغاء</Text>
            </TouchableOpacity>
          </View>
        </Pressable>
      </Modal>
    </View>
  );
};
