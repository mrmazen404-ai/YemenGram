// src/modules/database/migrations.js
// =============================================
// تهيئة قاعدة البيانات وتنفيذ الترحيلات
// =============================================

let db = null;

// =============================================
// 1. تشغيل الترحيلات
// =============================================

export async function runMigrations(database) {
  try {
    db = database;
    console.log('📦 [Migrations] بدء تهيئة قاعدة البيانات...');

    // ✅ 1. إعداد PRAGMA
    try {
      await db.execAsync(`
        PRAGMA journal_mode = WAL;
        PRAGMA foreign_keys = ON;
        PRAGMA synchronous = NORMAL;
        PRAGMA cache_size = 10000;
      `);
      console.log('✅ [Migrations] تم إعداد PRAGMA');
    } catch (pragmaError) {
      console.log('⚠️ [Migrations] فشل إعداد PRAGMA:', pragmaError.message);
    }

    // ✅ 2. إنشاء الجداول
    await createAllTables(db);

    // ✅ 3. تحديث الجداول الموجودة (إضافة الأعمدة الجديدة)
    await updateExistingTables(db);

    // ترقية آمنة للمخازن القديمة: لا تفشل إذا كان العمود موجوداً.
    for (const statement of [
      'ALTER TABLE subscriptions ADD COLUMN previous_status TEXT',
      "CREATE UNIQUE INDEX IF NOT EXISTS uq_subscription_trial_user ON subscriptions(user_id) WHERE plan = 'trial'",
      'CREATE INDEX IF NOT EXISTS idx_subscriptions_user_status ON subscriptions(user_id, status)',
    ]) {
      try { await db.execAsync(statement); } catch (_) { /* already applied */ }
    }

    // تحويل بيانات الإصدارات القديمة دون حذفها.
    await db.execAsync(`UPDATE subscriptions SET status = CASE
      WHEN status IN ('ACTIVE', 'active') THEN 'ACTIVE_FULL'
      WHEN status IN ('PENDING_PAYMENT', 'PENDING_VERIFICATION', 'REVIEWING_RECEIPT', 'RECEIPT_SUBMITTED') THEN 'VERIFICATION_PENDING'
      WHEN status IN ('EXPIRED', 'expired') THEN 'EXPIRED_GRACE'
      WHEN status IN ('SUSPENDED', 'suspended') THEN 'SECURITY_SUSPENDED'
      ELSE COALESCE(status, 'UNSUBSCRIBED') END
      WHERE status IS NULL OR status NOT IN ('UNSUBSCRIBED','TRIAL_ACTIVE','TRIAL_EXPIRED','ACTIVE_FULL','RESOURCES_EXCEEDED','VERIFICATION_PENDING','EXPIRED_GRACE','SECURITY_SUSPENDED','CANCELLED','REFUND_PENDING','EXTENSION_PENDING');`);

    // ✅ 4. إضافة البيانات الافتراضية
    await seedDefaultData(db);

    console.log('🎉 [Migrations] تم تهيئة قاعدة البيانات بالكامل بنجاح!');
    return { success: true, message: 'تم تهيئة قاعدة البيانات' };
  } catch (error) {
    console.log('❌ [Migrations] خطأ:', error.message);
    db = null;
    return { success: false, error: error.message };
  }
}

// =============================================
// 2. إنشاء جميع الجداول
// =============================================

async function createAllTables(db) {
  try {
    // قائمة الجداول (35 جدولاً)
    const tables = [
      createTableUser,
      createTableSession,
      createTableSettings,
      createTableAuditLog,
      createTableSyncQueue,
      createTableAccounts,
      createTableAccountMovements,
      createTableCustomerTiers,
      createTableCustomers,
      createTableCustomerContacts,
      createTableCustomerNotes,
      createTableCustomerActivities,
      createTableSuppliers,
      createTableProducts,
      createTableProductCategories,
      createTableJournalEntries,
      createTableJournalDetails,
      createTableInvoices,
      createTableInvoiceItems,
      createTableCashAccounts,
      createTableChecks,
      createTableSubscriptions,
      createTableNotifications,
      createTableEmployees,
      createTablePayroll,
      createTableExpenses,
      createTableRevenues,
      createTableTransfers,
      createTablePayments,
      createTableFixedAssets,
      createTableAssetDepreciation,
      createTableBackupHistory,
      createTableCurrencies,
      createTableVatRates,
      createTableDefaultAccounts,
      createTableSystemUpdates, // ✅ الجدول رقم 36: التحديثات السيادية
      createTableDevices,       // ✅ الجدول رقم 37: الأجهزة المرتبطة
      createTableReceipts,       // جدول الإيصالات
      createTableSubscriptionEventKeys, // مفاتيح idempotency
    ];

    for (let i = 0; i < tables.length; i++) {
      try {
        await tables[i](db);
      } catch (error) {
        throw new Error(`فشل إنشاء جدول الترحيل رقم ${i + 1}: ${error.message}`);
      }
    }

    console.log('✅ [Migrations] تم فحص وتحديث هيكلة الجداول (35 جدولاً)');
  } catch (error) {
    console.log('❌ [Migrations] خطأ في إنشاء الجداول:', error.message);
    throw error;
  }
}

// =============================================
// 3. دوال إنشاء الجداول (35 جدولاً)
// =============================================

async function createTableUser(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS user (
      id TEXT PRIMARY KEY NOT NULL,
      user_code TEXT UNIQUE,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      phone TEXT,
      avatar TEXT,
      role TEXT NOT NULL DEFAULT 'user',
      company_id TEXT,
      company_name TEXT,
      base_currency TEXT DEFAULT 'YER',
      is_blocked INTEGER DEFAULT 0,
      blocked_reason TEXT,
      blocked_at TEXT,
      trusted_device_id TEXT, -- ✅ بصمة الجهاز السيادية المعتمدة
      device_metadata TEXT,   -- ✅ معلومات الجهاز (موديل، ماركة)
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    );
  `);
  console.log('✅ 1. user');
}

async function createTableSession(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS session (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      token TEXT NOT NULL,
      device_fingerprint TEXT,
      signature TEXT, -- ✅ حقل التوقيع الرقمي للنزاهة
      hardware_signature TEXT, -- ✅ ربط الجلسة بالعتاد لمنع النقل
      expires_at TEXT NOT NULL,
      created_at TEXT DEFAULT (datetime('now'))
    );
  `);
  console.log('✅ 2. session');
}

async function createTableSettings(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY NOT NULL,
      value TEXT NOT NULL,
      updated_at TEXT DEFAULT (datetime('now'))
    );
  `);
  console.log('✅ 3. settings');
}

async function createTableAuditLog(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS audit_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT,
      action TEXT NOT NULL,
      table_name TEXT,
      record_id TEXT,
      details TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    );
  `);
  console.log('✅ 4. audit_log');
}

async function createTableSyncQueue(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS sync_queue (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT,
      action TEXT NOT NULL CHECK (action IN ('insert', 'update', 'delete')),
      table_name TEXT NOT NULL,
      record_id TEXT,
      data TEXT NOT NULL,
      status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'synced', 'failed')),
      attempts INTEGER DEFAULT 0,
      created_at TEXT DEFAULT (datetime('now')),
      synced_at TEXT
    );
  `);
  console.log('✅ 5. sync_queue');
}

async function createTableAccounts(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS accounts (
      id TEXT PRIMARY KEY NOT NULL,
      user_id TEXT,
      code TEXT NOT NULL,
      name TEXT NOT NULL,
      type TEXT NOT NULL CHECK (type IN ('asset', 'liability', 'equity', 'revenue', 'expense')),
      parent_id TEXT,
      currency TEXT DEFAULT 'YER',
      balance REAL DEFAULT 0,
      is_active INTEGER DEFAULT 1,
      notes TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (parent_id) REFERENCES accounts(id) ON DELETE CASCADE
    );
  `);
  console.log('✅ 6. accounts');
}

async function createTableAccountMovements(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS account_movements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      account_id TEXT NOT NULL,
      date TEXT NOT NULL DEFAULT (date('now')),
      journal_entry_id TEXT,
      invoice_id TEXT,
      reference TEXT,
      description TEXT,
      debit REAL DEFAULT 0,
      credit REAL DEFAULT 0,
      balance REAL DEFAULT 0,
      created_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE
    );
  `);
  console.log('✅ 7. account_movements');
}

async function createTableCustomerTiers(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS customer_tiers (
      id TEXT PRIMARY KEY NOT NULL,
      name TEXT NOT NULL UNIQUE,
      level INTEGER DEFAULT 1,
      description TEXT,
      is_active INTEGER DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    );
  `);
  console.log('✅ 8. customer_tiers');
}

async function createTableCustomers(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS customers (
      id TEXT PRIMARY KEY NOT NULL,
      user_id TEXT NOT NULL,
      code TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'individual',
      phone TEXT,
      email TEXT,
      address TEXT,
      tax_number TEXT,
      credit_limit REAL DEFAULT 0,
      balance REAL DEFAULT 0,
      account_id TEXT,
      tier_id TEXT,
      currency TEXT DEFAULT 'YER',
      default_discount REAL DEFAULT 0,
      payment_terms INTEGER DEFAULT 30,
      opening_balance REAL DEFAULT 0,
      category TEXT,
      preferred_payment_method TEXT,
      contact_person TEXT,
      contact_phone TEXT,
      assigned_to TEXT,
      source TEXT,
      tags TEXT,
      last_contact_date TEXT,
      notes TEXT,
      is_active INTEGER DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE,
      FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE SET NULL,
      FOREIGN KEY (tier_id) REFERENCES customer_tiers(id) ON DELETE SET NULL
    );
  `);
  console.log('✅ 9. customers');
}

async function createTableCustomerContacts(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS customer_contacts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      customer_id TEXT NOT NULL,
      name TEXT NOT NULL,
      phone TEXT,
      email TEXT,
      position TEXT,
      is_primary INTEGER DEFAULT 0,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE
    );
  `);
  console.log('✅ 10. customer_contacts');
}

async function createTableCustomerNotes(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS customer_notes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      customer_id TEXT NOT NULL,
      note TEXT NOT NULL,
      created_by TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE
    );
  `);
  console.log('✅ 11. customer_notes');
}

async function createTableCustomerActivities(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS customer_activities (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      customer_id TEXT NOT NULL,
      type TEXT NOT NULL CHECK (type IN ('call', 'email', 'meeting', 'note', 'visit')),
      description TEXT,
      date TEXT DEFAULT (datetime('now')),
      created_by TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE
    );
  `);
  console.log('✅ 12. customer_activities');
}

async function createTableSuppliers(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS suppliers (
      id TEXT PRIMARY KEY NOT NULL,
      user_id TEXT,
      code TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      phone TEXT,
      email TEXT,
      address TEXT,
      tax_number TEXT,
      account_id TEXT,
      notes TEXT,
      is_active INTEGER DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE,
      FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE SET NULL
    );
  `);
  console.log('✅ 13. suppliers');
}

async function createTableProducts(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS products (
      id TEXT PRIMARY KEY NOT NULL,
      user_id TEXT,
      code TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      category TEXT,
      unit TEXT,
      purchase_price REAL DEFAULT 0,
      sale_price REAL DEFAULT 0,
      quantity REAL DEFAULT 0,
      min_quantity REAL DEFAULT 0,
      account_id TEXT,
      notes TEXT,
      is_active INTEGER DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE,
      FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE SET NULL
    );
  `);
  console.log('✅ 14. products');
}

async function createTableProductCategories(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS product_categories (
      id TEXT PRIMARY KEY NOT NULL,
      name TEXT NOT NULL UNIQUE,
      description TEXT,
      is_active INTEGER DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    );
  `);
  console.log('✅ 15. product_categories');
}

async function createTableJournalEntries(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS journal_entries (
      id TEXT PRIMARY KEY NOT NULL,
      user_id TEXT,
      number INTEGER NOT NULL,
      date TEXT NOT NULL DEFAULT (date('now')),
      description TEXT,
      total_debit REAL DEFAULT 0,
      total_credit REAL DEFAULT 0,
      currency TEXT DEFAULT 'YER',
      status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'posted', 'void')),
      created_by TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE
    );
  `);
  console.log('✅ 16. journal_entries');
}

async function createTableJournalDetails(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS journal_details (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      journal_entry_id TEXT NOT NULL,
      account_id TEXT NOT NULL,
      debit REAL DEFAULT 0,
      credit REAL DEFAULT 0,
      description TEXT,
      FOREIGN KEY (journal_entry_id) REFERENCES journal_entries(id) ON DELETE CASCADE,
      FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE
    );
  `);
  console.log('✅ 17. journal_details');
}

async function createTableInvoices(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS invoices (
      id TEXT PRIMARY KEY NOT NULL,
      user_id TEXT NOT NULL,
      number TEXT NOT NULL UNIQUE,
      type TEXT NOT NULL CHECK (type IN ('sale', 'purchase', 'return_sale', 'return_purchase')),
      date TEXT NOT NULL DEFAULT (date('now')),
      customer_id TEXT,
      supplier_id TEXT,
      account_id TEXT,
      total REAL DEFAULT 0,
      discount REAL DEFAULT 0,
      tax REAL DEFAULT 0,
      net_total REAL DEFAULT 0,
      currency TEXT DEFAULT 'YER',
      status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'posted', 'void')),
      notes TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE,
      FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL,
      FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL,
      FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE SET NULL
    );
  `);
  console.log('✅ 18. invoices');
}

async function createTableInvoiceItems(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS invoice_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL,
      invoice_id TEXT NOT NULL,
      product_id TEXT,
      description TEXT,
      quantity REAL DEFAULT 1,
      unit_price REAL DEFAULT 0,
      total REAL DEFAULT 0,
      FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE,
      FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE,
      FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
    );
  `);
  console.log('✅ 19. invoice_items');
}

async function createTableCashAccounts(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS cash_accounts (
      id TEXT PRIMARY KEY NOT NULL,
      user_id TEXT,
      code TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      type TEXT NOT NULL CHECK (type IN ('cash', 'bank')),
      account_id TEXT,
      bank_name TEXT,
      account_number TEXT,
      balance REAL DEFAULT 0,
      currency TEXT DEFAULT 'YER',
      is_active INTEGER DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE,
      FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE SET NULL
    );
  `);
  console.log('✅ 20. cash_accounts');
}

async function createTableChecks(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS checks (
      id TEXT PRIMARY KEY NOT NULL,
      user_id TEXT,
      number TEXT NOT NULL,
      type TEXT NOT NULL CHECK (type IN ('received', 'issued')),
      amount REAL NOT NULL,
      date TEXT NOT NULL,
      due_date TEXT NOT NULL,
      bank_name TEXT,
      customer_id TEXT,
      supplier_id TEXT,
      cash_account_id TEXT,
      status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'cleared', 'bounced', 'void')),
      notes TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE,
      FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL,
      FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL,
      FOREIGN KEY (cash_account_id) REFERENCES cash_accounts(id) ON DELETE SET NULL
    );
  `);
  console.log('✅ 21. checks');
}

async function createTableSubscriptions(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS subscriptions (
      id TEXT PRIMARY KEY NOT NULL,
      user_id TEXT NOT NULL,
      status TEXT NOT NULL,
      previous_status TEXT,
      plan TEXT NOT NULL,
      start_date INTEGER NOT NULL,
      end_date INTEGER,
      trial_end_date INTEGER,
      grace_period_end INTEGER,
      max_devices INTEGER DEFAULT 1,
      registered_devices INTEGER DEFAULT 0,
      max_customers INTEGER,
      max_invoices INTEGER,
      max_storage INTEGER,
      auto_renew INTEGER DEFAULT 0,
      renewal_count INTEGER DEFAULT 0,
      price REAL DEFAULT 0,
      currency TEXT DEFAULT 'YER',
      discount REAL DEFAULT 0,
      tax REAL DEFAULT 0,
      total REAL DEFAULT 0,
      payment_method TEXT,
      payment_reference TEXT,
      payment_proof TEXT,
      verification_requested_at INTEGER,
      verification_approved_at INTEGER,
      verification_rejected_at INTEGER,
      cancelled_at INTEGER,
      cancellation_reason TEXT,
      refund_requested_at INTEGER,
      refund_status TEXT DEFAULT 'none',
      suspended_at INTEGER,
      suspension_reason TEXT,
      archived_at INTEGER,
      created_at INTEGER,
      updated_at INTEGER,
      FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE
    );
  `);
  console.log('✅ 22. subscriptions');
}

async function createTableNotifications(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT,
      type TEXT NOT NULL,
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      read INTEGER DEFAULT 0,
      action TEXT,
      action_data TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE
    );
  `);
  console.log('✅ 23. notifications');
}

async function createTableEmployees(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS employees (
      id TEXT PRIMARY KEY NOT NULL,
      user_id TEXT,
      code TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      phone TEXT,
      email TEXT,
      position TEXT,
      department TEXT,
      salary REAL DEFAULT 0,
      hire_date TEXT,
      account_id TEXT,
      is_active INTEGER DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE,
      FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE SET NULL
    );
  `);
  console.log('✅ 24. employees');
}

async function createTablePayroll(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS payroll (
      id TEXT PRIMARY KEY NOT NULL,
      user_id TEXT,
      employee_id TEXT NOT NULL,
      month TEXT NOT NULL,
      year TEXT NOT NULL,
      basic_salary REAL DEFAULT 0,
      allowances REAL DEFAULT 0,
      deductions REAL DEFAULT 0,
      net_salary REAL DEFAULT 0,
      status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'void')),
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE,
      FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
    );
  `);
  console.log('✅ 25. payroll');
}

async function createTableExpenses(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS expenses (
      id TEXT PRIMARY KEY NOT NULL,
      user_id TEXT,
      number TEXT NOT NULL UNIQUE,
      date TEXT NOT NULL DEFAULT (date('now')),
      account_id TEXT NOT NULL,
      amount REAL NOT NULL,
      category TEXT,
      description TEXT,
      payment_method TEXT CHECK (payment_method IN ('cash', 'bank', 'check')),
      cash_account_id TEXT,
      check_id TEXT,
      receipt_image TEXT,
      created_by TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE,
      FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE,
      FOREIGN KEY (cash_account_id) REFERENCES cash_accounts(id) ON DELETE SET NULL,
      FOREIGN KEY (check_id) REFERENCES checks(id) ON DELETE SET NULL
    );
  `);
  console.log('✅ 26. expenses');
}

async function createTableRevenues(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS revenues (
      id TEXT PRIMARY KEY NOT NULL,
      user_id TEXT,
      number TEXT NOT NULL UNIQUE,
      date TEXT NOT NULL DEFAULT (date('now')),
      account_id TEXT NOT NULL,
      amount REAL NOT NULL,
      source TEXT,
      description TEXT,
      payment_method TEXT CHECK (payment_method IN ('cash', 'bank', 'check')),
      cash_account_id TEXT,
      check_id TEXT,
      created_by TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE,
      FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE,
      FOREIGN KEY (cash_account_id) REFERENCES cash_accounts(id) ON DELETE SET NULL,
      FOREIGN KEY (check_id) REFERENCES checks(id) ON DELETE SET NULL
    );
  `);
  console.log('✅ 27. revenues');
}

async function createTableTransfers(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS transfers (
      id TEXT PRIMARY KEY NOT NULL,
      user_id TEXT,
      number TEXT NOT NULL UNIQUE,
      date TEXT NOT NULL DEFAULT (date('now')),
      from_account_id TEXT NOT NULL,
      to_account_id TEXT NOT NULL,
      amount REAL NOT NULL,
      currency TEXT DEFAULT 'YER',
      description TEXT,
      status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'void')),
      created_by TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE,
      FOREIGN KEY (from_account_id) REFERENCES cash_accounts(id) ON DELETE CASCADE,
      FOREIGN KEY (to_account_id) REFERENCES cash_accounts(id) ON DELETE CASCADE
    );
  `);
  console.log('✅ 28. transfers');
}

async function createTablePayments(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS payments (
      id TEXT PRIMARY KEY NOT NULL,
      user_id TEXT NOT NULL,
      number TEXT NOT NULL UNIQUE,
      date TEXT NOT NULL DEFAULT (date('now')),
      type TEXT NOT NULL CHECK (type IN ('customer', 'supplier', 'expense', 'salary')),
      customer_id TEXT,
      supplier_id TEXT,
      expense_id TEXT,
      employee_id TEXT,
      amount REAL NOT NULL,
      method TEXT CHECK (method IN ('cash', 'bank', 'check')),
      cash_account_id TEXT,
      check_id TEXT,
      description TEXT,
      status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'void')),
      created_by TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE,
      FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL,
      FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL,
      FOREIGN KEY (expense_id) REFERENCES expenses(id) ON DELETE SET NULL,
      FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE SET NULL,
      FOREIGN KEY (cash_account_id) REFERENCES cash_accounts(id) ON DELETE SET NULL,
      FOREIGN KEY (check_id) REFERENCES checks(id) ON DELETE SET NULL
    );
  `);
  console.log('✅ 29. payments');
}

async function createTableFixedAssets(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS fixed_assets (
      id TEXT PRIMARY KEY NOT NULL,
      user_id TEXT,
      code TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      category TEXT CHECK (category IN ('building', 'equipment', 'furniture', 'vehicle', 'machinery', 'other')),
      purchase_date TEXT,
      purchase_cost REAL NOT NULL,
      salvage_value REAL DEFAULT 0,
      useful_life INTEGER,
      depreciation_method TEXT DEFAULT 'straight_line' CHECK (depreciation_method IN ('straight_line', 'declining', 'units_of_production')),
      current_value REAL DEFAULT 0,
      accumulated_depreciation REAL DEFAULT 0,
      account_id TEXT,
      notes TEXT,
      is_active INTEGER DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE,
      FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE SET NULL
    );
  `);
  console.log('✅ 30. fixed_assets');
}

async function createTableAssetDepreciation(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS asset_depreciation (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      asset_id TEXT NOT NULL,
      period TEXT NOT NULL,
      amount REAL NOT NULL,
      accumulated REAL NOT NULL,
      created_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (asset_id) REFERENCES fixed_assets(id) ON DELETE CASCADE
    );
  `);
  console.log('✅ 31. asset_depreciation');
}

async function createTableBackupHistory(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS backup_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      filename TEXT NOT NULL,
      size INTEGER,
      type TEXT CHECK (type IN ('local', 'google_drive', 'cloud')),
      status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'success', 'failed')),
      notes TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    );
  `);
  console.log('✅ 32. backup_history');
}

async function createTableCurrencies(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS currencies (
      id TEXT PRIMARY KEY NOT NULL,
      code TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      symbol TEXT,
      exchange_rate REAL DEFAULT 1,
      is_base INTEGER DEFAULT 0,
      is_active INTEGER DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    );
  `);
  console.log('✅ 33. currencies');
}

async function createTableVatRates(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS vat_rates (
      id TEXT PRIMARY KEY NOT NULL,
      code TEXT NOT NULL UNIQUE,
      rate REAL NOT NULL,
      description TEXT,
      is_default INTEGER DEFAULT 0,
      is_active INTEGER DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    );
  `);
  console.log('✅ 34. vat_rates');
}

async function createTableDefaultAccounts(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS default_accounts (
      id TEXT PRIMARY KEY NOT NULL,
      key TEXT NOT NULL UNIQUE,
      account_id TEXT NOT NULL,
      description TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE
    );
  `);
  console.log('✅ 35. default_accounts');
}

async function createTableSystemUpdates(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS system_updates (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      version_code INTEGER NOT NULL,
      version_name TEXT NOT NULL,
      min_required_code INTEGER NOT NULL,
      update_url TEXT,
      severity TEXT DEFAULT 'low', -- low, high, critical
      release_notes TEXT,
      checksum TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    );
  `);
  console.log('✅ 36. system_updates');
}

async function createTableDevices(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS devices (
      id TEXT PRIMARY KEY NOT NULL,
      user_id TEXT NOT NULL,
      device_id TEXT NOT NULL,
      name TEXT,
      model TEXT,
      brand TEXT,
      os TEXT,
      last_seen TEXT DEFAULT (datetime('now')),
      status TEXT DEFAULT 'active',
      created_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE
    );
  `);
  console.log('✅ 37. devices');
}

async function createTableSubscriptionEventKeys(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS subscription_event_keys (
      idempotency_key TEXT PRIMARY KEY NOT NULL,
      subscription_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      FOREIGN KEY (subscription_id) REFERENCES subscriptions(id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE
    );
  `);
  console.log('✅ subscription_event_keys');
}

async function createTableReceipts(db) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS receipts (
      id TEXT PRIMARY KEY NOT NULL,
      user_id TEXT NOT NULL,
      subscription_id TEXT,
      transaction_number TEXT,
      image_url TEXT,
      bank_name TEXT,
      amount REAL DEFAULT 0,
      status TEXT DEFAULT 'pending',
      admin_notes TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE,
      FOREIGN KEY (subscription_id) REFERENCES subscriptions(id) ON DELETE SET NULL
    );
  `);
  console.log('✅ 38. receipts');
}

/**
 * دالة لتحديث الجداول القديمة بإضافة الأعمدة الجديدة (الارتباط العتادي)
 */
async function updateExistingTables(db) {
  try {
    // 1. تحديث جدول المستخدمين
    try {
      await db.execAsync("ALTER TABLE user ADD COLUMN trusted_device_id TEXT;");
      console.log('➕ تم إضافة عمود trusted_device_id لجدول user');
    } catch (e) { /* العمود موجود بالفعل */ }

    try {
      await db.execAsync("ALTER TABLE user ADD COLUMN device_metadata TEXT;");
      console.log('➕ تم إضافة عمود device_metadata لجدول user');
    } catch (e) { /* العمود موجود بالفعل */ }

    // 2. تحديث جدول الجلسات
    try {
      await db.execAsync("ALTER TABLE session ADD COLUMN hardware_signature TEXT;");
      console.log('➕ تم إضافة عمود hardware_signature لجدول session');
    } catch (e) { /* العمود موجود بالفعل */ }

    console.log('✅ [Migrations] اكتمل تحديث هيكلية الجداول');
  } catch (error) {
    console.log('⚠️ [Migrations] تنبيه في تحديث الهيكلية:', error.message);
  }
}

// =============================================
// 4. إضافة البيانات الافتراضية
// =============================================

async function seedDefaultData(db) {
  try {
    // إضافة مستويات العملاء
    const tiers = [
      { id: 'tier_basic', name: 'أساسي', level: 1, description: 'عميل عادي' },
      { id: 'tier_standard', name: 'فضي', level: 2, description: 'عميل مميز' },
      { id: 'tier_advanced', name: 'ذهبي', level: 3, description: 'عميل VIP' },
      { id: 'tier_enterprise', name: 'مؤسسة', level: 4, description: 'عميل شركة كبرى' },
    ];

    for (const tier of tiers) {
      try {
        const exists = await db.getFirstAsync('SELECT id FROM customer_tiers WHERE id = ?', [tier.id]);
        if (!exists) {
          await db.runAsync(
            `INSERT INTO customer_tiers (id, name, level, description) VALUES (?, ?, ?, ?)`,
            [tier.id, tier.name, tier.level, tier.description]
          );
          console.log(`✅ تم إضافة مستوى: ${tier.name}`);
        }
      } catch (error) {
        console.log(`⚠️ فشل إضافة مستوى ${tier.name}:`, error.message);
      }
    }

    // إضافة العملات الافتراضية
    const currencies = [
      { id: 'cur_yer', code: 'YER', name: 'ريال يمني', symbol: 'ريال', is_base: 1 },
      { id: 'cur_sar', code: 'SAR', name: 'ريال سعودي', symbol: 'ر.س', is_base: 0 },
      { id: 'cur_usd', code: 'USD', name: 'دولار أمريكي', symbol: '$', is_base: 0 },
    ];

    for (const cur of currencies) {
      try {
        const exists = await db.getFirstAsync('SELECT id FROM currencies WHERE code = ?', [cur.code]);
        if (!exists) {
          await db.runAsync(
            `INSERT INTO currencies (id, code, name, symbol, exchange_rate, is_base, is_active)
             VALUES (?, ?, ?, ?, 1, ?, 1)`,
            [cur.id, cur.code, cur.name, cur.symbol, cur.is_base]
          );
          console.log(`✅ تم إضافة عملة: ${cur.name}`);
        }
      } catch (error) {
        console.log(`⚠️ فشل إضافة عملة ${cur.code}:`, error.message);
      }
    }

    console.log('✅ [Migrations] تم إضافة البيانات الافتراضية');

    // إضافة إصدار النظام الأولي
    try {
      const exists = await db.getFirstAsync('SELECT id FROM system_updates WHERE version_code = 1');
      if (!exists) {
        await db.runAsync(
          `INSERT INTO system_updates (version_code, version_name, min_required_code, severity, release_notes)
           VALUES (1, '1.0.0', 1, 'low', 'الإصدار الأولي للسيادة الرقمية')`
        );
        console.log('✅ تم تسجيل إصدار النظام الأولي v1.0.0');
      }
    } catch (e) {
      console.log('⚠️ فشل تسجيل إصدار النظام:', e.message);
    }
  } catch (error) {
    console.log('⚠️ [Migrations] فشل إضافة البيانات الافتراضية:', error.message);
  }
}

// =============================================
// 5. الحصول على اتصال قاعدة البيانات
// =============================================

export function getDatabase() {
  if (!db) {
    throw new Error('⚠️ قاعدة البيانات غير مهيأة');
  }
  return db;
}